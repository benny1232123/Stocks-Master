"""推送多个文件（Git Database API）。用法: python _push_files.py <msg> <path1> <path2> ..."""
import base64
import hashlib
import json
import subprocess
import sys
from pathlib import Path

REPO = "benny1232123/Stocks-Master"
ROOT = Path(__file__).resolve().parents[1]
MSG = sys.argv[1]
PATHS = sys.argv[2:]


def gh(args, payload=None):
    cmd = ["gh", "api"] + args
    inp = None
    if payload is not None:
        cmd += ["--input", "-"]
        inp = json.dumps(payload)
    return subprocess.run(cmd, input=inp, capture_output=True, text=True, cwd=str(ROOT))


def jget(args):
    r = gh(args)
    if r.returncode != 0:
        print("FAIL read:", args, r.stderr.strip()[:300])
        sys.exit(1)
    return json.loads(r.stdout)


head = jget([f"repos/{REPO}/git/ref/heads/master"])["object"]["sha"]
base = jget([f"repos/{REPO}/git/commits/{head}"])["tree"]["sha"]
print("remote head:", head)

entries = []
for p in PATHS:
    text = (ROOT / p).read_text(encoding="utf-8")
    sha = json.loads(gh([f"repos/{REPO}/git/blobs", "--method", "POST"],
                        {"content": text, "encoding": "utf-8"}).stdout)["sha"]
    entries.append({"path": p, "mode": "100644", "type": "blob", "sha": sha})
    print("  blob", p)

tree = json.loads(gh([f"repos/{REPO}/git/trees", "--method", "POST"],
                     {"base_tree": base, "tree": entries}).stdout)["sha"]
commit = json.loads(gh([f"repos/{REPO}/git/commits", "--method", "POST"],
                       {"message": MSG, "tree": tree, "parents": [head]}).stdout)["sha"]
r = gh([f"repos/{REPO}/git/refs/heads/master", "--method", "PATCH"],
       {"sha": commit, "force": False})
if r.returncode != 0:
    print("FAIL ref:", r.stdout.strip()[:300])
    sys.exit(1)
print("PUSH_OK", commit)

for p in PATHS:
    r = gh([f"repos/{REPO}/contents/{p}"])
    remote = base64.b64decode(json.loads(r.stdout)["content"]).decode("utf-8")
    local = (ROOT / p).read_text(encoding="utf-8")
    print("MATCH" if remote == local else "DIFF ", p,
          hashlib.sha256(local.encode()).hexdigest()[:12])
