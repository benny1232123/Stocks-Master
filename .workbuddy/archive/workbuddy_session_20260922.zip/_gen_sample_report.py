"""生成「修复后」的持仓日报样例 HTML（纯本地、无网络），用于直观检查新区块。

新区块：⚖️ 仓位调整（目标由总仓位推导 + 超限只减到上限）、纯技术面标注、
⚖️ 仓位口径提示、⚠️ 数据滞后告警。
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from smcore.analysis import position_sizing_recommendation  # noqa: E402
from smcore.config.defaults import POSITION_SIZING_CONFIG  # noqa: E402
import scripts.notify_holdings_analysis as N  # noqa: E402

OUT = ROOT / ".workbuddy" / "holdings_sample_20260921.html"


def mk(code, close, qty, cost, name, strong=True, fund=None, bars=2):
    latest = {
        "close": close, "upper": close * 1.06, "lower": close * 0.94, "middle": close,
        "ma5": close * 1.01, "ma10": close * 1.02, "ma20": close * 1.03, "ma60": close * 0.98,
        "rsi": 42 if strong else 72, "dif": 1.2 if strong else -0.8,
        "dea": 0.6 if strong else -0.4, "macd_hist": 0.6 if strong else -0.4,
        "k_val": 55 if strong else 78, "d_val": 50 if strong else 70,
        "j_val": 65 if strong else 92,
    }
    metrics = {"signal_text": "布林中轨回踩买点", "dist_to_lower_pct": 2.1,
               "dist_to_upper_pct": -4.3, "bandwidth": 4.2}
    return {"code": code, "latest": latest, "metrics": metrics, "fundamentals": fund,
            "series": {"rows": [{"close": close * 0.99}, {"close": close}]},
            "_pos": {"name": name, "qty": qty, "cost": cost}}


FUND = {"pe": 9.2, "pb": 1.1, "roe": 0.14, "gross_margin": 0.42,
        "mkt_cap": 3200.0, "turnover": 2.4, "revenue_growth": 0.12}

STOCKS = [
    mk("600519", 1700.0, 100, 1600.0, "贵州茅台", strong=True, fund=None),   # 缺基本面
    mk("601318", 45.0, 2000, 50.0, "中国平安", strong=True, fund=FUND),
    mk("300750", 200.0, 500, 180.0, "宁德时代", strong=False, fund=FUND),
]

os.environ["ACCOUNT_CASH"] = "1000000"
holdings_value = sum(s["latest"]["close"] * s["_pos"]["qty"] for s in STOCKS)
# _account_cash 已更名为 _resolve_denominator（返回 分母/现金/口径来源）
total, cash, basis = N._resolve_denominator(holdings_value, POSITION_SIZING_CONFIG)
print(f"持仓市值 {holdings_value:,.0f} + 现金 {cash:,.0f} = 总资产 {total:,.0f}  [口径 {basis}]")

cards = []
for s in STOCKS:
    pos = s.pop("_pos")
    sizing = position_sizing_recommendation(
        s, pos, total, cfg=POSITION_SIZING_CONFIG, n_holdings=len(STOCKS)
    )
    cards.append(N.render_stock_html(s, pos, sizing))

summary = {"total_value": holdings_value, "total_cost": sum(
    s["series"]["rows"][-1]["close"] * 0 for s in STOCKS) or 353000.0,
    "today_pnl": 1200.0, "today_pnl_pct": 0.33}
summary["total_pnl"] = holdings_value - summary["total_cost"]
summary["total_pnl_pct"] = summary["total_pnl"] / summary["total_cost"] * 100

doc = N.build_html_report(
    "20260921", "样例（离线生成）", "成功 3 只 / 失败 0 只 / 共 3 只",
    "\n".join(cards),
    N.render_summary_html(summary, len(STOCKS), cash=cash, equity_total=total),
)
OUT.write_text(doc, encoding="utf-8")
print("样例已写出:", OUT)
