"""探针：实测 hithink 个股 K 端点的可用窗口 / 分片行为 / 吞吐，为全量重拉定参数。

结论将写入 .workbuddy/probe_hithink_klimits.json
"""
import json
import sys
import time
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(ROOT / ".env")

from smcore.data import hithink as hk  # noqa: E402

OUT = ROOT / ".workbuddy" / "probe_hithink_klimits.json"


def t_fetch(code, start, end, adjust):
    t0 = time.time()
    df = hk.fetch_historical_k(code, start, end, adjust)
    dt = time.time() - t0
    if df is None or df.empty:
        return {"n": 0, "sec": round(dt, 2), "min_close": None, "first": None, "last": None}
    df = df.dropna(subset=["close"])
    neg = int((df["close"] <= 0).sum())
    return {
        "n": int(len(df)),
        "sec": round(dt, 2),
        "neg": neg,
        "min_close": float(df["close"].min()),
        "first": str(df["date"].iloc[0]),
        "last": str(df["date"].iloc[-1]),
    }


def main():
    res = {"available": hk.available()}
    if not hk.available():
        OUT.write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
        print("no key")
        return

    today = date(2026, 9, 14)
    # A) 个股单次全区间（2015→今）
    res["A_single_2015_2026_qfq"] = t_fetch("000001", date(2015, 1, 5), today, "qfq")
    # B) 按不同长度切片的起点行为：固定终点=今天，起点逐年后移
    for yrs, tag in [(6, "B_6y"), (7, "B_7y"), (8, "B_8y"), (10, "B_10y"), (11, "B_11y")]:
        s = today - timedelta(days=int(365.25 * yrs))
        res[f"{tag}_qfq"] = t_fetch("000001", s, today, "qfq")
    # C) 分片拼接：2015-2019 / 2019-2023 / 2023-今（每片 ~4 年）
    for (a, b, tag) in [
        (date(2015, 1, 5), date(2019, 1, 5), "C_chunk1_2015_2019"),
        (date(2019, 1, 5), date(2023, 1, 5), "C_chunk2_2019_2023"),
        (date(2023, 1, 5), today, "C_chunk3_2023_now"),
    ]:
        res[tag] = t_fetch("000001", a, b, "qfq")
    # D) 负价样本：600519 / 000651 / 600036 的 qfq vs hfq（全区间）
    for code in ["600519", "000651", "600036"]:
        res[f"D_{code}_qfq"] = t_fetch(code, date(2015, 1, 5), today, "qfq")
        res[f"D_{code}_hfq"] = t_fetch(code, date(2015, 1, 5), today, "hfq")
    # E) 吞吐：连拉 8 只票各 5 年，测平均秒/请求
    codes = ["000002", "000063", "000333", "000538", "000568", "000625", "000651", "000725"]
    t0 = time.time()
    ok = 0
    for c in codes:
        d = t_fetch(c, today - timedelta(days=1826), today, "qfq")
        if d["n"] > 0:
            ok += 1
    res["E_throughput"] = {
        "stocks": len(codes), "ok": ok,
        "total_sec": round(time.time() - t0, 2),
        "sec_per_request": round((time.time() - t0) / len(codes), 3),
    }
    OUT.write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    print("done ->", OUT)


if __name__ == "__main__":
    main()
