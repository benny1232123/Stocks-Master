# -*- coding: utf-8 -*-
"""回测体检 ⑤：体重结论的稳健性 + 样本量功效（只读）。"""
import glob
import math
import re
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_bt_probe5_out.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


def safe_read(f):
    try:
        return pd.read_csv(f, dtype=str)
    except Exception:
        return None


frames = []
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv"))):
    d = safe_read(f)
    if d is None or d.empty or "return_pct" not in d.columns:
        continue
    for c in ("return_pct", "qty", "buy_price"):
        if c in d.columns:
            d[c] = pd.to_numeric(d[c], errors="coerce")
    d["_v"] = d["qty"] * d["buy_price"]
    d["_batch"] = re.search(r"(\d{8})", Path(f).name).group(1)
    frames.append(d)
T = pd.concat(frames, ignore_index=True)

p("=" * 92)
p("A) qty 结构：是「固定手数」还是「按权重定金额」？")
p("=" * 92)
p(f"  qty 取值分布（前 12）：{T['qty'].value_counts().head(12).to_dict()}")
p(f"  qty 唯一值个数 = {T['qty'].nunique()} / n={len(T)}")
p(f"  corr(qty, buy_price) = {T['qty'].corr(T['buy_price']):+.4f}")
p(f"  corr(qty*price, return) = {T['_v'].corr(T['return_pct']):+.4f}")
p(f"  仓位市值分位: p10={T['_v'].quantile(.1):,.0f} p50={T['_v'].quantile(.5):,.0f} "
  f"p90={T['_v'].quantile(.9):,.0f}")
p(f"  最大/最小 仓位市值 比值 = {T['_v'].max() / T['_v'].min():.1f}x")

p("")
p("=" * 92)
p("B) 「加权 vs 等权」的稳健性：逐批次配对检验")
p("=" * 92)
rows = []
for b, g in T.groupby("_batch"):
    if len(g) < 3:
        continue
    eq = g["return_pct"].mean()
    w = (g["return_pct"] * g["_v"]).sum() / g["_v"].sum()
    rows.append({"batch": b, "n": len(g), "eq": eq, "w": w, "diff": w - eq})
D = pd.DataFrame(rows)
p(D.round(3).to_string(index=False))
d = D["diff"]
n = len(d)
neg = int((d < 0).sum())
p("")
p(f"  批次数 n={n}   diff 均值={d.mean():+.3f}pp  标准差={d.std():.3f}pp")
se = d.std() / math.sqrt(n)
t = d.mean() / se if se else float("nan")
p(f"  配对 t = {t:+.2f}  (se={se:.3f})  → {'显著' if abs(t) > 2.1 else '边缘/不显著'}")
# 符号检验
from math import comb  # noqa: E402

pv = sum(comb(n, k) for k in range(neg, n + 1)) / (2 ** n)
p(f"  符号检验：{neg}/{n} 个批次 加权<等权，单尾 p={pv:.3f}")

p("")
p("=" * 92)
p("C) 样本量功效：这 120 笔到底能不能下结论？")
p("=" * 92)
r = T["return_pct"].dropna()
n = len(r)
sd = r.std()
se = sd / math.sqrt(n)
p(f"  笔均收益 = {r.mean():+.3f}%   std = {sd:.3f}%   n = {n}")
p(f"  笔均的 95% 置信区间 = [{r.mean() - 1.96 * se:+.3f}%, {r.mean() + 1.96 * se:+.3f}%]")
# 检验"是否有 edge"所需样本量（假设真实 edge = 1%/笔，σ=7%）
for edge in (1.0, 2.0, 3.0):
    need = int((1.96 * sd / edge) ** 2) + 1
    p(f"  若真实 edge={edge:.0f}%/笔，要在 95% 置信下检出需 ≈ {need} 笔"
      f"（现 {n} 笔 → 需再跑 ≈ {max(0, need - n)} 笔，约 {max(0, need - n)/7.5:.0f} 个信号日）")

p("")
p("=" * 92)
p("D) 出场结构：亏损是被什么吃掉的")
p("=" * 92)
if "exit_reason" in T.columns:
    g = T.groupby("exit_reason")["return_pct"].agg(
        n="count", mean="mean", total="sum")
    g["贡献_pct点"] = g["total"]
    p(g.sort_values("total").round(2).to_string())
    p("")
    p(f"  合计（Σ return_pct）= {T['return_pct'].sum():+.0f} 百分点")
    p(f"  仅 stop_hard 一项       = {g.loc['stop_hard', 'total']:+.0f} 百分点"
      if "stop_hard" in g.index else "")
    p(f"  仅 trend_break 一项      = {g.loc['trend_break', 'total']:+.0f} 百分点"
      if "trend_break" in g.index else "")
    pos_only = g[g["total"] > 0]["total"].sum()
    neg_only = g[g["total"] <= 0]["total"].sum()
    p(f"  所有盈利出场合计 = {pos_only:+.0f} 点；所有亏损出场合计 = {neg_only:+.0f} 点")

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
