# -*- coding: utf-8 -*-
"""长样本(60d) vs 试点(15d) mask A/B 对比报告。
从落盘 DAL 现算前向收益/配对 t/构成，输出 HTML。"""
import pathlib, glob, io, contextlib, time
import numpy as np
import pandas as pd

ROOT = pathlib.Path(r"E:\Stocks-Master")
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "mask_ab_60d_vs_15d_20260921.html"

# ── 行情日历（与驱动脚本同口径）──
_T0 = time.time()
parts = []
for f in sorted((SD / "k_data").glob("*.parquet")):
    d = pd.read_parquet(f, columns=["code", "date", "open", "close"])
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d[(d["date"] >= pd.Timestamp("2026-01-01")) & (d["date"] <= pd.Timestamp("2026-10-10"))]
    if not d.empty:
        parts.append(d)
K = pd.concat(parts, ignore_index=True)
K["code"] = K["code"].astype(str).str.zfill(6)
CAL = sorted(K["date"].dropna().unique())
IDX = {pd.Timestamp(d).strftime("%Y%m%d"): i for i, d in enumerate(CAL)}
OPENF = K.pivot_table(index="date", columns="code", values="open", aggfunc="last")
CLOSEF = K.pivot_table(index="date", columns="code", values="close", aggfunc="last")
print(f"[行情] {len(CAL)} 交易日  用时 {time.time()-_T0:.0f}s", flush=True)


def fwd(day, h, codes):
    ei = IDX.get(day)
    if ei is None or ei + 1 + h >= len(CAL):
        return pd.Series(dtype=float)
    o, c = OPENF.iloc[ei + 1], CLOSEF.iloc[ei + 1 + h]
    cc = [str(x).zfill(6) for x in codes]
    o, c = o.reindex(cc), c.reindex(cc)
    m = o.notna() & c.notna() & (o > 0)
    return ((c[m] / o[m] - 1) * 100).astype(float)


def mkt(day, h):
    ei = IDX.get(day)
    if ei is None or ei + 1 + h >= len(CAL):
        return None
    o, c = OPENF.iloc[ei + 1], CLOSEF.iloc[ei + 1 + h]
    m = o.notna() & c.notna() & (o > 0)
    return float(((c[m] / o[m] - 1) * 100).mean()) if m.any() else None


def load_dals(arm_dir):
    dfs = {}
    for f in sorted(glob.glob(str(arm_dir / "Daily-Action-List-*.csv"))):
        day = pathlib.Path(f).name[-12:-4]
        d = pd.read_csv(f, dtype=str)
        if d.empty:
            continue
        d["code"] = d["股票代码"].astype(str).str.zfill(6)
        dfs[day] = d
    return dfs


def summary(arm_dir):
    dfs = load_dals(arm_dir)
    res = {}
    for h in (1, 2, 3, 5):
        a_, e_ = [], []
        for day, df in dfs.items():
            r = fwd(day, h, list(df["code"]))
            mk = mkt(day, h)
            if r.empty or mk is None:
                continue
            a_.append(r.mean())
            e_.append(r.mean() - mk)
        res[h] = (a_, e_)
    return dfs, res


def paired(on_dir, off_dir):
    don, doff = load_dals(on_dir), load_dals(off_dir)
    rows = {h: [] for h in (1, 2, 3, 5)}
    for h in (1, 2, 3, 5):
        for day in sorted(don):
            if day not in doff:
                continue
            ra = fwd(day, h, list(don[day]["code"]))
            rb = fwd(day, h, list(doff[day]["code"]))
            if ra.empty or rb.empty:
                continue
            rows[h].append((day, ra.mean(), rb.mean(), rb.mean() - ra.mean()))
    out = {}
    for h, rs in rows.items():
        if not rs:
            out[h] = None
            continue
        D = pd.DataFrame(rs, columns=["day", "on", "off", "d"])
        t = D["d"].mean() / (D["d"].std() / np.sqrt(len(D))) if D["d"].std() else float("nan")
        out[h] = dict(n=len(D), mean=D["d"].mean(), med=D["d"].median(),
                      t=t, better=int((D["d"] > 0).sum()), worse=int((D["d"] < 0).sum()))
    return out


def composition(on_dir, off_dir):
    from collections import Counter
    don, doff = load_dals(on_dir), load_dals(off_dir)
    cn, cf = Counter(), Counter()
    for dfs, c in ((don, cn), (doff, cf)):
        for day, df in dfs.items():
            if "来源策略" in df.columns:
                for v in df["来源策略"].astype(str):
                    if "/" not in v:
                        c[v] += 1
    nd = max(len(don), 1)
    return {k: cn.get(k, 0) / nd for k in set(cn) | set(cf)}, \
           {k: cf.get(k, 0) / nd for k in set(cn) | set(cf)}


EDGE = {"Skew60": 6.70, "VRatio10_60": 4.76, "CVAmt60": 2.54, "VRatio20_120": 1.65,
        "Vol20": 0.82, "PVCorr20": 0.18, "DistLo10": -1.31, "Skew20": -1.72,
        "CVAmt20": -3.76, "PVCorr60": -10.72, "Illiq20": -9.90, "DistLo60": 0.0}

# ── 两个样本 ──
SAMPLES = {
    "15d": (ROOT / ".workbuddy" / "mask_ab", "试点(15 信号日)"),
    "60d": (ROOT / ".workbuddy" / "hist_ab", "长样本(60 信号日)"),
}
data = {}
for key, (base, label) in SAMPLES.items():
    on, ron = summary(base / "mask_on")
    off, roff = summary(base / "mask_off")
    pr = paired(base / "mask_on", base / "mask_off")
    comp_on, comp_off = composition(base / "mask_on", base / "mask_off")
    data[key] = dict(label=label, on=ron, off=roff, paired=pr,
                     comp_on=comp_on, comp_off=comp_off, n_on=len(on), n_off=len(off))

# ── 渲染 HTML ──
def fwd_rows(res, n):
    out = []
    for h in (1, 2, 3, 5):
        a, e = res[h]
        if not a:
            continue
        wr = 100 * np.mean([x > 0 for x in a])
        out.append(f"<tr><td>H={h}</td><td>{len(a)}</td><td class='num'>{np.mean(a):+.2f}</td>"
                   f"<td class='num'>{np.mean(e):+.2f}</td><td class='num'>{wr:.1f}</td></tr>")
    return "\n".join(out)


def paired_rows(pr):
    out = []
    for h in (1, 2, 3, 5):
        p = pr[h]
        if not p:
            continue
        cls = "pos" if p["mean"] > 0 else "neg"
        sig = "✔ 显著" if abs(p["t"]) >= 1.96 else ("△ 边际" if abs(p["t"]) >= 1.0 else "✗ 不显著")
        out.append(f"<tr><td>H={h}</td><td>{p['n']}</td>"
                   f"<td class='num {cls}'>{p['mean']:+.3f}</td>"
                   f"<td class='num {cls}'>{p['med']:+.3f}</td>"
                   f"<td class='num'>{p['t']:+.2f}</td>"
                   f"<td>{p['better']} / {p['worse']}</td><td>{sig}</td></tr>")
    return "\n".join(out)


def comp_rows(c_on, c_off):
    out = []
    keys = sorted(set(c_on) | set(c_off), key=lambda x: -EDGE.get(x, 0))
    for k in keys:
        a = c_on.get(k, 0)
        b = c_off.get(k, 0)
        mult = (b / a) if a else float("inf")
        mc = "pos" if b > a else ("neg" if b < a else "")
        out.append(f"<tr><td>{k}</td><td class='num'>{EDGE.get(k, float('nan')):+.2f}</td>"
                   f"<td class='num'>{a:.2f}</td><td class='num'>{b:.2f}</td>"
                   f"<td class='num {mc}'>{mult:.2f}</td></tr>")
    return "\n".join(out)


# 15d vs 60d 配对 t 对比
cmp_rows = []
for h in (1, 2, 3, 5):
    p15 = data["15d"]["paired"][h]
    p60 = data["60d"]["paired"][h]
    if not p15 or not p60:
        continue
    cmp_rows.append(
        f"<tr><td>H={h}</td>"
        f"<td class='num'>{p15['mean']:+.3f}</td><td class='num'>{p15['t']:+.2f}</td>"
        f"<td>{p15['better']}/{p15['worse']}</td>"
        f"<td class='num'>{p60['mean']:+.3f}</td><td class='num'>{p60['t']:+.2f}</td>"
        f"<td>{p60['better']}/{p60['worse']}</td></tr>")

HTML = f"""<!doctype html><html lang=zh><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>mask A/B：60d vs 15d</title>
<style>
*{{box-sizing:border-box}}
body{{font-family:-apple-system,'Segoe UI',Roboto,'PingFang SC','Microsoft YaHei',sans-serif;
background:#0f1115;color:#e6e8eb;margin:0;padding:32px;line-height:1.6}}
.wrap{{max-width:1080px;margin:0 auto}}
h1{{font-size:24px;margin:0 0 4px}}
.sub{{color:#8b929c;font-size:13px;margin-bottom:24px}}
.card{{background:#171a21;border:1px solid #262b35;border-radius:12px;padding:20px 22px;margin:18px 0}}
.card h2{{font-size:17px;margin:0 0 12px;color:#cdd3dc}}
table{{width:100%;border-collapse:collapse;font-size:13px;margin:8px 0}}
th,td{{padding:7px 10px;text-align:left;border-bottom:1px solid #232833}}
th{{color:#9aa3af;font-weight:600}}
td.num{{text-align:right;font-variant-numeric:tabular-nums}}
.pos{{color:#4ade80}}.neg{{color:#f87171}}
.tag{{display:inline-block;padding:2px 8px;border-radius:6px;font-size:12px;margin-left:8px}}
.tag.warn{{background:#3a2a12;color:#fbbf24}}.tag.bad{{background:#3a1518;color:#f87171}}
.tag.ok{{background:#14321f;color:#4ade80}}
.note{{background:#1d2230;border-left:3px solid #3b82f6;padding:10px 14px;border-radius:6px;
font-size:13px;color:#c4ccd6;margin:12px 0}}
.hl{{color:#fbbf24;font-weight:600}}
.kpis{{display:flex;gap:14px;flex-wrap:wrap;margin:10px 0}}
.kpi{{flex:1;min-width:150px;background:#11151c;border:1px solid #262b35;border-radius:10px;padding:14px}}
.kpi .v{{font-size:22px;font-weight:700}}
.kpi .l{{font-size:12px;color:#8b929c}}
</style></head><body><div class=wrap>
<h1>factor_timing mask 开关 A/B：长样本 vs 试点</h1>
<div class=sub>离线重跑融合链路（零联网）· 唯一变量 = adaptive_weights_config.json::factor_timing.enabled
· 生成于 2026-09-21 · 已落盘 {data['60d']['n_on']} 天 × 2 arm 因子池与 DAL</div>

<div class=note><b>一句话结论：</b>机制层 100% 确认是 bug（mask 把高 edge 因子清零、保留无证据/负 edge 因子）；
但<b>关掉它的前向收益改善很小、且统计不显著</b>——60 天样本下 H=1 配对 t 仅 +1.45，H≥2 全 &lt;1.1；
<b>拉长样本后改善幅度反而比 15 天试点更小</b>，说明 15 天那次高估了效果。</div>

<div class=card><h2>① 前向收益（DAL 等权 · 次日开盘买 → 持有 H 日收盘卖 · 超额 vs 全市场等权）</h2>
<div class=kpis>
<div class=kpi><div class=v>{data['60d']['off'][1][1] and np.mean(data['60d']['off'][1][1]):+.2f}pp</div>
<div class=l>60d · H=1 超额(mask_off)</div></div>
<div class=kpi><div class=v>{data['60d']['on'][1][1] and np.mean(data['60d']['on'][1][1]):+.2f}pp</div>
<div class=l>60d · H=1 超额(mask_on)</div></div>
<div class=kpi><div class=v>{data['60d']['paired'][1]['t']:+.2f}</div>
<div class=l>H=1 配对 t（n={data['60d']['paired'][1]['n']}）</div></div>
</div>
<h3 style="color:#9aa3af;font-size:14px">60 天样本</h3>
<table><tr><th>arm</th><th>H</th><th>天数</th><th>绝对均%</th><th>超额均%</th><th>胜率%</th></tr>
<tr><td rowspan=4>mask_on（生产）</td>{fwd_rows(data['60d']['on'],data['60d']['n_on']).replace('<tr>','</tr><tr>').replace('</tr><tr><td>H','<td>H')}</tr>
<tr><td rowspan=4>mask_off（关闭）</td>{fwd_rows(data['60d']['off'],data['60d']['n_off']).replace('<tr>','</tr><tr>').replace('</tr><tr><td>H','<td>H')}</tr>
</table>
<h3 style="color:#9aa3af;font-size:14px">15 天样本（试点，对照）</h3>
<table><tr><th>arm</th><th>H</th><th>天数</th><th>绝对均%</th><th>超额均%</th><th>胜率%</th></tr>
<tr><td rowspan=4>mask_on（生产）</td>{fwd_rows(data['15d']['on'],data['15d']['n_on']).replace('<tr>','</tr><tr>').replace('</tr><tr><td>H','<td>H')}</tr>
<tr><td rowspan=4>mask_off（关闭）</td>{fwd_rows(data['15d']['off'],data['15d']['n_off']).replace('<tr>','</tr><tr>').replace('</tr><tr><td>H','<td>H')}</tr>
</table>
</div>

<div class=card><h2>② 逐日配对（mask_off − mask_on）· 15d vs 60d 直接对比</h2>
<table><tr><th>H</th><th>15d Δ均值</th><th>15d t</th><th>15d 更好/更差</th>
<th>60d Δ均值</th><th>60d t</th><th>60d 更好/更差</th></tr>
{''.join(cmp_rows)}</table>
<div class=note><span class="tag warn">关键</span>拉长样本后：H=1 的 Δ 从 +0.081→+0.088（基本持平，t 0.71→1.45 因 n 增大）；
<b>但 H=2/3/5 的 Δ 从 +0.20/+0.18/+0.25 大幅缩水到 +0.08/+0.06/+0.08，t 从 1.6/1.5/1.5 跌到 1.1/0.6/0.7</b>。
即 15 天试点里「关掉 mask 明显变好」主要是一小撮高 Δ 日的巧合，长样本被稀释。</div>
</div>

<div class=card><h2>③ 构成对照（每日单策略命中数 / 天）+ 实测 edge</h2>
<h3 style="color:#9aa3af;font-size:14px">60 天样本</h3>
<table><tr><th>因子</th><th>实测 edge</th><th>mask_on/天</th><th>mask_off/天</th><th>倍数(off/on)</th></tr>
{comp_rows(data['60d']['comp_on'],data['60d']['comp_off'])}</table>
<div class=note><span class="tag ok">机制确证</span>关掉 mask 后：<b>Skew60 ×4.0、VRatio10_60 ×3.8</b>（最强正 edge 因子进 DAL 量大涨）；
<b>VRatio20_120 ×0.26、Skew20 ×0.42、CVAmt20 ×0.42</b>（负 edge 因子被压到 1/4~1/2）。
构成确实按 edge 方向重排——mask 是「惩罚好因子、保留坏因子」的自挫败回路，这条在 60 天样本依然成立。</div>
</div>

<div class=card><h2>④ 诚实的下一步</h2>
<table><tr><th>维度</th><th>发现</th><th>含义</th></tr>
<tr><td>机制</td><td class=pos>确证 bug</td><td>mask 判据在短窗口下方向反转，把高 edge 因子清零。与 edge 实测完全对得上。</td></tr>
<tr><td>前向 P&L</td><td class=neg>改善微弱且不显著</td><td>60d 下两 arm 超额全为负；关掉 mask 仅把 H=1 负超额从 −0.20 收窄到 −0.12，t=1.45 未过 2。整体仍是「少亏」而非「赚钱」。</td></tr>
<tr><td>样本稳健性</td><td class=neg>拉长反而变弱</td><td>15d 试点的高 Δ 是少数日的巧合；60d 显示真实效应很小。不能再拿 15d 当证据。</td></tr>
<tr><td>风险</td><td>关闭零下行</td><td>去掉一个已确认反向的层，方向为正、幅度小，不会更差。</td></tr>
</table>
<div class=note><b>推荐：</b>两件事不冲突——
<span class="tag ok">A. 先关</span>把 <code>factor_timing.enabled</code> 置 false（一行、零风险、方向为正，当作止损）；
<span class="tag warn">B. 再修</span>根因在 <code>factor_timing_mask_from_points</code> 的判据：把「IC 不显著→清零」改为「证据不足→保留；有证据且显著为负→清零」，
并给窗口点数加下限（现在 n=2~3 也在参与判定）。B 才是让这层「既能杀真死因子、又不误杀好因子」的正解。
两者都做完，再回填一次确认。</div>
</div>

<div class=card><h2>⑤ 性能与口径注记</h2>
<ul style="font-size:13px;color:#c4ccd6;margin:0;padding-left:18px">
<li><b>性能：</b>两 arm 都是 ~22s/信号日（60 天 ≈22min/arm）。瓶颈是 <code>compute_edge</code> 的因果分析<b>每个信号日按 as_of 重算</b>（与 mask 无关，两 arm 同速）。
本实验的 conviction_points 缓存对这个瓶颈无效——此前「mask_on 慢一个数量级」的判断需修正：那是 16 天样本的错觉，60 天两边一样慢。</li>
<li><b>口径：</b>历史回放时 <code>compute_edge</code> 用的是<b>当前</b>因果 edge（生产只跑今天），绝对值非当年真实复现；
但两 arm 同源同参，<b>差值仍然可比</b>。</li>
<li><b>落盘：</b>因子池 720 CSV 在 <code>.workbuddy/hist_pools/</code>，DAL 在 <code>.workbuddy/hist_ab/&lt;arm&gt;/</code>，均隔离、未写 stock_data/。</li>
</ul></div>
</div></body></html>"""

OUT.write_text(HTML, encoding="utf-8")
print("WROTE", OUT, len(HTML), "bytes")
