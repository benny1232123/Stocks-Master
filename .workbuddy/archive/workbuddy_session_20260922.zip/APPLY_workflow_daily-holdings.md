# 待应用：daily-holdings.yml 的 CI 硬化步骤（可选项）

## 为什么没自动推上去

本机 / 沙箱的 `gh` 令牌 scope = `gist, read:org, repo`，**缺 `workflow`**。
GitHub 会拒绝任何把 `.github/workflows/*` 写进 tree/内容 的请求，并且是用
**404 Not Found** 掩盖（不是 403）。已二分确认：同一 payload 去掉这个文件就成功、
只放这一个 entry 就 404。Contents API `PUT` 也一样 404。

**这不影响本次修复生效** —— 「K 线新鲜度」与「基本面回填」两个守卫已内建到
`scripts/notify_holdings_analysis.py` 自身（`_refresh_klines` / `_refresh_fundamentals`），
CI 现有 workflow 无需任何改动即可生效。下面这些 step 只是**可选硬化**：把网络操作
从「报告步骤内」提到「报告步骤前」，让耗时与失败在 Actions 页面上更可见。

## 方式一：给令牌补 scope（推荐，之后可自动推）

```bash
gh auth refresh -h github.com -s workflow
```
（会开浏览器做交互授权；完成后告诉我，我把改动推上去。）

## 方式二：GitHub 网页手动粘贴

编辑 `https://github.com/benny1232123/Stocks-Master/blob/master/.github/workflows/daily-holdings.yml`，
在 `- name: 安装依赖` 这一步之后、
`- name: 生成持仓个股分析并推送` 之前，插入：

```yaml
      - name: 数据新鲜度硬校验（信号日 bar 必须存在，防止用 D-1 数据出当日信号）
        if: steps.gate.outputs.ok == 'true'
        timeout-minutes: 5
        env:
          KLINE_BACKEND: hithink
          HITHINK_FINANCE_API_KEY: ${{ secrets.HITHINK_FINANCE_API_KEY }}
          ALLOW_STALE_DATA: ${{ vars.ALLOW_STALE_DATA }}
        run: |
          python scripts/verify_data_freshness.py --signal-date ${{ steps.gate.outputs.today }}

      - name: 持仓 K 线定向刷新 + 新鲜度复核
        if: steps.gate.outputs.ok == 'true'
        timeout-minutes: 15
        env:
          TODAY: ${{ steps.gate.outputs.today }}
          KLINE_BACKEND: hithink
          HITHINK_FINANCE_API_KEY: ${{ secrets.HITHINK_FINANCE_API_KEY }}
          SUPABASE_URL: ${{ secrets.SUPABASE_URL }}
          SUPABASE_KEY: ${{ secrets.SUPABASE_KEY }}
          TRADES_BACKEND: auto
          ALLOW_STALE_DATA: ${{ vars.ALLOW_STALE_DATA }}
        run: |
          if [ "${ALLOW_STALE_DATA}" = "1" ]; then
            echo "ALLOW_STALE_DATA=1 → 跳过定向刷新（手动补跑/非交易日）"
          else
            python scripts/prepull_klines.py --date "${TODAY}" --from-holdings
          fi

      - name: 持仓基本面缓存刷新（best-effort，失败不阻塞日报）
        if: steps.gate.outputs.ok == 'true'
        continue-on-error: true
        timeout-minutes: 10
        env:
          SUPABASE_URL: ${{ secrets.SUPABASE_URL }}
          SUPABASE_KEY: ${{ secrets.SUPABASE_KEY }}
          TRADES_BACKEND: auto
          HITHINK_FINANCE_API_KEY: ${{ secrets.HITHINK_FINANCE_API_KEY }}
        run: |
          python scripts/refresh_fundamentals.py --from-holdings
```

本地文件已经是这个状态（`.github/workflows/daily-holdings.yml`），已通过 `yaml.safe_load` 校验。

## 顺带说明：几个开关

| 环境变量 | 默认 | 作用 |
|---|---|---|
| `HOLDINGS_FUND_REFRESH` | `1` | 报告前只回填**缺失**的持仓基本面缓存（已缓存不重复联网）。设 `0` 走纯离线确定模式。 |
| `ACCOUNT_TOTAL` | 配置里已设 `30000` | 账户总资产（= 持仓市值 + 现金）→ 直接作「仓位调整」分母。 |
| `ACCOUNT_CASH` | 未设 | 或只给可用现金 → 分母 = 持仓市值 + 现金。**env 优先于配置**。 |
| `ACCOUNT_BASIS` | 未设 | 设 `holdings` = 忽略账户口径、强制纯持仓分母（补跑 / 口径对照）。 |
| `ALLOW_STALE_DATA` | 未设 | `1` = 跳过 K 线定向刷新与新鲜度复核（补跑历史日 / 非交易日）。 |
