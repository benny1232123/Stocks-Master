# -*- coding: utf-8 -*-
"""为仓位层引入 target_equity_ratio 模型 + 超限只减到上限。所有替换断言命中恰好 1 次。"""
import pathlib
import sys

ROOT = pathlib.Path(r"E:\Stocks-Master")


def patch(rel, old, new):
    p = ROOT / rel
    text = p.read_text(encoding="utf-8")
    cnt = text.count(old)
    if cnt != 1:
        print(f"!! {rel}: 期望命中 1 次，实际 {cnt} 次 -- 中止")
        sys.exit(1)
    p.write_text(text.replace(old, new), encoding="utf-8")
    print(f"OK  {rel}  (1 处)")


# ==================== defaults.py ====================
patch(
    "smcore/config/defaults.py",
    '''# 设计原则（符合"权重/阈值集中配置、禁散落魔数"）：
#  - 单票目标权重 target_weight_pct：组合层"等权偏中枢"默认目标，per_code_targets 可逐票覆盖。
#  - hard_cap_pct：单票硬上限，超过此权重**无论研判如何**都强制减仓（与 MAX_SINGLE_WEIGHT_PCT 同口径）。
#  - add/reduce_band_pct：当前权重相对目标偏离超过 ±band 才触发"候选加仓/减仓"。''',
    '''# 设计原则（符合"权重/阈值集中配置、禁散落魔数"）：
#  - 单票目标权重（三口径，优先级从高到低）：
#      ① per_code_targets[code]    —— 逐票显式覆盖（%）
#      ② target_equity_ratio ÷ N   —— 总仓位目标均分到 N 只（**推荐**，与持有只数解耦）
#      ③ target_weight_pct         —— 固定每票权重（%）：隐含"总仓位 = 8% × N"，
#                                     N 一变全表结论就变 <- 2026-09-21 全表减仓的根因
#  - 单票硬上限：显式 hard_cap_pct 优先；否则 = 每票目标 × hard_cap_multiple（以
#    hard_cap_ceiling_pct 封顶）。**必须 > 目标**，否则"目标本身就越线"、报告永远要求减仓；
#    倍数化后 cap 随持有只数自适应，任何 N 都自洽。
#    ⚠️ 超限时只减到「上限」而非一步减到政策目标（削掉超限部分即可，避免过度交易）。
#  - add/reduce_band_pct：当前权重相对目标偏离超过 ±band 才触发"候选加仓/减仓"。''',
)

patch(
    "smcore/config/defaults.py",
    '''    "target_weight_pct": 8.0,           # 单票目标权重（%）
    "hard_cap_pct": 15.0,               # 单票硬上限（%），超过强制减仓''',
    '''    # ── 单票目标权重：优先级 per_code_targets > target_equity_ratio > target_weight_pct ──
    "target_equity_ratio": 0.70,        # ① 总仓位目标(0~1) ÷ 持有只数 = 每票目标。推荐：与只数解耦。
                                        #    现持 4 只 → 17.5%/只；加到 6 只自动变 11.7%，无需改配置。
    "target_weight_pct": 8.0,           # ③ 固定每票目标(%)：仅当 target_equity_ratio=None 时生效
    # ── 单票硬上限：显式 hard_cap_pct 优先；否则 = 每票目标 × multiple，以 ceiling 封顶 ──
    "hard_cap_pct": None,               # 显式绝对上限(%)；None = 按下面两项推导（推荐 None）
    "hard_cap_multiple": 1.5,           # 推导口径：上限 = 每票目标 × 1.5（4 只时 = 26.25%）
    "hard_cap_ceiling_pct": 35.0,       # 绝对天花板：任何只数下单票都不得超此权重''',
)

# ==================== analysis.py ====================
patch(
    "smcore/analysis.py",
    '''def position_sizing_recommendation(
    analysis: dict, pos: dict | None, portfolio_value: float, cfg: dict | None = None
) -> dict[str, object]:''',
    '''def _resolve_target_weight(
    code: str, cfg: dict, n_holdings: int | None
) -> tuple[float, str]:
    """解析单票目标权重（%），返回 ``(目标, 口径来源)``。

    优先级：
    1. ``per_code_targets[code]`` —— 逐票显式指定（压过全局口径）。
    2. ``target_equity_ratio`` ÷ 持有只数 —— **推荐**：表达「想投多少、均分到 N 只」，
       与只数解耦；N 变化时结论自动跟随。
    3. ``target_weight_pct`` —— 旧口径：固定每票权重，隐含「总仓位 = 8% × N」，
       N 一变全表结论就变（2026-09-21 全表减仓的根因）。

    口径来源（``per_code`` / ``equity_ratio`` / ``fixed_pct``）随结果返回，供报告/前端标注。
    """
    per = cfg.get("per_code_targets") or {}
    if code in per:
        return float(per[code]), "per_code"
    ratio = cfg.get("target_equity_ratio")
    if ratio is not None and n_holdings:
        try:
            r = float(ratio)
            n = int(n_holdings)
        except (TypeError, ValueError):
            r, n = 0.0, 0
        if r > 0 and n > 0:
            return r * 100.0 / n, "equity_ratio"
    return float(cfg.get("target_weight_pct", 8.0)), "fixed_pct"


def _resolve_hard_cap(cfg: dict, target_w: float) -> float:
    """解析单票硬上限（%）。

    显式 ``hard_cap_pct`` 优先（显式即绝对，尊重调用方）；否则按 ``目标 ×
    hard_cap_multiple`` 推导，并以 ``hard_cap_ceiling_pct`` 封顶。

    为什么按目标倍数推导：固定上限与「按总仓位推导的目标」会互相矛盾 ——
    例如 2 只票、总仓位 70% → 每票目标 35%；若上限仍写 15%，目标本身就越线、
    报告会永远要求减仓。倍数化后 cap 随持有只数自适应，任何 N 都自洽。
    推导口径下再取 ``max(…, target_w)``：上限绝不低于目标本身（ceiling 低于目标时兜底）。
    """
    explicit = cfg.get("hard_cap_pct")
    if explicit is not None:
        return float(explicit)
    mult = float(cfg.get("hard_cap_multiple", 1.5))
    ceiling = float(cfg.get("hard_cap_ceiling_pct", 35.0))
    return max(min(target_w * mult, ceiling), target_w)


def position_sizing_recommendation(
    analysis: dict,
    pos: dict | None,
    portfolio_value: float,
    cfg: dict | None = None,
    n_holdings: int | None = None,
) -> dict[str, object]:''',
)

patch(
    "smcore/analysis.py",
    '''    - portfolio_value: 组合市值分母（建议传 build_portfolio_summary.total_value）
    - cfg: POSITION_SIZING_CONFIG（可覆盖）

    输出（口径全部 %/元/股，前端/报告直接展示）：
    - action: 加仓 / 持有偏多 / 持有观望 / 减仓偏空 / 减仓
    - current_weight / target_weight / delta_weight (%)
    - delta_value (元，正=应加钱 / 负=应减钱)
    - delta_qty (股，正=买 / 负=卖，已取整到一手)
    - reason: 自然语言理由
    - rating / score / faces: 复用 recommendation_from_analysis 的健康研判（仅展示，不参与 delta 决策）

    决策：
    1. current_weight > hard_cap → 强制「减仓」（超单票硬上限，无论研判）。''',
    '''    - portfolio_value: 组合市值分母（建议传 build_portfolio_summary.total_value）
    - cfg: POSITION_SIZING_CONFIG（可覆盖）
    - n_holdings: 当前**持有只数** N。仅 ``target_equity_ratio`` 口径需要
      （每票目标 = 总仓位目标 ÷ N）；缺省 None 时退化为固定 ``target_weight_pct`` 口径。

    输出（口径全部 %/元/股，前端/报告直接展示）：
    - action: 加仓 / 持有偏多 / 持有观望 / 减仓偏空 / 减仓
    - current_weight / target_weight / delta_weight (%)
      target_weight = **政策目标**；delta_weight 是相对 ``aim_weight`` 的偏离
    - aim_weight: 本次动作实际要到达的权重。正常 = target_weight；
      **超硬上限时 = hard_cap_weight**（只削超限部分，不一步砍到政策目标）
    - capped_trim: 是否因超硬上限而"只减到上限"
    - cap_below_target: 配置自相矛盾告警（显式硬上限 < 政策目标 → 目标本身就越线）
    - hard_cap_weight: 本次生效的单票硬上限（%）
    - target_source: 政策目标来自哪个口径（per_code / equity_ratio / fixed_pct）
    - delta_value (元，正=应加钱 / 负=应减钱)
    - delta_qty (股，正=买 / 负=卖，已取整到一手)
    - reason: 自然语言理由
    - rating / score / faces: 复用 recommendation_from_analysis 的健康研判（仅展示，不参与 delta 决策）

    决策：
    0. 先解析政策目标 target_w（_resolve_target_weight）与单票硬上限 hard_cap（_resolve_hard_cap）。
    1. current_weight > hard_cap → 强制「减仓」，且**只减到上限**（aim_weight = hard_cap）。''',
)

patch(
    "smcore/analysis.py",
    '''        return {
            "action": "未知", "current_weight": None, "target_weight": None,
            "delta_weight": None, "delta_value": None, "delta_qty": None,
            "reason": "缺少最新价或组合市值，无法测算仓位",
            "rating": rating, "score": score, "faces": faces,
        }''',
    '''        return {
            "action": "未知", "current_weight": None, "target_weight": None,
            "aim_weight": None, "capped_trim": False, "cap_below_target": False,
            "target_source": None, "hard_cap_weight": None,
            "delta_weight": None, "delta_value": None, "delta_qty": None,
            "reason": "缺少最新价或组合市值，无法测算仓位",
            "rating": rating, "score": score, "faces": faces,
        }''',
)

patch(
    "smcore/analysis.py",
    '''    target_w = float(cfg.get("target_weight_pct", 8.0))
    per = cfg.get("per_code_targets") or {}
    if code in per:
        target_w = float(per[code])
    hard_cap = float(cfg.get("hard_cap_pct", 15.0))
    add_band = float(cfg.get("add_band_pct", 2.0))''',
    '''    # 政策目标权重：per_code_targets > target_equity_ratio/N > target_weight_pct
    target_w, target_src = _resolve_target_weight(code, cfg, n_holdings)
    # 单票硬上限：显式 hard_cap_pct 优先；否则 = 目标 × multiple（以 ceiling 封顶）
    hard_cap = _resolve_hard_cap(cfg, target_w)
    cap_below_target = hard_cap < target_w
    add_band = float(cfg.get("add_band_pct", 2.0))''',
)

patch(
    "smcore/analysis.py",
    '''    current_value = float(close) * qty
    current_w = current_value / float(portfolio_value) * 100.0
    delta_w = target_w - current_w''',
    '''    current_value = float(close) * qty
    current_w = current_value / float(portfolio_value) * 100.0
    # 超硬上限 → 只减到「上限」而非一步减到政策目标（削掉超限部分即可，避免过度交易）
    capped_trim = current_w > hard_cap
    aim_w = hard_cap if capped_trim else target_w
    delta_w = aim_w - current_w''',
)

patch(
    "smcore/analysis.py",
    '''    if current_w > hard_cap:
        action = "减仓"
        reason = (
            f"当前权重 {current_w:.1f}% 已超单票硬上限 {hard_cap:.0f}%，"
            f"须降至上限内；研判「{rating}」"
        )''',
    '''    if capped_trim:
        action = "减仓"
        reason = (
            f"当前权重 {current_w:.1f}% 已超单票硬上限 {hard_cap:.1f}%，先减至上限内"
            f"（政策目标 {target_w:.1f}%）；研判「{rating}」"
        )''',
)

patch(
    "smcore/analysis.py",
    '''    return {
        "action": action,
        "current_weight": round(current_w, 2),
        "target_weight": round(target_w, 2),
        "delta_weight": round(delta_w, 2),
        "delta_value": round(delta_value, 2),
        "delta_qty": delta_qty,
        "reason": reason,
        "rating": rating,
        "score": score,
        "faces": faces,
    }''',
    '''    return {
        "action": action,
        "current_weight": round(current_w, 2),
        "target_weight": round(target_w, 2),
        "aim_weight": round(aim_w, 2),
        "capped_trim": capped_trim,
        "cap_below_target": cap_below_target,
        "hard_cap_weight": round(hard_cap, 2),
        "target_source": target_src,
        "delta_weight": round(delta_w, 2),
        "delta_value": round(delta_value, 2),
        "delta_qty": delta_qty,
        "reason": reason,
        "rating": rating,
        "score": score,
        "faces": faces,
    }''',
)

# ==================== notify_holdings_analysis.py ====================
patch(
    "scripts/notify_holdings_analysis.py",
    '''        sections: list[str] = []
        sections_html: list[str] = []
        tech_only = 0''',
    '''        sections: list[str] = []
        sections_html: list[str] = []
        tech_only = 0
        sizing_probe: dict | None = None   # 取首只成功票的 sizing，用于日志展示目标口径''',
)

patch(
    "scripts/notify_holdings_analysis.py",
    '''            # 仓位调整：用组合总资产分母算 (target − current) 的 delta
            sizing = position_sizing_recommendation(
                analysis, pos, portfolio_value, cfg=POSITION_SIZING_CONFIG
            )''',
    '''            # 仓位调整：用组合总资产分母算 (target − current) 的 delta。
            # n_holdings=len(codes)：target_equity_ratio 口径下「每票目标 = 总仓位目标 ÷ N」，
            # 故必须把持有只数传进去（注意分母=组合总资产、N=持有只数，两者口径不同，别混）。
            sizing = position_sizing_recommendation(
                analysis, pos, portfolio_value, cfg=POSITION_SIZING_CONFIG,
                n_holdings=len(codes),
            )
            if sizing_probe is None:
                sizing_probe = sizing''',
)

patch(
    "scripts/notify_holdings_analysis.py",
    '''        if tech_only:
            log_lines.append(
                f"⚠️ {tech_only}/{ok} 只缺基本面数据 → 综合分退化为纯技术面（报告内已标注「纯技术面」）"
            )''',
    '''        if sizing_probe:
            log_lines.append(
                f"目标权重口径[{sizing_probe.get('target_source')}]：每票目标 "
                f"{sizing_probe.get('target_weight')}%、单票硬上限 "
                f"{sizing_probe.get('hard_cap_weight')}%"
                + ("（⚠️ 硬上限 < 目标：配置自相矛盾，目标本身就越线）"
                   if sizing_probe.get("cap_below_target") else "")
            )
        if tech_only:
            log_lines.append(
                f"⚠️ {tech_only}/{ok} 只缺基本面数据 → 综合分退化为纯技术面（报告内已标注「纯技术面」）"
            )''',
)

patch(
    "scripts/notify_holdings_analysis.py",
    '''        _cw = sizing.get("current_weight")
        _tw = sizing.get("target_weight")
        _dw = sizing.get("delta_weight")
        _dv = sizing.get("delta_value")
        _dq = sizing.get("delta_qty")
        _cw_s = f"{_cw:.1f}%" if _cw is not None else "—"
        _tw_s = f"{_tw:.1f}%" if _tw is not None else "—"
        _dw_s = f"{_dw:+.1f}%" if _dw is not None else "—"
        _dv_s = f"{'+' if _dv >= 0 else ''}{fmt_money(_dv)}" if _dv is not None else "—"
        _dq_s = f"{'+' if _dq >= 0 else ''}{_dq}" if _dq is not None else "—"
        lines.append(
            f"- **⚖️ 仓位调整**：{sizing.get('action')}（当前 {_cw_s} → 目标 {_tw_s}，"
            f"Δ {_dw_s}；建议 {_dv_s} / {_dq_s} 股）— {sizing.get('reason')}"
        )''',
    '''        _cw = sizing.get("current_weight")
        _tw = sizing.get("target_weight")
        _aim = sizing.get("aim_weight")
        _dw = sizing.get("delta_weight")
        _dv = sizing.get("delta_value")
        _dq = sizing.get("delta_qty")
        _capped = bool(sizing.get("capped_trim"))
        _cw_s = f"{_cw:.1f}%" if _cw is not None else "—"
        _tw_s = f"{_tw:.1f}%" if _tw is not None else "—"
        # 超限时 aim=上限（只削超限部分）；否则 aim=政策目标
        _aim_s = f"{_aim:.1f}%" if _aim is not None else _tw_s
        _head = f"当前 {_cw_s} → {'上限' if _capped else '目标'} {_aim_s}"
        _tw_note = f"，政策目标 {_tw_s}" if _capped and _tw is not None else ""
        _dw_s = f"{_dw:+.1f}%" if _dw is not None else "—"
        _dv_s = f"{'+' if _dv >= 0 else ''}{fmt_money(_dv)}" if _dv is not None else "—"
        _dq_s = f"{'+' if _dq >= 0 else ''}{_dq}" if _dq is not None else "—"
        lines.append(
            f"- **⚖️ 仓位调整**：{sizing.get('action')}（{_head}，Δ {_dw_s}{_tw_note}；"
            f"建议 {_dv_s} / {_dq_s} 股）— {sizing.get('reason')}"
        )''',
)

patch(
    "scripts/notify_holdings_analysis.py",
    '''        _cw = sizing.get("current_weight")
        _tw = sizing.get("target_weight")
        _dw = sizing.get("delta_weight")
        _dv = sizing.get("delta_value")
        _dq = sizing.get("delta_qty")
        _cw_s = f"{_cw:.1f}%" if _cw is not None else "—"
        _tw_s = f"{_tw:.1f}%" if _tw is not None else "—"
        _dw_s = f"{_dw:+.1f}%" if _dw is not None else "—"
        _dv_s = f"{'+' if _dv >= 0 else ''}{fmt_money(_dv)}" if _dv is not None else "—"
        _dq_s = f"{'+' if _dq >= 0 else ''}{_dq}" if _dq is not None else "—"
        _saction = html_escape_mod.escape(str(sizing.get("action") or ""))
        _sreason = html_escape_mod.escape(str(sizing.get("reason") or ""))
        sizing_html = (
            f'<div class="rec {_scls}">⚖️ 仓位调整：{_saction}'
            f'　｜　当前 {_cw_s} → 目标 {_tw_s}（Δ {_dw_s}）'
            f'　｜　建议 {_dv_s} / {_dq_s} 股'
            f'<br><span style="font-weight:400;font-size:12px">'
            f'📋 {_sreason}（与上方「股票研判」并列：研判=票本身强弱，本栏=相对目标的仓位 delta）</span></div>'
        )''',
    '''        _cw = sizing.get("current_weight")
        _tw = sizing.get("target_weight")
        _aim = sizing.get("aim_weight")
        _dw = sizing.get("delta_weight")
        _dv = sizing.get("delta_value")
        _dq = sizing.get("delta_qty")
        _capped = bool(sizing.get("capped_trim"))
        _cw_s = f"{_cw:.1f}%" if _cw is not None else "—"
        _tw_s = f"{_tw:.1f}%" if _tw is not None else "—"
        # 超限时 aim=上限（只削超限部分）；否则 aim=政策目标
        _aim_s = f"{_aim:.1f}%" if _aim is not None else _tw_s
        _head = f"当前 {_cw_s} → {'上限' if _capped else '目标'} {_aim_s}"
        _tw_note = f"　｜　政策目标 {_tw_s}" if _capped and _tw is not None else ""
        _dw_s = f"{_dw:+.1f}%" if _dw is not None else "—"
        _dv_s = f"{'+' if _dv >= 0 else ''}{fmt_money(_dv)}" if _dv is not None else "—"
        _dq_s = f"{'+' if _dq >= 0 else ''}{_dq}" if _dq is not None else "—"
        _saction = html_escape_mod.escape(str(sizing.get("action") or ""))
        _sreason = html_escape_mod.escape(str(sizing.get("reason") or ""))
        sizing_html = (
            f'<div class="rec {_scls}">⚖️ 仓位调整：{_saction}'
            f'　｜　{_head}（Δ {_dw_s}）{_tw_note}'
            f'　｜　建议 {_dv_s} / {_dq_s} 股'
            f'<br><span style="font-weight:400;font-size:12px">'
            f'📋 {_sreason}（与上方「股票研判」并列：研判=票本身强弱，本栏=相对目标的仓位 delta）</span></div>'
        )''',
)

print("\n全部替换完成。")
