import json
from pathlib import Path

ROOT = Path(r"E:\Stocks-Master")
tags = ["20260827","20260828","20260831","20260901","20260902","20260903",
        "20260904","20260907","20260908","20260909","20260910","20260911",
        "20260914","20260915","20260916","20260917"]
out = []
for t in tags:
    fj = ROOT / ".workbuddy" / "fuse_results" / f"{t}.json"
    st = "MISSING"
    if fj.exists():
        st = json.loads(fj.read_text(encoding="utf-8")).get("status")
    dal = ROOT / "stock_data" / f"Daily-Action-List-{t}.csv"
    rows = 0
    if dal.exists():
        lines = [l for l in dal.read_text(encoding="utf-8").splitlines() if l.strip()]
        rows = max(0, len(lines) - 1)
    out.append(f"{t}: fuse={st} dal_rows={rows}")
Path(r"E:\Stocks-Master\.workbuddy\_check_fusion_out.txt").write_text(
    "\n".join(out), encoding="utf-8")
