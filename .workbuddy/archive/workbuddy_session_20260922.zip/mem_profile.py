"""Render 内存画像：测量导入链路各级 RSS 占用 + tracemalloc 前 25 大分配点。"""
from __future__ import annotations

import os
import sys
import tracemalloc

sys.path.insert(0, r"E:\Stocks-Master")
os.environ.setdefault("KLINE_BACKEND", "akshare")
os.environ.setdefault("RENDER_LITE", "1")


def rss_mb() -> float:
    try:
        import psutil  # type: ignore

        return psutil.Process().memory_info().rss / 1024 / 1024
    except Exception:
        pass
    # 无 psutil 时退化为 Windows API
    try:
        import ctypes
        from ctypes import wintypes

        class PMC(ctypes.Structure):
            _fields_ = [
                ("cb", wintypes.DWORD),
                ("PageFaultCount", wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t),
                ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t),
                ("PeakPagefileUsage", ctypes.c_size_t),
            ]

        c = PMC()
        c.cb = ctypes.sizeof(PMC)
        ctypes.windll.psapi.GetProcessMemoryInfo(
            ctypes.windll.kernel32.GetCurrentProcess(), ctypes.byref(c), c.cb
        )
        return c.WorkingSetSize / 1024 / 1024
    except Exception:
        return -1.0


tracemalloc.start(15)
base = rss_mb()
print(f"[base]                     {base:8.1f} MB")

STEPS = [
    ("pandas", "import pandas"),
    ("numpy", "import numpy"),
    ("pyarrow", "import pyarrow"),
    ("akshare", "import akshare"),
    ("baostock", "import baostock"),
    ("backtrader", "import backtrader"),
    ("jieba", "import jieba"),
    ("matplotlib", "import matplotlib"),
    ("supabase", "import supabase"),
    ("fastapi", "import fastapi, uvicorn"),
]

prev = base
for label, stmt in STEPS:
    try:
        exec(stmt, {})
    except Exception as exc:  # noqa: BLE001
        print(f"[{label:24}] SKIP ({type(exc).__name__})")
        continue
    cur = rss_mb()
    print(f"[{label:24}] {cur:8.1f} MB   (+{cur - prev:6.1f})")
    prev = cur

# 完整应用导入（这才是 Render 启动后的真实基线）
try:
    from backend.main import app  # noqa: F401

    cur = rss_mb()
    print(f"[backend.main (full app)]  {cur:8.1f} MB   (+{cur - prev:6.1f})")
    print(f"[TOTAL STARTUP RSS]        {cur:8.1f} MB")
except Exception as exc:  # noqa: BLE001
    print(f"[backend.main] FAILED: {type(exc).__name__}: {exc}")

snapshot = tracemalloc.take_snapshot()
tracemalloc.stop()
print("\n=== tracemalloc top 25 (by size) ===")
for stat in snapshot.statistics("lineno")[:25]:
    print(f"{stat.size / 1024 / 1024:8.2f} MB  {stat.traceback[0]}")
