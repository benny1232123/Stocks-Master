# -*- coding: utf-8 -*-
"""自适应仓位：regime 定总仓位 + 波动率倾斜个股权重。所有替换断言命中恰好 1 次。"""
import pathlib
import sys

ROOT = pathlib.Path(r"E:\Stocks-Master")


def patch(rel, old, new):
    p = ROOT / rel
    text = p.read_text(encoding="utf-8")
    cnt = text.count(old)
    if cnt != 1:
        print(f"!! {rel}: 期望命中 1 次，实际 {cnt} 次 -- 中止")
        sys.exit(1)
    p.write_text(text.replace(old, new), encoding="utf-8")
    print(f"OK  {rel}  (1 处)")


# ==================== defaults.py ====================
patch(
    "smcore/config/defaults.py",
    '''    "hard_cap_ceiling_pct": 35.0,       # 绝对天花板：任何只数下单票都不得超此权重''',
    '''    "hard_cap_ceiling_pct": 35.0,       # 绝对天花板：任何只数下单票都不得超此权重
    # ── 自适应仓位（2026-09-21）：regime 定总仓位 + 波动率给个股权重倾斜 ──
    # 总仓位不再固定：基线由市场状态给，再按 regime_strength 连续微调；
    # 个股权重 = 等权 × 波动率倾斜（按均值归一化 → 只重分配、不改总仓位）。
    # 任一环节缺数据都 fail-soft 回落到静态 target_equity_ratio 口径，绝不抛异常。
    # 一键关闭：把 enabled 置 False 即完全回到静态口径。
    "adaptive": {
        "enabled": True,
        # regime → 总仓位基线（0~1）。三态来自 market.compute_market_profile(as_of)。
        "equity_ratio_by_regime": {
            "趋势上行": 0.85,
            "震荡轮动": 0.70,
            "下行防御": 0.55,
        },
        # regime_strength(0~1，是「看多程度」合成分；0.5 = 恰在基线) 在基线 ±span/2 内微调
        "strength_span": 0.10,
        # 总仓位绝对边界（防极端数据把仓位推到 0 或满仓）
        "equity_ratio_bounds": [0.30, 0.95],
        # 个股权重波动率倾斜：复用 risk_config.json 的 vol_target（低波动多配、高波动少配）
        "vol_tilt": True,
        "vol_window": 20,
        "vol_scale_bounds": [0.5, 2.0],   # 归一化后的倾斜系数上下限，防单票吃掉仓位
    },''',
)

# ==================== analysis.py ====================
patch(
    "smcore/analysis.py",
    '''def _resolve_target_weight(
    code: str, cfg: dict, n_holdings: int | None
) -> tuple[float, str]:
    """解析单票目标权重（%），返回 ``(目标, 口径来源)``。

    优先级：
    1. ``per_code_targets[code]`` —— 逐票显式指定（压过全局口径）。
    2. ``target_equity_ratio`` ÷ 持有只数 —— **推荐**：表达「想投多少、均分到 N 只」，
       与只数解耦；N 变化时结论自动跟随。
    3. ``target_weight_pct`` —— 旧口径：固定每票权重，隐含「总仓位 = 8% × N」，
       N 一变全表结论就变（2026-09-21 全表减仓的根因）。

    口径来源（``per_code`` / ``equity_ratio`` / ``fixed_pct``）随结果返回，供报告/前端标注。
    """
    per = cfg.get("per_code_targets") or {}
    if code in per:
        return float(per[code]), "per_code"
    ratio = cfg.get("target_equity_ratio")
    if ratio is not None and n_holdings:
        try:
            r = float(ratio)
            n = int(n_holdings)
        except (TypeError, ValueError):
            r, n = 0.0, 0
        if r > 0 and n > 0:
            return r * 100.0 / n, "equity_ratio"
    return float(cfg.get("target_weight_pct", 8.0)), "fixed_pct"''',
    '''def adaptive_sizing_context(
    codes: list[str], as_of: "date | None" = None, cfg: dict | None = None
) -> dict:
    """一次算好整份报告共用的**自适应仓位**参数：总仓位目标 + 每票波动率倾斜系数。

    设计（2026-09-21）：
    - **总仓位自适应**：``regime`` 定基线（趋势上行/震荡轮动/下行防御），``regime_strength``
      在基线 ±span/2 内连续微调（strength 是「看多程度」合成分，0.5 恰好落在基线）。
    - **个股权重自适应**：等权 × 波动率倾斜 ``vol_target_scale(20 日年化波动)``
      （复用 risk_config.json 的 vol_target：低波动多配、高波动少配），再**按均值归一化**
      → 只做**重分配**、不改变总仓位（否则会把「择时」和「分配」两件事混在一起）。
    - **fail-soft**：任一环节失败/数据缺失都回落静态 ``target_equity_ratio`` 口径
      （``source="static"``），**绝不抛异常**。regime 检测本身缺数据时会退「震荡轮动」。

    ⚠️ 本函数内一律**懒 import** `smcore.strategy.*`：defaults.py 明确警告过
    `smcore.strategy` 包初始化期间（fusion→position_sizing→defaults）存在循环导入，
    模块顶层 import 会在已导入 engine 后炸。

    返回：
    - enabled / source: 是否生效 / ``adaptive_regime`` | ``static``
    - regime / regime_strength: 市场状态与连续强度
    - equity_ratio: 本次总仓位目标（0~1）
    - vol_scale: ``{code: 已归一化倾斜系数}``（缺数据的票为 1.0）
    - note: 未生效或部分降级的原因（供日志/报告展示）
    """
    cfg = cfg or POSITION_SIZING_CONFIG
    a_cfg = dict(cfg.get("adaptive") or {})
    out: dict = {
        "enabled": False, "source": "static", "regime": None, "regime_strength": None,
        "equity_ratio": float(cfg.get("target_equity_ratio") or 0.70),
        "vol_scale": {}, "note": "",
    }
    if not a_cfg.get("enabled"):
        out["note"] = "adaptive.enabled=False → 用静态 target_equity_ratio"
        return out

    # ① 市场状态 → 总仓位
    try:
        from smcore.strategy.market import compute_market_profile

        prof = compute_market_profile(as_of)
        regime = getattr(prof, "regime", None)
        strength = getattr(prof, "regime_strength", None)
    except Exception as exc:                                     # noqa: BLE001
        out["note"] = f"regime 检测失败（{type(exc).__name__}: {exc}）→ 回落静态口径"
        return out

    by_regime = a_cfg.get("equity_ratio_by_regime") or {}
    if regime not in by_regime:
        out["note"] = f"regime「{regime}」未命中映射表 → 回落静态口径"
        return out
    try:
        s = float(strength) if strength is not None else 0.5
    except (TypeError, ValueError):
        s = 0.5
    span = float(a_cfg.get("strength_span", 0.0) or 0.0)
    equity = float(by_regime[regime]) + (s - 0.5) * span
    bounds = list(a_cfg.get("equity_ratio_bounds") or [0.30, 0.95])
    equity = min(max(equity, float(bounds[0])), float(bounds[-1]))

    # ② 波动率倾斜（按均值归一化 → 只重分配、不改总仓位）
    vol_scale: dict[str, float] = {}
    if a_cfg.get("vol_tilt", True):
        try:
            from smcore.strategy.position_sizing import _estimate_vol20
            from smcore.strategy.risk_rules import (
                compute_vol_target_params,
                vol_target_scale,
            )
            from smcore.utils.code import format_stock_code

            params = compute_vol_target_params()
            if params.get("enabled"):
                window = int(a_cfg.get("vol_window") or params.get("window") or 20)
                vols = _estimate_vol20(list(codes), window=window)
                raw = {
                    str(c): float(vol_target_scale(vols.get(format_stock_code(str(c))), params))
                    for c in codes
                }
                b2 = list(a_cfg.get("vol_scale_bounds") or [0.5, 2.0])
                cl = {c: min(max(v, float(b2[0])), float(b2[-1])) for c, v in raw.items()}
                m = (sum(cl.values()) / len(cl)) if cl else 1.0
                clamped = {c: (v / m if m > 0 else v) for c, v in cl.items()}
                # 收口后再归一化一次：保证 Σscale/N == 1，总仓位不被倾斜改动
                cv = [v for v in clamped.values() if v > 0]
                cm = (sum(cv) / len(cv)) if cv else 1.0
                vol_scale = {c: (v / cm if cm > 0 else v) for c, v in clamped.items()}
        except Exception as exc:                                 # noqa: BLE001
            out["note"] = f"波动率倾斜不可用（{type(exc).__name__}）→ 个股权重退化为等权"

    out.update(
        enabled=True, source="adaptive_regime", regime=regime,
        regime_strength=round(s, 2), equity_ratio=round(equity, 4),
        vol_scale=vol_scale,
    )
    return out


def _resolve_target_weight(
    code: str, cfg: dict, n_holdings: int | None, adaptive: dict | None = None
) -> tuple[float, float, str]:
    """解析单票目标权重（%），返回 ``(目标, 政策目标, 口径来源)``。

    优先级：
    1. ``per_code_targets[code]`` —— 逐票显式指定（压过全局口径）。
    2. **自适应**：``adaptive.equity_ratio ÷ N × vol_scale[code]``
       （regime 定总仓位、波动率定分配）。
    3. ``target_equity_ratio`` ÷ 持有只数 —— 静态口径：表达「想投多少、均分到 N 只」。
    4. ``target_weight_pct`` —— 旧口径：固定每票权重，隐含「总仓位 = 8% × N」，
       N 一变全表结论就变（2026-09-21 全表减仓的根因）。

    **政策目标**（第 2 个返回值）是**未做波动率倾斜**的 ``equity_ratio ÷ N``：
    单票硬上限必须按它推导，否则波动率倾斜会把上限一起带偏。静态口径下两者相等。
    口径来源（``per_code`` / ``adaptive`` / ``equity_ratio`` / ``fixed_pct``）随结果返回。
    """
    per = cfg.get("per_code_targets") or {}
    if code in per:
        w = float(per[code])
        return w, w, "per_code"
    n = 0
    if n_holdings:
        try:
            n = int(n_holdings)
        except (TypeError, ValueError):
            n = 0
    a = adaptive or {}
    if a.get("enabled") and n > 0:
        try:
            ratio = float(a.get("equity_ratio") or 0.0)
        except (TypeError, ValueError):
            ratio = 0.0
        if ratio > 0:
            policy = ratio * 100.0 / n
            try:
                scale = float((a.get("vol_scale") or {}).get(code, 1.0) or 1.0)
            except (TypeError, ValueError):
                scale = 1.0
            return policy * scale, policy, "adaptive"
    ratio = cfg.get("target_equity_ratio")
    if ratio is not None and n > 0:
        try:
            r = float(ratio)
        except (TypeError, ValueError):
            r = 0.0
        if r > 0:
            w = r * 100.0 / n
            return w, w, "equity_ratio"
    w = float(cfg.get("target_weight_pct", 8.0))
    return w, w, "fixed_pct"''',
)

patch(
    "smcore/analysis.py",
    '''    portfolio_value: float,
    cfg: dict | None = None,
    n_holdings: int | None = None,
) -> dict[str, object]:''',
    '''    portfolio_value: float,
    cfg: dict | None = None,
    n_holdings: int | None = None,
    adaptive: dict | None = None,
) -> dict[str, object]:''',
)

patch(
    "smcore/analysis.py",
    '''    - n_holdings: 当前**持有只数** N。仅 ``target_equity_ratio`` 口径需要
      （每票目标 = 总仓位目标 ÷ N）；缺省 None 时退化为固定 ``target_weight_pct`` 口径。''',
    '''    - n_holdings: 当前**持有只数** N。自适应与 ``target_equity_ratio`` 口径都需要
      （每票目标 = 总仓位目标 ÷ N）；缺省 None 时退化为固定 ``target_weight_pct`` 口径。
    - adaptive: :func:`adaptive_sizing_context` 的输出。enabled 时每票目标 =
      ``equity_ratio ÷ N × vol_scale[code]``（regime 定总仓位、波动率定分配）。''',
)

patch(
    "smcore/analysis.py",
    '''    - target_source: 政策目标来自哪个口径（per_code / equity_ratio / fixed_pct）''',
    '''    - target_source: 目标来自哪个口径（per_code / adaptive / equity_ratio / fixed_pct）''',
)

patch(
    "smcore/analysis.py",
    '''    # 政策目标权重：per_code_targets > target_equity_ratio/N > target_weight_pct
    target_w, target_src = _resolve_target_weight(code, cfg, n_holdings)
    # 单票硬上限：显式 hard_cap_pct 优先；否则 = 目标 × multiple（以 ceiling 封顶）
    hard_cap = _resolve_hard_cap(cfg, target_w)''',
    '''    # 目标权重：per_code_targets > 自适应(regime×vol) > target_equity_ratio/N > target_weight_pct
    target_w, policy_w, target_src = _resolve_target_weight(code, cfg, n_holdings, adaptive)
    # 单票硬上限按**未倾斜的政策目标**推导，避免波动率倾斜把上限一起带偏
    hard_cap = _resolve_hard_cap(cfg, policy_w)''',
)

# ==================== notify_holdings_analysis.py ====================
patch(
    "scripts/notify_holdings_analysis.py",
    '''    position_sizing_recommendation,''',
    '''    adaptive_sizing_context,
    position_sizing_recommendation,''',
)

patch(
    "scripts/notify_holdings_analysis.py",
    '''        _refresh_fundamentals(codes)

        # ── 两段式：① 先逐只分析 → ② 汇总求组合分母 → ③ 再统一渲染 ──''',
    '''        _refresh_fundamentals(codes)

        # ── 自适应仓位：regime 定总仓位 + 波动率给个股权重倾斜（一次算好、全报告共用）──
        adaptive_ctx = adaptive_sizing_context(codes, as_of=as_of_date, cfg=POSITION_SIZING_CONFIG)
        if adaptive_ctx.get("enabled"):
            _eq = float(adaptive_ctx.get("equity_ratio") or 0) * 100
            log_lines.append(
                f"自适应仓位[{adaptive_ctx.get('source')}]：市场状态 "
                f"{adaptive_ctx.get('regime')}（强度 {adaptive_ctx.get('regime_strength')}）"
                f"→ 总仓位目标 {_eq:.1f}%；个股权重按 "
                f"{len(adaptive_ctx.get('vol_scale') or {})} 只的波动率倾斜"
            )
            if adaptive_ctx.get("note"):
                log_lines.append(f"⚠️ 自适应仓位部分降级：{adaptive_ctx['note']}")
            _an = (
                f"市场状态 **{adaptive_ctx.get('regime')}**"
                f"（强度 {adaptive_ctx.get('regime_strength')}）→ 总仓位目标 **{_eq:.1f}%**；"
                f"个股权重 = 等权 × 波动率倾斜（低波动多配、高波动少配）"
            )
        else:
            log_lines.append(
                f"自适应仓位未启用 → 用静态口径（{adaptive_ctx.get('note') or '—'}）"
            )
            _an = f"静态仓位口径（自适应未启用：{adaptive_ctx.get('note') or '—'}）"
        data_warn_md += f"> 📊 **自适应仓位**：{_an}\\n\\n"
        data_warn_html += f'<div class="card"><div class="sig">📊 自适应仓位：{_an}</div></div>'

        # ── 两段式：① 先逐只分析 → ② 汇总求组合分母 → ③ 再统一渲染 ──''',
)

patch(
    "scripts/notify_holdings_analysis.py",
    '''            sizing = position_sizing_recommendation(
                analysis, pos, portfolio_value, cfg=POSITION_SIZING_CONFIG,
                n_holdings=len(codes),
            )''',
    '''            sizing = position_sizing_recommendation(
                analysis, pos, portfolio_value, cfg=POSITION_SIZING_CONFIG,
                n_holdings=len(codes), adaptive=adaptive_ctx,
            )''',
)

print("\n全部替换完成。")
