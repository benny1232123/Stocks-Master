# Realign Rerun 自动审计（run 35439406256）

## 执行摘要
- **触发时间**：2026-09-20 09:26 GMT+8
- **Run 状态**：`status=completed`, `conclusion=success` → 走成功分支，运行 `audit_realign.py`（用 `E:/Anaconda/python.exe`，受管 Python 缺 pandas）。
- **审计结论**：
  - 16 窗口日（08-27..09-17）**全部 A_BATCH / FRESH**，0 LEGACY、0 MISSING。
  - DAL 缺口 09-01、09-15 **均已补齐**且 `A_BATCH=True`。
  - tally: `{'A_BATCH': 16}`，`dates not A_BATCH: []`，`DAL gap ok: {09-01: True, 09-15: True}`。
- **对比前次快照**：此前因 realign-full.yml `python -c "..."` YAML 缩进坑（continue-on-error:true 掩盖）导致 4 A_BATCH / 7 LEGACY / 5 MISSING；本次重跑（heredoc `python - <<'PY'` 修复后）已**完全恢复**，无 legacy 残留、无缺失。
- **无需后续动作**：成功分支，未创建 3h 跟进自动化。

## 产物
- `E:/Stocks-Master/_audit_realign_out.json`（脚本写出）

---

# 进度核查（2026-09-20，续「两者都做」两修复）

## 触发
用户问「进度」，核查：① 09-18 选股补跑 run 35484275633 是否完成并落库；② 新闻对齐护栏 commit 5fc62c5 是否到达 origin/master。

## 发现
- run 35484275633：`completed/success`；`stock_data/Daily-Action-List-20260918.csv` 已落远程（6a947924…, 1304B）；09-18 三件套 CCTV 文件均在远程。
- 护栏 commit `5fc62c5` **不在**远程（gh api 422），远程 `news_surface.py` 0 处护栏标记 → 早前 rebase+push 后台任务确实失败。
- 本会话本地 git 因 shell shim（`dirname`/`cd` 缺失）不可用，但 GitHub REST API 可达（gh api 正常）。

## 动作
- 经 Git Database API（blob→tree→commit→PATCH ref，fast-forward 于远程 tip d7a1cf5）把本地干净版 `news_surface.py`（仅护栏改动）推上 master。
- 新 master tip = `363a2f7324eadbef4cb1e9acec72df7dd81ff1a4`；远程复核含 12 处护栏标记。
- 两项修复均上线：选股最新日=20260918，新闻面板自动对齐 09-18，新闻日期==选股日。

## 产物 / 备注
- 状态报告：`E:/Stocks-Master/.workbuddy/PROGRESS_2026-09-20.md`
- 待办（未擅动）：run_cctv 接入每日 CI；清理 `.workbuddy/` 诊断产物。

---

# 持仓日报「仓位调整」升级（2026-09-21 续「可以」批准）

## 触发
用户批准把「持仓建议」升级成真正的仓位调整建议（目标权重 → 当前权重的 delta 驱动加减仓），因持仓日报直接指导加减仓。本自动化继续并落地该改造。

## 动作
- `smcore/config/defaults.py`：新增 `POSITION_SIZING_CONFIG`（目标权重8%/硬上限15%/带宽±2%/健康门控/一手100/逐票覆盖）。
- `smcore/analysis.py`：新增 `position_sizing_recommendation(analysis,pos,portfolio_value,cfg)`，复用股票研判健康度，按 delta+硬上限+健康门控产出 加仓/持有偏多/持有观望/减仓偏空/减仓，返回权重/delta金额/delta股数。不改 `recommendation_from_analysis` 语义。
- `scripts/notify_holdings_analysis.py`：主循环用组合市值分母逐只算 sizing，渲染「⚖️ 仓位调整」区块，与「持仓建议」并列。
- 验证：py_compile 通过；`_demo_sizing.py` 6 决策分支全对；`_demo_render.py` 确认 MD/HTML 均吐出「仓位调整」。
- 推送：经 Git Database API fast-forward 上 master，新 tip `a6bb619d166c65eb45fd97adb6ec5398899d79bb`；远程三文件内容已复核。

## 结论
仓位调整层已上线，弱票欠配不再误判加仓、超硬上限强制减仓。残留设计问题（holdings 无 K 线新鲜度门控、纯技术面退化、报告不含现金）未动。

---

# 持仓日报「全部修复」（2026-09-21 续「全部修复」）

## 触发
用户「全部修复」= 上条列的三项残留设计问题（无 K 线门控 / 纯技术面退化 / 口径不含现金）。

## 关键发现（超出预期，优先处理）
- **CRITICAL**：上一轮 `a6bb619` 把 sizing 调用写进「边分析边渲染」循环、而 `portfolio_value`
  在循环之后才赋值 → 首只票即 `UnboundLocalError`，**线上持仓日报整体崩**（上一轮只单测
  `render_stock` 没跑 `main()`，故漏掉）。修法：两段式渲染。

## 动作
- `notify_holdings_analysis.py`：两段式主循环（修崩溃 + 保序）；`_account_cash()` 现金分母；
  `_refresh_klines()` / `_refresh_fundamentals()` **自包含前置守卫**（缺 bar → `::error::` +
  报告横幅但不 exit 非零；基本面只回填缺失项）；纯技术面标注。
- `smcore/analysis.py`：新增 `fundamentals_available()` 作 `hasF` 单一判据（`faces` 恒为 int，不能拿它判）。
- `smcore/config/defaults.py`：`account_cash` / `account_cash_pct`。
- `prepull_klines.py` / `refresh_fundamentals.py`：各加 `--from-holdings`（+`--codes`）。
- `.github/workflows/daily-holdings.yml`：本地已加 3 个硬化 step，但**推不上去**（见下）。

## 阻碍
令牌 scope 缺 `workflow` → 任何写 `.github/workflows/*` 的请求被 GitHub 以 **404** 拒绝
（Contents API 亦然；已二分确认）。**故选择把守卫内建进脚本**，CI 零改动即生效。
待应用片段落在 `.workbuddy/APPLY_workflow_daily-holdings.md`（含 `gh auth refresh -s workflow`）。

## 验证 / 产物
- `.workbuddy/_test_holdings_main.py`：全离线打桩 4 组用例全过（含顺序回归、现金口径、纯技术面、stale 守卫、逃生口）。
- `pytest tests`：148 项仅 2 项失败，与改动前 `lastfailed` 快照完全一致（预存在数据漂移，不碰改动模块）。
- 推送：`ee4e40db`（5 文件）→ `9aedc4aa`（自包含守卫）；5 文件远程内容逐一 sha256 MATCH。
- 样例外观：`.workbuddy/holdings_sample_20260921.html`。

---

# 分母口径修正为「账户总资产 30000」（2026-09-21 续）

## 触发
用户先「30000现金算」，随即更正「**不是30000现金 是市值+现金一共30000**」。

## 动作（push `78dd0f4e`）
- `account_total=30000.0` 作**首选分母**（现金 = 总资产 − 持仓市值 自动反推）；
  `account_cash` / `account_cash_pct` 降为备选档。
- `_account_cash()` → `_resolve_denominator()` 返回 `(分母, 现金, 口径来源)`，四档优先级。
- ★ 修优先级陷阱：初版让「配置 account_total」压过「env ACCOUNT_CASH」→ 现改为
  **env 一律优先于配置**；另加 `ACCOUNT_BASIS=holdings` 逃生口。
- 汇总卡片开关 `cash>0` → `equity_total`（否则超配且现金为 0 时总资产行被藏掉）。
- 回归测试扩到 **6 组用例**（含优先级 6a–6f）全过。

## 真实结果（持仓 20,247 + 现金 9,753 = 30,000，实际仓位 67.5%）
`002284` −500 股（26.4% 超 15% 硬上限）、`600269` −1100 股（22.9% 超上限）、
`603187` −100 股（14.5% 再平衡）、`603390` +200 股（3.7% 欠配加仓）。

## 遗留提示（未擅自改）
`target_weight_pct=8%` × 4 只 = 32% 目标总仓位，与实际 67.5% 严重不符 → 全表减仓。
维持当前仓位需 ≈16.9%/只 **且** `hard_cap_pct` 提到 ~20%（否则 target > cap 自相矛盾）。
已向用户说明并给出选项，等其拍板。


