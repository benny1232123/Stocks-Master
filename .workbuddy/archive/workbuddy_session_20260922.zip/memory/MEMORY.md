# Stocks-Master 记忆（v26, 2026-09-22 精简）

> 细节回查 `.workbuddy/memory/2026-09-*.md` 当日日志；本文只留跨会话铁律与索引。

## 策略菜单（真源）
`smcore/strategy/factor_types.py`：`STRATEGY_ORDER`(活跃12价格因子)/`STRATEGY_LABEL`/`RETIRED_STRATEGY_NAMES`/`ALL_STRATEGIES`。不变量 `STRATEGY_LABEL[id].lower()==id`（import 自检）。改集合必同步前端 3 副本（`factorTypes.js`/`App.jsx::STRAT_LABEL`/`styles.css::.top-tag--<id>`，守卫 `test_frontend_registry_parity.py`）+ 全仓 grep 旧字面量。新 config 键须注册 `_BUILTIN_DEFAULTS`。

## ★ 通用铁律
1. **同消息对同一文件多个 Edit 会互相覆盖**（静默丢）→ 同文件多处改，写断言式 patch 脚本（每处 `count(old)` 断言后替换）。
2. **接线改动必须端到端跑 `main()`**，只单测 `render_*` 会漏（曾致线上日报 `UnboundLocalError` 全崩）。
3. git：pre-commit 会 stage 整个脏工作树 → 提交前 `git diff --cached --name-only`；plumbing 改动后必 `git reset --mixed <同tip>`；**勿用 `git pull --rebase`**；推送前 `ls-remote` 比对。
4. **CI 前置逻辑下沉到脚本自身**：本机 `gh` token 缺 `workflow` scope → 改 `.github/workflows/*` 被 **404** 拒。
5. **依赖真实持仓的脚本必须在 import smcore 前加载 `.env`**，否则 `TradeRepository` 静默 fallback 到空 `trades.json`，跑出「无持仓」假结果。
6. Python：类体推导式/lambda 看不到类体命名空间 → `NameError`；`monkeypatch` 遇 `__init__` re-export 同名遮蔽会静默失效 → 用 `importlib.import_module` 打源模块。
7. 环境：受管 venv 缺 pandas → `E:/Anaconda/python.exe`；Bash coreutils 间歇失效 → 读写走 Read/Write。

## 持仓日报
- 分母口径：`env ACCOUNT_TOTAL > env ACCOUNT_CASH > cfg *`（**env 优先于配置**）；`account_total=30000`；`ACCOUNT_BASIS=holdings` 逃生口。
- 仓位层 `POSITION_SIZING_CONFIG` + `position_sizing_recommendation()` 是加减仓动作层；`recommendation_from_analysis` 只看该票健康度（技术40/基本35/资金25），**不看当前仓位**。
- 目标权重：`per_code_targets > target_equity_ratio(0.70)÷N > target_weight_pct(8)`；未传 `n_holdings` 会静默退化 fixed_pct。超硬上限只减到上限（`aim_weight`），硬上限 = 生效目标×1.5 封顶 35%。
- ★ 自适应仓位：`adaptive` 配置块（regime → 总仓位 0.85/0.70/0.55，`risk_parity_erc` 分配，`min_weight_frac` 防清零，fail-soft 回 static）。硬上限基准必须用**倾斜后的生效目标**。`adaptive.enabled=False` 一键回静态。
- 数据新鲜度：`_refresh_klines(codes, as_of)` 复核信号日 bar；缺 bar 报 `::error::` 但**不 exit 非零**。
- `fundamentals_available(analysis)` 是 hasF 单一判据（`faces` 恒为 int）。成本基不计买入手续费 → 未实现盈亏高估 ~0.03%。
- 持仓（09-21 修正）：002284 900@13.15 / 600269 1800@4.51 / 603187 400@14.32 / 603390 100@14.86。

## CI
`daily-pick.yml`：zoo_factor_strategy → 12×CSV → fusion → Daily-Action-List → export_web_data；触发 `*/20 8-13 UTC` + dispatch，无 push 触发，直推 master。

## 已修线上 bug（带 push SHA，勿回退）
- **融合反向筛选（B，push `b256133e`）**：`factor_timing_mask_from_points` 判据由「仅显著正才保留」改为「**仅显著负才清零**」（`smcore/strategy/factor_timing.py` L102）。生产 `adaptive_weights_config.json::factor_timing.enabled=true` 现跑修复后逻辑；验证器 `walk_forward_validator` 委托本函数自动生效。守卫 `tests/test_factor_timing.py`（11 项，含「正但不显著 IC 必须保留」核心钉）。
  - **三臂实证（`mask_3arm_20260921.html`）**：mask_fixed ≡ mask_off（前向超额到0.01pp）、胜率 H=1/2/3 更高（61.0/51.7/49.1% vs 55.9/46.6/47.4%），buggy 每档最差 → 修复消除误杀且未引入更差行为。两 arm 超额全负 → 正确性修复非 alpha 修复。
- **止损统一单一真源（push `42cb6f7d`）**：真源 = `boll_levels.py` 的 `stop_pct = clamp(2.5×日σ, 4%, 12%)`，由 `fusion.py` 写进 DAL → `PositionMonitor` 与 `daily_backtest` 都读 DAL 该列。旧口径 `clamp(8×日σ,6%,15%)` 仅 `BACKTEST_STOP_SOURCE=legacy` 下可用。守卫 `tests/test_stop_source_unified.py`（11 项）。⚠️ **历史 Multi-Backtest 是旧口径产物，与新口径不可比，须 `rerun_backtest_history.py` 重建**。
- **回测快照端点（push `cd7dce3a`）**：空快照自我毒化 fix + 候选家族补全；`export_web_data` 新增 `_is_empty_payload` 不写空载荷。守卫 `tests/test_backtests_latest_snapshot.py`（6 项）。前端未渲染 `backtests_latest.json`，回测 Tab 由 `/api/backtests/daily-latest`+`daily-summary` 驱动。本地无 `.git` → 查远端 `git/trees/master?recursive=1`。

## 回测体检硬结论（方法 skill `stocksmaster-backtest-diagnose`）
- 出场层：两套止损已统一（见上）；**真正杠杆是持有期不是止损**：固定持有 1 日 +0.56%（n=38 胜率63.2%）≥4 日全负；买入价=信号日次日开盘×1.001；摩擦≈0.46%/笔。须先跑带成本回测再改持有期配置。
- 仓位分配反预测：等权 +0.04% vs 加权 -1.43%（配对 t=-2.55/p=0.018）→ 问题在分配/执行层。
- 16 天/120 笔：笔均 +0.04%、胜率 47.5%、95%CI ±1.25pp 与 0 不可区分；组合 -0.85% vs 沪深300 -1.94% → 超额 +1.09%（绝对亏损主要是 β）。

## 信号有效性体检（方法可复用）
- k_data 覆盖 4380 只 → 全市场等权基准；12 个 A 批因子池各 16 天 ~40 只/池（只有 `[代码,名称,综合分≡100]` 二元成员表，算不了 IC）。
- H=3 池超额全 12 因子在 ±0.7pp 内（短持有期无 edge）；H=12 才拉开（VRatio20_120 +3.19、VRatio10_60 +1.32、Illiq20 +0.87，量比/流动性家族）。
- 结论：因子池 edge 极弱 + 融合进一步反向筛选 + 唯一真 edge 在量比/流动性家族且需更长持有期。限制：仅 16 天、子样本 n=1~4，方向性证据。

## 离线重跑驱动（无本地 .git；推远端走 `_push_fix.py` REST API）
- 融合重跑：`.workbuddy/rerun_fusion_offline.py`（单进程+每日期线程超时+断点续跑；中和 baostock/login、基本面纯缓存、regime hs300=None）。改完 factor_timing 后须重跑生产 16 信号日 DAL。
- 回测重跑：`.workbuddy/rerun_backtest_offline.py` → `scripts/rerun_backtest_history.py`（清旧 Multi-Backtest → 全量用新 DAL 重算；`HOLD_DAYS=12, LOOKBACK_DAYS=130` 须对齐 CI）。
- 因子池重生成：`scripts/zoo_factor_strategy.py --date YYYYMMDD`（22s/天，本地零联网），长样本验证可行。

## 其他
- 网站 = CI 清单只读展示层（第二套选股实现已退役）；`strat_label` 查表须 `.toLowerCase()`。
- CCTV 面板：远程数据停 09-19 待查；walk-forward 校准须等市场退出防御 regime 才回写配置。
- 因子文法饱和（纯 OHLCV）；升 live 须用户拍板 + OOS 门控 + ≤35 上限。

## 待办（勿擅自动）
调研 35224641189「CI 绿但空」；修 `realign-full.yml` 缩进坑。
- ★ 生产重跑 + 推送已完成（2026-09-22）：本地 `.git` 损坏（git 报 not a git repository），改走 REST API（GitHub Git Database API，方案 B）单 commit 推 master；commit `f8fbcf2a`。推送 97 文件 = 16 DAL + 48 Multi-Backtest(summary/equity/trades) + 7 web_data JSON + 26 个 Stock-Selection-*-20260916 因子池（此前断档补齐）；令牌 `gh auth token` 注入、按内容哈希逐文件比对 blob sha 全 OK。推送脚本 `.workbuddy/_push_data.py`（并发建 blob + SHA 缓存续跑）。
- 仓库根 scratch 已清理：`_run125.log`/`_run127.log`（0B）归档至 `.workbuddy/archive/cleaned_root_20260922.zip` 后删除。
