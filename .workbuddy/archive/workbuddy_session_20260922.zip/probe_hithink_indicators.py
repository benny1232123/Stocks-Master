"""探针 2：同花顺五类财务指标 index_id 清单（判断能否映射 roe/毛利率/营收增速）。"""
import json
import os
import sys

sys.path.insert(0, r"E:\Stocks-Master")
os.environ.setdefault("HITHINK_FINANCE_API_KEY", "sk-fuyao-5ZAyYPbdnL8A3rjehEj0vgM8Iz-g_-6C")

import requests

KEY = os.environ["HITHINK_FINANCE_API_KEY"]
r = requests.get(
    "https://fuyao.aicubes.cn/api/a-share/financials/indicators",
    params={"thscode": "600519.SH", "report": "2025-4"},
    headers={"X-api-key": KEY},
    timeout=20,
)
body = r.json()
print("code:", body.get("code"), body.get("message"))
data = body.get("data") or {}
print("data keys:", list(data.keys()))
for ab in data.get("abilities") or []:
    print("-" * 60)
    print("ability:", ab.get("name") or ab.get("ability_name") or ab.get("id"))
    for ind in ab.get("indicators") or []:
        print("   ", ind.get("index_id"), "|", ind.get("name") or ind.get("index_name"), "=", ind.get("value"))
