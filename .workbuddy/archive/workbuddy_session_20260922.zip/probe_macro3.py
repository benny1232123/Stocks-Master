"""第三轮探针：验证 10Y 债券近期区间 + 免费外汇 API 可达性。"""
import threading, json, urllib.request, akshare as ak

def probe(name, fn, timeout=15):
    box = {}
    def run():
        try:
            box["r"] = fn()
        except Exception as e:  # noqa
            box["e"] = e
    t = threading.Thread(target=run, daemon=True); t.start(); t.join(timeout)
    if t.is_alive():
        return f"{name}: TIMEOUT"
    if "e" in box:
        return f"{name}: ERR {type(box['e']).__name__}: {str(box['e'])[:90]}"
    r = box["r"]
    if hasattr(r, "shape"):
        last = r.iloc[-1] if not r.empty else {}
        head = f"df{r.shape} | last="
        head += ",".join(f"{c}={last[c]}" for c in r.columns if c in last)
    else:
        head = repr(r)[:200]
    return f"{name}: OK {head}"

# 10Y 债券近期区间
print(probe("bond_china_yield 2025-2026", lambda: ak.bond_china_yield(start_date="20250701", end_date="20260805")))

# 免费外汇 API 测试
def http_json(url, timeout=12):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))

def test_fx_open_er():
    # base CNY -> 其他货币
    d = http_json("https://open.er-api.com/v6/latest/CNY")
    rates = d.get("rates", {})
    return {k: rates.get(k) for k in ["USD", "EUR", "JPY", "HKD"]}

def test_fx_frankfurter():
    d = http_json("https://api.frankfurter.app/latest?from=CNY&to=USD,EUR,JPY,HKD")
    return d.get("rates")

print(probe("open.er-api.com CNY", test_fx_open_er))
print(probe("frankfurter.app CNY", test_fx_frankfurter))
