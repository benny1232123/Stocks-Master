# -*- coding: utf-8 -*-
"""更新端到端回归 `.workbuddy/_test_holdings_main.py` 以适配「自适应仓位」默认开启。

背景：main() 现默认启用 adaptive（真实 compute_market_profile），导致用例7 的静态
期望（equity_ratio / 23.33%）不再成立，且结果随市场数据漂移、测试不确定。

改法：
  ① 默认把 N.adaptive_sizing_context 打桩为 enabled=False → 用例1~7 回到**确定性静态口径**；
  ② 新增用例8：临时换成自适应桩，验证 main() 的接线（regime→总仓位 + 倾斜权重→报告）。
每处断言 count == 1，失配即中止。
"""
import pathlib
import sys

ROOT = pathlib.Path(r"E:\Stocks-Master")
TARGET = ROOT / ".workbuddy" / "_test_holdings_main.py"

REPL = [
    # ① 打桩：默认关闭自适应（放在 K 线桩之后，确保所有 main() 调用前生效）
    (
        "set_kline(empty_kline)                                  # 默认：无 bar → 全部 stale\n",
        "set_kline(empty_kline)                                  # 默认：无 bar → 全部 stale\n"
        "\n"
        "# 自适应仓位默认**打桩为关闭** → main() 走确定性静态口径（用例1~7 均按静态断言）；\n"
        "# 用例8 再临时换成自适应桩，验证 main() 的接线（regime→总仓位 + 倾斜权重 → 报告渲染）。\n"
        "_STATIC_CTX = {\n"
        '    "enabled": False, "source": "static", "regime": None, "regime_strength": None,\n'
        '    "equity_ratio": 0.70, "weight_frac": {}, "weight_method": None,\n'
        '    "note": "test: adaptive disabled",\n'
        "}\n"
        "N.adaptive_sizing_context = lambda *a, **k: dict(_STATIC_CTX)\n",
    ),
    # ② 用例7 注释：说明自适应被打桩关闭
    (
        "# ── 用例 7：目标权重口径（target_equity_ratio ÷ 持有只数）已接入 main() ──\n"
        "# 3 只持仓 → 每票目标 = 70% ÷ 3 = 23.33%；上限 = min(23.33 × 1.5, ceiling 35) = 35.0%\n",
        "# ── 用例 7：静态目标口径（target_equity_ratio ÷ 持有只数）已接入 main() ──\n"
        "# （自适应已打桩关闭 → 走静态口径）3 只持仓 → 每票目标 = 70% ÷ 3 = 23.33%；\n"
        "# 上限 = min(23.33 × 1.5, ceiling 35) = 35.0%\n",
    ),
    # ③ 用例7 断言文案里对 out5 的引用保持；新增用例8（插在结论打印之前）
    (
        'print("\\n================== 结论 ==================")\n',
        "# ── 用例 8：自适应仓位接线（regime→总仓位 + 组合优化层→单票权重）已在 main() 生效 ──\n"
        "# 桩：总仓位 60%（下行防御档）、倾斜权重 {600000: 0.60, 000001: 0.20, 300750: 0.20}\n"
        "#   → 政策目标 = 60% ÷ 3 = 20.0%；各票目标 = 60% × frac = 36% / 12% / 12%\n"
        "#   → 硬上限基准 = max(政策 20, 目标) → 600000: min(36×1.5,35)=35；其余: min(20×1.5,35)=30\n"
        "# 纯持仓分母(15,000)下 000001 = 10,000/15,000 = 66.7% > 30% → 只减到「上限 30.0%」\n"
        "N.adaptive_sizing_context = lambda *a, **k: {\n"
        '    "enabled": True, "source": "adaptive_regime", "regime": "下行防御",\n'
        '    "regime_strength": 0.30, "equity_ratio": 0.60,\n'
        '    "weight_frac": {"600000": 0.60, "000001": 0.20, "300750": 0.20},\n'
        '    "weight_method": "risk_parity_erc", "note": "",\n'
        "}\n"
        'os.environ["ACCOUNT_BASIS"] = "holdings"\n'
        'rc8, md8, html8, out8 = run("用例8 自适应仓位（regime+倾斜权重）")\n'
        'os.environ.pop("ACCOUNT_BASIS", None)\n'
        "if rc8 != 0:\n"
        '    fails.append(f"用例8 rc={rc8}")\n'
        'if "目标权重口径[adaptive]" not in out8:\n'
        '    fails.append("用例8 main() 未走自适应口径（日志缺 目标权重口径[adaptive]）")\n'
        'if "自适应仓位" not in md8 or "自适应仓位" not in html8:\n'
        '    fails.append("用例8 报告缺「自适应仓位」说明横幅")\n'
        'if "下行防御" not in md8:\n'
        '    fails.append("用例8 自适应横幅未展示 regime（期望 下行防御）")\n'
        'if "每票目标 36.0%" not in out8:\n'
        '    fails.append("用例8 倾斜权重未生效（600000 期望目标 36.0%）："\n'
        '                 + next((l for l in out8.splitlines() if "目标权重口径" in l), "<无>"))\n'
        'if "→ 上限 30.0%" not in md8:\n'
        '    fails.append("用例8 超限票未按「只减到上限 30.0%」渲染")\n'
        'if "政策目标 20.0%" not in md8:\n'
        '    fails.append("用例8 超限票未标注政策目标 20.0%")\n'
        "\n"
        'print("\\n================== 结论 ==================")\n',
    ),
    # ④ 结论列表补自适应
    (
        'print("   ⑥ 目标口径 = target_equity_ratio ÷ 持有只数；超硬上限只减到上限（非一步砍到目标）")\n',
        'print("   ⑥ 静态目标口径 = target_equity_ratio ÷ 持有只数；超硬上限只减到上限（非一步砍到目标）")\n'
        'print("   ⑦ 自适应仓位：regime→总仓位 + 组合优化层→单票权重，已接入 main() 并渲染横幅")\n',
    ),
    # ⑤ run() 日志过滤：把口径/自适应日志也打出来，便于人工核对
    (
        '        if any(k in line for k in ("组合分母", "纯技术面", "基本面缓存", "K 线", "跳过")):\n',
        '        if any(k in line for k in ("组合分母", "纯技术面", "基本面缓存", "K 线", "跳过",\n'
        '                                   "目标权重口径", "自适应仓位")):\n',
    ),
]

src = TARGET.read_text(encoding="utf-8")
for i, (old, new) in enumerate(REPL, 1):
    n = src.count(old)
    if n != 1:
        print(f"FAIL #{i}: expected 1 hit, got {n}")
        print("--- old ---")
        print(old)
        sys.exit(1)
    src = src.replace(old, new)
    print(f"OK #{i}: replaced 1 hit")

TARGET.write_text(src, encoding="utf-8")
print("WROTE", TARGET)
