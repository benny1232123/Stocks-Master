# -*- coding: utf-8 -*-
"""生成回测体检报告（自包含 HTML，数据全部现算，无手抄）。"""
import glob
import math
import re
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "backtest_diagnosis_20260921.html"


def safe_read(p):
    try:
        return pd.read_csv(p, dtype=str)
    except Exception:
        return None


# ── 数据 ──
frames, sums = [], []
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv"))):
    d = safe_read(f)
    if d is None or d.empty or "return_pct" not in d.columns:
        continue
    d["_batch"] = re.search(r"(\d{8})", Path(f).name).group(1)
    frames.append(d)
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-summary.csv"))):
    d = safe_read(f)
    if d is None or d.empty:
        continue
    d["_batch"] = re.search(r"(\d{8})", Path(f).name).group(1)
    sums.append(d)

T = pd.concat(frames, ignore_index=True)
T["return_pct"] = pd.to_numeric(T["return_pct"], errors="coerce")
T["qty"] = pd.to_numeric(T["qty"], errors="coerce")
T["buy_price"] = pd.to_numeric(T["buy_price"], errors="coerce")
T["_v"] = T["qty"] * T["buy_price"]
T["_hold"] = (pd.to_datetime(T["sell_date"], errors="coerce")
              - pd.to_datetime(T["buy_date"], errors="coerce")).dt.days
S = pd.concat(sums, ignore_index=True)
for c in ("total_return", "bench_return", "excess_return", "win_rate", "hold_days",
          "max_drawdown", "sharpe", "num_trades", "bench_return_exposed", "cash_pct"):
    if c in S.columns:
        S[c] = pd.to_numeric(S[c], errors="coerce")
Sc = S[S["num_trades"] > 0] if "num_trades" in S.columns else S
n_batch_done = len(Sc)

# ── 指标 ──
r = T["return_pct"].dropna()
n, sd = len(r), r.std()
se = sd / math.sqrt(n)
ci = (r.mean() - 1.96 * se, r.mean() + 1.96 * se)
full = S[S["hold_days"] >= 12]
ex = T.groupby("exit_reason")["return_pct"].agg(
    n="count", mean="mean", total="sum", win=lambda s: 100 * (s > 0).mean()
).sort_values("total")

eq = r.mean()
w_mean = (T["return_pct"] * T["_v"]).sum() / T["_v"].sum()
rows = []
for b, g in T.groupby("_batch"):
    if len(g) < 3:
        continue
    rows.append((g["return_pct"] * g["_v"]).sum() / g["_v"].sum() - g["return_pct"].mean())
D = pd.Series(rows)
tstat = D.mean() / (D.std() / math.sqrt(len(D)))
neg = int((D < 0).sum())
pv = sum(math.comb(len(D), k) for k in range(neg, len(D) + 1)) / 2 ** len(D)

hb = T.dropna(subset=["_hold"]).copy()
hb["_bucket"] = pd.cut(hb["_hold"], [0, 1, 3, 5, 8, 14, 999],
                       labels=["1 天", "2-3 天", "4-5 天", "6-8 天", "9-14 天", "≥15 天"])
hold_tbl = hb.groupby("_bucket", observed=True)["return_pct"].agg(
    n="count", mean="mean")

q_hi, q_lo = T["_v"].quantile(.75), T["_v"].quantile(.25)
v_hi = T[T["_v"] >= q_hi]["return_pct"].mean()
v_lo = T[T["_v"] <= q_lo]["return_pct"].mean()
corr_v = T["_v"].corr(T["return_pct"])

# DAL join
recs = []
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv"))):
    t = safe_read(f)
    if t is None or t.empty or "return_pct" not in t.columns:
        continue
    tag = re.search(r"(\d{8})", Path(f).name).group(1)
    dal = SD / f"Daily-Action-List-{tag}.csv"
    if not dal.exists():
        continue
    d = safe_read(dal)
    if d is None or d.empty:
        continue
    d = d.rename(columns={"股票代码": "code"})
    d["code"] = d["code"].astype(str).str.zfill(6)
    t["code"] = t["code"].astype(str).str.zfill(6)
    recs.append(t.merge(d, on="code", how="left"))
M = pd.concat(recs, ignore_index=True)
M["return_pct"] = pd.to_numeric(M["return_pct"], errors="coerce")

score_tbl = {}
for c in ("综合评分", "命中策略数", "权重", "因子分"):
    if c not in M.columns:
        continue
    M[c] = pd.to_numeric(M[c], errors="coerce")
    sub = M.dropna(subset=[c, "return_pct"])
    if len(sub) < 8:
        continue
    try:
        grp = pd.qcut(sub[c], 4, duplicates="drop")
    except Exception:
        continue
    g = sub.groupby(grp, observed=True)["return_pct"].mean()
    score_tbl[c] = (sub[c].corr(sub["return_pct"]), [round(float(x), 2) for x in g.tolist()])


def cards(items):
    out = []
    for label, val, sub in items:
        out.append(f'<div class="mc"><div class="k">{label}</div>'
                   f'<div class="v">{val}</div><div class="s">{sub}</div></div>')
    return "".join(out)


def table(head, rows_):
    th = "".join(f"<th>{h}</th>" for h in head)
    tr = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in rw) + "</tr>" for rw in rows_)
    return f'<table><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table>'


# 出场结构条形
mx = max(abs(ex["total"]))
exit_rows = []
for k, row in ex.iterrows():
    pct = abs(row["total"]) / mx * 100
    col = "pos" if row["total"] > 0 else "neg"
    exit_rows.append(
        f'<tr><td class="nm">{k}</td><td class="num">{int(row["n"])}</td>'
        f'<td class="num">{row["mean"]:+.2f}%</td><td class="num">{row["win"]:.0f}%</td>'
        f'<td class="num">{row["total"]:+.0f}</td>'
        f'<td><div class="bar {col}" style="width:{pct:.1f}%"></div></td></tr>')

pos_sum = ex[ex["total"] > 0]["total"].sum()
neg_sum = ex[ex["total"] <= 0]["total"].sum()

html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>回测体检报告 2026-09-21</title>
<style>
:root{{--bg:#faf9f6;--card:#fff;--fg:#1c1c1a;--mut:#6b6a65;--bd:#e3e1da;--pos:#c0392b;--neg:#2e7d32;--warn:#8a6d18;}}
@media (prefers-color-scheme:dark){{:root{{--bg:#1b1b19;--card:#232320;--fg:#f0efe9;--mut:#9b9a93;--bd:#3a3a35;--pos:#e8695a;--neg:#6bbf6f;--warn:#d0b055;}}}}
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 20px 64px;background:var(--bg);color:var(--fg);
font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;font-size:14px;line-height:1.65}}
.wrap{{max-width:900px;margin:0 auto}}
h1{{font-size:20px;font-weight:500;margin:0 0 4px}}
.sub{{color:var(--mut);font-size:13px;margin-bottom:28px}}
h2{{font-size:15px;font-weight:500;margin:34px 0 12px;padding-bottom:6px;border-bottom:1px solid var(--bd)}}
h3{{font-size:14px;font-weight:500;margin:20px 0 8px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}}
.mc{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px 16px}}
.mc .k{{font-size:12px;color:var(--mut)}}
.mc .v{{font-size:22px;font-weight:500;margin:2px 0}}
.mc .s{{font-size:12px;color:var(--mut)}}
table{{width:100%;border-collapse:collapse;font-size:13px;background:var(--card);
border:1px solid var(--bd);border-radius:10px;overflow:hidden;table-layout:fixed}}
th,td{{padding:7px 10px;text-align:left;border-bottom:1px solid var(--bd)}}
th{{font-weight:500;font-size:12px;color:var(--mut)}}
tr:last-child td{{border-bottom:none}}
.num{{text-align:right;font-variant-numeric:tabular-nums}}
.nm{{font-family:ui-monospace,Consolas,monospace;font-size:12px}}
.bar{{height:9px;border-radius:2px}}
.bar.pos{{background:var(--pos)}}.bar.neg{{background:var(--neg)}}
.box{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px 18px;margin:12px 0}}
.box.warn{{border-color:var(--warn)}}
ul{{margin:6px 0 0;padding-left:20px}}li{{margin-bottom:4px}}
code{{font-family:ui-monospace,Consolas,monospace;font-size:12px;background:var(--bg);
padding:1px 5px;border-radius:4px;border:1px solid var(--bd)}}
.hl{{color:var(--pos)}}.hl2{{color:var(--neg)}}
</style></head><body><div class="wrap">
<h1>回测体检报告</h1>
<div class="sub">2026-09-21 · 数据窗口 {T['_batch'].min()}–{T['_batch'].max()} · {len(T)} 笔成交 / {S['_batch'].nunique()} 个信号日 · 只读诊断，未改任何生产代码</div>

<h2>一、先看结论</h2>
<div class="grid">
{cards([
 ("笔均收益", f"{r.mean():+.2f}%", f"95%CI [{ci[0]:+.2f}%, {ci[1]:+.2f}%] · σ={sd:.2f}%"),
 ("胜率", f"{100*(r>0).mean():.1f}%", f"均盈 +{r[r>0].mean():.2f}% / 均亏 {r[r<0].mean():.2f}%"),
 ("组合收益", f"{Sc['total_return'].mean():+.2f}%", f"{n_batch_done} 个已走完批次的均值"),
 ("同期沪深300", f"{Sc['bench_return'].mean():+.2f}%", "同批次 bench_return 均值"),
 ("敞口调整后超额", f"{Sc['excess_return'].mean():+.2f}pp", "扣掉平均闲置现金后的真实超额"),
 ("平均现金占比", f"{Sc['cash_pct'].mean():.0f}%", "组合长期只用了六成资金"),
 ("出场净额", f"{r.sum():+.0f} 点", f"止盈 +{pos_sum:.0f} vs 亏损 {neg_sum:.0f}"),
 ("样本量", f"{n} 笔", f"检出 1%/笔 edge 需 ≈{int((1.96*sd/1.0)**2)+1} 笔"),
])}
</div>
<div class="box warn">
<b>最重要的一句话：以现有 {n} 笔，笔均收益与 0 在统计上不可区分（95% 置信区间横跨零点）。</b>
单批次均值在 {T.groupby('_batch')['return_pct'].mean().min():+.2f}% ~ {T.groupby('_batch')['return_pct'].mean().max():+.2f}% 之间跳动、单批仅 3–11 笔——
用这个样本量判「策略好坏」本身不成立。下面四层归因给出的是<b>方向</b>，不是定论。
</div>

<div class="box">
<b>关于「跑赢还是跑输」：基准口径决定答案，先看这个再谈成败。</b><br>
同一批数据、按 <code>Multi-Backtest-*-summary.csv</code> 的满仓口径：
组合 <b>{Sc['total_return'].mean():+.2f}%</b> vs 基准 <b>{Sc['bench_return'].mean():+.2f}%</b>
→ 差 <b>{Sc['total_return'].mean()-Sc['bench_return'].mean():+.2f}pp</b>。<br>
但组合平均有 <b>{Sc['cash_pct'].mean():.0f}%</b> 时间空仓，按实际敞口调整后的基准是
<b>{Sc['bench_return_exposed'].mean():+.2f}%</b> → 超额变成
<b class="hl2">{Sc['excess_return'].mean():+.2f}pp</b>（反而落后）。<br>
而网站 <code>/api/backtests/daily-summary</code> 用沪深300序列自己重算窗口，得出基准
<b>-1.94%</b>、超额 <b class="hl">+1.09%</b>。<br>
⇒ 同一个「超额」可以是 +1.09pp / +0.13pp / -0.34pp，全看口径。
<b>结论：当前不构成可靠超额，且三个口径应当先统一。</b>
</div>

<h2>二、出场结构：利润被哪一类出口吃掉</h2>
<table><thead><tr><th>出场原因</th><th class="num">笔数</th><th class="num">均值</th>
<th class="num">胜率</th><th class="num">总贡献</th><th>占比</th></tr></thead>
<tbody>{''.join(exit_rows)}</tbody></table>
<div class="box">
四类止盈出口合计 <b class="hl">+{pos_sum:.0f} 点</b>（且每一笔止盈都是赚的），
但三类亏损出口 <b class="hl2">{neg_sum:.0f} 点</b>把它们抹平 —— 净额只有 <b>{r.sum():+.0f} 点</b>。<br>
<span class="hl2">56 笔趋势破位胜率仅 14%</span>、<b>5 笔硬止损均值 -18.8%</b>（最差单笔 -33.5%）是主要出血点。
</div>

<h2>三、持有期：alpha 只活在进场后 1–3 天</h2>
{table(["持有天数","笔数","平均收益"],
       [[str(k), int(v["n"]), f'{v["mean"]:+.2f}%'] for k, v in hold_tbl.iterrows()])}
<div class="box">
相关(持有天数, 收益) = <b>{hb['_hold'].corr(hb['return_pct']):+.2f}</b>。
1–3 天为正、6 天以上全面转负，而系统的持有设计是 <code>hold_days=12</code>
——把短命 alpha 一直持有到变成负 alpha。
</div>

<h2>四、仓位分配：押得越重，事后越差</h2>
{table(["口径","平均收益"],
       [["下注最轻的 1/4 分位（≤ %.0f 元）" % q_lo, f"{v_lo:+.2f}%"],
        ["等权口径（每笔同金额）", f"{eq:+.2f}%"],
        ["实际回测（按模型权重加权）", f"{w_mean:+.2f}%"],
        ["下注最重的 1/4 分位（≥ %.0f 元）" % q_hi, f"{v_hi:+.2f}%"]])}
<div class="box">
corr(下注金额, 收益) = <b>{corr_v:+.2f}</b>（t = {corr_v*math.sqrt(n-2)/math.sqrt(1-corr_v**2):+.2f}）<br>
逐批次配对：均值 <b>{D.mean():+.2f}pp</b>、t = <b>{tstat:+.2f}</b>、
{neg}/{len(D)} 个批次「加权 &lt; 等权」、符号检验 p = <b>{pv:.3f}</b> → <b>显著</b>。<br>
去混淆后仍成立（股价四分位内、金额四分位内的相关都为负）。<br>
<span style="color:var(--mut)">但模型「计划权重」与收益相关仅 {score_tbl.get('权重',(0,))[0]:+.2f}
→ 有信息的是<b>选股</b>，不是<b>分配</b>；问题出在分配与执行层（含一手取整）。</span>
</div>

<h2>五、模型自己的分数有没有预测力</h2>
{table(["字段","与收益相关","四分位平均收益（低 → 高）","判断"],
       [[c, f"{v[0]:+.3f}", " → ".join(f"{x:+.2f}%" for x in v[1]),
         "单调，弱有效" if v[1] == sorted(v[1]) else "非单调，无信息"]
        for c, v in score_tbl.items()])}
<div class="box">
<b>综合评分是唯一方向正确的排序信号</b>（最低档亏、最高档赚）；
但 <b>命中策略数相关 ≈ 0</b>：单日分布 {{1 个策略: 171, 2: 16, 3: 8, 4: 2}} ——
<b>87% 的候选只命中 1 个策略</b>，所谓「多因子融合」实际退化成了单因子选股，没有共识加成。
</div>

<h2>六、展示层（与策略无关，但影响你看到的数字）</h2>
<ul>
<li><code>stock_data/web_data/backtests_latest.json</code> = <code>{{"latest": null}}</code>
（本地与 master 一致），master 上该文件停更于 <b>09-15</b>，而 <code>daily_summary.json</code> 更新到 09-20
→ <b>网站「回测」Tab 首屏是空的</b>。</li>
<li>本地 <code>web_data/*.json</code> 是过期快照（<code>portfolio.json</code> 里持仓仍是 002284 800 股 @13.53）。</li>
<li>本地仓库无 <code>.git</code>：判断「CI 还在不在产出」必须查远端
<code>git/trees/master?recursive=1</code>（远端 DAL 到 20260918）。</li>
<li><code>archive/backtest_v1/</code> 里 83 个旧 trades 属旧代码时代，统计时必须排除。</li>
</ul>

<h2>七、建议的处置顺序</h2>
<ul>
<li><b>P0 · 出场逻辑</b>：单独审计 <code>trend_break</code> 与 <code>stop_hard</code> ——
止损是否挂在盘中可成交价、是否有滑点/跳空保护；56 笔胜率 14% 的出口不该保留。</li>
<li><b>P1 · 持有期</b>：把 <code>hold_days</code> 从 12 下调并做 1/3/5/8/12 的网格对比
（现有数据已强烈指向短持有）。</li>
<li><b>P1 · 仓位分配</b>：先做「等权 vs 现状」的 A/B；若等权更优，则冻结权重倾斜。</li>
<li><b>P2 · 因子覆盖</b>：87% 单策略命中说明融合没生效，查 12 因子的信号产出率与去相关。</li>
<li><b>P2 · 展示层</b>：修 <code>/api/backtests/latest</code> 让回测 Tab 有内容。</li>
<li><b>前提</b>：以上结论需 ≥ 200–300 笔才可置信。当前 {n} 笔只够指出方向。</li>
</ul>
</div></body></html>"""

OUT.write_text(html, encoding="utf-8")
print("WROTE", OUT)
print(f"n={n} mean={r.mean():+.3f} ci={ci} sd={sd:.2f}")
print(f"eq={eq:+.3f} w={w_mean:+.3f} corr_v={corr_v:+.3f}")
print(f"paired mean={D.mean():+.3f} t={tstat:+.2f} neg={neg}/{len(D)} p={pv:.4f}")
print(f"exit pos={pos_sum:.1f} neg={neg_sum:.1f}")
print("score_tbl:", {k: v[0] for k, v in score_tbl.items()})
