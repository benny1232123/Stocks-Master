# -*- coding: utf-8 -*-
"""mask A/B 汇总（从已落盘的 DAL 现算，不重跑融合）。修正了 fwd() 的越界判断。"""
import glob
import re
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
SD = ROOT / "stock_data"
AB = ROOT / ".workbuddy" / "mask_ab"
OUT = ROOT / ".workbuddy" / "_mask_ab_summary.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


D0, D1 = pd.Timestamp("2026-08-10"), pd.Timestamp("2026-10-10")
parts = []
for f in sorted((SD / "k_data").glob("*.parquet")):
    d = pd.read_parquet(f, columns=["code", "date", "open", "close"])
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d[(d["date"] >= D0) & (d["date"] <= D1)]
    if not d.empty:
        parts.append(d)
K = pd.concat(parts, ignore_index=True)
K["code"] = K["code"].astype(str).str.zfill(6)
CAL = sorted(K["date"].dropna().unique())
OPEN = K.pivot_table(index="date", columns="code", values="open", aggfunc="last")
CLOSE = K.pivot_table(index="date", columns="code", values="close", aggfunc="last")
IDX = {pd.Timestamp(d).strftime("%Y%m%d"): i for i, d in enumerate(CAL)}
p(f"交易日历 {len(CAL)} 天：{CAL[0].date()} ~ {CAL[-1].date()}")


def fwd(day, h, codes):
    ei = IDX.get(day)
    if ei is None or ei + 1 + h >= len(CAL):        # ← 修正：含 entry 那一格
        return pd.Series(dtype=float)
    o, c = OPEN.iloc[ei + 1], CLOSE.iloc[ei + 1 + h]
    cc = [str(x).zfill(6) for x in codes]
    o, c = o.reindex(cc), c.reindex(cc)
    m = o.notna() & c.notna() & (o > 0)
    return ((c[m] / o[m] - 1) * 100).astype(float)


def mkt(day, h):
    ei = IDX.get(day)
    if ei is None or ei + 1 + h >= len(CAL):
        return None
    o, c = OPEN.iloc[ei + 1], CLOSE.iloc[ei + 1 + h]
    m = o.notna() & c.notna() & (o > 0)
    return float(((c[m] / o[m] - 1) * 100).mean()) if m.any() else None


ARMS = ("mask_on", "mask_off")
store = {}
for arm in ARMS:
    dfs = {}
    for f in sorted(glob.glob(str(AB / arm / "Daily-Action-List-*.csv"))):
        day = re.search(r"(\d{8})", Path(f).name).group(1)
        d = pd.read_csv(f, dtype=str)
        if d.empty:
            continue
        d["code"] = d["股票代码"].astype(str).str.zfill(6)
        dfs[day] = d
    store[arm] = dfs
    p(f"  [{arm}] {len(dfs)} 天")

p("")
p("=" * 96)
p("DAL 等权组合前向收益（口径 = 信号日次日开盘买 → 持有 H 日收盘卖；全市场等权为基准）")
p("=" * 96)
p(f"  {'arm':<10}{'H':>4}{'天数':>6}{'绝对均%':>10}{'超额均%':>11}{'胜率%':>8}{'最差%':>9}")
for arm in ARMS:
    for h in (1, 2, 3, 5):
        a_, e_ = [], []
        for day, df in store[arm].items():
            r = fwd(day, h, list(df["code"]))
            mk = mkt(day, h)
            if r.empty or mk is None:
                continue
            a_.append(r.mean())
            e_.append(r.mean() - mk)
        if a_:
            p(f"  {arm:<10}{h:>4}{len(a_):>6}{np.mean(a_):>10.2f}{np.mean(e_):>11.2f}"
              f"{100*np.mean([x > 0 for x in a_]):>8.1f}{np.min(a_):>9.2f}")

p("")
p("=" * 96)
p("逐日配对（mask_off − mask_on，同信号日）")
p("=" * 96)
for h in (1, 2, 3, 5):
    rows = []
    for day in sorted(store["mask_on"]):
        if day not in store["mask_off"]:
            continue
        ra = fwd(day, h, list(store["mask_on"][day]["code"]))
        rb = fwd(day, h, list(store["mask_off"][day]["code"]))
        if ra.empty or rb.empty:
            continue
        rows.append((day, ra.mean(), rb.mean(), rb.mean() - ra.mean()))
    if not rows:
        continue
    D = pd.DataFrame(rows, columns=["day", "on", "off", "d"])
    t = D["d"].mean() / (D["d"].std() / np.sqrt(len(D))) if D["d"].std() else float("nan")
    p(f"  H={h}  n={len(D)}  均值Δ={D['d'].mean():+.3f}pp  t={t:+.2f}  "
      f"off更好 {int((D['d']>0).sum())} / 更差 {int((D['d']<0).sum())}")
    if h == 1:
        p("    " + D.round(2).to_string(index=False).replace("\n", "\n    "))

p("")
p("=" * 96)
p("构成对照（每日单策略命中数，两 arm 均 50 行/天）")
p("=" * 96)
from collections import Counter  # noqa: E402
EDGE = {"Skew60": 6.70, "VRatio10_60": 4.76, "CVAmt60": 2.54, "VRatio20_120": 1.65,
        "Vol20": 0.82, "PVCorr20": 0.18, "DistLo10": -1.31, "Skew20": -1.72,
        "CVAmt20": -3.76, "PVCorr60": -10.72, "Illiq20": -9.90, "DistLo60": 0.0}
tab = {}
for arm in ARMS:
    c = Counter()
    nday = len(store[arm])
    for day, df in store[arm].items():
        if "来源策略" in df.columns:
            for v in df["来源策略"].astype(str):
                if "/" not in v:
                    c[v] += 1
    tab[arm] = {k: v / nday for k, v in c.items()}
p(f"  {'因子':<15}{'实测edge':>9}{'mask_on/天':>11}{'mask_off/天':>12}{'倍数':>8}")
for k in sorted(set(tab['mask_on']) | set(tab['mask_off']), key=lambda x: -EDGE.get(x, 0)):
    a = tab["mask_on"].get(k, 0)
    b = tab["mask_off"].get(k, 0)
    p(f"  {k:<15}{EDGE.get(k, float('nan')):>9.2f}{a:>11.2f}{b:>12.2f}"
      f"{(b/a if a else float('inf')):>8.2f}")

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
