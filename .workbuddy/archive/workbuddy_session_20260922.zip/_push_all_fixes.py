"""推送「全部修复」。

⚠️ token scope = gist/read:org/repo，**没有 workflow** → 任何引用
`.github/workflows/*` 的 tree 都会被 GitHub 拒绝（返回 404）。
故先推 5 个非 workflow 文件（含 CRITICAL 崩溃修复），再单独试 workflow。
"""
import base64
import json
import pathlib
import subprocess
import sys

REPO = "benny1232123/Stocks-Master"
ROOT = pathlib.Path(__file__).resolve().parents[1]

PY_FILES = [
    "smcore/config/defaults.py",
    "smcore/analysis.py",
    "scripts/notify_holdings_analysis.py",
    "scripts/prepull_klines.py",
    "scripts/refresh_fundamentals.py",
]
WF = ".github/workflows/daily-holdings.yml"

MSG = (
    "fix(holdings): 修持仓日报崩溃 + 现金口径 + 纯技术面标注 + 定向刷新脚本\n\n"
    "1) CRITICAL: notify_holdings_analysis.main() 在「边分析边渲染」循环里引用循环后\n"
    "   才赋值的 portfolio_value -> 首只票即 UnboundLocalError，整份持仓日报崩溃\n"
    "   (a6bb619 引入)。改为两段式：先逐只分析 -> 汇总求分母 -> 再统一渲染，\n"
    "   渲染顺序与 FIFO 输出一致（失败卡片不再被提前）。\n"
    "2) 现金口径：POSITION_SIZING_CONFIG 新增 account_cash / account_cash_pct，\n"
    "   支持 ACCOUNT_CASH 环境变量。分母 = 持仓市值 + 现金，避免各票权重和约 100%\n"
    "   导致全员超配减仓；未配置时报告显式提示修正方法。\n"
    "3) 纯技术面标注：新增 smcore.analysis.fundamentals_available() 作为 hasF 单一判据，\n"
    "   缺基本面缓存的票在 MD/HTML 标注「纯技术面」（综合分=技术面单维）。\n"
    "4) prepull_klines.py 新增 --from-holdings：定向刷新 + 逐只复核信号日 bar，\n"
    "   全部缺则 exit 1（把抓到旧 bar 的静默失真变成显式失败）。\n"
    "5) refresh_fundamentals.py 新增 --from-holdings / --codes（定向 best-effort，\n"
    "   失败不阻塞日报）。\n\n"
    "注：daily-holdings.yml 的 CI 接线需 workflow scope，另行提交。\n"
)


def gh(args, payload=None):
    cmd = ["gh", "api"] + args
    inp = None
    if payload is not None:
        cmd += ["--input", "-"]
        inp = json.dumps(payload)
    r = subprocess.run(cmd, input=inp, capture_output=True, text=True, cwd=str(ROOT))
    return r


def jget(args):
    r = gh(args)
    if r.returncode != 0:
        print("FAIL read:", args, r.stderr.strip()[:300])
        sys.exit(1)
    return json.loads(r.stdout)


head = jget([f"repos/{REPO}/git/ref/heads/master"])["object"]["sha"]
base = jget([f"repos/{REPO}/git/commits/{head}"])["tree"]["sha"]
print("remote head:", head)
print("base tree  :", base)

entries = []
for p in PY_FILES:
    text = (ROOT / p).read_text(encoding="utf-8")
    b = json.loads(gh([f"repos/{REPO}/git/blobs", "--method", "POST"],
                      {"content": text, "encoding": "utf-8"}).stdout)["sha"]
    entries.append({"path": p, "mode": "100644", "type": "blob", "sha": b})
    print("  blob", p, "->", b[:10])

r = gh([f"repos/{REPO}/git/trees", "--method", "POST"], {"base_tree": base, "tree": entries})
if r.returncode != 0:
    print("FAIL trees:", r.stdout.strip()[:300])
    sys.exit(1)
new_tree = json.loads(r.stdout)["sha"]

r = gh([f"repos/{REPO}/git/commits", "--method", "POST"],
       {"message": MSG, "tree": new_tree, "parents": [head]})
if r.returncode != 0:
    print("FAIL commit:", r.stdout.strip()[:300])
    sys.exit(1)
new_sha = json.loads(r.stdout)["sha"]

r = gh([f"repos/{REPO}/git/refs/heads/master", "--method", "PATCH"],
       {"sha": new_sha, "force": False})
if r.returncode != 0:
    print("FAIL ref:", r.stdout.strip()[:300])
    sys.exit(1)
print("PUSH_OK", new_sha)

# ── workflow 单独尝试（Contents API）──
wf_text = (ROOT / WF).read_text(encoding="utf-8")
r = gh([f"repos/{REPO}/contents/{WF}", "--method", "PUT"],
       {"message": "ci(holdings): 加 K 线新鲜度门控 + 定向刷新 + 基本面刷新步骤",
        "content": base64.b64encode(wf_text.encode("utf-8")).decode("ascii"),
        "branch": "master"})
print("WORKFLOW_PUSH rc =", r.returncode)
print("  out:", r.stdout.strip()[:300])
print("  err:", r.stderr.strip()[:300])
