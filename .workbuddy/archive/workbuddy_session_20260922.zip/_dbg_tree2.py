"""二分定位 create-tree 的 404：base_tree 还是某个 blob？"""
import json
import subprocess

REPO = "benny1232123/Stocks-Master"


def gh(args, payload=None, label=""):
    cmd = ["gh", "api"] + args
    inp = None
    if payload is not None:
        cmd += ["--input", "-"]
        inp = json.dumps(payload)
    r = subprocess.run(cmd, input=inp, capture_output=True, text=True)
    tag = "OK " if r.returncode == 0 else "ERR"
    msg = (r.stdout.strip() or r.stderr.strip())[:120]
    print(f"[{tag}] {label}: {msg}")
    return r


head = json.loads(gh([f"repos/{REPO}/git/ref/heads/master"]).stdout)["object"]["sha"]
base = json.loads(gh([f"repos/{REPO}/git/commits/{head}"]).stdout)["tree"]["sha"]
rb = json.loads(gh([f"repos/{REPO}/contents/Readme.md"]).stdout)["sha"]
print("base tree:", base, "| readme blob:", rb[:10])

one_rd = [{"path": "Readme.md", "mode": "100644", "type": "blob", "sha": rb}]

gh([f"repos/{REPO}/git/trees", "--method", "POST"],
   {"base_tree": base, "tree": one_rd}, "T1 base_tree + 1 entry")

# 逐文件建 blob，再累积测试
FILES = [
    "smcore/config/defaults.py",
    "smcore/analysis.py",
    "scripts/notify_holdings_analysis.py",
    "scripts/prepull_klines.py",
    "scripts/refresh_fundamentals.py",
    ".github/workflows/daily-holdings.yml",
]
entries = []
for p in FILES:
    text = open(f"E:/Stocks-Master/{p}", encoding="utf-8").read()
    b = json.loads(gh([f"repos/{REPO}/git/blobs", "--method", "POST"],
                      {"content": text, "encoding": "utf-8"}).stdout)["sha"]
    entries.append({"path": p, "mode": "100644", "type": "blob", "sha": b})
    r = gh([f"repos/{REPO}/git/trees", "--method", "POST"],
           {"base_tree": base, "tree": entries}, f"cumulative n={len(entries)} ({p})")
