# -*- coding: utf-8 -*-
"""止损口径统一 · 变更报告（自包含 HTML，A/B 数字现场从 stop_ab/ 现算）。"""
import glob
import math
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
AB = ROOT / ".workbuddy" / "stop_ab"
OUT = ROOT / ".workbuddy" / "stop_unify_20260921.html"

res, exits = {}, {}
for arm in ("stop_dal", "stop_legacy"):
    d = AB / arm
    per, dd = {}, {}
    for f in sorted(glob.glob(str(d / "Multi-Backtest-*-equity.csv"))):
        tag = Path(f).name[len("Multi-Backtest-"):-len("-equity.csv")]
        try:
            e = pd.read_csv(f)
        except Exception:
            continue
        if e.empty or "total" not in e.columns:
            continue
        e["total"] = pd.to_numeric(e["total"], errors="coerce").dropna()
        if e.empty:
            continue
        per[tag] = float(e["total"].iloc[-1]) / 100000.0 - 1
        if "drawdown" in e.columns:
            dd[tag] = float(pd.to_numeric(e["drawdown"], errors="coerce").min())
    res[arm] = (pd.Series(per) * 100, pd.Series(dd))
    tl = []
    for f in sorted(glob.glob(str(d / "Multi-Backtest-*-trades.csv"))):
        try:
            t = pd.read_csv(f, dtype=str)
        except Exception:
            continue
        if not t.empty and "return_pct" in t.columns:
            tl.append(t)
    T = pd.concat(tl, ignore_index=True) if tl else pd.DataFrame()
    if not T.empty:
        T["return_pct"] = pd.to_numeric(T["return_pct"], errors="coerce")
        exits[arm] = T.groupby("exit_reason")["return_pct"].agg(n="count", mean="mean")

a, b = res["stop_dal"][0], res["stop_legacy"][0]
j = pd.concat([a.rename("dal"), b.rename("legacy")], axis=1).dropna()
dd = j["dal"] - j["legacy"]
t = dd.mean() / (dd.std() / math.sqrt(len(dd))) if dd.std() else float("nan")


def tbl(head, rows_):
    th = "".join(f"<th>{h}</th>" for h in head)
    tr = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows_)
    return f"<table><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table>"


sum_rows = []
for arm, label in (("stop_dal", "修复后（透传 DAL · boll 口径）"),
                   ("stop_legacy", "修复前（就地重算 8×σ）")):
    r, d = res[arm]
    hl = ' style="background:rgba(127,127,127,.10)"' if arm == "stop_legacy" else ""
    sum_rows.append([f'<span{hl}>{label}</span>', len(r), f"{r.mean():+.3f}", f"{r.median():+.3f}",
                     f"{int((r > 0).sum())}/{len(r)}", f"{r.min():+.2f}", f"{d.mean():+.3f}"])

ex_rows = []
for arm, label in (("stop_dal", "修复后"), ("stop_legacy", "修复前")):
    g = exits.get(arm)
    if g is None:
        continue
    for k, v in g.sort_values("n", ascending=False).iterrows():
        ex_rows.append([label, k, int(v["n"]), f"{v['mean']:+.2f}%"])

html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>止损口径统一 2026-09-21</title>
<style>
:root{{--bg:#faf9f6;--card:#fff;--fg:#1c1c1a;--mut:#6b6a65;--bd:#e3e1da;--g:#c0392b;--b:#2e7d32;--w:#8a6d18;}}
@media (prefers-color-scheme:dark){{:root{{--bg:#1b1b19;--card:#232320;--fg:#f0efe9;--mut:#9b9a93;--bd:#3a3a35;--g:#e8695a;--b:#6bbf6f;--w:#d0b055;}}}}
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 20px 64px;background:var(--bg);color:var(--fg);font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;font-size:14px;line-height:1.65}}
.wrap{{max-width:940px;margin:0 auto}}
h1{{font-size:20px;font-weight:500;margin:0 0 4px}}
.sub{{color:var(--mut);font-size:13px;margin-bottom:24px}}
h2{{font-size:15px;font-weight:500;margin:32px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--bd)}}
table{{width:100%;border-collapse:collapse;font-size:13px;background:var(--card);border:1px solid var(--bd);border-radius:10px;overflow:hidden}}
th,td{{padding:7px 10px;text-align:left;border-bottom:1px solid var(--bd)}}
th{{font-weight:500;font-size:12px;color:var(--mut)}}
tr:last-child td{{border-bottom:none}}
td:nth-child(n+2){{font-variant-numeric:tabular-nums;text-align:right}}
.box{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px 18px;margin:12px 0}}
.box.warn{{border-color:var(--w)}}
ul{{margin:6px 0 0;padding-left:20px}}li{{margin-bottom:5px}}
code{{font-family:ui-monospace,Consolas,monospace;font-size:12px;background:var(--bg);padding:1px 5px;border-radius:4px;border:1px solid var(--bd)}}
.g{{color:var(--g)}}.b{{color:var(--b)}}
.flow{{display:flex;flex-wrap:wrap;gap:8px;align-items:center;font-size:12.5px;margin:8px 0}}
.flow span{{background:var(--bg);border:1px solid var(--bd);border-radius:6px;padding:4px 9px}}
</style></head><body><div class="wrap">
<h1>止损口径统一为单一真源</h1>
<div class="sub">2026-09-21 · commit <code>42cb6f7d</code> · 文件：<code>scripts/daily_backtest.py</code>
+ 新增 <code>tests/test_stop_source_unified.py</code>（11 项守卫）</div>

<h2>一、问题</h2>
<div class="box warn">
清单 / 网站 / <code>PositionMonitor</code> 用的逐只止损，来自 fusion 写入 DAL 的
<code>stop_pct</code> 列，唯一计算处是 <code>boll_levels.py</code>
= <code>clamp(2.5 × 日σ, 4%, 12%)</code>。<br>
但 <code>daily_backtest.py</code> 又<b>就地重算</b>成 <code>clamp(8 × 日σ, 6%, 15%)</code>
并覆盖该列 —— 实测 <b>120/120 笔两套止损都不相等</b>（中位 <b>5.45%</b> vs <b>15.00%</b>，
平均差 <b>+4.74pp</b>）。<br>
⇒ 你在清单/网站上看到的「止损价」，<b>不是</b>回测与实盘监控真正执行的止损。
更讽刺的是 <code>fusion.py</code> 的注释写着「引擎 stop_pct 列优先」—— 设计意图本就是同源，
回测这行重算属于实现偏离。
</div>

<h2>二、修复后的数据流（单一真源）</h2>
<div class="flow">
<span><code>risk_config.json::boll</code><br>mult 2.5 / [4%, 12%]</span><span>→</span>
<span><code>boll_levels._compute_boll_levels</code><br>唯一计算处</span><span>→</span>
<span><code>fusion.py</code> 写 <code>DAL.stop_pct</code></span><span>→</span>
<span><code>PositionMonitor</code> 读 DAL</span><span>+</span>
<span><code>daily_backtest</code> 读 DAL（本次修复）</span>
</div>
<div class="box">
回测新增纯函数 <code>_resolve_stops(dal_values, codes, lv_get, source="dal")</code>：
默认<b>原样透传</b> DAL 值；DAL 缺值时按同一个 <code>boll_levels</code> 口径就地补算 —— 仍然单一真源。<br>
旧口径只保留在 <code>BACKTEST_STOP_SOURCE=legacy</code> 下，用于复现历史结果与参数实验；
<code>VOL_STOP_MULT</code> 常量继续导出（<code>historical_backtest*</code> / <code>param_scan</code> 仍 import）但已标注 DEPRECATED。
</div>

<h2>三、实测影响（16 信号日，hold=12、出场全开，唯一差异 = 止损来源）</h2>
{tbl(["方案", "批次", "批均%", "批中位%", "正收益批次", "最差%", "平均回撤%"], sum_rows)}
<div class="box">
配对检验：Δ = <b>{dd.mean():+.3f}pp</b>，t = <b>{t:+.2f}</b>，胜/负 {int((dd>0).sum())}/{int((dd<0).sum())}
⇒ <b>组合层面中性</b>。<br>
<b>但止损行为变化很大</b>：单笔止损均值从 <b class="b">-18.8%</b> 收窄到
<b class="g">-8.1%</b>，而触发次数从 <b>5 次</b>增加到 <b>26 次</b> ——
更紧的止损亏得更少，但被洗得更频繁，两者基本抵消。<br>
<span style="color:var(--mut)">所以这是一次<b>一致性修复</b>，不是收益优化。
它的价值在于：回测现在真正模拟了「你被告知要用的那个止损」。</span>
</div>

<h2>四、出场构成对比</h2>
{tbl(["方案", "出场原因", "笔数", "单笔均值"], ex_rows)}

<h2>五、⚠️ 需要知道的副作用</h2>
<ul>
<li><b>历史 Multi-Backtest 产物是旧口径（15%）跑出来的</b>：仓库里 09-18 及以前的
<code>Multi-Backtest-*.csv</code> 与新口径不可比。回测面板会在一段时间内<b>混着两种止损口径</b>，
直到历史信号日被重跑（仓库有 <code>scripts/rerun_backtest_history.py</code> 可全量重建）。</li>
<li>回测的止损<b>胜率会下降、交易更频繁</b>（26 次 vs 5 次），这是紧止损的必然结果，不是 bug。</li>
<li><code>scripts/historical_backtest*.py</code>（产出 <code>Historical-Backtest-*.csv</code>）
<b>不在 CI 里</b>，本次未改；它们仍会用旧口径，若那些产物还要用需单独对齐。</li>
</ul>

<h2>六、守卫测试（<code>tests/test_stop_source_unified.py</code>，11 项）</h2>
<ul>
<li>DAL 值原样透传（含 <code>None</code> / <code>NaN</code> / 字符串数字的逐位回退）。</li>
<li><b>dal 源下即使存在 vol20 也不得应用 VOL_STOP_MULT</b>（本次修复的核心不变式）。</li>
<li>legacy 源仍复现旧上下限 [6%, 15%]，且 <code>VOL_STOP_MULT == 8.0</code>。</li>
<li>默认 env 必须是 <code>dal</code>；<code>risk_config.json::boll</code> 三个参数仍是唯一配置入口。</li>
<li><code>fusion.py</code> 写 DAL、<code>daily_backtest</code> 读 DAL 的接线未断，且 summary 记录 <code>stop_mode</code>。</li>
</ul>
<div class="box">再次分叉时这套测试会立刻变红 —— 这是防止「两套止损」事故复发的机制化保障。</div>
</div></body></html>"""

OUT.write_text(html, encoding="utf-8")
print("WROTE", OUT)
print(f"dal={a.mean():+.3f} legacy={b.mean():+.3f} delta={dd.mean():+.3f} t={t:+.2f}")
