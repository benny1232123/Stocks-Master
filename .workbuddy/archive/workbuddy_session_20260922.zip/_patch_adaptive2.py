# -*- coding: utf-8 -*-
"""改回「复用 portfolio.py 组合优化层」而不是自造波动率倾斜。断言命中恰好 1 次。"""
import pathlib
import sys

ROOT = pathlib.Path(r"E:\Stocks-Master")


def patch(rel, old, new):
    p = ROOT / rel
    text = p.read_text(encoding="utf-8")
    cnt = text.count(old)
    if cnt != 1:
        print(f"!! {rel}: 期望命中 1 次，实际 {cnt} 次 -- 中止")
        sys.exit(1)
    p.write_text(text.replace(old, new), encoding="utf-8")
    print(f"OK  {rel}  (1 处)")


# ==================== defaults.py ====================
patch(
    "smcore/config/defaults.py",
    '''        # 个股权重波动率倾斜：复用 risk_config.json 的 vol_target（低波动多配、高波动少配）
        "vol_tilt": True,
        "vol_window": 20,
        "vol_scale_bounds": [0.5, 2.0],   # 归一化后的倾斜系数上下限，防单票吃掉仓位''',
    '''        # 个股权重分配方法（**复用 smcore/strategy/portfolio.py**，与选股清单同一条实现）：
        #   "risk_parity_erc" → w ∝ 1/σ（**默认**：只调风险、不掺观点，保持「仓位层与研判层正交」）
        #   "equal_weight"    → 等权
        #   "score_weighted"  → w ∝ score^power（强票多配；但会把「研判观点」引进仓位层，
        #                        且最低分票可能被压到 ~0% —— 对已持仓等于强制清仓，慎用）
        #   "inherit"         → 跟随 risk_config.json 的 portfolio.method（当前为 score_weighted）
        "weight_method": "risk_parity_erc",
        "vol_window": 20,                 # 波动率估计窗口（交易日），供 ERC / 波动估计用
        # 单票权重下限（占总仓位的比例）：防止某只已持仓被算成 0% 目标（≈强制清仓）。
        # 先按下限夹取、再重新归一化，保证 Σ权重 == 1（总仓位不被下限改动）。
        "min_weight_frac": 0.05,''',
)

# ==================== analysis.py ====================
patch(
    "smcore/analysis.py",
    '''def adaptive_sizing_context(
    codes: list[str], as_of: "date | None" = None, cfg: dict | None = None
) -> dict:''',
    '''def adaptive_sizing_context(
    codes: list[str],
    as_of: "date | None" = None,
    cfg: dict | None = None,
    analyses: dict | None = None,
) -> dict:''',
)

patch(
    "smcore/analysis.py",
    '''    - **个股权重自适应**：等权 × 波动率倾斜 ``vol_target_scale(20 日年化波动)``
      （复用 risk_config.json 的 vol_target：低波动多配、高波动少配），再**按均值归一化**
      → 只做**重分配**、不改变总仓位（否则会把「择时」和「分配」两件事混在一起）。''',
    '''    - **个股权重自适应**：委托 :func:`smcore.strategy.portfolio.compute_target_weights`
      （**与选股清单同一条实现**，方法见 ``adaptive.weight_method``），返回权重和为 1 →
      只做**重分配**、不改变总仓位（否则会把「择时」和「分配」两件事混在一起）。
      再按 ``min_weight_frac`` 夹下限并重新归一化，避免把某只已持仓算成 0%（≈强制清仓）。''',
)

patch(
    "smcore/analysis.py",
    '''    - vol_scale: ``{code: 已归一化倾斜系数}``（缺数据的票为 1.0）''',
    '''    - weight_frac: ``{code: 权重占比}``（和为 1；整体退化为等权时为 1/N）
    - weight_method: 实际生效的分配方法（``inherit`` 会解析为具体方法名）
    - analyses: 可选 ``{code: analysis}``，用于给 ``score_weighted`` 提供综合分''',
)

patch(
    "smcore/analysis.py",
    '''        "vol_scale": {}, "note": "",
    }''',
    '''        "weight_frac": {}, "weight_method": None, "note": "",
    }''',
)

patch(
    "smcore/analysis.py",
    '''    # ② 波动率倾斜（按均值归一化 → 只重分配、不改总仓位）
    vol_scale: dict[str, float] = {}
    if a_cfg.get("vol_tilt", True):
        try:
            from smcore.strategy.position_sizing import _estimate_vol20
            from smcore.strategy.risk_rules import (
                compute_vol_target_params,
                vol_target_scale,
            )
            from smcore.utils.code import format_stock_code

            params = compute_vol_target_params()
            if params.get("enabled"):
                window = int(a_cfg.get("vol_window") or params.get("window") or 20)
                vols = _estimate_vol20(list(codes), window=window)
                raw = {
                    str(c): float(vol_target_scale(vols.get(format_stock_code(str(c))), params))
                    for c in codes
                }
                b2 = list(a_cfg.get("vol_scale_bounds") or [0.5, 2.0])
                cl = {c: min(max(v, float(b2[0])), float(b2[-1])) for c, v in raw.items()}
                m = (sum(cl.values()) / len(cl)) if cl else 1.0
                clamped = {c: (v / m if m > 0 else v) for c, v in cl.items()}
                # 收口后再归一化一次：保证 Σscale/N == 1，总仓位不被倾斜改动
                cv = [v for v in clamped.values() if v > 0]
                cm = (sum(cv) / len(cv)) if cv else 1.0
                vol_scale = {c: (v / cm if cm > 0 else v) for c, v in clamped.items()}
        except Exception as exc:                                 # noqa: BLE001
            out["note"] = f"波动率倾斜不可用（{type(exc).__name__}）→ 个股权重退化为等权"''',
    '''    # ② 个股权重分配：委托组合优化层（与选股清单同一条实现，全配置驱动）
    weight_frac: dict[str, float] = {}
    method = str(a_cfg.get("weight_method", "risk_parity_erc") or "risk_parity_erc")
    try:
        from smcore.strategy.portfolio import compute_target_weights
        from smcore.strategy.position_sizing import _estimate_vol20
        from smcore.strategy.risk_rules import CONFIG as _RISK_CFG
        from smcore.utils.code import format_stock_code

        pcfg = dict(_RISK_CFG.get("portfolio") or {})
        if method == "inherit":
            method = str(pcfg.get("method", "score_weighted"))
        codes6 = [format_stock_code(str(c)) for c in codes]
        scores: dict[str, float] = {}
        for c in codes:
            a = (analyses or {}).get(str(c))
            if not a or a.get("error"):
                continue
            try:
                scores[format_stock_code(str(c))] = float(
                    recommendation_from_analysis(a, cfg=RECOMMENDATION_CONFIG).get("score") or 0.0
                )
            except Exception:                                    # noqa: BLE001
                pass
        vols = _estimate_vol20(
            codes6, window=int(a_cfg.get("vol_window") or pcfg.get("window") or 20)
        )
        weight_frac = compute_target_weights(
            codes6, scores, vols,
            method=method,
            score_power=float(pcfg.get("score_power", 1.5)),
            score_floor=float(pcfg.get("score_floor", 0.0)),
            erc_max_iter=int(pcfg.get("erc_max_iter", 50)),
            risk_parity_fallback=str(pcfg.get("risk_parity_fallback", "equal_weight")),
        )
        # 下限夹取 + 重新归一化：避免把某只已持仓算成 0% 目标（≈强制清仓）
        floor = float(a_cfg.get("min_weight_frac") or 0.0)
        if weight_frac and floor > 0:
            weight_frac = {c: max(v, floor) for c, v in weight_frac.items()}
            tot = sum(weight_frac.values())
            if tot > 0:
                weight_frac = {c: v / tot for c, v in weight_frac.items()}
    except Exception as exc:                                     # noqa: BLE001
        out["note"] = f"个股权重分配不可用（{type(exc).__name__}: {exc}）→ 退化为等权"
        weight_frac = {}''',
)

patch(
    "smcore/analysis.py",
    '''        regime_strength=round(s, 2), equity_ratio=round(equity, 4),
        vol_scale=vol_scale,
    )''',
    '''        regime_strength=round(s, 2), equity_ratio=round(equity, 4),
        weight_frac=weight_frac, weight_method=method,
    )''',
)

patch(
    "smcore/analysis.py",
    '''    2. **自适应**：``adaptive.equity_ratio ÷ N × vol_scale[code]``
       （regime 定总仓位、波动率定分配）。''',
    '''    2. **自适应**：``adaptive.equity_ratio × weight_frac[code]``
       （regime 定总仓位、组合优化层定分配）。''',
)

patch(
    "smcore/analysis.py",
    '''        if ratio > 0:
            policy = ratio * 100.0 / n
            try:
                scale = float((a.get("vol_scale") or {}).get(code, 1.0) or 1.0)
            except (TypeError, ValueError):
                scale = 1.0
            return policy * scale, policy, "adaptive"''',
    '''        if ratio > 0:
            policy = ratio * 100.0 / n
            try:
                frac = float((a.get("weight_frac") or {}).get(code, 0.0) or 0.0)
            except (TypeError, ValueError):
                frac = 0.0
            # 自适应未覆盖该票（如不在 codes 里）→ 退回政策等权目标
            return (ratio * 100.0 * frac if frac > 0 else policy), policy, "adaptive"''',
)

patch(
    "smcore/analysis.py",
    '''    - adaptive: :func:`adaptive_sizing_context` 的输出。enabled 时每票目标 =
      ``equity_ratio ÷ N × vol_scale[code]``（regime 定总仓位、波动率定分配）。''',
    '''    - adaptive: :func:`adaptive_sizing_context` 的输出。enabled 时每票目标 =
      ``equity_ratio × weight_frac[code]``（regime 定总仓位、组合优化层定分配）。''',
)

# ==================== notify_holdings_analysis.py ====================
patch(
    "scripts/notify_holdings_analysis.py",
    '''        _refresh_fundamentals(codes)

        # ── 自适应仓位：regime 定总仓位 + 波动率给个股权重倾斜（一次算好、全报告共用）──
        adaptive_ctx = adaptive_sizing_context(codes, as_of=as_of_date, cfg=POSITION_SIZING_CONFIG)
        if adaptive_ctx.get("enabled"):
            _eq = float(adaptive_ctx.get("equity_ratio") or 0) * 100
            log_lines.append(
                f"自适应仓位[{adaptive_ctx.get('source')}]：市场状态 "
                f"{adaptive_ctx.get('regime')}（强度 {adaptive_ctx.get('regime_strength')}）"
                f"→ 总仓位目标 {_eq:.1f}%；个股权重按 "
                f"{len(adaptive_ctx.get('vol_scale') or {})} 只的波动率倾斜"
            )
            if adaptive_ctx.get("note"):
                log_lines.append(f"⚠️ 自适应仓位部分降级：{adaptive_ctx['note']}")
            _an = (
                f"市场状态 **{adaptive_ctx.get('regime')}**"
                f"（强度 {adaptive_ctx.get('regime_strength')}）→ 总仓位目标 **{_eq:.1f}%**；"
                f"个股权重 = 等权 × 波动率倾斜（低波动多配、高波动少配）"
            )
        else:
            log_lines.append(
                f"自适应仓位未启用 → 用静态口径（{adaptive_ctx.get('note') or '—'}）"
            )
            _an = f"静态仓位口径（自适应未启用：{adaptive_ctx.get('note') or '—'}）"
        data_warn_md += f"> 📊 **自适应仓位**：{_an}\\n\\n"
        data_warn_html += f'<div class="card"><div class="sig">📊 自适应仓位：{_an}</div></div>'

        # ── 两段式：① 先逐只分析 → ② 汇总求组合分母 → ③ 再统一渲染 ──''',
    '''        _refresh_fundamentals(codes)

        # ── 两段式：① 先逐只分析 → ② 汇总求组合分母 → ③ 再统一渲染 ──''',
)

patch(
    "scripts/notify_holdings_analysis.py",
    '''        sections: list[str] = []
        sections_html: list[str] = []
        tech_only = 0
        sizing_probe: dict | None = None   # 取首只成功票的 sizing，用于日志展示目标口径''',
    '''        # ── 自适应仓位：regime 定总仓位 + 组合优化层定个股权重 ──
        # ⚠️ 必须放在逐只分析**之后**：score_weighted 口径要用到各票综合分。
        _analyses = {e["code"]: e["analysis"] for e in entries if not e["err"]}
        adaptive_ctx = adaptive_sizing_context(
            codes, as_of=as_of_date, cfg=POSITION_SIZING_CONFIG, analyses=_analyses
        )
        if adaptive_ctx.get("enabled"):
            _eq = float(adaptive_ctx.get("equity_ratio") or 0) * 100
            log_lines.append(
                f"自适应仓位[{adaptive_ctx.get('source')}]：市场状态 "
                f"{adaptive_ctx.get('regime')}（强度 {adaptive_ctx.get('regime_strength')}）"
                f"→ 总仓位目标 {_eq:.1f}%；个股权重方法 "
                f"{adaptive_ctx.get('weight_method')}"
            )
            if adaptive_ctx.get("note"):
                log_lines.append(f"⚠️ 自适应仓位部分降级：{adaptive_ctx['note']}")
            _an = (
                f"市场状态 **{adaptive_ctx.get('regime')}**"
                f"（强度 {adaptive_ctx.get('regime_strength')}）→ 总仓位目标 **{_eq:.1f}%**；"
                f"个股权重方法 **{adaptive_ctx.get('weight_method')}**"
            )
        else:
            log_lines.append(
                f"自适应仓位未启用 → 用静态口径（{adaptive_ctx.get('note') or '—'}）"
            )
            _an = f"静态仓位口径（自适应未启用：{adaptive_ctx.get('note') or '—'}）"
        data_warn_md += f"> 📊 **自适应仓位**：{_an}\\n\\n"
        data_warn_html += f'<div class="card"><div class="sig">📊 自适应仓位：{_an}</div></div>'

        sections: list[str] = []
        sections_html: list[str] = []
        tech_only = 0
        sizing_probe: dict | None = None   # 取首只成功票的 sizing，用于日志展示目标口径''',
)

print("\n全部替换完成。")
