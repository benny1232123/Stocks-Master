"""审计全部 akshare 导入点：是否被 try 保护、是否模块级、所在文件。"""
from __future__ import annotations

import ast
import pathlib

ROOT = pathlib.Path(r"E:\Stocks-Master")
SKIP_DIRS = {"node_modules", ".git", ".git_broken_20260901", "__pycache__", "dist", ".workbuddy"}

rows: list[tuple[str, int, str, bool]] = []

for path in sorted(ROOT.rglob("*.py")):
    if any(part in SKIP_DIRS for part in path.parts):
        continue
    try:
        src = path.read_text(encoding="utf-8")
        tree = ast.parse(src)
    except (SyntaxError, UnicodeDecodeError):
        continue

    parents: dict[ast.AST, ast.AST] = {}
    for node in ast.walk(tree):
        for child in ast.iter_child_nodes(node):
            parents[child] = node

    for node in ast.walk(tree):
        names: list[str] = []
        if isinstance(node, ast.Import):
            names = [a.name.split(".")[0] for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module:
            names = [node.module.split(".")[0]]
        if "akshare" not in names:
            continue

        guarded = False
        cur: ast.AST = node
        while cur in parents:
            prev = cur
            cur = parents[cur]
            if isinstance(cur, ast.Try) and any(prev is x for x in cur.body):
                guarded = True
                break
            if isinstance(cur, (ast.FunctionDef, ast.AsyncFunctionDef)):
                break

        level = "模块级" if node.col_offset == 0 else "函数内"
        rel = str(path.relative_to(ROOT))
        rows.append((rel, node.lineno, level, guarded))

print(f"共 {len(rows)} 处 akshare 导入\n")

unguarded = [r for r in rows if not r[3]]
print(f"=== ❌ 未被 try 保护（{len(unguarded)} 处，拆分后会 ImportError）===")
for rel, ln, level, _ in unguarded:
    print(f"  {rel}:{ln}  [{level}]")

print(f"\n=== ✅ 已被 try 保护（{len(rows) - len(unguarded)} 处）===")
for rel, ln, level, _ in [r for r in rows if r[3]]:
    print(f"  {rel}:{ln}  [{level}]")
