import subprocess, json, re

out = subprocess.run(
    ["gh", "api", "repos/benny1232123/Stocks-Master/git/trees/master?recursive=1"],
    capture_output=True, text=True, timeout=120)
data = json.loads(out.stdout)
paths = [t["path"] for t in data["tree"] if t["path"].startswith("stock_data/")]

def date_of(p):
    m = re.search(r"(\d{8})", p)
    return m.group(1) if m else "00000000"

CUT = "20260827"
bt = [p for p in paths if p.startswith("stock_data/Multi-Backtest-") and date_of(p) < CUT]
dal = [p for p in paths if p.startswith("stock_data/Daily-Action-List-") and date_of(p) < CUT]
ss = [p for p in paths if "Stock-Selection" in p and date_of(p) < CUT]

print("=== 删除范围（pre-0827， date < 20260827）===")
print("Multi-Backtest 三件套文件数:", len(bt))
print("  (涉及日期数:", len({date_of(p) for p in bt}), ")")
print("Daily-Action-List 文件数:", len(dal))
print("Stock-Selection 文件数(仅供参考,未纳入本次):", len(ss))
print("本次将删除(回测+DAL):", len(bt) + len(dal))
print()
# break down backtest variants
from collections import Counter
variants = Counter()
for p in bt:
    m = re.search(r"Multi-Backtest-\d{8}-(.+)\.csv", p)
    variants[m.group(1) if m else "?"] += 1
print("回测文件按后缀:", dict(variants))
