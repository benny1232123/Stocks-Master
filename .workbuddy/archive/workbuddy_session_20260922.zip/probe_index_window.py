# -*- coding: utf-8 -*-
"""探针：对比 hithink / sina / baostock 三源沪深300 历史长度与首末日期。

只读、不写任何缓存。用于评估「指数主源改为 hithink」后历史窗口是否变短
（服务端可用历史 ≈ 2022-01 起 vs baostock 全历史 / sina datalen=320）。
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

for line in (ROOT / ".env").read_text(encoding="utf-8", errors="ignore").splitlines():
    line = line.strip()
    if line and not line.startswith("#") and "=" in line:
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())

out = []


def show(tag, s):
    if s is None:
        out.append(f"{tag}: None")
        return
    try:
        n = len(s)
        first = s.index[0]
        last = s.index[-1]
        out.append(f"{tag}: n={n} first={first} last={last} lastval={float(s.values[-1]):.2f}")
    except Exception as e:  # noqa: BLE001
        out.append(f"{tag}: ERR {e!r}")


# 1) hithink
try:
    from smcore.data import hithink as hk
    import pandas as pd
    out.append(f"hithink.available={hk.available()}")
    df = hk.fetch_index_historical("000300.SH", "2020-01-01", pd.Timestamp.today().strftime("%Y-%m-%d"))
    if df is None or df.empty:
        out.append("hithink 000300.SH: EMPTY")
    else:
        dts = pd.to_datetime(df["date"])
        out.append(f"hithink 000300.SH: n={len(df)} first={dts.iloc[0].date()} last={dts.iloc[-1].date()} lastclose={float(df['close'].iloc[-1]):.2f}")
except Exception as e:  # noqa: BLE001
    out.append(f"hithink ERR {e!r}")

# 2) sina
try:
    from smcore.strategy.market import _fetch_index_series_sina
    s = _fetch_index_series_sina("sh.000300")
    if s is None:
        out.append("sina sh.000300: None")
    else:
        out.append(f"sina sh.000300: n={len(s)} first={s.index[0].date()} last={s.index[-1].date()} lastclose={float(s['close'].iloc[-1]):.2f}")
except Exception as e:  # noqa: BLE001
    out.append(f"sina ERR {e!r}")

# 3) baostock
try:
    from smcore.strategy.market import _fetch_index_series
    s = _fetch_index_series("sh.000300")
    if s is None:
        out.append("baostock sh.000300: None")
    else:
        out.append(f"baostock sh.000300: n={len(s)} first={s.index[0].date()} last={s.index[-1].date()} lastclose={float(s['close'].iloc[-1]):.2f}")
except Exception as e:  # noqa: BLE001
    out.append(f"baostock ERR {e!r}")

# 4) 现有统一入口实际拿到什么
try:
    import smcore.strategy.market as mkt
    mkt._INDEX_SERIES_CACHE.clear()
    df = mkt._get_index_series("sh.000300")
    if df is None:
        out.append("_get_index_series: None")
    else:
        out.append(f"_get_index_series: n={len(df)} first={df.index[0].date()} last={df.index[-1].date()} lastclose={float(df['close'].iloc[-1]):.2f}")
except Exception as e:  # noqa: BLE001
    out.append(f"_get_index_series ERR {e!r}")

# 5) regime_filter 收盘 Series
try:
    import smcore.strategy.regime_filter as rf
    rf._HS300_CLOSE_CACHE = None
    rf._HS300_CACHE_DATE = None
    s = rf._get_hs300_close(use_daily_cache=False)
    if s is None:
        out.append("_get_hs300_close: None")
    else:
        out.append(f"_get_hs300_close: n={len(s)} first={s.index[0].date()} last={s.index[-1].date()} lastclose={float(s.iloc[-1]):.2f}")
    out.append(f"RS_LOOKBACK={rf.RS_LOOKBACK}")
    for d in ("2021-06-30", "2022-06-30", "2024-06-28", "2026-06-30"):
        out.append(f"  _index_20d_return({d}) = {rf._index_20d_return(d)}")
except Exception as e:  # noqa: BLE001
    out.append(f"regime ERR {e!r}")

(ROOT / ".workbuddy" / "probe_index_window.txt").write_text("\n".join(out), encoding="utf-8")
print("\n".join(out))
