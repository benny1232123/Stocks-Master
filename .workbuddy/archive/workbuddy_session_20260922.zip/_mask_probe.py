# -*- coding: utf-8 -*-
"""① 打印 factor_timing 的实际 mask / 信念 IC；② 试跑一天历史因子池生成并计时。"""
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(r"E:\Stocks-Master")
os.environ["SECTOR_MAP_ONDEMAND"] = "0"
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_mask_probe.txt"
lines = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


import importlib  # noqa: E402

kl = importlib.import_module("smcore.data.kline")


def _lf(code, start=None, end=None, *a, **k):
    import pandas as pd
    try:
        d = kl.read_kline_cache(str(code).zfill(6), base_dir=SD / "k_data")
    except Exception:
        d = None
    if d is None or getattr(d, "empty", True) or "date" not in getattr(d, "columns", []):
        return pd.DataFrame()
    d = d.copy()
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d.dropna(subset=["date"])
    if start is not None:
        d = d[d["date"] >= pd.Timestamp(start)]
    if end is not None:
        d = d[d["date"] <= pd.Timestamp(end)]
    return d.sort_values("date").reset_index(drop=True)


for mn in ("smcore.data.kline", "smcore.backtest.engine", "smcore.strategy.boll_levels",
           "smcore.strategy.factor_scoring"):
    try:
        m = importlib.import_module(mn)
        if hasattr(m, "fetch_daily_k"):
            m.fetch_daily_k = _lf
    except Exception:
        pass

import smcore.strategy.adaptive_weights as AW  # noqa: E402
import smcore.strategy.factor_timing as FT  # noqa: E402

ALL = AW.ALL_STRATEGIES
edge = AW.compute_edge(20)

p("=" * 100)
p("① factor_timing mask（当前信号日）")
p("=" * 100)
p(f"  CONFIG.factor_timing = {AW.CONFIG.get('factor_timing')}")
sd = FT.latest_signal_date()
p(f"  latest_signal_date = {sd}")
mask = FT.factor_timing_mask(sd)
p(f"  mask = {mask}")
p("")
p(f"  {'因子':<16}{'mask':>7}{'edge(n)':>14}{'窗口点数':>9}")
pts = FT.conviction_points()
prev = [d for d in FT._signal_days() if d < sd][-int(AW.CONFIG['factor_timing'].get('window', 10)):]
p(f"  窗口 {len(prev)} 天: {prev}")
for s in ALL:
    e = edge.get(s) or {}
    npts = len(pts.get(s, []))
    p(f"  {s:<16}{str(mask.get(s)):>7}{str(e.get('edge'))[:9] + '(' + str(e.get('n')) + ')':>14}{npts:>9}")
# 逐因子 IC
p("")
p("  ── 逐因子信念 IC（窗口内 Spearman(权重, 当日平均前向收益)）──")
for s in ALL:
    series = [(w, r) for (d, w, r) in pts.get(s, []) if d in prev]
    ic = FT.spearman_ic([w for w, _ in series], [r for _, r in series]) if len(series) >= 2 else None
    p(f"    {s:<16} n={len(series):<4} ic={ic if ic is None else round(ic, 3)}")

p("")
p("  ── 叠加 mask 后的最终权重 vs 不加 mask ──")
w_raw = AW.adaptive_weights(edge, shrinkage=None, floor=AW.CONFIG["FLOOR"],
                            zero_negative_edge=True, min_evidence_n=0)
w_mask = FT.apply_mask(w_raw, signal_date=sd)
p(f"  {'因子':<16}{'不加mask':>10}{'加mask':>9}{'edge':>10}")
for s in ALL:
    e = (edge.get(s) or {}).get("edge")
    p(f"  {s:<16}{w_raw.get(s, 0):>10}{w_mask.get(s, 0):>9}"
      f"{(round(e,2) if e is not None else 0):>10}")

# ── ② 历史因子池生成试跑（一天）──
p("")
p("=" * 100)
p("② 历史因子池生成试跑（zoo_factor_strategy --date 20260715）")
p("=" * 100)
t0 = time.time()
r = subprocess.run(
    [sys.executable, str(ROOT / "scripts" / "zoo_factor_strategy.py"),
     "--date", "20260715", "--out-dir", str(ROOT / ".workbuddy" / "_zoo_probe")],
    capture_output=True, text=True, cwd=str(ROOT), timeout=900,
)
p(f"  rc={r.returncode}  用时 {time.time()-t0:.1f}s")
p("  stdout尾: " + (r.stdout or "")[-600:].replace("\n", " | "))
p("  stderr尾: " + (r.stderr or "")[-400:].replace("\n", " | "))
fs = sorted((ROOT / ".workbuddy" / "_zoo_probe").glob("*.csv"))
p(f"  产出 {len(fs)} 个池文件")
for f in fs[:4]:
    try:
        d = __import__("pandas").read_csv(f, dtype=str)
        p(f"    {f.name}: {len(d)} 行")
    except Exception as exc:
        p(f"    {f.name}: 读取失败 {exc}")

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
