# -*- coding: utf-8 -*-
"""收尾修正 ②：硬上限基准 = 生效目标（而非 max(政策, 倾斜目标)）；并把「政策目标」措辞
改为「目标」——自适应下 target_weight 就是倾斜后的生效目标，叫「政策目标」会误导。

同时修 notify 的「静态仓位口径」横幅文案 → 「静态口径」：前者含子串「仓位口径」，
与「未配置账户口径」提示串冲突，令端到端回归误报。

每处 count(old) 断言 == 1。
"""
import pathlib
import sys

ROOT = pathlib.Path(r"E:\Stocks-Master")
A = ROOT / "smcore" / "analysis.py"
N = ROOT / "scripts" / "notify_holdings_analysis.py"
D = ROOT / "smcore" / "config" / "defaults.py"
T = ROOT / ".workbuddy" / "_test_holdings_main.py"

REPL = {
    A: [
        # ① _resolve_target_weight docstring：政策目标降级为「仅供展示」
        (
            "    **政策目标**（第 2 个返回值）是**未做波动率倾斜**的 ``equity_ratio ÷ N``：\n"
            "    单票硬上限以它为**下限基准**、再取 ``max(政策, 倾斜后目标)``（见\n"
            "    :func:`_resolve_hard_cap` 的调用点），既保留绝对风控语义、又保证目标永不越线。\n"
            "    静态口径下政策目标与目标相等。\n",
            "    **政策目标**（第 2 个返回值）是**未做波动率倾斜**的 ``equity_ratio ÷ N``，\n"
            "    仅供展示/诊断（自适应下与倾斜后的生效目标可能不同）；单票硬上限一律按\n"
            "    **生效目标** ``target_w`` 比例推导（见 :func:`_resolve_hard_cap`），\n"
            "    保证目标永不越线。静态口径下政策目标与生效目标相等。\n",
        ),
        # ② 调用点：基准改生效目标
        (
            "    target_w, policy_w, target_src = _resolve_target_weight(code, cfg, n_holdings, adaptive)\n"
            "    # 单票硬上限的推导基准 = max(政策目标, 倾斜后目标)：\n"
            "    #  - 以政策目标为底 → 保留「绝对风控」语义（倾斜把某票压小时上限不被一起压小）；\n"
            "    #  - 取 max(…, target_w) → 保证上限**永不低于该票目标**，否则目标自身越线、\n"
            "    #    报告会永远要求减仓（风险平价给低波票的倾斜目标可 > 政策 × multiple）。\n"
            "    hard_cap = _resolve_hard_cap(cfg, max(float(policy_w), float(target_w)))\n",
            "    target_w, _policy_w, target_src = _resolve_target_weight(code, cfg, n_holdings, adaptive)\n"
            "    # 单票硬上限的推导基准 = **该票生效目标** target_w（自适应下 = 倾斜后的目标）：\n"
            "    #  - 比例化：上限 = 目标 × hard_cap_multiple（ceiling 封顶）→「允许的最大偏离」\n"
            "    #    天然与该票自身目标成比例（低波票目标大→允许更宽；高波票目标小→同步收紧）；\n"
            "    #  - _resolve_hard_cap 内兜底 max(…, target_w) → 保证上限 ≥ 目标、目标永不越线。\n"
            "    #    ⚠️ 曾误用「政策目标」做基准：风险平价给低波票的倾斜目标可 > 政策 × multiple\n"
            "    #    → cap_below_target 恒 True、报告永远要求减仓。\n"
            "    hard_cap = _resolve_hard_cap(cfg, float(target_w))\n",
        ),
        # ③ 输出字段说明：target_weight 是生效目标
        (
            "      target_weight = **政策目标**；delta_weight 是相对 ``aim_weight`` 的偏离\n"
            "    - aim_weight: 本次动作实际要到达的权重。正常 = target_weight；\n"
            "      **超硬上限时 = hard_cap_weight**（只削超限部分，不一步砍到政策目标）\n",
            "      target_weight = **生效目标**（自适应下为倾斜后的目标）；delta_weight 是相对\n"
            "      ``aim_weight`` 的偏离\n"
            "    - aim_weight: 本次动作实际要到达的权重。正常 = target_weight；\n"
            "      **超硬上限时 = hard_cap_weight**（只削超限部分，不一步砍到目标）\n",
        ),
        # ④ cap_below_target 说明
        (
            "    - cap_below_target: 配置自相矛盾告警（显式硬上限 < 政策目标 → 目标本身就越线）\n",
            "    - cap_below_target: 配置自相矛盾告警（显式硬上限 < 生效目标 → 目标本身就越线）\n",
        ),
        # ⑤ 决策 0 措辞
        (
            "    0. 先解析政策目标 target_w（_resolve_target_weight）与单票硬上限 hard_cap（_resolve_hard_cap）。\n",
            "    0. 先解析生效目标 target_w（_resolve_target_weight）与单票硬上限 hard_cap（_resolve_hard_cap）。\n",
        ),
        # ⑥ capped_trim 的自然语言理由：政策目标 → 目标
        (
            '            f"当前权重 {current_w:.1f}% 已超单票硬上限 {hard_cap:.1f}%，先减至上限内"\n'
            '            f"（政策目标 {target_w:.1f}%）；研判「{rating}」"\n',
            '            f"当前权重 {current_w:.1f}% 已超单票硬上限 {hard_cap:.1f}%，先减至上限内"\n'
            '            f"（目标 {target_w:.1f}%）；研判「{rating}」"\n',
        ),
    ],
    N: [
        # ⑦ MD 渲染：政策目标 → 目标
        (
            '        _tw_note = f"，政策目标 {_tw_s}" if _capped and _tw is not None else ""\n',
            '        _tw_note = f"，目标 {_tw_s}" if _capped and _tw is not None else ""\n',
        ),
        # ⑧ HTML 渲染：政策目标 → 目标
        (
            '        _tw_note = f"　｜　政策目标 {_tw_s}" if _capped and _tw is not None else ""\n',
            '        _tw_note = f"　｜　目标 {_tw_s}" if _capped and _tw is not None else ""\n',
        ),
        # ⑨ 横幅文案：去掉与「仓位口径」提示冲突的子串
        (
            '            _an = f"静态仓位口径（自适应未启用：{adaptive_ctx.get(\'note\') or \'—\'}）"\n',
            '            _an = f"静态口径（自适应未启用：{adaptive_ctx.get(\'note\') or \'—\'}）"\n',
        ),
    ],
    D: [
        # ⑩ 配置注释措辞一致
        (
            "#    ⚠️ 超限时只减到「上限」而非一步减到政策目标（削掉超限部分即可，避免过度交易）。\n",
            "#    ⚠️ 超限时只减到「上限」而非一步减到目标（削掉超限部分即可，避免过度交易）。\n",
        ),
    ],
    T: [
        # ⑪ 用例7：措辞改「目标」
        (
            'if "政策目标 23.3%" not in md1:\n'
            '    fails.append("用例7 超限票未同时标注政策目标（期望「政策目标 23.3%」）")\n',
            'if "目标 23.3%" not in md1:\n'
            '    fails.append("用例7 超限票未同时标注目标（期望「目标 23.3%」）")\n',
        ),
        # ⑫ 用例8：上限基准改生效目标后的期望值（000001 target 12% → 上限 18%）
        (
            'if "→ 上限 30.0%" not in md8:\n'
            '    fails.append("用例8 超限票未按「只减到上限 30.0%」渲染")\n'
            'if "政策目标 20.0%" not in md8:\n'
            '    fails.append("用例8 超限票未标注政策目标 20.0%")\n',
            'if "→ 上限 18.0%" not in md8:      # 000001 生效目标 12% × 1.5 = 18%\n'
            '    fails.append("用例8 超限票未按「只减到上限 18.0%」渲染")\n'
            'if "目标 12.0%" not in md8:\n'
            '    fails.append("用例8 超限票未标注生效目标 12.0%")\n',
        ),
        # ⑬ 用例8 注释里的上限推导同步
        (
            "#   → 硬上限基准 = max(政策 20, 目标) → 600000: min(36×1.5,35)=35；其余: min(20×1.5,35)=30\n"
            "# 纯持仓分母(15,000)下 000001 = 10,000/15,000 = 66.7% > 30% → 只减到「上限 30.0%」\n",
            "#   → 硬上限 = min(生效目标×1.5, ceiling 35)（不足则抬到目标）\n"
            "#     600000: min(36×1.5,35)=35 < 36 → 抬到 36；000001: min(12×1.5,35)=18\n"
            "# 纯持仓分母(15,000)下 000001 = 10,000/15,000 = 66.7% > 18% → 只减到「上限 18.0%」\n",
        ),
    ],
}

total = 0
for path, items in REPL.items():
    src = path.read_text(encoding="utf-8")
    for i, (old, new) in enumerate(items, 1):
        n = src.count(old)
        if n != 1:
            print(f"FAIL {path.name} #{i}: expected 1 hit, got {n}")
            print("--- old ---")
            print(old)
            sys.exit(1)
        src = src.replace(old, new)
        total += 1
        print(f"OK {path.name} #{i}")
    path.write_text(src, encoding="utf-8")
print(f"WROTE {total} replacements across {len(REPL)} files")
