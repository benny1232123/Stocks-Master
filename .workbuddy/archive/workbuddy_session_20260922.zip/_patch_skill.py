# -*- coding: utf-8 -*-
"""更新 skill `stocksmaster-config-model-change`：补自适应仓位相关的可复用铁律。"""
import pathlib
import sys

P = pathlib.Path(r"C:\Users\29408\.workbuddy\skills\stocksmaster-config-model-change\SKILL.md")

REPL = [
    (
        "触发词：改仓位模型、",
        "触发词：自适应仓位、regime 定总仓位、market.compute_market_profile、"
        "portfolio.compute_target_weights、risk_parity_erc、改仓位模型、",
    ),
    (
        "6. **派生量优于固定量**。发现「固定上限 vs 推导目标」会自相矛盾（小 N 时目标 > 上限）时，\n"
        "   把上限改成**倍数化**（`目标 × multiple`）再以 ceiling 封顶，并加 `max(…, target)` 兜底。\n"
        "\n"
        "## 步骤\n",
        "6. **派生量优于固定量，且基准必须用「生效量」**。发现「固定上限 vs 推导目标」会自相矛盾\n"
        "   （小 N 时目标 > 上限）时，把上限改成**倍数化**（`目标 × multiple`）再以 ceiling 封顶，\n"
        "   并加 `max(…, target)` 兜底。\n"
        "   ⚠️ 基准**不能选中间量**：自适应下硬上限若按「未倾斜的政策目标」推导，风险平价给低波票的\n"
        "   倾斜目标可 > 政策 × 1.5 → `cap_below_target` 恒 True、报告**永远**要求减仓（本次实测复现）。\n"
        "7. **先 grep 是否已有规范实现，别自造**。本次第一版给个股权重自造了 ad-hoc vol tilt，\n"
        "   随后发现仓库早已有：`smcore/strategy/portfolio.py::compute_target_weights`（`fusion.py`\n"
        "   在用的唯一分配器，支持 `equal_weight`/`score_weighted`/`risk_parity_erc`）、\n"
        "   `smcore/strategy/market.py::compute_market_profile(as_of)`（regime 三态 +\n"
        "   `regime_strength` 连续 0~1，支持 `as_of` 因果安全）、`risk_rules.py::vol_target_scale`。\n"
        "   **新功能优先「接线复用」而非重写**。同时务必看 **live 配置是否启用**：\n"
        "   `risk_config.json::vol_target.enabled=false`（仓库自带波动率目标化在线上是**关**的）。\n"
        "8. **分层正交**：仓位层（「买多少」）不要掺入研判层（「这票好不好」）。权重法默认\n"
        "   `risk_parity_erc`（w ∝ 1/σ，只看风险）；`score_weighted` 会把评分引进仓位层，\n"
        "   且最低分票可能被压到 ~0% —— 对**已持仓**等于强制清仓，慎用。同时用\n"
        "   `min_weight_frac` 夹下限 + 重归一（防已持仓被算成 0% ≈ 强制清仓）。\n"
        "   ⚠️ 函数内一律**懒 import** `smcore.strategy.*`：defaults.py 明确警告\n"
        "   `smcore.strategy` 包初始化期（fusion→position_sizing→defaults）存在循环导入。\n"
        "9. **报告/日志文案必须跟语义一起改**。`target_weight` 在自适应下就是倾斜后的**生效目标**，\n"
        "   再叫「政策目标」会误导 → 全链路（`reason` 文案 + MD/HTML 渲染 + docstring）一起改「目标」。\n"
        "10. **非确定的外部依赖在测试里必须打桩**。regime 检测读市场数据 → 端到端测试会随数据漂移、\n"
        "    结论不定。做法：默认 `N.<fn> = lambda *a, **k: {<disabled 桩>}` 让静态用例确定性通过，\n"
        "    **另开一个用例**注入自适应桩，验证 `main()` 的接线（横幅渲染 / 口径日志 / 上限渲染）。\n"
        "11. **新增文案要避开既有断言的子串**。本次「静态仓位**口径**」与「未配置账户**口径**」提示串\n"
        "    里的「仓位口径」冲突 → 端到端断言误报。命名前先搜一下被断言的短子串。\n"
        "\n"
        "## 步骤\n",
    ),
]

src = P.read_text(encoding="utf-8")
for i, (old, new) in enumerate(REPL, 1):
    n = src.count(old)
    if n != 1:
        print(f"FAIL #{i}: expected 1 hit, got {n}")
        sys.exit(1)
    src = src.replace(old, new)
    print(f"OK #{i}")
P.write_text(src, encoding="utf-8")
print("WROTE", P)
