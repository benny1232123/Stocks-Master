# -*- coding: utf-8 -*-
"""把 _signal_health.txt 转成可读报告（直接嵌入原文，零手抄）。"""
import html as _h
from pathlib import Path

ROOT = Path(r"E:\Stocks-Master")
SRC = ROOT / ".workbuddy" / "_signal_health.txt"
OUT = ROOT / ".workbuddy" / "signal_health_20260921.html"

raw = SRC.read_text(encoding="utf-8")

# 抽出四段
blocks = {}
cur = None
for ln in raw.splitlines():
    if ln.startswith("0) "):
        cur = "k"; blocks[cur] = []
    elif ln.startswith("1) "):
        cur = "pool"; blocks[cur] = []
    elif ln.startswith("2) "):
        cur = "dal"; blocks[cur] = []
    elif ln.startswith("3) "):
        cur = "sel"; blocks[cur] = []
    elif ln.startswith("4) "):
        cur = "inner"; blocks[cur] = []
    if cur:
        blocks[cur].append(ln)


def pre(key):
    return "<pre>" + _h.escape("\n".join(blocks.get(key, []))) + "</pre>"


ACTIVE = ["CVAmt20", "CVAmt60", "DistLo10", "DistLo60", "Illiq20", "PVCorr20",
          "PVCorr60", "Skew20", "Skew60", "VRatio10_60", "VRatio20_120", "Vol20"]

html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>信号有效性体检 2026-09-21</title>
<style>
:root{{--bg:#faf9f6;--card:#fff;--fg:#1c1c1a;--mut:#6b6a65;--bd:#e3e1da;--g:#c0392b;--b:#2e7d32;--w:#8a6d18;}}
@media (prefers-color-scheme:dark){{:root{{--bg:#1b1b19;--card:#232320;--fg:#f0efe9;--mut:#9b9a93;--bd:#3a3a35;--g:#e8695a;--b:#6bbf6f;--w:#d0b055;}}}}
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 20px 64px;background:var(--bg);color:var(--fg);font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;font-size:14px;line-height:1.65}}
.wrap{{max-width:1020px;margin:0 auto}}
h1{{font-size:20px;font-weight:500;margin:0 0 4px}}
.sub{{color:var(--mut);font-size:13px;margin-bottom:24px}}
h2{{font-size:15px;font-weight:500;margin:32px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--bd)}}
h3{{font-size:14px;font-weight:500;margin:20px 0 8px}}
.box{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px 18px;margin:12px 0}}
.box.warn{{border-color:var(--w)}}.box.good{{border-color:var(--g)}}
pre{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:12px 14px;overflow:auto;
font-family:ui-monospace,Consolas,"Cascadia Mono",monospace;font-size:12px;line-height:1.5;margin:10px 0}}
ul{{margin:6px 0 0;padding-left:20px}}li{{margin-bottom:5px}}
code{{font-family:ui-monospace,Consolas,monospace;font-size:12px;background:var(--bg);padding:1px 5px;border-radius:4px;border:1px solid var(--bd)}}
.g{{color:var(--g)}}.b{{color:var(--b)}}
table{{width:100%;border-collapse:collapse;font-size:13px;background:var(--card);border:1px solid var(--bd);border-radius:10px;overflow:hidden}}
th,td{{padding:7px 10px;text-align:left;border-bottom:1px solid var(--bd)}}
th{{font-weight:500;font-size:12px;color:var(--mut)}}
tr:last-child td{{border-bottom:none}}
td:nth-child(n+2){{font-variant-numeric:tabular-nums;text-align:right}}
</style></head><body><div class="wrap">
<h1>信号有效性体检</h1>
<div class="sub">2026-09-21 · 16 个信号日 · 全市场基准 = k_data 覆盖 4374 只等权 ·
口径：信号日<b>次日开盘买入</b>，持有 H 个交易日后收盘卖出 · 池文件与 DAL 均取自仓库</div>

<h2>一、结论（三层，按重要性）</h2>
<div class="box warn">
<b>① 因子池本身的 edge 极弱。</b>
12 个活跃因子在 H=3 上的池超额（池等权 − 全市场等权）<b>全部落在 ±0.7pp 内</b>：
最好的是 VRatio10_60 +0.66、Illiq20 +0.50、VRatio20_120 +0.36、PVCorr20 +0.18、Vol20 +0.16；
最差的是 PVCorr60 <b class="b">−0.47</b>、Skew20 −0.22、CVAmt60 −0.11。
<b>没有任何一个因子在短持有期上给出可用 edge。</b>
</div>
<div class="box warn">
<b>② 融合/排序层在"反向筛选"。</b>
决定性检验（同一因子池内，进入 DAL 的成员 vs 没进的成员，H=3）：
多数因子里<b>入选的反而更差</b> ——
CVAmt20 入选 −3.74% vs 落选 −0.17%（<b class="b">−3.57pp</b>）、
Skew20 −2.29pp、Illiq20 −2.04pp、DistLo10 −0.88pp、PVCorr60 −0.80pp。
<b>融合没有提取 edge，而是往坏的方向挑。</b>
</div>
<div class="box warn">
<b>③ 融合名单整体跑输全市场。</b>
DAL 等权组合相对全市场的超额：
H=1 <b class="b">−0.06pp</b>、H=3 <b class="b">−0.27pp</b>、H=5 <b class="b">−1.00pp</b>
（H=12 为 +1.15pp，但只有 4 天样本）。⇒ 选股层目前是<b>负贡献</b>，
这与其后回测里"组合收益为负、超额≈0"完全一致。
</div>
<div class="box good">
<b>④ 但有一条真实线索：量比 / 流动性家族在更长持有期上有 edge。</b>
VRatio20_120 H=12 超额 <b class="g">+3.19pp</b>、VRatio10_60 +1.32pp、Illiq20 +0.87pp，
且三者在 H=3 上也为正（+0.36 / +0.66 / +0.50）。这与"alpha 只活在前 1–3 天"的另一条
观测并不矛盾——说明这几类因子需要**更长的持有期**才释放，而当前 12 日窗口对它们偏短、
对其它因子又偏长。<b>这是下一步最值得验证的方向。</b>
</div>

<h2>二、原始输出（零手抄，直接嵌入）</h2>
<h3>0) 数据装载</h3>
{pre("k")}
<h3>1) 各因子池超额（池等权 − 全市场等权，同信号日配对）</h3>
<div class="sub" style="margin:0 0 6px">"进DAL率" = 该因子池成员进入当日融合名单的比例。
Boll_* / Quality / Size / Value / Rel_* / Momentum / Shared-Seed 为**已退役**因子，仅作参照。</div>
{pre("pool")}
<h3>2) 融合名单（DAL）vs 全市场</h3>
{pre("dal")}
<h3>3) ★决定性检验：池内「进了 DAL」vs「没进 DAL」（H=3）</h3>
{pre("sel")}
<h3>4) DAL 内部结构（H=3）</h3>
{pre("inner")}

<h2>三、方法学限制（下结论前必读）</h2>
<ul>
<li><b>窗口只有 16 个信号日</b>，池内"入选"子样本常常只有 1~4 笔（如表 3 里那些 n=1 的行）
→ 单因子结论不稳健，本报告只能当<b>方向性证据</b>。</li>
<li>因子池文件只有 <code>[股票代码, 股票名称, 综合分]</code> 且 <code>综合分≡100</code>
—— 是<b>二元成员表</b>，拿不到因子值 ⇒ <b>无法算 IC</b>，只能算"池 vs 市场"的超额。</li>
<li>DAL 的 <code>来源策略</code> 是<b>融合后</b>的标注，未必等于因子原始打分排序。</li>
<li>H=12 只有 4 天可用（数据末端限制），该列应视为参考。</li>
<li>全市场基准用的是 k_data 覆盖的 4374 只（含停牌/新股缺失），未做行业中性化、未剔除涨跌停。</li>
</ul>

<h2>四、建议动作（按性价比排序）</h2>
<table><thead><tr><th>优先级</th><th>动作</th><th>依据</th></tr></thead><tbody>
<tr><td>P0</td><td>把因子池文件的<b>留存期拉长</b>（现在只有 16 天，远端 17 天）——没有历史就没法做因子取舍</td>
<td>所有结论都受 16 天限制</td></tr>
<tr><td>P0</td><td>查<b>融合层的排序/权重逻辑</b>：为什么它挑出的子集比同池落选的更差</td>
<td>表 3 多个因子 −2 ~ −3.6pp</td></tr>
<tr><td>P1</td><td>对 VRatio20_120 / VRatio10_60 / Illiq20 做<b>更长持有期</b>的验证（12 日 vs 20 日）</td>
<td>它们 H=12 超额 +0.9 ~ +3.2pp</td></tr>
<tr><td>P1</td><td>复核 PVCorr60 / CVAmt20 / Skew20 是否该留在菜单（池超额为负 / 入选显著更差）</td>
<td>PVCorr60 H=12 −1.74pp；CVAmt20 入选 −3.57pp</td></tr>
<tr><td>P2</td><td>给因子池补上<b>因子值列</b>（现在是二元表），才能算 IC / 分位单调性</td>
<td>无法做因子层面的精确定位</td></tr>
</tbody></table>
<div class="box">⚠️ 本轮<b>只读诊断，未改任何生产代码</b>；结论均为方向性证据，不足以直接改配置。</div>
</div></body></html>"""

OUT.write_text(html, encoding="utf-8")
print("WROTE", OUT, len(html))
