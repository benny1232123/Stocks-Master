# -*- coding: utf-8 -*-
"""统一止损口径：让回测**透传 DAL 的 stop_pct**（= boll_levels.py 单一真源），
不再用 clamp(VOL_STOP_MULT × σ, 6%, 15%) 重算覆盖。

背景：`fusion.py` 写入 DAL 的 `stop_pct` 来自 `boll_levels._compute_boll_levels`
= clamp(2.5 × 日σ, 4%, 12%)，注释明确写着「引擎 stop_pct 列优先」，
`position_monitor`（实盘监控）也是读 DAL 该列 —— 只有 `daily_backtest.py` 就地重算成
clamp(8 × 日σ, 6%, 15%)，导致清单/网站/监控与回测的止损 120/120 笔不一致
（中位 5.45% vs 15%）。本次改为单一真源；旧口径保留在 BACKTEST_STOP_SOURCE=legacy
以便复现历史结果与做参数实验（其他 historical_backtest*/param_scan 脚本仍 import
VOL_STOP_MULT，故常量保留）。

每处 count(old) 断言 == 1。
"""
import pathlib
import sys

ROOT = pathlib.Path(r"E:\Stocks-Master")
T = ROOT / "scripts" / "daily_backtest.py"

REPL = [
    # ① 常量注释：标明已不是默认口径
    (
        "# 波动率自适应止损：个股近20日波动率 vol20 → 止损比例 = clamp(VOL_STOP_MULT*vol20, 6%, 15%)。\n"
        "# 高波动股给更宽止损避免被洗、低波动给更紧；无 vol 数据时回退引擎全局 -8%。\n"
        "VOL_STOP_MULT = 8.0\n",
        "# ⚠️ DEPRECATED（2026-09-21）：VOL_STOP_MULT 已**不再是默认止损口径**。\n"
        "# 止损的单一真源 = `smcore/strategy/boll_levels.py::_compute_boll_levels`\n"
        "#   → stop_pct = clamp(stop_pct_vol_mult(2.5) × 日σ, stop_pct_min(4%), stop_pct_max(12%))\n"
        "# 该值由 fusion 写入 DAL 的 `stop_pct` 列，PositionMonitor 与回测都直接读它。\n"
        "# 旧口径 clamp(VOL_STOP_MULT × 日σ, 6%, 15%) 仅保留给 _resolve_stops(source=\"legacy\")、\n"
        "# 供复现历史结果或用 BACKTEST_STOP_SOURCE=legacy 做参数实验；\n"
        "# 其他脚本（historical_backtest*.py / param_scan.py / experiment_exit_ab.py）仍 import 本常量。\n"
        "VOL_STOP_MULT = 8.0\n"
        "# 旧口径的上下限（只给 legacy 分支用）\n"
        "VOL_STOP_LEGACY_BOUNDS = (0.06, 0.15)\n",
    ),
    # ② 抽出纯函数 _resolve_stops（可单测的守卫点）
    (
        "class _PortfolioCurve:\n",
        "def _resolve_stops(\n"
        "    dal_values,\n"
        "    codes,\n"
        "    lv_get,\n"
        "    source: str = \"dal\",\n"
        "    vol_mult: float = VOL_STOP_MULT,\n"
        "    legacy_bounds=VOL_STOP_LEGACY_BOUNDS,\n"
        ") -> list:\n"
        "    \"\"\"解析逐只止损比例（正数小数，如 0.10 = 10%）。\n"
        "\n"
        "    **单一真源**：``source=\"dal\"`` 直接透传融合写入 DAL 的 ``stop_pct``\n"
        "    （= boll_levels 口径），缺失时才用同一 ``lv_get`` 口径就地补算 —— 保证\n"
        "    清单 / 网站 / PositionMonitor / 回测四者同源。\n"
        "    ``source=\"legacy\"`` 复现旧口径 ``clamp(vol_mult × σ, 6%, 15%)``（仅实验用）。\n"
        "\n"
        "    参数：dal_values 与 codes 等长（可为 None/NaN，逐位回退）；\n"
        "    lv_get(code) -> dict，至少含 ``stop_pct`` / ``vol20``。\n"
        "    \"\"\"\n"
        "    import math as _math\n"
        "    lo, hi = legacy_bounds\n"
        "    out = []\n"
        "    for i, code in enumerate(codes):\n"
        "        d = None\n"
        "        if dal_values is not None:\n"
        "            try:\n"
        "                d = dal_values[i]\n"
        "            except Exception:\n"
        "                d = None\n"
        "        try:\n"
        "            if d is not None and not (isinstance(d, float) and _math.isnan(d)) and float(d) > 0:\n"
        "                d = float(d)\n"
        "            else:\n"
        "                d = None\n"
        "        except (TypeError, ValueError):\n"
        "            d = None\n"
        "        if source == \"legacy\":\n"
        "            v = (lv_get(str(code).strip()) or {}).get(\"vol20\")\n"
        "            out.append(max(lo, min(vol_mult * v, hi)) if (v and v > 0) else None)\n"
        "            continue\n"
        "        if d is not None:\n"
        "            out.append(d)\n"
        "            continue\n"
        "        sp = (lv_get(str(code).strip()) or {}).get(\"stop_pct\")\n"
        "        out.append(float(sp) if sp else None)\n"
        "    return out\n"
        "\n"
        "\n"
        "class _PortfolioCurve:\n",
    ),
    # ③ sub 构造：把 DAL 的 stop_pct 带进来
    (
        "    if \"权重\" in df.columns:\n"
        "        sub[\"权重\"] = pd.to_numeric(df[\"权重\"], errors=\"coerce\").values[: len(codes)]\n",
        "    if \"权重\" in df.columns:\n"
        "        sub[\"权重\"] = pd.to_numeric(df[\"权重\"], errors=\"coerce\").values[: len(codes)]\n"
        "    # 逐只止损比例：**直接沿用融合写入 DAL 的 stop_pct**（单一真源，与网站/监控同源）。\n"
        "    # 引擎在 enable_exits 下优先用该列（engine: eff_stop = row_stop or 全局 stop_loss_pct）。\n"
        "    if \"stop_pct\" in df.columns:\n"
        "        sub[\"stop_pct\"] = pd.to_numeric(df[\"stop_pct\"], errors=\"coerce\").values[: len(codes)]\n",
    ),
    # ④ 用 _resolve_stops 取代就地重算
    (
        "            if _vol_stop_on:\n"
        "                _stops = []\n"
        "                for code in sub[\"代码\"]:\n"
        "                    v = _lv(str(code).strip()).get(\"vol20\")\n"
        "                    if v and v > 0:\n"
        "                        _stops.append(max(0.06, min(_vol_mult * v, 0.15)))\n"
        "                    else:\n"
        "                        _stops.append(None)\n"
        "                sub[\"stop_pct\"] = _stops\n"
        "                print(f\"  [波动率自适应] 市场波动={_prof.volatility_level} 总仓位缩放={capital_scale} \"\n"
        "                      f\"逐只止损: {sum(1 for s in _stops if s)}/{len(_stops)} 只已定\")\n",
        "            if _vol_stop_on:\n"
        "                _stops = _resolve_stops(\n"
        "                    sub[\"stop_pct\"].tolist() if \"stop_pct\" in sub.columns else None,\n"
        "                    sub[\"代码\"].tolist(), _lv,\n"
        "                    source=_stop_src, vol_mult=_vol_mult,\n"
        "                )\n"
        "                sub[\"stop_pct\"] = _stops\n"
        "                _ok = [s for s in _stops if s]\n"
        "                _med = pd.Series(_ok).median() if _ok else 0.0\n"
        "                print(f\"  [止损口径] 源={_stop_src} 市场波动={_prof.volatility_level} \"\n"
        "                      f\"总仓位缩放={capital_scale} 逐只止损: {len(_ok)}/{len(_stops)} 只已定 \"\n"
        "                      f\"(中位 {_med * 100:.2f}%)\")\n",
    ),
    # ⑤ 新增 _stop_src 读取
    (
        "    _vol_stop_on = os.environ.get(\"VOL_SCALED_STOP\", \"1\") == \"1\"\n",
        "    _vol_stop_on = os.environ.get(\"VOL_SCALED_STOP\", \"1\") == \"1\"\n"
        "    # 止损来源：dal（默认，单一真源=boll_levels 写入 DAL 的 stop_pct）| legacy（旧口径，实验用）\n"
        "    _stop_src = (os.environ.get(\"BACKTEST_STOP_SOURCE\", \"dal\") or \"dal\").strip().lower()\n"
        "    if _stop_src not in (\"dal\", \"legacy\"):\n"
        "        _stop_src = \"dal\"\n",
    ),
    # ⑥ summary 记录止损口径
    (
        "    summary[\"size_mode\"] = f\"adaptive_weight({size_by})\" if size_by else \"equal\"\n",
        "    summary[\"size_mode\"] = f\"adaptive_weight({size_by})\" if size_by else \"equal\"\n"
        "    # 止损口径（可追溯：下次有人说「回测止损和清单不一致」时先看这一列）\n"
        "    summary[\"stop_mode\"] = (\n"
        "        \"dal_boll(2.5σ,[4%,12%])\" if _stop_src == \"dal\"\n"
        "        else f\"legacy({_vol_mult}σ,[6%,15%])\"\n"
        "    )\n",
    ),
    # ⑦ 顶部说明同步
    (
        "        # 波动率自适应：stop_loss_pct 为全局兜底(-8%)，逐只 stop_pct 列（个股 vol20 定）优先。\n"
        "        # 全局兜底也改由 compute_adaptive_exit_params 自适应（波动率/regime 浮动）。\n",
        "        # 逐只止损比例 stop_pct：**单一真源 = 融合写入 DAL 的 stop_pct**（boll_levels 口径\n"
        "        # clamp(2.5×日σ, 4%, 12%)），与清单/网站/PositionMonitor 同源；缺值时按同一\n"
        "        # boll_levels 口径就地补算。全局 stop_loss_pct 仅在该列为空时兜底。\n"
        "        # （旧口径 clamp(8×日σ, 6%, 15%) 见 BACKTEST_STOP_SOURCE=legacy，仅供实验。）\n",
    ),
]

src = T.read_text(encoding="utf-8")
for i, (old, new) in enumerate(REPL, 1):
    n = src.count(old)
    if n != 1:
        print(f"FAIL #{i}: expected 1 hit, got {n}")
        print("--- old ---")
        print(old)
        sys.exit(1)
    src = src.replace(old, new)
    print(f"OK #{i}")
T.write_text(src, encoding="utf-8")
print("WROTE", T)
