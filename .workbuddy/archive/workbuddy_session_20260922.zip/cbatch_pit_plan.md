# C 批（基本面因子）重开方案 —— 现状盘点 + 分阶段计划

> 撰写：2026-09-17。目的：为「因子驱动主导」补齐**正交维度**。
> ⚠️ 本文只是**方案**，未实施。实施前需你拍板（尤其 G2 的技术选型与首轮菜单范围）。

## 0. 为什么需要 C 批（不要重复劳动，先看结论）

Phase 2 已证明**纯 OHLCV 文法饱和**：123 个候选里只有 `a20_10` 是新的独立存活，
且 OOS 门控（`candidate_gate.md`）判定它**不可交易**（跑输等权基准 ~4pp）。
→ 继续在价格/成交量里挖，边际收益已近 0；要扩**正交**维度只能靠基本面/事件/资金流。

## 1. 现状盘点（**关键修正**：PIT 基建已建成，不是从零开始）

### 1.1 已有资产 ✅
| 资产 | 状态 |
|---|---|
| `smcore/strategy/fundamental.py`（723 行） | **完整的 PIT 机制**：`CACHE_VERSION=2`、`_period_available_date()`、`_select_pit_period_keyed(periods, as_of)`、`_extract_for_asof(data, as_of)`、baostock/hithink 两条历史报告期拉取路径 |
| `risk_config.json::fundamental_pit` | 已配置：`prefer_pub_date=true` + 法定披露滞后兜底 `{03-31:30, 06-30:62, 09-30:31, 12-31:120}` |
| `stock_data/fundamental_cache/` | 717 个 JSON；其中 **301 个是 v2**（`periods` 含 17–26 个报告期，2020-03-31→2026-06-30，**301/301 带真实公告日 `_pub`**） |
| `scripts/fundamental_strategy.py`（306 行，现 DEPRECATED） | 打分逻辑保留：复合体 Quality/Value/Size + 原子 ROE/Gross_Margin/EP/BP |

**v2 缓存布局**（已验证）：
```json
{"_v": 2, "_spot_as_of": "2026-09-10",
 "spot": {"pe": 5.21, "pb": 21.12, "mkt_cap": 54.6},
 "periods": {"2026-06-30": {"_pub": "2026-08-25", "roe": 0.023425, "gross_margin": 0.801682}, ...},
 "kline_stats": {"turnover": 2.6525, "amount_20": 250412978.7}}
```

### 1.2 字段可用性（301 个 v2 文件实测）
| 字段 | 覆盖 | 历史 PIT 回放 | 说明 |
|---|---|---|---|
| `periods.roe` | **301/301** | ✅ **可用** | 按 `_pub` 真实公告日选期，无未来函数 |
| `periods.gross_margin` | 280/301 | ✅ **可用** | 同上 |
| `periods.revenue_growth` | **0/301** | ❌ 未采集 | 需补（成长维度目前拿不到） |
| `spot.pe` / `spot.pb` | 298 / 178 | ❌ **不可用** | 只有**当前**快照；历史日 `as_of < _spot_as_of` 被 PIT 守卫**正确拒绝** |
| `spot.mkt_cap` | 301/301 | ❌ **不可用** | 同上 |
| `kline_stats.turnover` | 301/301 | ⚠️ 近似 | 刷新日快照，历史沿用（已知妥协；且与 relativity 资金流重叠，建议**不**用作新因子） |

### 1.3 缺口（要解决的）
- **G1 覆盖率**：301 只（可回放）/ 717 只（有缓存）/ 4380 只（k_data 宇宙）。6.9% 的截面做全市场横截面因子**不够**。
- **G2 估值无历史**：Value（PE/PB）与 Size（市值）**无法做 PIT 回放** → 这是本方案最需要决策的一环（见 §3）。
- **G3 `revenue_growth` 未采集**：成长维度空缺。
- **G4 数据结构错配**：`fundamental_strategy.py` 的 `_SCORERS` 读 **v1 扁平字段**（`roe`/`pe` 在顶层），而 PIT 数据在 **v2 `periods`** 里 → 直接复活会对 301 个 v2 文件**全部取空**。必须改走 `fetch_fundamentals_batch(codes, as_of=信号日)`（`fundamental.py:633`）或 `_extract_for_asof`。
- **G5 CI 未接线**：`scripts/refresh_fundamentals.py` **不被任何 workflow 调用**（与 A 批生成器当初的缺口同一类）。且刷新是**联网**动作（baostock/hithink），本机离线环境跑不了。

## 2. 三条硬约束（动手前必读）

1. **菜单总量 ≈30–35 上限**：探索预算池 `explore_pool_cap_pct=30%` + 整数百分比粒度 → 无证据策略超过 ~28 个会有因子被舍入到 **0%**，永远拿不到探索权重、永远「毕业」不了。
2. **升菜单 = 5 处同步**：`factor_types.STRATEGY_ORDER/STRATEGY_LABEL/STRATEGY_FACTOR_TYPE` + 前端三件套（`factorTypes.js`/`App.jsx::STRAT_LABEL`/`styles.css::.top-tag--<id>`），否则 `test_frontend_registry_parity` 红灯。
3. **产出 CSV ≠ 进 DAL**：要拿到新因子的历史 edge，必须对历史信号日**重跑 fusion**（offline-refusion）把因子打进 DAL「来源策略」，`compute_universe_edge` 才能归因。且 **OOS 门控 + 预注册**是纪律，不是可选项。

## 3. G2 技术选型（**需要你决策**）

历史估值只有两条可行路径：

**方案 A（推荐）：用 baostock 日线自带的估值字段**
- `baostock.query_history_k_data_plus` 除 OHLCV 外还可返回 **`peTTM` / `pbMRQ` / `psTTM` / `pcfNcfTTM`**（逐日）。
- 优点：**逐日、天然 PIT、无需自算**；一次拉取同时补 `revenue_growth` 之外的估值历史。
- 代价：需在 `smcore/data/kline.py` 之外**新增一条估值序列的落盘**（现有 `DAILY_K_COLUMNS` 只有 code/date/OHLCV/amount，不加字段以保持 k_data 契约不变）→ 建议新目录 `stock_data/valuation_history/`（分片 parquet，按 code 存 date×{peTTM,pbMRQ}）。
- 风险：baostock 在海外 Runner 可用性一般（现有代码已有回退链）；数据量大（4380 只 × 逐日）。

**方案 B：自算 PE = close / EPS(TTM)，PB = close / BVPS**
- 用 k_data 的 close（已有）+ PIT 财报的 EPS/BVPS 自算。
- 优点：完全离线、与因子池同口径。
- 难点：**现有 v2 `periods` 没有 EPS/每股净资产字段**（只有 roe/gross_margin）→ 要先扩展采集字段（净利、净资产、股本），改动比 A 大。
- 优点：口径可控（TTM 拼接规则自己定）。

**推荐 A**：改动面小（只新增一条只读估值序列），且 `peTTM/pbMRQ` 是数据源直接给的 PIT 口径，不易出错。

## 4. 分阶段实施计划

### P0（先做，零风险）：可行性验证 —— 只用**已可用**的 Quality 维度
- **只加 1 个因子**：`Quality` = 截面 z(ROE_annualized) + z(gross_margin)，走 PIT `as_of=信号日`。
- 用 301 只 v2 覆盖（截面小，但足够回答「这个维度在我们数据上有没有 edge」）。
- 复用 `factor_engine.cross_sectional_ic` + `mine_factors` 的存活屏逻辑 + 非重叠取样 t 检验（`stocksmaster-preregistered-gate` skill 的判据阈值）。
- **预注册**：先写死判据（IC 符号/量级阈值、两段一致性、t 门槛），再跑，避免事后挑选。
- 产出：一份 `quality_pit_ic.md`。**P0 不改任何菜单/CI**，纯研究。

### P1：补数据（依赖你在联网主机执行，或 CI 上跑）
- 扩覆盖：301 → 全宇宙（或至少 DAL 候选池 + 全 A）。用 `scripts/refresh_fundamentals.py`（可加 `VE_MAX_DAYS` 控量）。
- 补 `revenue_growth` 采集。
- 落 G2 选的估值历史序列（方案 A/B）。
- **验收判据**：v2 文件数 ≥ 3000、`periods.roe` 覆盖 ≥ 90%、估值历史覆盖 ≥ 90% 且逐日。

### P2：接线
- 改 `fundamental_strategy.py`：`_SCORERS` 改为消费 `_extract_for_asof` 的输出（修 G4）；`main()` 取消 DEPRECATED。
- `daily-pick.yml` 新增 `refresh_fundamentals` 步骤（**放在 K 线刷新的同一层，且在因子生成之前**）+ 与 A 批同款**覆盖度门控**（带 `always()` 告警）。
- 教训复用：新步骤的**输入从哪来、谁在 CI 里刷新它**必须先答清楚（见 `stocksmaster-strategy-set-refactor` skill 的「隐式副作用」节）。

### P3：升菜单（严格按纪律）
- 注册表 + 前端三件套同步 → 跑 `test_frontend_registry_parity`。
- 历史信号日 offline-refusion 回填 → `compute_universe_edge` 归因。
- OOS 门控通过才保留；不通过则用 `excluded_strategies` 退休（改 1 处 config 可回滚）。
- ⚠️ 每加一个都检查菜单总数是否逼近 30–35。

## 5. 首轮菜单范围建议（保守）

**只加 `Quality` 一个**（ROE+gross_margin 复合）。理由：
1. 它是**唯一**当前 PIT-可回放的维度（301 只 × 17–26 报告期已就绪）。
2. 原子（`ROE`/`Gross_Margin`）与复合体**高度相关**（ρ 必然很高）→ 同时加会撞冗余剔重（|ρ|>0.85）。
3. `Value`/`Size` 等估值历史（G2）就绪后再单独评估，避免用「当前快照」污染历史 IC（那会重演「用未来信息」的错误）。

## 6. 风险清单
- **未来函数**：任何绕过 `_extract_for_asof` 的取值方式都可能引入；`spot` 的历史拒绝逻辑是正确行为，**不要**为了「多几个字段」而放宽它。
- **存活偏差 / 微盘虚高**：因子池报告 §六 的三重折扣（微盘+幸存者+不可交易流动性）对基本面因子同样适用 → IC 显著性 ≠ 可交易 alpha，仍须 OOS 门控。
- **覆盖率与截面一致性**：301 只的截面 = 某类票（多为中大盘？）→ 结论不可外推到全市场；P1 扩覆盖后**必须重跑** P0 验证。
- **CI 时长**：4380 只 × 25 报告期联网拉取很慢；需控量（先 DAL 候选池）并允许增量（已有 `CACHE_TTL_DAYS`）。
