# -*- coding: utf-8 -*-
"""批量补齐 fundamental_cache 中只有 {roe, gross_margin} 的部分缓存。

背景: 1ceffd3 批量预填时 baostock 质量子块成功、其余子块(估值/资金)失败，
导致 ~300 只票缓存只有 2 字段 → 网站/日报查这些票时基本面=质量分、资金面=missing 50。

方法: fetch_fundamental(force=True) 全量重拉(腾讯估值 + baostock 质量/成长/换手)，
成功自动写回缓存；失败重试 1 次，仍失败记入 fail 清单。
用法: E:\\Anaconda\\python.exe .workbuddy/fund_cache_fill.py
"""
import glob
import json
import os
import socket
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from smcore.strategy.fundamental import fetch_fundamental  # noqa: E402

# 防挂死: baostock 自定义 TCP 协议(10030) 无响应时 socket 默认可挂数分钟。
# 设 15s 全局超时让失败快速落袋，由外层循环探测端口恢复后重跑。
socket.setdefaulttimeout(15)

FULL = {"pe", "pb", "roe", "gross_margin", "mkt_cap", "turnover", "amount_20"}

PROGRESS = os.path.join(".workbuddy", "fund_fill_progress.json")


def save_progress(i: int, total: int, ok: int, fail: list) -> None:
    """增量进度: 每 10 只写一次，便于外部监视剩余量。"""
    try:
        remaining = len(targets())
        with open(PROGRESS, "w", encoding="utf-8") as f:
            json.dump({"processed": i, "total": total, "ok": ok,
                       "fail": [c for c, _ in fail], "remaining": remaining},
                      f, ensure_ascii=False, indent=1)
    except Exception:
        pass


def targets() -> list[str]:
    out = []
    for f in sorted(glob.glob(os.path.join("stock_data", "fundamental_cache", "*.json"))):
        try:
            d = json.load(open(f, encoding="utf-8"))
        except Exception:
            continue
        if "turnover" not in d or "amount_20" not in d:  # 缺资金面 = 部分缓存
            out.append(os.path.basename(f)[:-5])
    return out


def main() -> int:
    codes = targets()
    print(f"待补齐 {len(codes)} 只", flush=True)
    ok, fail, skip = 0, [], 0
    for i, c in enumerate(codes, 1):
        for attempt in range(2):
            try:
                d = fetch_fundamental(c, force=True)
            except Exception as e:
                d = None
                last_err = repr(e)
            if d and "turnover" in d and "amount_20" in d:
                ok += 1
                print(f"[{i}/{len(codes)}] {c} OK: turnover={d.get('turnover'):.4f} amount_20={d.get('amount_20'):.1f}", flush=True)
                break
            time.sleep(1)
        else:
            fail.append((c, last_err if "last_err" in dir() else "empty"))
            print(f"[{i}/{len(codes)}] {c} FAIL", flush=True)
        if i % 25 == 0:
            print(f"--- 进度 {i}/{len(codes)}  成功 {ok}  失败 {len(fail)} ---", flush=True)
        if i % 10 == 0:
            save_progress(i, len(codes), ok, fail)
    print(f"\n=== 完成: 成功 {ok}  失败 {len(fail)} ===", flush=True)
    if fail:
        with open(os.path.join(".workbuddy", "fund_cache_fill_fail.json"), "w", encoding="utf-8") as f:
            json.dump(dict(fail), f, ensure_ascii=False, indent=1)
        print("失败清单: .workbuddy/fund_cache_fill_fail.json", flush=True)
    return 0 if not fail else 1


if __name__ == "__main__":
    sys.exit(main())
