"""决定性试验：hithink 个股 K 端点的复权基准是否**按请求窗口**重锚？

方法：对同一区间用不同窗口请求两次，比较重叠日期的 close 比值：
  - 比值恒定(≠1)  → 每个请求各自重锚（分片拼接会产生 seam，不可分片）
  - 比值恒等于 1  → 绝对基准（可安全分片拼接）
覆盖 qfq(forward) 与 hfq(backward) 两种口径。

输出 .workbuddy/probe_rebase.json
"""
import json
import sys
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(ROOT / ".env")

from smcore.data import hithink as hk  # noqa: E402

OUT = ROOT / ".workbuddy" / "probe_rebase.json"


def one(code, s, e, adjust):
    d = hk.fetch_historical_k(code, s, e, adjust)
    if d is None or d.empty:
        return pd.DataFrame(columns=["date", "close"])
    d = d.dropna(subset=["close"]).copy()
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d["close"] = pd.to_numeric(d["close"], errors="coerce")
    return d.dropna(subset=["date", "close"])[["date", "close"]].sort_values("date").reset_index(drop=True)


def overlap_ratio(a, b):
    m = a.merge(b, on="date", suffixes=("_a", "_b"))
    if m.empty:
        return None
    m = m[(m["close_b"].abs() > 1e-9)]
    if m.empty:
        return None
    r = m["close_a"] / m["close_b"]
    return {
        "n_overlap": int(len(m)),
        "ratio_min": round(float(r.min()), 5),
        "ratio_max": round(float(r.max()), 5),
        "ratio_cv": round(float(r.std() / (r.mean() or 1)), 6),
        "const_like": bool(r.std() / (abs(r.mean()) or 1) < 1e-4),
    }


def main():
    res = {}
    cases = {
        # 全窗口 vs 收窄起点（重叠 2016-2020）
        "win_A_2015_2020": (date(2015, 1, 5), date(2020, 1, 1)),
        "win_B_2016_2020": (date(2016, 1, 1), date(2020, 1, 1)),
        "win_C_2015_2026_c1": (date(2015, 1, 5), date(2019, 12, 30)),
        "win_D_2017_2021": (date(2017, 1, 3), date(2021, 1, 4)),
    }
    for code in ["000002", "600519", "000001", "600036"]:
        res[code] = {}
        for adjust in ["qfq", "hfq"]:
            series = {k: one(code, s, e, adjust) for k, (s, e) in cases.items()}
            res[code][adjust] = {
                "n": {k: int(len(v)) for k, v in series.items()},
                "A_vs_B_2016_2020": overlap_ratio(series["win_A_2015_2020"], series["win_B_2016_2020"]),
                "C_vs_A_2015_2019": overlap_ratio(series["win_C_2015_2026_c1"], series["win_A_2015_2020"]),
                "D_vs_A_2017_2020": overlap_ratio(series["win_D_2017_2021"], series["win_A_2015_2020"]),
            }
        print(code, "done")

    OUT.write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    print("done ->", OUT)


if __name__ == "__main__":
    main()
