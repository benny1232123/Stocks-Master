# -*- coding: utf-8 -*-
"""对比重建前(备份)与重建后的 Multi-Backtest 产物。"""
import glob
import re
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
SD = ROOT / "stock_data"
BK = ROOT / ".workbuddy" / "_bt_backup_20260921"
OUT = ROOT / ".workbuddy" / "_rebuild_cmp.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


def load_sum(d):
    fs = sorted(glob.glob(str(Path(d) / "Multi-Backtest-*-summary.csv")))
    S = pd.concat([pd.read_csv(f, dtype=str) for f in fs], ignore_index=True) if fs else pd.DataFrame()
    for c in ("total_return", "max_drawdown", "win_rate", "num_trades", "cash_pct",
              "bench_return", "excess_return", "sharpe"):
        if c in S.columns:
            S[c] = pd.to_numeric(S[c], errors="coerce")
    if "date" in S.columns:
        S["date"] = S["date"].astype(str).str[:8]
    return S


def load_tr(d):
    tl = []
    for f in sorted(glob.glob(str(Path(d) / "Multi-Backtest-*-trades.csv"))):
        try:
            t = pd.read_csv(f, dtype=str)
        except Exception:
            continue
        if t.empty or "return_pct" not in t.columns:
            continue
        t["_batch"] = re.search(r"(\d{8})", Path(f).name).group(1)
        tl.append(t)
    T = pd.concat(tl, ignore_index=True) if tl else pd.DataFrame()
    if not T.empty:
        T["return_pct"] = pd.to_numeric(T["return_pct"], errors="coerce")
    return T


OLD_S, NEW_S = load_sum(BK), load_sum(SD)
OLD_T, NEW_T = load_tr(BK), load_tr(SD)

p("=" * 96)
p("重建前 vs 重建后 · 批次级汇总")
p("=" * 96)
for tag, S in (("旧（8σ / 15% 口径）", OLD_S), ("新（DAL boll 口径）", NEW_S)):
    comp = S[S["num_trades"] > 0]
    p(f"  [{tag}] 批次 {len(S)}（有成交 {len(comp)}）")
    p(f"    组合均 {comp['total_return'].mean():+.3f}%  中位 {comp['total_return'].median():+.3f}%  "
      f"正收益 {int((comp['total_return']>0).sum())}/{len(comp)}  "
      f"回撤均 {comp['max_drawdown'].mean():+.3f}%  超额均 {comp['excess_return'].mean():+.3f}%")
    if "stop_mode" in S.columns:
        p(f"    stop_mode 分布: {S['stop_mode'].value_counts().to_dict()}")
    if "exit_mode" in S.columns:
        p(f"    exit_mode: {S['exit_mode'].iloc[0]}")
    p(f"    hold_days: {sorted(set(pd.to_numeric(S['hold_days'], errors='coerce').dropna()))}")

p("")
p("=" * 96)
p("逐笔汇总")
p("=" * 96)
for tag, T in (("旧", OLD_T), ("新", NEW_T)):
    if T.empty:
        p(f"  [{tag}] 无成交")
        continue
    p(f"  [{tag}] 笔数 {len(T)}  笔均 {T['return_pct'].mean():+.3f}%  "
      f"中位 {T['return_pct'].median():+.3f}%  胜率 {100*(T['return_pct']>0).mean():.1f}%")

p("")
p("=" * 96)
p("出场构成")
p("=" * 96)
for tag, T in (("旧", OLD_T), ("新", NEW_T)):
    if T.empty or "exit_reason" not in T.columns:
        continue
    g = T.groupby("exit_reason")["return_pct"].agg(n="count", mean="mean", total="sum")
    p(f"  [{tag}] Σ={T['return_pct'].sum():+.0f} 点")
    p("    " + g.round(2).to_string().replace("\n", "\n    "))

p("")
p("=" * 96)
p("逐批次组合收益对照（旧 → 新）")
p("=" * 96)
if not OLD_S.empty and not NEW_S.empty:
    o = OLD_S.set_index("date")["total_return"]
    n = NEW_S.set_index("date")["total_return"]
    j = pd.concat([o.rename("旧"), n.rename("新")], axis=1)
    j["Δ"] = j["新"] - j["旧"]
    p(j.round(3).to_string())
    d = j["Δ"].dropna()
    p(f"  均值 Δ={d.mean():+.3f}pp  中位 Δ={d.median():+.3f}pp  "
      f"（新更好 {int((d>0).sum())} / 更差 {int((d<0).sum())} / 相同 {int((d==0).sum())}）")

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
