# -*- coding: utf-8 -*-
"""自适应仓位收尾修补：硬上限推导基准改 max(政策目标, 倾斜后目标)。

问题：cap 按「未倾斜政策目标」推导时，风险平价给低波票的倾斜目标可以
      > 政策目标 × multiple（如 600269: 倾斜 21.40% > 政策 13.53%×1.5=20.29%）
      → 目标本身越线 → 报告永远要求减仓，且 cap_below_target 恒 True。

修法：推导基准 = max(policy_w, target_w)。
  - 以政策目标为底：倾斜把某票压小时，上限不被一起压小（保留绝对风控语义）。
  - 取 max(…, target_w)：保证上限 >= 该票目标，目标永不越线。

每处 text.count(old) 断言 == 1，失配即中止。
"""
import pathlib
import sys

ROOT = pathlib.Path(r"E:\Stocks-Master")
TARGET = ROOT / "smcore" / "analysis.py"

REPL = [
    # ① _resolve_target_weight docstring：修正「硬上限按政策目标推导」的陈述
    (
        "    **政策目标**（第 2 个返回值）是**未做波动率倾斜**的 ``equity_ratio ÷ N``：\n"
        "    单票硬上限必须按它推导，否则波动率倾斜会把上限一起带偏。静态口径下两者相等。\n",
        "    **政策目标**（第 2 个返回值）是**未做波动率倾斜**的 ``equity_ratio ÷ N``：\n"
        "    单票硬上限以它为**下限基准**、再取 ``max(政策, 倾斜后目标)``（见\n"
        "    :func:`_resolve_hard_cap` 的调用点），既保留绝对风控语义、又保证目标永不越线。\n"
        "    静态口径下政策目标与目标相等。\n",
    ),
    # ② 调用点：硬上限推导基准
    (
        "    # 单票硬上限按**未倾斜的政策目标**推导，避免波动率倾斜把上限一起带偏\n"
        "    hard_cap = _resolve_hard_cap(cfg, policy_w)\n",
        "    # 单票硬上限的推导基准 = max(政策目标, 倾斜后目标)：\n"
        "    #  - 以政策目标为底 → 保留「绝对风控」语义（倾斜把某票压小时上限不被一起压小）；\n"
        "    #  - 取 max(…, target_w) → 保证上限**永不低于该票目标**，否则目标自身越线、\n"
        "    #    报告会永远要求减仓（风险平价给低波票的倾斜目标可 > 政策 × multiple）。\n"
        "    hard_cap = _resolve_hard_cap(cfg, max(float(policy_w), float(target_w)))\n",
    ),
]

src = TARGET.read_text(encoding="utf-8")
for i, (old, new) in enumerate(REPL, 1):
    n = src.count(old)
    if n != 1:
        print(f"FAIL #{i}: expected 1 hit, got {n}")
        print("--- old ---")
        print(old)
        sys.exit(1)
    src = src.replace(old, new)
    print(f"OK #{i}: replaced 1 hit")

TARGET.write_text(src, encoding="utf-8")
print("WROTE", TARGET)
