# -*- coding: utf-8 -*-
"""把自适应仓位接入两个预览脚本（_real_sizing_preview.py / _gen_real_preview.py），
使本地预览 = 线上真实口径（此前它们只传 n_holdings → 走静态口径，与生产不一致）。

每项带期望命中数（同一文件内可能多处相同片段），失配即中止。
"""
import pathlib
import sys

ROOT = pathlib.Path(r"E:\Stocks-Master")
P1 = ROOT / ".workbuddy" / "_real_sizing_preview.py"
P2 = ROOT / ".workbuddy" / "_gen_real_preview.py"

_CALL_OLD = "total, cfg=POSITION_SIZING_CONFIG, n_holdings=len(codes)"
_CALL_NEW = ("total, cfg=POSITION_SIZING_CONFIG, n_holdings=len(codes),\n"
             "        adaptive=_ADAPTIVE")

REPL = [
    # ── _real_sizing_preview.py ──
    (P1, 1,
     "from smcore.analysis import (  # noqa: E402\n"
     "    build_stock_analysis, fundamentals_available, position_sizing_recommendation,\n"
     ")\n",
     "from smcore.analysis import (  # noqa: E402\n"
     "    adaptive_sizing_context, build_stock_analysis, fundamentals_available,\n"
     "    position_sizing_recommendation,\n"
     ")\n"),
    (P1, 1,
     'print(f"当前仓位比 = {hv / total * 100:.1f}%（现金 {cash / total * 100:.1f}%）")\n',
     'print(f"当前仓位比 = {hv / total * 100:.1f}%（现金 {cash / total * 100:.1f}%）")\n'
     "_ADAPTIVE = adaptive_sizing_context(\n"
     "    codes, as_of=AS_OF, cfg=POSITION_SIZING_CONFIG,\n"
     '    analyses={c: a for c, a, _ in rows if not a.get("error")},\n'
     ")\n"
     'print(f"自适应仓位[{_ADAPTIVE[\'source\']}]：regime {_ADAPTIVE[\'regime\']}"\n'
     '      f"（强度 {_ADAPTIVE[\'regime_strength\']}）→ 总仓位 "'
     'f"{(_ADAPTIVE[\'equity_ratio\'] or 0) * 100:.1f}%；权重法 {_ADAPTIVE[\'weight_method\']}"\n'
     '      + (f"｜note: {_ADAPTIVE[\'note\']}" if _ADAPTIVE.get("note") else ""))\n'
     "for _c in codes:\n"
     '    _f = (_ADAPTIVE.get("weight_frac") or {}).get(_c)\n'
     '    print(f"    {_c}: 权重占比 {_f * 100:.1f}%" if _f else f"    {_c}: 未分配（退等权）")\n'),
    (P1, 3, _CALL_OLD, _CALL_NEW),
    (P1, 1,
     '    print(f"目标口径[{_probe[\'target_source\']}]：总仓位目标 "\n'
     '          f"{POSITION_SIZING_CONFIG.get(\'target_equity_ratio\')} ÷ {len(codes)} 只 "\n'
     '          f"= 每票 {_probe[\'target_weight\']}%；单票硬上限 {_probe[\'hard_cap_weight\']}%"\n'
     '          f"（超限只减到上限，不一步砍到目标）")\n',
     '    print(f"目标口径[{_probe[\'target_source\']}]：本票目标 {_probe[\'target_weight\']}%；"\n'
     '          f"单票硬上限 {_probe[\'hard_cap_weight\']}%"\n'
     '          f"（超限只减到上限，不一步砍到目标）")\n'),
    # ── _gen_real_preview.py ──
    (P2, 1,
     "from smcore.analysis import build_stock_analysis, position_sizing_recommendation  # noqa: E402\n",
     "from smcore.analysis import (  # noqa: E402\n"
     "    adaptive_sizing_context, build_stock_analysis, position_sizing_recommendation,\n"
     ")\n"),
    (P2, 1,
     'equity_total = total if basis != "holdings_only" else None\n',
     'equity_total = total if basis != "holdings_only" else None\n'
     "_ADAPTIVE = adaptive_sizing_context(\n"
     "    codes, as_of=AS_OF, cfg=POSITION_SIZING_CONFIG,\n"
     '    analyses={c: a for c, a, p in ok},\n'
     ")\n"),
    (P2, 1, _CALL_OLD, _CALL_NEW),
    (P2, 1,
     'news_html = N.render_news_surface_html(N.build_news_surface())\n',
     'if _ADAPTIVE.get("enabled"):\n'
     '    _an = (f"市场状态 <b>{_ADAPTIVE.get(\'regime\')}</b>"\n'
     '           f"（强度 {_ADAPTIVE.get(\'regime_strength\')}）→ 总仓位目标 "\n'
     '           f"<b>{(_ADAPTIVE.get(\'equity_ratio\') or 0) * 100:.1f}%</b>；"\n'
     '           f"个股权重方法 <b>{_ADAPTIVE.get(\'weight_method\')}</b>")\n'
     "else:\n"
     '    _an = f"静态口径（自适应未启用：{_ADAPTIVE.get(\'note\') or \'—\'}）"\n'
     'cards.insert(0, f\'<div class="card"><div class="sig">📊 自适应仓位：{_an}</div></div>\')\n'
     "\n"
     'news_html = N.render_news_surface_html(N.build_news_surface())\n'),
    (P2, 1,
     'print(f"分母[{basis}] = 持仓市值 {hv:,.0f} + 现金 {cash:,.0f} = 总资产 {total:,.0f}")\n',
     'print(f"分母[{basis}] = 持仓市值 {hv:,.0f} + 现金 {cash:,.0f} = 总资产 {total:,.0f}")\n'
     'print(f"自适应仓位[{_ADAPTIVE[\'source\']}]：regime {_ADAPTIVE[\'regime\']}"\n'
     '      f"（强度 {_ADAPTIVE[\'regime_strength\']}）→ 总仓位 "'
     'f"{(_ADAPTIVE[\'equity_ratio\'] or 0) * 100:.1f}%；权重法 {_ADAPTIVE[\'weight_method\']}")\n'),
]

# 逐文件成组替换（同文件内按顺序应用；计数断言在**当前**内容上做）
byfile = {}
for path, n, old, new in REPL:
    byfile.setdefault(path, []).append((n, old, new))

for path, items in byfile.items():
    src = path.read_text(encoding="utf-8")
    for i, (n, old, new) in enumerate(items, 1):
        got = src.count(old)
        if got != n:
            print(f"FAIL {path.name} #{i}: expected {n} hit(s), got {got}")
            print("--- old ---")
            print(old)
            sys.exit(1)
        src = src.replace(old, new)
        print(f"OK {path.name} #{i} ({got} hit)")
    path.write_text(src, encoding="utf-8")
print("WROTE", ", ".join(p.name for p in byfile))
