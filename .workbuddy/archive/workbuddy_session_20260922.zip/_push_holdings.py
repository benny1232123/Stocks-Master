import subprocess, json, base64, sys

REPO = "benny1232123/Stocks-Master"
FILE_PATH = "scripts/notify_holdings_analysis.py"
LOCAL = r"E:\Stocks-Master\scripts\notify_holdings_analysis.py"
LOG = r"E:\Stocks-Master\.workbuddy\_push_holdings.log"

def gh(method, path, body=None):
    cmd = ["gh", "api", "-X", method]
    if body is not None:
        cmd += ["--input", "-"]
    cmd += ["repos/%s/%s" % (REPO, path)]
    stdin = json.dumps(body).encode("utf-8") if body is not None else None
    r = subprocess.run(cmd, input=stdin, capture_output=True)
    out = r.stdout.decode("utf-8", "replace")
    err = r.stderr.decode("utf-8", "replace")
    return r.returncode, out, err

lines = []
def log(s):
    lines.append(s); print(s)

# 动态拉取当前 master tip（避免基于过期 base）
rc, out, err = gh("GET", "git/refs/heads/master", None)
if rc != 0:
    log("GET ref FAILED rc=%d err=%s" % (rc, err[:300])); raise SystemExit(1)
BASE = json.loads(out)["object"]["sha"]
log("base(master tip)=%s" % BASE)

# base tree
rc, out, err = gh("GET", "git/commits/%s" % BASE, None)
if rc != 0:
    log("GET base commit FAILED rc=%d err=%s" % (rc, err[:300])); raise SystemExit(1)
base_tree = json.loads(out)["tree"]["sha"]
log("base_tree=%s" % base_tree)

# blob
with open(LOCAL, "rb") as f:
    content = f.read()
b64 = base64.b64encode(content).decode("ascii")
rc, out, err = gh("POST", "git/blobs", {"content": b64, "encoding": "base64"})
if rc != 0:
    log("POST blob FAILED rc=%d err=%s" % (rc, err[:300])); raise SystemExit(1)
blob_sha = json.loads(out)["sha"]
log("blob_sha=%s" % blob_sha)

# tree
rc, out, err = gh("POST", "git/trees", {
    "base_tree": base_tree,
    "tree": [{"path": FILE_PATH, "mode": "100644", "type": "blob", "sha": blob_sha}],
})
if rc != 0:
    log("POST tree FAILED rc=%d err=%s" % (rc, err[:300])); raise SystemExit(1)
tree_sha = json.loads(out)["sha"]
log("tree_sha=%s" % tree_sha)

# commit
msg = ("fix(holdings): 多批次建仓按代码聚合成本/数量，修正持仓日报盈亏\n\n"
       "FIFO 同一代码多次买入会产出多行 pos_df；原 pos_map[c] 被末笔覆盖，"
       "导致报告只显示最后一笔的数量/成本、组合层还因 codes 重复把末笔乘二次，"
       "数量与浮动盈亏双双算错（演示见 .workbuddy/_demo_multilot.py）。\n"
       "现改为按代码聚合：总数量 + 数量加权平均成本 + 最早买入日，codes 去重。")
rc, out, err = gh("POST", "git/commits", {"message": msg, "tree": tree_sha, "parents": [BASE]})
if rc != 0:
    log("POST commit FAILED rc=%d err=%s" % (rc, err[:300])); raise SystemExit(1)
commit_sha = json.loads(out)["sha"]
log("commit_sha=%s" % commit_sha)

# patch ref (fast-forward: parent == current tip)
rc, out, err = gh("PATCH", "git/refs/heads/master", {"sha": commit_sha, "force": False})
if rc != 0:
    log("PATCH ref FAILED rc=%d err=%s" % (rc, err[:300])); raise SystemExit(1)
log("PUSH OK -> master now at %s" % commit_sha)

with open(LOG, "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")
