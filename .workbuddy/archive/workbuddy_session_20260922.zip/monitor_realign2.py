import subprocess, time, json, datetime, sys

RUN = "35423716985"
STATUS_FILE = "E:/Stocks-Master/.workbuddy/_monitor2.txt"
TERMINAL = {"completed", "failure", "cancelled", "skipped", "timed_out"}

def gh(args, retries=5):
    for i in range(retries):
        try:
            p = subprocess.run(["gh"] + args, capture_output=True, text=True, timeout=90)
            if p.returncode == 0:
                return p.stdout
            sys.stderr.write("gh rc=%s err=%s\n" % (p.returncode, p.stderr[:200]))
        except Exception as e:
            sys.stderr.write("gh exc %s\n" % e)
        try:
            subprocess.run(["gh", "auth", "status"], capture_output=True, text=True, timeout=30)
        except Exception:
            pass
        time.sleep(8)
    return None

def view():
    out = gh(["run", "view", RUN, "--json", "status,conclusion,updatedAt,url"])
    if not out:
        return None
    try:
        return json.loads(out)
    except Exception:
        return None

start = datetime.datetime.utcnow()
with open(STATUS_FILE, "w", encoding="utf-8") as f:
    f.write("monitor2 start %s run=%s\n" % (start.isoformat(), RUN))

done = None
for tick in range(300):  # up to 5h
    now = datetime.datetime.utcnow()
    st = view()
    if st is None:
        line = "tick %d %s UNKNOWN" % (tick, now.isoformat())
    else:
        status = st.get("status"); concl = st.get("conclusion")
        line = "tick %d %s %s/%s upd=%s" % (tick, now.isoformat(), status, concl, st.get("updatedAt"))
        if status in TERMINAL:
            done = concl
    with open(STATUS_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")
    if done is not None:
        with open(STATUS_FILE, "a", encoding="utf-8") as f:
            f.write("REALIGN_DONE conclusion=%s\n" % done)
        break
    time.sleep(60)
