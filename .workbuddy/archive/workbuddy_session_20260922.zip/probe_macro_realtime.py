"""Probe macro data sources that work from overseas (Render)."""
import json, ssl, urllib.request, warnings
import pandas as pd
warnings.filterwarnings("ignore")

ctx = ssl.create_default_context()
results = {}

# ── 1. World Bank: China CPI (inflation, consumer prices) ──
try:
    url = ("http://api.worldbank.org/v2/country/CHN/indicator/"
           "FP.CPI.TOTL.ZG?format=json&date=2024:2026&per_page=3")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    resp = urllib.request.urlopen(req, timeout=10, context=ctx)
    data = json.loads(resp.read())
    if isinstance(data, list) and len(data) > 1:
        e = data[1][0] if data[1] else {}
        results["WB_CPI"] = (e.get("value"), e.get("date"))
        print(f"WB CPI: {e.get('value')} @ {e.get('date')}")
except Exception as exc:
    results["WB_CPI"] = None
    print(f"WB CPI FAIL: {exc}")

# ── 2. World Bank: China PPI (producer prices) ──
try:
    url = ("http://api.worldbank.org/v2/country/CHN/indicator/"
           "FP.PI.TOTL.ZG?format=json&date=2024:2026&per_page=3")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    resp = urllib.request.urlopen(req, timeout=10, context=ctx)
    data = json.loads(resp.read())
    if isinstance(data, list) and len(data) > 1:
        e = data[1][0] if data[1] else {}
        results["WB_PPI"] = (e.get("value"), e.get("date"))
        print(f"WB PPI: {e.get('value')} @ {e.get('date')}")
except Exception as exc:
    results["WB_PPI"] = None
    print(f"WB PPI FAIL: {exc}")

# ── 3. OECD: China PMI ──
try:
    url = ("https://stats.oecd.org/SDMX-JSON/data/DP_LIVE/.PMI.TOT.CHN.M/OECD"
           "?contentType=csv&detail=dataOnly&startPeriod=2025-01")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    resp = urllib.request.urlopen(req, timeout=10, context=ctx)
    text = resp.read().decode("utf-8", "ignore").strip()
    lines = [l for l in text.split("\n") if l]
    if lines:
        last = lines[-1]
        parts = last.split(",")
        val = None
        for p in parts:
            try:
                v = float(p.strip())
                if 30 < v < 70:
                    val = v
            except ValueError:
                continue
        results["OECD_PMI"] = (val, parts[2].strip() if len(parts) > 2 else None)
        print(f"OECD PMI: val={val}, raw={last[:180]}")
except Exception as exc:
    results["OECD_PMI"] = None
    print(f"OECD PMI FAIL: {exc}")

# ── 4. akshare: non-jin10 sources for PMI/CPI/PPI ──
try:
    import akshare as ak

    # 4a. PMI monthly (may use eastmoney instead of jin10)
    try:
        df = ak.macro_china_pmi()
        if df is not None and not df.empty:
            last = df.iloc[-1]
            for col in ("制造业PMI", "PMI", "值", "数值"):
                if col in last and pd.notna(last[col]):
                    v = float(last[col])
                    if 30 < v < 70:
                        results["AK_PMI_M"] = (v, str(last.get("月份", "")))
                        print(f"AK PMI(monthly): {v} via col={col}")
                        break
            if "AK_PMI_M" not in results:
                print(f"AK PMI(monthly): cols={list(df.columns)}, no match")
        else:
            print("AK PMI(monthly): empty")
    except Exception as exc:
        print(f"AK PMI(monthly) FAIL: {exc}")

    # 4b. CPI monthly
    try:
        df = ak.macro_china_cpi_monthly()
        if df is not None and not df.empty:
            last = df.iloc[-1]
            for col in ("全国CPI_当月同比", "CPI", "CPI年率"):
                if col in last and pd.notna(last[col]):
                    v = float(last[col])
                    if -10 < v < 20:
                        results["AK_CPI_M"] = (v, str(last.get("月份", "")))
                        print(f"AK CPI(monthly): {v} via col={col}")
                        break
            if "AK_CPI_M" not in results:
                print(f"AK CPI(monthly): cols={list(df.columns)}")
        else:
            print("AK CPI(monthly): empty")
    except Exception as exc:
        print(f"AK CPI(monthly) FAIL: {exc}")

    # 4c. PPI monthly
    try:
        df = ak.macro_china_ppi_monthly()
        if df is not None and not df.empty:
            last = df.iloc[-1]
            for col in ("全国PPI_当月同比", "PPI", "PPI年率"):
                if col in last and pd.notna(last[col]):
                    v = float(last[col])
                    if -20 < v < 20:
                        results["AK_PPI_M"] = (v, str(last.get("月份", "")))
                        print(f"AK PPI(monthly): {v} via col={col}")
                        break
            if "AK_PPI_M" not in results:
                print(f"AK PPI(monthly): cols={list(df.columns)}")
        else:
            print("AK PPI(monthly): empty")
    except Exception as exc:
        print(f"AK PPI(monthly) FAIL: {exc}")
except ImportError:
    print("akshare not available")

print("\n=== SUMMARY ===")
for k, v in results.items():
    print(f"  {k}: {v}")
