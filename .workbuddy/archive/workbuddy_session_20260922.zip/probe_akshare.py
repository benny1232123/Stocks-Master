"""快速校验 akshare(新浪) qfq 作为退化股票的兜底源：取值、覆盖率、吞吐、是否含非正价。"""
import sys
import time
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

OUT = ROOT / ".workbuddy" / "probe_akshare.txt"
lines = []


def ak_qfq(code):
    import akshare as ak
    sym = ("sh" if code.startswith(("5", "6", "9")) else "sz") + code
    raw = ak.stock_zh_a_daily(symbol=sym, start_date="20150105", end_date="20260914", adjust="qfq")
    return raw


for code in ["600519", "000858", "000333", "600036", "000651", "000001"]:
    t0 = time.time()
    try:
        raw = ak_qfq(code)
        dt = time.time() - t0
        n = len(raw)
        c = pd.to_numeric(raw["close"], errors="coerce")
        lines.append(
            f"{code}: rows={n} sec={dt:.2f} nonpos={int((c<=0).sum())} "
            f"min={c.min()} first={raw['date'].iloc[0]} last={raw['date'].iloc[-1]}"
        )
    except Exception as exc:  # noqa: BLE001
        lines.append(f"{code}: ERROR {exc!r} sec={time.time()-t0:.2f}")

# 吞吐：连拉 8 只
t0 = time.time()
ok = 0
for code in ["000002", "000063", "000538", "000568", "000625", "000725", "600000", "601318"]:
    try:
        r = ak_qfq(code)
        if r is not None and not r.empty:
            ok += 1
    except Exception:  # noqa: BLE001
        pass
el = time.time() - t0
lines.append(f"throughput: ok={ok}/8 total={el:.1f}s per_stock={el/8:.2f}s")

OUT.write_text("\n".join(lines), encoding="utf-8")
print("\n".join(lines))
