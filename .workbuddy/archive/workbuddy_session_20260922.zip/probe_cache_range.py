"""查现有 k_data 各物理文件的行数 / 股票数 / 日期范围 / 与 amount/volume 自洽性。"""
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

KD = ROOT / "stock_data" / "k_data"
OUT = ROOT / ".workbuddy" / "probe_cache_range.txt"

lines = []
for pf in sorted(KD.glob("qfq_b*.parquet")):
    df = pd.read_parquet(pf)
    n_codes = df["code"].nunique()
    lines.append(
        f"{pf.name}: rows={len(df)} codes={n_codes} "
        f"date=[{df['date'].min()} .. {df['date'].max()}] MB={pf.stat().st_size/1e6:.1f}"
    )
    # 自洽性：amount/volume vs close（多只抽样）
    smp = df[df["code"].isin(sorted(df["code"].unique())[:3])].copy()
    smp = smp[pd.to_numeric(smp["volume"], errors="coerce") > 0]
    ratio = (pd.to_numeric(smp["amount"], errors="coerce") / pd.to_numeric(smp["volume"], errors="coerce")) / pd.to_numeric(smp["close"], errors="coerce")
    ratio = ratio.replace([float("inf"), float("-inf")], pd.NA).dropna()
    if len(ratio):
        lines.append(
            f"    selfcheck amount/vol÷close: median={ratio.median():.3f} "
            f"p99={ratio.quantile(0.99):.3f} max={ratio.max():.1f} min={ratio.min():.4f}"
        )

OUT.write_text("\n".join(lines), encoding="utf-8")
print("\n".join(lines))
