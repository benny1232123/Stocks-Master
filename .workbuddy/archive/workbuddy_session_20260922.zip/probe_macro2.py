"""第二轮探针：找可用的 LPR / 10Y / FX / PMI-CPI-PPI 替代接口。"""
import threading, akshare as ak

def probe(name, fn, timeout=15):
    box = {}
    def run():
        try:
            box["r"] = fn()
        except Exception as e:  # noqa
            box["e"] = e
    t = threading.Thread(target=run, daemon=True); t.start(); t.join(timeout)
    if t.is_alive():
        return f"{name}: TIMEOUT"
    if "e" in box:
        return f"{name}: ERR {type(box['e']).__name__}: {str(box['e'])[:90]}"
    r = box["r"]
    try:
        if hasattr(r, "shape"):
            head = f"df{r.shape} cols={list(r.columns)[:10]}"
            if not r.empty:
                last = r.iloc[-1]
                head += " | last=" + ",".join(f"{c}={last[c]}" for c in r.columns[:8] if c in last)
        else:
            head = repr(r)[:140]
    except Exception as e:  # noqa
        head = f"repr-err {e}"
    return f"{name}: OK {head}"

# LPR
for fn in ["macro_china_lpr", "lpr_data"]:
    if hasattr(ak, fn):
        print(probe(f"ak.{fn}()", lambda f=fn: getattr(ak, f)()))
    else:
        print(f"ak.{fn}: NOT EXIST")

# Bond 10Y
for fn in ["bond_zh_us_rate", "bond_china_yield", "macro_china_bond_zh_us_rate"]:
    if hasattr(ak, fn):
        try:
            import inspect
            sig = str(inspect.signature(getattr(ak, fn)))
        except Exception:  # noqa
            sig = "?"
        print(f"-- ak.{fn}{sig}")
        if fn == "bond_zh_us_rate":
            print(probe(f"ak.{fn}() no-arg", lambda: getattr(ak, fn)()))
        else:
            print(probe(f"ak.{fn}()", lambda f=fn: getattr(ak, f)()))
    else:
        print(f"ak.{fn}: NOT EXIST")

# FX alternatives
for fn in ["currency_boc", "fx_spot_em", "currency_value_hist"]:
    if hasattr(ak, fn):
        try:
            import inspect
            sig = str(inspect.signature(getattr(ak, fn)))
        except Exception:  # noqa
            sig = "?"
        print(f"-- ak.{fn}{sig}")
        if fn == "currency_boc":
            print(probe("currency_boc 美元", lambda: ak.currency_boc(symbol="美元")))
        elif fn == "fx_spot_em":
            print(probe("fx_spot_em", lambda: ak.fx_spot_em()))
        elif fn == "currency_value_hist":
            print(probe("currency_value_hist 美元", lambda: ak.currency_value_hist(symbol="美元")))
    else:
        print(f"ak.{fn}: NOT EXIST")

# CPI/PPI/PMI non-yearly / alternate hosts
for fn in ["macro_china_cpi", "macro_china_ppi", "macro_china_pmi", "macro_china_gdp_yearly", "macro_china_cpi_monthly", "macro_china_ppi_monthly"]:
    if hasattr(ak, fn):
        print(probe(f"ak.{fn}()", lambda f=fn: getattr(ak, f)()))
    else:
        print(f"ak.{fn}: NOT EXIST")
