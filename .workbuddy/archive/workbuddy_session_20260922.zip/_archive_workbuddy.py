# -*- coding: utf-8 -*-
"""把 .workbuddy session 残留压缩成 zip（排除白名单驱动脚本 + 大体积可复现缓存）。

排除项：
  - 白名单驱动脚本（保留本地、不归档）：rerun_fusion_offline.py / rerun_backtest_offline.py
    / _push_data.py / _push_fix.py / _clean_root.py
  - archive/ 子树（已归档）
  - 大体积可复现缓存（单文件 > 25 MB 一律排除）：
      cctv_out\\stocks_data.db, cctv_run\\stocks_data.db （sqlite 缓存，可重建）
      data_churn_backup_20260916/ （k_data parquet 备份 ~257 MB）
      k_data_backup_20260914/    （k_data parquet 备份 ~235 MB）
      sm-blob/                   （散落的 .git pack）
  - __pycache__ / *.pyc （编译产物，永不归档）
本地残留不删除（本次无"清理"动词）。
"""
import os, zipfile

BASE = r"E:\Stocks-Master\.workbuddy"
ZIP_PATH = os.path.join(BASE, "archive", "workbuddy_session_20260922.zip")
MAX_FILE = 25 * 1024 * 1024  # 25 MB 安全上限

WHITE = {"rerun_fusion_offline.py", "rerun_backtest_offline.py",
         "_push_data.py", "_push_fix.py", "_clean_root.py"}
# 整目录排除（按相对路径首段）
EXCLUDE_DIRS = {"archive", "data_churn_backup_20260916",
                "k_data_backup_20260914", "sm-blob", "__pycache__"}


def rel_parts(path):
    rel = os.path.relpath(path, BASE)
    return [] if rel == "." else rel.split(os.sep)


included, excluded_big, excluded_dir, excluded_white = [], [], [], []
for root, dirs, files in os.walk(BASE):
    parts = rel_parts(root)
    if parts and parts[0] in EXCLUDE_DIRS:
        # 整目录跳过；记录其中大文件用于报告
        for f in files:
            excluded_dir.append(os.path.relpath(os.path.join(root, f), BASE))
        dirs[:] = []  # 不再下钻
        continue
    for f in files:
        full = os.path.join(root, f)
        rel = os.path.relpath(full, BASE)
        if f in WHITE:
            excluded_white.append(rel)
            continue
        if f.endswith(".pyc"):
            continue
        try:
            sz = os.path.getsize(full)
        except OSError:
            continue
        if sz > MAX_FILE:
            excluded_big.append((rel, sz))
            continue
        included.append((rel, full, sz))

included.sort(key=lambda x: x[0])
os.makedirs(os.path.dirname(ZIP_PATH), exist_ok=True)
with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as z:
    for rel, full, _ in included:
        z.write(full, arcname=rel)

zip_sz = os.path.getsize(ZIP_PATH)
tot_bytes = sum(s for _, _, s in included)
lines = []
lines.append(f"INCLUDED files={len(included)} uncompressed={tot_bytes} ({tot_bytes/1024:.1f} KiB)")
lines.append(f"ZIP={ZIP_PATH}")
lines.append(f"ZIP size={zip_sz} ({zip_sz/1024:.1f} KiB, {zip_sz/1024/1024:.2f} MiB)")
lines.append(f"EXCLUDED whitelist scripts ({len(excluded_white)}): " + ", ".join(excluded_white))
lines.append(f"EXCLUDED dirs ({len(excluded_dir)} files): " + ", ".join(sorted(set(excluded_dir))[:8])
             + (f" ... +{len(excluded_dir)-8} more" if len(excluded_dir) > 8 else ""))
lines.append(f"EXCLUDED big files >25MB ({len(excluded_big)}):")
for rel, sz in sorted(excluded_big, key=lambda x: -x[1]):
    lines.append(f"    {sz/1024/1024:.1f} MiB  {rel}")
lines.append("--- first 40 included ---")
for rel, _, sz in included[:40]:
    lines.append(f"  {sz:>9}  {rel}")
txt = "\n".join(lines)
with open(os.path.join(BASE, "_archive_log.txt"), "w", encoding="utf-8") as fh:
    fh.write(txt)
print(txt)
