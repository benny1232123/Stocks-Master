# -*- coding: utf-8 -*-
"""自适应仓位冒烟测试：真实数据下 regime 检测 + 波动率倾斜是否可用。"""
import os
import pathlib
import sys
from datetime import date

ROOT = pathlib.Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
_env = ROOT / ".env"
if _env.exists():
    for _ln in _env.read_text(encoding="utf-8").splitlines():
        _ln = _ln.strip()
        if not _ln or _ln.startswith("#") or "=" not in _ln:
            continue
        _k, _, _v = _ln.partition("=")
        _k, _v = _k.strip(), _v.strip().strip('"').strip("'")
        if _k and _k not in os.environ:
            os.environ[_k] = _v

from smcore.analysis import adaptive_sizing_context  # noqa: E402
from smcore.config.defaults import POSITION_SIZING_CONFIG  # noqa: E402

CODES = ["002284", "600269", "603187", "603390"]
AS_OF = date(2026, 9, 21)

print("=== 原始市场状态 ===")
try:
    from smcore.strategy.market import compute_market_profile
    p = compute_market_profile(AS_OF)
    print(f"regime={p.regime}  strength={p.regime_strength}  trend={p.trend}  "
          f"vol_lvl={p.volatility_level}  vol_pctile={p.volatility_pctile}  "
          f"breadth={p.breadth_score}  hs300_ret20={p.hs300_ret20}")
except Exception as exc:
    print("market_profile FAILED:", type(exc).__name__, exc)

print("\n=== 原始波动率 & 缩放系数 ===")
try:
    from smcore.strategy.position_sizing import _estimate_vol20
    from smcore.strategy.risk_rules import compute_vol_target_params, vol_target_scale
    from smcore.utils.code import format_stock_code
    prm = compute_vol_target_params()
    print("vol_target params:", prm)
    vols = _estimate_vol20(CODES, window=20)
    for c in CODES:
        v = vols.get(format_stock_code(c))
        print(f"  {c}: vol20={('%.4f' % v) if v else None}  scale={vol_target_scale(v, prm):.3f}")
except Exception as exc:
    print("vol FAILED:", type(exc).__name__, exc)

print("\n=== adaptive_sizing_context ===")
ctx = adaptive_sizing_context(CODES, as_of=AS_OF, cfg=POSITION_SIZING_CONFIG)
for k, v in ctx.items():
    print(f"  {k}: {v}")

print("\n=== 对比：静态 vs 自适应 每票目标权重 ===")
from smcore.analysis import _resolve_target_weight  # noqa: E402
for c in CODES:
    static_w, _, static_src = _resolve_target_weight(c, POSITION_SIZING_CONFIG, len(CODES), None)
    ad_w, ad_pol, ad_src = _resolve_target_weight(c, POSITION_SIZING_CONFIG, len(CODES), ctx)
    print(f"  {c}: 静态 {static_w:6.2f}% [{static_src:<12}] → 自适应 {ad_w:6.2f}% "
          f"(政策 {ad_pol:5.2f}%, {ad_src})")
