"""决定式探针：为 k_data 重拉选复权口径。

对比三者在多个历史日期的取值与「近期日收益一致性」：
  A) hithink qfq（服务端前复权，疑似加法式 → 高分红票会出负价）
  B) hithink hfq 派生 qfq（qfq = hfq / hfq[-1]，乘法式，恒正）
  C) akshare 新浪 qfq（与 baostock 同口径，标准乘法前复权 = 参照真值）

输出 .workbuddy/probe_adjust_compare.json
"""
import json
import sys
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(ROOT / ".env")

from smcore.data import hithink as hk  # noqa: E402

OUT = ROOT / ".workbuddy" / "probe_adjust_compare.json"
START = date(2015, 1, 5)
END = date(2026, 9, 14)
CHUNK = 1800  # 自然日/片；实测 <3652 安全


def hk_chunked(code, adjust, start=START, end=END):
    """分片拉 hithink 全历史（每片 start 距片尾 < CHUNK 天）。"""
    frames = []
    cur = start
    while cur <= end:
        ce = min(cur + timedelta(days=CHUNK), end)
        d = hk.fetch_historical_k(code, cur, ce, adjust)
        if d is not None and not d.empty:
            frames.append(d)
        cur = ce + timedelta(days=1)
    if not frames:
        return pd.DataFrame(columns=["date", "open", "high", "low", "close", "volume", "amount"])
    out = pd.concat(frames, ignore_index=True)
    out["date"] = pd.to_datetime(out["date"], errors="coerce")
    out = out.dropna(subset=["date", "close"]).drop_duplicates("date", keep="last")
    return out.sort_values("date").reset_index(drop=True)


def ak_qfq(code):
    try:
        import akshare as ak
    except ImportError:
        return None
    sym = ("sh" if code.startswith(("5", "6", "9")) else "sz") + code
    try:
        raw = ak.stock_zh_a_daily(symbol=sym, start_date="20150105", end_date="20260914", adjust="qfq")
    except Exception:
        return None
    if raw is None or raw.empty:
        return None
    raw = raw.copy()
    raw["date"] = pd.to_datetime(raw["date"], errors="coerce")
    return raw[["date", "close"]].dropna().sort_values("date").reset_index(drop=True)


CODES = ["000001", "600519", "000651", "600036", "000002", "600000", "000858", "601318", "000333", "600030"]
PROBE_DATES = ["2015-01-05", "2018-01-02", "2021-01-04", "2024-01-02", "2026-09-11"]
RECENT_N = 250


def val_at(df, ds):
    if df is None or df.empty:
        return None
    s = df[df["date"] <= pd.Timestamp(ds)]
    if s.empty:
        return None
    return round(float(s["close"].iloc[-1]), 4)


def recent_ret_diff(df_a, df_b, n=RECENT_N):
    """近 n 交易日日收益的最大绝对差（百分点）。"""
    if df_a is None or df_b is None or df_a.empty or df_b.empty:
        return None
    a = df_a.tail(n).set_index("date")["close"]
    b = df_b.tail(n).set_index("date")["close"]
    ra = a.pct_change().dropna() * 100
    rb = b.pct_change().dropna() * 100
    idx = ra.index.intersection(rb.index)
    if len(idx) < 10:
        return None
    d = (ra.loc[idx] - rb.loc[idx]).abs()
    return {"n": int(len(idx)), "max": round(float(d.max()), 4), "median": round(float(d.median()), 4)}


def main():
    res = {"rows": {}}
    for code in CODES:
        row = {}
        h_qfq = hk_chunked(code, "qfq")
        h_hfq = hk_chunked(code, "hfq")
        # 派生 qfq
        if not h_hfq.empty and float(h_hfq["close"].iloc[-1]) != 0:
            base = float(h_hfq["close"].iloc[-1])
            h_hfq_qfq = h_hfq.copy()
            for c in ["open", "high", "low", "close"]:
                h_hfq_qfq[c] = h_hfq_qfq[c] / base
        else:
            h_hfq_qfq = pd.DataFrame(columns=["date", "close"])
        ak = ak_qfq(code)

        row["rows"] = {
            "hithink_qfq": int(len(h_qfq)),
            "hithink_hfq": int(len(h_hfq)),
            "akshare_qfq": int(len(ak)) if ak is not None else None,
        }
        row["neg_rows"] = {
            "hithink_qfq": int((h_qfq["close"] <= 0).sum()) if not h_qfq.empty else None,
            "hithink_hfq": int((h_hfq["close"] <= 0).sum()) if not h_hfq.empty else None,
            "hithink_hfq_qfq": int((h_hfq_qfq["close"] <= 0).sum()) if not h_hfq_qfq.empty else None,
        }
        row["min_close"] = {
            "hithink_qfq": round(float(h_qfq["close"].min()), 3) if not h_qfq.empty else None,
            "hithink_hfq_qfq": round(float(h_hfq_qfq["close"].min()), 4) if not h_hfq_qfq.empty else None,
        }
        row["values"] = {
            "hithink_qfq": {d: val_at(h_qfq, d) for d in PROBE_DATES},
            "hithink_hfq_qfq": {d: val_at(h_hfq_qfq, d) for d in PROBE_DATES},
            "akshare_qfq": {d: val_at(ak, d) for d in PROBE_DATES},
        }
        # 近期日收益一致性（以 akshare 为标准参照）
        row["recent_ret_diff_vs_akshare_pp"] = {
            "hithink_qfq": recent_ret_diff(h_qfq, ak),
            "hithink_hfq_qfq": recent_ret_diff(h_hfq_qfq, ak),
        }
        res["rows"][code] = row
        print(code, "done", row["rows"], row["neg_rows"])

    OUT.write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    print("done ->", OUT)


if __name__ == "__main__":
    main()
