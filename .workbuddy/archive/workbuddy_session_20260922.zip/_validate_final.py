import json, csv, glob, os

sd = r"E:\Stocks-Master\stock_data"
dates = ["20260827","20260828","20260831","20260901","20260902","20260903","20260904",
         "20260907","20260908","20260909","20260910","20260911","20260914","20260915",
         "20260916","20260917"]
print("== DAL check ==")
for d in dates:
    p = os.path.join(sd, f"Daily-Action-List-{d}.csv")
    if not os.path.exists(p):
        print(f"  {d}: MISSING"); continue
    with open(p, encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    strat_col = None
    for c in rows[0].keys() if rows else []:
        if "策略" in c or "strateg" in c.lower():
            strat_col = c; break
    joined = " ".join((r.get(strat_col) or "") for r in rows)
    has_skew60 = "Skew60" in joined
    has_vr = "VRatio10_60" in joined
    print(f"  {d}: rows={len(rows)} Skew60={has_skew60} VRatio10_60={has_vr}")

di = os.path.join(sd, "web_data", "daily_items.json")
with open(di, encoding="utf-8") as f:
    obj = json.load(f)
n = len(obj) if isinstance(obj, list) else len(obj.get("items", obj.get("days", [])))
print(f"== daily_items.json: type={type(obj).__name__} len={n} ==")

mb = glob.glob(os.path.join(sd, "Multi-Backtest-*-summary.csv"))
print(f"== Multi-Backtest summary files: {len(mb)} ==")
print("DONE")
