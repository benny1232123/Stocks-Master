# -*- coding: utf-8 -*-
"""反事实研究（离线只读）：
  A) 校验 buy_price 的定价时点（信号日收盘？次日开盘？）
  B) 每笔成交在某固定持有期 H 下的收益 —— 选出最优 H
  C) 对 trend_break 的 56 笔做「不出场、持有到满期」的反事实，量化 MA60 破位出场的净损益
"""
import glob
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_exit_cf_out.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


from smcore.data.kline import read_kline_cache  # noqa: E402

_kc: dict[str, pd.DataFrame] = {}


def kof(code):
    code = str(code).zfill(6)
    if code not in _kc:
        try:
            k = read_kline_cache(code, base_dir=SD / "k_data")
        except Exception:
            k = pd.DataFrame()
        if not k.empty and "date" in k.columns:
            k = k.copy()
            k["date"] = pd.to_datetime(k["date"], errors="coerce")
            for c in ("open", "high", "low", "close"):
                if c in k.columns:
                    k[c] = pd.to_numeric(k[c], errors="coerce")
            k = k.dropna(subset=["date"]).sort_values("date").reset_index(drop=True)
        _kc[code] = k
    return _kc[code]


# 载入成交
frames = []
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv"))):
    try:
        d = pd.read_csv(f, dtype=str)
    except Exception:
        continue
    if d.empty or "return_pct" not in d.columns:
        continue
    d["_batch"] = re.search(r"(\d{8})", Path(f).name).group(1)
    frames.append(d)
T = pd.concat(frames, ignore_index=True)
T["return_pct"] = pd.to_numeric(T["return_pct"], errors="coerce")
T["buy_price"] = pd.to_numeric(T["buy_price"], errors="coerce")

# ── A) 定价时点校验 ──
p("=" * 96)
p("A) buy_price 的定价时点校验（对照 k_data）")
p("=" * 96)
same_close = next_open = other = miss = 0
for _, r in T.head(40).iterrows():
    k = kof(r["code"])
    if k.empty:
        miss += 1
        continue
    bd = pd.Timestamp(r["buy_date"])
    m = k.index[k["date"] == bd]
    if len(m) == 0:
        # 买日非交易日 → 取最近的前一日
        prev = k.index[k["date"] <= bd]
        if len(prev) == 0:
            miss += 1
            continue
        i = prev[-1]
    else:
        i = m[0]
    c = k.loc[i, "close"] if "close" in k.columns else np.nan
    if pd.notna(c) and abs(c - r["buy_price"]) / r["buy_price"] < 0.005:
        same_close += 1
    elif i + 1 < len(k) and abs(k.loc[i + 1, "open"] - r["buy_price"]) / r["buy_price"] < 0.005:
        next_open += 1
    else:
        other += 1
p(f"  ≈信号日收盘价 {same_close} 笔 / ≈次日开盘价 {next_open} 笔 / 都不像 {other} 笔 / 缺数据 {miss}")

# ── B) 固定持有期 H ──
p("")
p("=" * 96)
p("B) 固定持有期 H（自 buy_date 起 H 个交易日收盘，不含费用/滑点）")
p("=" * 96)
HORIZONS = [1, 2, 3, 4, 5, 6, 8, 10, 12, 17, 20]
res = {h: [] for h in HORIZONS}
used = 0
for _, r in T.iterrows():
    k = kof(r["code"])
    if k.empty:
        continue
    bd = pd.Timestamp(r["buy_date"])
    idx = k.index[k["date"] <= bd]
    if len(idx) == 0:
        continue
    i = idx[-1]
    row = {}
    for h in HORIZONS:
        j = i + h
        if j < len(k) and pd.notna(k.loc[j, "close"]):
            row[h] = (k.loc[j, "close"] / r["buy_price"] - 1) * 100
    if row:
        used += 1
        for h, v in row.items():
            res[h].append(v)
p(f"  可用 {used}/{len(T)} 笔")
p(f"  {'H(交易日)':<12}{'n':>5}{'均值%':>10}{'中位%':>10}{'胜率%':>9}{'标准差':>9}")
for h in HORIZONS:
    v = pd.Series(res[h])
    if len(v) >= 20:
        p(f"  {h:<12}{len(v):>5}{v.mean():>10.2f}{v.median():>10.2f}"
          f"{100*(v>0).mean():>9.1f}{v.std():>9.2f}")
p("")
p("  对照：实际回测已实现（含出场策略/滑点/费用）")
p(f"  {'实际':<12}{len(T):>5}{T['return_pct'].mean():>10.2f}"
  f"{T['return_pct'].median():>10.2f}{100*(T['return_pct']>0).mean():>9.1f}"
  f"{T['return_pct'].std():>9.2f}")

# ── C) trend_break 反事实 ──
p("")
p("=" * 96)
p("C) trend_break 反事实：若不出场、继续持有至 H 个交易日")
p("=" * 96)
tb = T[T["exit_reason"] == "trend_break"].copy()
p(f"  trend_break {len(tb)} 笔，实际均值 {tb['return_pct'].mean():+.2f}%")
p(f"  {'反事实 H':<12}{'n':>5}{'均值%':>10}{'中位%':>10}{'相对实际':>12}")
for h in HORIZONS:
    v, rel = [], []
    for _, r in tb.iterrows():
        k = kof(r["code"])
        if k.empty:
            continue
        bd = pd.Timestamp(r["buy_date"])
        idx = k.index[k["date"] <= bd]
        if len(idx) == 0:
            continue
        i = idx[-1]
        j = i + h
        if j < len(k) and pd.notna(k.loc[j, "close"]):
            ret = (k.loc[j, "close"] / r["buy_price"] - 1) * 100
            v.append(ret)
            rel.append(ret - r["return_pct"])
    if len(v) >= 20:
        p(f"  {h:<12}{len(v):>5}{np.mean(v):>10.2f}{np.median(v):>10.2f}"
          f"{np.mean(rel):>+12.2f}pp")

# 300534 / 002855 明细
p("")
p("  个案明细（最差几笔的实际路径）：")
for code, buys in (("002855", "2026-09-07"), ("300534", "2026-08-31"), ("300534", "2026-08-28")):
    k = kof(code)
    if k.empty:
        continue
    bd = pd.Timestamp(buys)
    idx = k.index[(k["date"] >= bd) & (k["date"] <= bd + pd.Timedelta(days=14))]
    if len(idx) == 0:
        continue
    p(f"    {code} 买入日 {buys}:")
    for i in idx:
        p(f"      {k.loc[i,'date'].date()}  open={k.loc[i,'open']:.2f} "
          f"low={k.loc[i,'low']:.2f} close={k.loc[i,'close']:.2f} "
          f"日涨跌={100*(k.loc[i,'close']/k.loc[i-1,'close']-1):+.2f}%"
          + ("  <=钉在最低(疑似跌停)" if abs(k.loc[i,'low']-k.loc[i,'close'])<1e-9 else ""))

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
