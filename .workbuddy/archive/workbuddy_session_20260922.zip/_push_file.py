"""推送单个文件到 master（Git Database API）。用法: python _push_file.py <path>"""
import base64
import json
import subprocess
import sys
import hashlib
from pathlib import Path

REPO = "benny1232123/Stocks-Master"
ROOT = Path(__file__).resolve().parents[1]
PATH = sys.argv[1]
MSG = sys.argv[2] if len(sys.argv) > 2 else f"chore: 更新 {PATH}"


def gh(args, payload=None):
    cmd = ["gh", "api"] + args
    inp = None
    if payload is not None:
        cmd += ["--input", "-"]
        inp = json.dumps(payload)
    return subprocess.run(cmd, input=inp, capture_output=True, text=True, cwd=str(ROOT))


def jget(args):
    r = gh(args)
    if r.returncode != 0:
        print("FAIL read:", args, r.stderr.strip()[:300])
        sys.exit(1)
    return json.loads(r.stdout)


head = jget([f"repos/{REPO}/git/ref/heads/master"])["object"]["sha"]
base = jget([f"repos/{REPO}/git/commits/{head}"])["tree"]["sha"]
text = (ROOT / PATH).read_text(encoding="utf-8")
print("remote head:", head)

blob = json.loads(gh([f"repos/{REPO}/git/blobs", "--method", "POST"],
                     {"content": text, "encoding": "utf-8"}).stdout)["sha"]
tree = json.loads(gh([f"repos/{REPO}/git/trees", "--method", "POST"],
                     {"base_tree": base, "tree": [
                         {"path": PATH, "mode": "100644", "type": "blob", "sha": blob}]}).stdout)["sha"]
commit = json.loads(gh([f"repos/{REPO}/git/commits", "--method", "POST"],
                       {"message": MSG, "tree": tree, "parents": [head]}).stdout)["sha"]
r = gh([f"repos/{REPO}/git/refs/heads/master", "--method", "PATCH"],
       {"sha": commit, "force": False})
if r.returncode != 0:
    print("FAIL ref:", r.stdout.strip()[:300])
    sys.exit(1)
print("PUSH_OK", commit)

r = gh([f"repos/{REPO}/contents/{PATH}"])
remote = base64.b64decode(json.loads(r.stdout)["content"]).decode("utf-8")
print("MATCH", hashlib.sha256(remote.encode()).hexdigest()[:12],
      "==", hashlib.sha256(text.encode()).hexdigest()[:12], remote == text)
