# -*- coding: utf-8 -*-
"""闸门：hithink 前复权 vs 「标准前复权」(akshare/baostock 同源口径) 对**滚动收益**的影响。

背景：三者关系已查清
  - 仓库缓存 2015-01-05=0.0426 → 坏（偏 ~180x）
  - 全新 akshare 前复权 8.19 == baostock 8.1886 → 二者是同一套标准口径
  - hithink 7.6037 → 自成一套，与标准口径长周期相差 3%~234%
关键问题：hithink 与标准口径的差异是「缓慢变化的缩放」还是「会污染收益」？
  若滚动收益差可忽略 → 用 hithink 全量重建对策略近乎中性（可放心换）；
  若近期滚动收益差明显 → 换源会改变策略行为，需另行评估。
"""
import os
import sys
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
for line in (ROOT / ".env").read_text(encoding="utf-8", errors="ignore").splitlines():
    line = line.strip()
    if line and not line.startswith("#") and "=" in line:
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())

import pandas as pd  # noqa: E402
import baostock as bs  # noqa: E402
from smcore.data import hithink as hk  # noqa: E402

HOLD = 10
out = []


def chunked(c, d1, d2, days=1500):
    fr, cur = [], d1
    while cur <= d2:
        e = min(cur + timedelta(days=days), d2)
        df = hk.fetch_historical_k(c, cur, e, "qfq")
        if df is not None and not df.empty:
            fr.append(df)
        cur = e + timedelta(days=1)
    if not fr:
        return pd.DataFrame()
    a = pd.concat(fr, ignore_index=True)
    return a.drop_duplicates(subset=["date"]).sort_values("date").reset_index(drop=True)


codes = ["000001", "600000", "600519", "000002", "601318", "002415",
         "300750", "600036", "000651", "601899", "002960", "603836"]
bs.login()
rows = []
for c in codes:
    sym = ("sh." if c[0] in "69" else "sz.") + c
    rs = bs.query_history_k_data_plus(sym, "date,close", start_date="2015-01-01",
                                      end_date="2026-09-04", frequency="d", adjustflag="2")
    recs = []
    while rs.next():
        recs.append(rs.get_row_data())
    b = pd.DataFrame([(r[0], float(r[1])) for r in recs if r[1]], columns=["date", "std"])
    h = chunked(c, date(2015, 1, 1), date(2026, 9, 4))
    if h.empty or b.empty:
        continue
    h["date"] = h["date"].astype(str)
    h = h.rename(columns={"close": "hit"})
    m = b.merge(h[["date", "hit"]], on="date").sort_values("date").reset_index(drop=True)
    if len(m) < 300:
        continue
    lvl = ((m["hit"] - m["std"]).abs() / m["std"])
    rs_std = m["std"].pct_change(HOLD)
    rs_hit = m["hit"].pct_change(HOLD)
    d_all = (rs_std - rs_hit).abs().dropna()
    d_rec = (rs_std - rs_hit).abs().dropna().tail(250)
    rows.append((c, float(lvl.median()), float(d_all.median()), float(d_all.max()),
                 float(d_rec.median()), float(d_rec.max())))
bs.logout()

out.append(f"code      level_med   10d_all_med  10d_all_max  10d_recent_med  10d_recent_max")
for r in rows:
    out.append(f"{r[0]}  {r[1]:.4e}  {r[2]:.4e}  {r[3]:.4e}  {r[4]:.4e}  {r[5]:.4e}")
if rows:
    for name, idx in (("level_med", 1), ("10d_all_med", 2), ("10d_all_max", 3),
                      ("10d_recent_med", 4), ("10d_recent_max", 5)):
        v = sorted(x[idx] for x in rows)
        out.append(f"[汇总] {name}: p50={v[len(v)//2]:.4e} max={v[-1]:.4e}")

txt = "\n".join(out)
(ROOT / ".workbuddy" / "probe_hithink_vs_std.txt").write_text(txt, encoding="utf-8")
print(txt)
