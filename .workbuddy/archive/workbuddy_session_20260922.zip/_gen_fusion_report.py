# -*- coding: utf-8 -*-
"""融合排序逻辑调查报告（嵌入原始插桩输出，零手抄）。"""
import html as _h
from pathlib import Path

ROOT = Path(r"E:\Stocks-Master")
W = ROOT / ".workbuddy" / "_weight_align.txt"
Z = ROOT / ".workbuddy" / "_wzero.txt"
M = ROOT / ".workbuddy" / "_mask_probe.txt"
OUT = ROOT / ".workbuddy" / "fusion_weight_rootcause_20260921.html"


def pre(p):
    return "<pre>" + _h.escape(Path(p).read_text(encoding="utf-8")) + "</pre>"


html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>融合排序层根因 2026-09-21</title>
<style>
:root{{--bg:#faf9f6;--card:#fff;--fg:#1c1c1a;--mut:#6b6a65;--bd:#e3e1da;--g:#c0392b;--b:#2e7d32;--w:#8a6d18;}}
@media (prefers-color-scheme:dark){{:root{{--bg:#1b1b19;--card:#232320;--fg:#f0efe9;--mut:#9b9a93;--bd:#3a3a35;--g:#e8695a;--b:#6bbf6f;--w:#d0b055;}}}}
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 20px 64px;background:var(--bg);color:var(--fg);font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;font-size:14px;line-height:1.65}}
.wrap{{max-width:1040px;margin:0 auto}}
h1{{font-size:20px;font-weight:500;margin:0 0 4px}}
.sub{{color:var(--mut);font-size:13px;margin-bottom:24px}}
h2{{font-size:15px;font-weight:500;margin:32px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--bd)}}
h3{{font-size:14px;font-weight:500;margin:20px 0 8px}}
.box{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px 18px;margin:12px 0}}
.box.warn{{border-color:var(--w)}}.box.good{{border-color:var(--g)}}
pre{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:12px 14px;overflow:auto;
font-family:ui-monospace,Consolas,monospace;font-size:12px;line-height:1.5;margin:10px 0}}
table{{width:100%;border-collapse:collapse;font-size:13px;background:var(--card);border:1px solid var(--bd);border-radius:10px;overflow:hidden}}
th,td{{padding:7px 10px;text-align:left;border-bottom:1px solid var(--bd)}}
th{{font-weight:500;font-size:12px;color:var(--mut)}}
tr:last-child td{{border-bottom:none}}
td:nth-child(n+3){{font-variant-numeric:tabular-nums;text-align:right}}
ul{{margin:6px 0 0;padding-left:20px}}li{{margin-bottom:5px}}
code{{font-family:ui-monospace,Consolas,monospace;font-size:12px;background:var(--bg);padding:1px 5px;border-radius:4px;border:1px solid var(--bd)}}
.g{{color:var(--g)}}.b{{color:var(--b)}}
</style></head><body><div class="wrap">
<h1>融合排序层根因调查</h1>
<div class="sub">2026-09-21 · 只读诊断，未改任何生产代码 · 结论：<b>权重链路是好的，是「因子择时 mask」把它反转了</b></div>

<h2>一、因果链（四步，每步都有实测）</h2>
<div class="box">
<b>① 选股分数 = 命中因子的自适应权重之和</b><br>
<code>fusion.py</code> L296-301：<code>score += strategy_scores[_sid]</code>，
随后 L428 <code>sort_values("综合评分", ascending=False)</code> 取 TOP_N。<br>
⇒ <b>谁有权重，就买谁选的票</b>。这是"权重指错方向"能直接变成"选股反向"的传导路径。
</div>
<div class="box good">
<b>② 纯 edge→权重的函数是对的。</b>
<code>adaptive_weights()</code> 直接调用（不叠加择时层）得到：
<code>skew60 27%</code> + <code>vratio10_60 35%</code> = <b>62%</b>，
最差的 <code>illiq20</code>(edge −9.90) 只拿 3% —— <b>方向完全正确</b>。
</div>
<div class="box warn">
<b>③ 但 <code>compute_adaptive_allocation</code> 里插了一层 <code>_apply_factor_timing</code>，
它把上面这个正确结果清零了。</b>
<code>adaptive_weights_config.json</code> 的 <code>factor_timing.enabled = true</code>
（window=10, min_n=5）→ 最终权重变成
<code>pvcorr20 21 / skew20 21 / vratio20_120 21 / cvamt20 17 / illiq20 17 / distlo60 3 / 其余 6 个 0</code>。
</div>
<div class="box warn">
<b>④ mask 的判据在短窗口下发生了方向反转。</b>
<code>factor_timing.py</code> L87 的原则是「<b>点数不足 / IC 无定义 → 保留</b>（无证据不判失效）」、
「IC 显著为正才保留」。在 10 天窗口 + min_n=5 下，绝大多数因子的 IC 都不显著 ⇒
<b>实际决定权落到了「点数够不够」上</b>，而这个判据反向惩罚了证据最多、权重最高的因子。
</div>

<h2>二、mask 实测：正 edge 全被枪毙，负 edge 全被放行</h2>
<table><thead><tr><th>因子</th><th>实测 edge（n 笔）</th><th>窗口内 IC</th><th>mask</th><th>结果</th></tr></thead><tbody>
<tr><td>skew60</td><td><b class="g">+6.70</b>（12 笔，胜率 91.7%）</td><td>+0.179</td><td>False</td><td class="b">清零 ✗</td></tr>
<tr><td>vratio10_60</td><td><b class="g">+4.76</b>（18 笔）</td><td>−0.029</td><td>False</td><td class="b">清零 ✗</td></tr>
<tr><td>cvamt60</td><td><b class="g">+2.54</b>（7 笔，胜率 85.7%）</td><td>−0.614</td><td>False</td><td class="b">清零 ✗</td></tr>
<tr><td>vol20</td><td>+0.82（9 笔）</td><td>−0.764</td><td>False</td><td class="b">清零 ✗</td></tr>
<tr><td>pvcorr60</td><td>−10.72（12 笔）</td><td>0.000</td><td>False</td><td>清零 ✓</td></tr>
<tr><td>distlo10</td><td>−1.31（7 笔）</td><td>−0.698</td><td>False</td><td>清零 ✓</td></tr>
<tr><td><b>pvcorr20</b></td><td>+0.18（<b>仅 1 笔</b>）</td><td><b>None</b></td><td><b>True</b></td><td class="b">保留 ✗</td></tr>
<tr><td><b>illiq20</b></td><td><b class="b">−9.90</b>（9 笔，胜率 22.2%）</td><td><b>None</b></td><td><b>True</b></td><td class="b">保留 ✗</td></tr>
<tr><td><b>cvamt20</b></td><td>−3.76（14 笔）</td><td><b>None</b></td><td><b>True</b></td><td class="b">保留 ✗</td></tr>
<tr><td>skew20</td><td>−1.72（3 笔）</td><td>+0.258</td><td>True</td><td>保留</td></tr>
<tr><td>vratio20_120</td><td>+1.65（4 笔）</td><td><b>None</b></td><td>True</td><td>保留</td></tr>
<tr><td>distlo60</td><td>0.00（<b>0 笔</b>）</td><td><b>None</b></td><td>True</td><td class="b">保留 ✗</td></tr>
</tbody></table>
<div class="box warn">
<b>净效果</b>：三个正 edge 最强的因子（skew60 / vratio10_60 / cvamt60）全部被清零；
而 <code>illiq20</code>(−9.90)、<code>cvamt20</code>(−3.76) 以及 <code>pvcorr20</code>(n=1)、
<code>distlo60</code>(n=0) 这些<b>无证据或负证据</b>的因子全部保留。
<b>「IC 无定义」= 免死金牌，「IC 正但不显著」= 死刑</b>，在 10 天窗口下这两类几乎覆盖全部因子，
于是 mask 的净效应就是<b>惩罚高权重因子、保留低权重因子</b> —— 一个自我挫败的回路。
</div>
<div class="box">
这条链正好解释了上一轮实测的「反向筛选」：mask 保留的名单里包含
<b>illiq20</b> 与 <b>cvamt20</b>，而实测里
<code>illiq20 入选 −1.93% vs 落选 +0.11%</code>、
<code>cvamt20 入选 −3.74% vs 落选 −0.17%</code> —— 数字对得上。
</div>

<h2>三、原始插桩输出</h2>
<h3>A. 权重 vs 因子真实 edge（含由 compute_adaptive_allocation 得到的最终权重）</h3>
{pre(W)}
<h3>B. 逐步插桩：weight 在哪一步变成 0</h3>
{pre(Z)}
<h3>C. mask / 信念 IC / 历史因子池生成试跑</h3>
{pre(M)}

<h2>四、顺带确认的「补数据」能力</h2>
<div class="box good">
<code>scripts/zoo_factor_strategy.py --date YYYYMMDD</code>
<b>可以为任意历史日期重新生成 12 个因子池</b>（读本地 k_data，零联网）。
实测 <b>一天 22 秒</b>、产出 12 × 40 只 —— 意味着
<b>60 个交易日 ≈ 22 分钟、250 个交易日 ≈ 90 分钟</b>即可把因子池历史从 16 天扩到 3 个月~1 年。
下一步要做的长样本验证因此是可行的（详见建议）。
</div>

<h2>五、建议（按性价比）</h2>
<table><thead><tr><th>优先级</th><th>动作</th><th>依据</th></tr></thead><tbody>
<tr><td><b>P0</b></td><td><b>对 <code>factor_timing</code> 做 A/B</b>：把
<code>adaptive_weights_config.json</code> 的 <code>enabled</code> 置 false，
用同一批信号日重跑融合，比较 DAL 的前向收益。<b>16 天窗口即可先看方向。</b></td>
<td>它是唯一的反转层，且是一行配置</td></tr>
<tr><td>P0</td><td>若 A/B 支持关闭：同时审 <code>factor_timing_mask_from_points</code> 的判据 ——
「IC 不显著 → 清零」与「IC 无定义 → 保留」在短窗口下互相矛盾，
应改为「证据不足 → 保留」+「有证据且显著为负 → 清零」</td>
<td>表② 的 12 行</td></tr>
<tr><td>P1</td><td>把窗口从 10 天拉长（IC 在 10 天/5 点上没有统计意义），或直接停用整层</td>
<td>窗口内多点 n=2~3 也在参与判定</td></tr>
<tr><td>P1</td><td>用 zoo_factor_strategy 回填 60~250 天因子池 + 离线重跑融合，
在长样本上复核本结论</td><td>实测 22s/天，成本可接受</td></tr>
</tbody></table>
<div class="box warn">⚠️ 本报告<b>只读诊断</b>，未改任何生产配置。上述 P0 的 A/B 需在下一轮执行。</div>
</div></body></html>"""

OUT.write_text(html, encoding="utf-8")
print("WROTE", OUT, len(html))
