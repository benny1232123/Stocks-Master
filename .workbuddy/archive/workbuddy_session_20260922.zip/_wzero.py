# -*- coding: utf-8 -*-
"""插桩定位：权重里的 0 是在哪一步产生的。"""
import os
import sys
from pathlib import Path

ROOT = Path(r"E:\Stocks-Master")
os.environ["SECTOR_MAP_ONDEMAND"] = "0"
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_wzero.txt"
lines = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


import importlib  # noqa: E402

kl = importlib.import_module("smcore.data.kline")


def _lf(code, start=None, end=None, *a, **k):
    import pandas as pd
    try:
        d = kl.read_kline_cache(str(code).zfill(6), base_dir=SD / "k_data")
    except Exception:
        d = None
    if d is None or getattr(d, "empty", True) or "date" not in getattr(d, "columns", []):
        return pd.DataFrame()
    d = d.copy()
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d.dropna(subset=["date"])
    if start is not None:
        d = d[d["date"] >= pd.Timestamp(start)]
    if end is not None:
        d = d[d["date"] <= pd.Timestamp(end)]
    return d.sort_values("date").reset_index(drop=True)


for mn in ("smcore.data.kline", "smcore.backtest.engine", "smcore.strategy.boll_levels",
           "smcore.strategy.factor_scoring"):
    try:
        m = importlib.import_module(mn)
        if hasattr(m, "fetch_daily_k"):
            m.fetch_daily_k = _lf
    except Exception:
        pass

import smcore.strategy.adaptive_weights as AW  # noqa: E402

ALL_STRATEGIES = AW.ALL_STRATEGIES

C = AW.CONFIG
p("=" * 96)
p("0) CONFIG 实况")
p("=" * 96)
p(f"  ALL_STRATEGIES ({len(ALL_STRATEGIES)}) = {list(ALL_STRATEGIES)}")
for k in ("FLOOR", "temp", "pseudo", "shrinkage", "excluded_strategies",
          "exclude_no_evidence_strategies", "min_evidence_for_allocation",
          "explore_pool_cap_pct", "shrinkage_dynamic"):
    p(f"  {k} = {C.get(k)!r}")
p(f"  CONFIG['edge'] = {C.get('edge')}")
p(f"  CONFIG['factor_timing'] = {C.get('factor_timing')}")

edge = AW.compute_edge(20)
p("")
p("=" * 96)
p("1) compute_edge(20) 逐策略")
p("=" * 96)
tot = 0
for s in ALL_STRATEGIES:
    e = edge.get(s) or {}
    n = int(e.get("n", 0) or 0)
    tot += n
    p(f"  {s:<16} n={n:>4}  edge={e.get('edge')!r}  win={e.get('win_rate')!r}")
p(f"  total_n = {tot}")

p("")
p("=" * 96)
p("2) adaptive_weights 中间步骤")
p("=" * 96)
w1 = AW.adaptive_weights(edge, shrinkage=None, floor=C["FLOOR"],
                         zero_negative_edge=True, min_evidence_n=0)
p(f"  adaptive_weights() → {w1}")
p(f"  合计 = {sum(w1.values())}")

p("")
p("3) _finalize_allocation_weights 中间步骤")
p("=" * 96)
excluded = {s.lower() for s in (C.get("excluded_strategies") or [])}
p(f"  excluded = {excluded}")
p(f"  min_ev_n = {C.get('min_evidence_for_allocation')}")
no_ev, ev = set(), set()
for s in w1:
    if s in excluded:
        continue
    n = int((edge.get(s, {}) or {}).get("n", 0) or 0)
    (no_ev if n < int(C.get("min_evidence_for_allocation", 1) or 1) else ev).add(s)
p(f"  ev      = {sorted(ev)}")
p(f"  no_ev   = {sorted(no_ev)}")
p(f"  excluded 命中权重初稿的 = {sorted(set(excluded) & set(w1))}")
w2 = AW._finalize_allocation_weights(
    w1, edge, excluded,
    exclude_no_evidence=bool(C.get("exclude_no_evidence_strategies", True)),
    eff_floor=float(C["FLOOR"]),
    min_ev_n=int(C.get("min_evidence_for_allocation", 1) or 1),
)
p(f"  _finalize → {w2}")
p(f"  合计 = {sum(w2.values())}")
zeros = [s for s, v in w2.items() if v == 0]
p("")
p(f"  ★ 被清零的策略 ({len(zeros)}) = {zeros}")
p(f"  ★ 它们在 excluded 里吗？ " +
  str({s: (s in excluded) for s in zeros}))

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
