"""定位重依赖的导入来源 + 用正确签名测真实 RSS。"""
from __future__ import annotations

import ctypes
import os
import sys
from ctypes import wintypes

sys.path.insert(0, r"E:\Stocks-Master")
os.environ.setdefault("KLINE_BACKEND", "akshare")
os.environ.setdefault("RENDER_LITE", "1")
os.environ.setdefault("TDX_ENABLED", "0")

k32 = ctypes.windll.kernel32
psapi = ctypes.windll.psapi


class PMC(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD),
        ("PageFaultCount", wintypes.DWORD),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
    ]


psapi.GetProcessMemoryInfo.argtypes = [
    wintypes.HANDLE, ctypes.POINTER(PMC), wintypes.DWORD
]
psapi.GetProcessMemoryInfo.restype = wintypes.BOOL
k32.GetCurrentProcess.restype = wintypes.HANDLE


def rss_mb() -> float:
    c = PMC()
    c.cb = ctypes.sizeof(PMC)
    ok = psapi.GetProcessMemoryInfo(k32.GetCurrentProcess(), ctypes.byref(c), c.cb)
    if not ok:
        return -1.0
    return c.WorkingSetSize / 1024 / 1024


HEAVY = ("akshare", "backtrader", "baostock", "jieba", "matplotlib", "supabase",
         "talib", "pyarrow", "bs4", "lxml")

print(f"[base empty] {rss_mb():7.1f} MB")

MODS = [
    "smcore.analysis",
    "smcore.backtest",
    "smcore.dashboard",
    "smcore.holdings",
    "smcore.selection",
    "smcore.strategy",
    "smcore.risk.external",
    "smcore.strategy.news_surface",
]

prev_mods = set(sys.modules)
prev_rss = rss_mb()
for m in MODS:
    try:
        __import__(m)
    except Exception as exc:  # noqa: BLE001
        print(f"  {m:34} FAILED {type(exc).__name__}: {exc}")
        continue
    new_mods = set(sys.modules) - prev_mods
    pulled = sorted({mm.split(".")[0] for mm in new_mods} & set(HEAVY))
    cur = rss_mb()
    print(f"  {m:34} +{cur - prev_rss:6.1f} MB   -> 引入 {pulled}")
    prev_rss = cur
    prev_mods = set(sys.modules)

print("\n--- 完整 backend.main 启动基线 ---")
before_mods = set(sys.modules)
b = rss_mb()
from backend.main import app  # noqa: E402,F401

a = rss_mb()
print(f"导入 backend.main: {b:.1f} -> {a:.1f} MB (增量 {a - b:.1f} MB)")
heavy_now = sorted({mm.split(".")[0] for mm in sys.modules} & set(HEAVY))
print(f"启动即加载的重依赖: {heavy_now}")

# akshare 是否在启动链里？
print(f"\nakshare loaded at startup: {'akshare' in sys.modules}")
print(f"backtrader loaded at startup: {'backtrader' in sys.modules}")
print(f"matplotlib loaded at startup: {'matplotlib' in sys.modules}")
