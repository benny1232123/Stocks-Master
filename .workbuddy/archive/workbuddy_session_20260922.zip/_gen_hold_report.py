# -*- coding: utf-8 -*-
"""持有期 / 出场 A/B 报告（自包含 HTML，数据现场从 hold_exp/ 现算）。"""
import glob
import math
import re
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
OUTROOT = ROOT / ".workbuddy" / "hold_exp"
OUT = ROOT / ".workbuddy" / "hold_ab_20260921.html"
ARMS = [("base12", "生产现状（出场全开 + 持有 12 日）"),
        ("h1", "纯固定持有 1 日（关全部出场）"),
        ("h2", "纯固定持有 2 日"),
        ("h3", "纯固定持有 3 日"),
        ("h5", "纯固定持有 5 日"),
        ("h12_notrend", "出场全开但关掉 MA60 破位")]

D = {}
for arm, _ in ARMS:
    d = OUTROOT / arm
    sfs = sorted(glob.glob(str(d / "Multi-Backtest-*-summary.csv")))
    S = pd.concat([pd.read_csv(f, dtype=str) for f in sfs], ignore_index=True) if sfs else pd.DataFrame()
    for c in ("total_return", "cash_pct", "max_drawdown", "num_trades",
              "bench_return", "excess_return"):
        if c in S.columns:
            S[c] = pd.to_numeric(S[c], errors="coerce")
    if "date" in S.columns:
        S["date"] = S["date"].astype(str).str[:8]
    tl = []
    for f in sorted(glob.glob(str(d / "Multi-Backtest-*-trades.csv"))):
        try:
            t = pd.read_csv(f, dtype=str)
        except Exception:
            continue
        if t.empty or "return_pct" not in t.columns:
            continue
        t["_batch"] = re.search(r"(\d{8})", Path(f).name).group(1)
        tl.append(t)
    T = pd.concat(tl, ignore_index=True) if tl else pd.DataFrame()
    if not T.empty:
        for c in ("return_pct", "qty", "buy_price"):
            T[c] = pd.to_numeric(T[c], errors="coerce")
        T["_v"] = T["qty"] * T["buy_price"]
        T["exit_reason"] = T["exit_reason"].fillna("—")
    D[arm] = (S, T)

POS = {}
for arm, _ in ARMS:
    S, T = D[arm]
    if T.empty:
        POS[arm] = pd.DataFrame()
        continue
    POS[arm] = T.groupby(["_batch", "code"]).apply(
        lambda x: pd.Series({
            "ret": (x["return_pct"] * x["_v"]).sum() / x["_v"].sum() if x["_v"].sum() else x["return_pct"].mean(),
            "val": x["_v"].sum(),
        }), include_groups=False).reset_index()

b0 = D["base12"][0].set_index("date")["total_return"]


def tbl(head, rows_):
    th = "".join(f"<th>{h}</th>" for h in head)
    tr = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows_)
    return f"<table><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table>"


main_rows = []
for arm, label in ARMS:
    S, T = D[arm]
    comp = S[S["num_trades"] > 0]
    pos = POS[arm]
    hl = ' style="background:rgba(127,127,127,.10)"' if arm == "base12" else ""
    main_rows.append(
        [f'<span{hl}>{label}</span>', len(comp), len(pos),
         f"{pos['ret'].mean():+.3f}", f"{pos['ret'].median():+.3f}",
         f"{100*(pos['ret']>0).mean():.1f}",
         f"{(pos['ret']*pos['val']).sum()/pos['val'].sum():+.3f}",
         f"<b>{comp['total_return'].mean():+.3f}</b>",
         f"{comp['max_drawdown'].mean():+.3f}",
         f"{comp['excess_return'].mean():+.3f}"])

pair_rows = []
for arm, label in ARMS[1:]:
    b = D[arm][0].set_index("date")["total_return"]
    j = pd.concat([b0.rename("base"), b.rename("arm")], axis=1).dropna()
    dd = j["arm"] - j["base"]
    t = dd.mean() / (dd.std() / math.sqrt(len(dd))) if dd.std() else float("nan")
    pair_rows.append([label, len(j), f"{dd.mean():+.3f}", f"{t:+.2f}",
                      f"{int((dd>0).sum())} / {int((dd<0).sum())}"])

exit_rows = []
for arm in ("base12", "h12_notrend"):
    S, T = D[arm]
    g = T.groupby("exit_reason")["return_pct"].agg(n="count", mean="mean", total="sum")
    for k, r in g.sort_values("total").iterrows():
        exit_rows.append([arm, k, int(r["n"]), f"{r['mean']:+.2f}%", f"{r['total']:+.0f}"])

html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>持有期 / 出场 A/B 2026-09-21</title>
<style>
:root{{--bg:#faf9f6;--card:#fff;--fg:#1c1c1a;--mut:#6b6a65;--bd:#e3e1da;--g:#c0392b;--b:#2e7d32;--w:#8a6d18;}}
@media (prefers-color-scheme:dark){{:root{{--bg:#1b1b19;--card:#232320;--fg:#f0efe9;--mut:#9b9a93;--bd:#3a3a35;--g:#e8695a;--b:#6bbf6f;--w:#d0b055;}}}}
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 20px 64px;background:var(--bg);color:var(--fg);font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;font-size:14px;line-height:1.65}}
.wrap{{max-width:1000px;margin:0 auto}}
h1{{font-size:20px;font-weight:500;margin:0 0 4px}}
.sub{{color:var(--mut);font-size:13px;margin-bottom:24px}}
h2{{font-size:15px;font-weight:500;margin:32px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--bd)}}
table{{width:100%;border-collapse:collapse;font-size:12.5px;background:var(--card);border:1px solid var(--bd);border-radius:10px;overflow:hidden}}
th,td{{padding:7px 9px;text-align:left;border-bottom:1px solid var(--bd)}}
th{{font-weight:500;font-size:12px;color:var(--mut)}}
tr:last-child td{{border-bottom:none}}
td:nth-child(n+2){{font-variant-numeric:tabular-nums;text-align:right}}
.box{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px 18px;margin:12px 0}}
.box.warn{{border-color:var(--w)}}
.box.good{{border-color:var(--g)}}
ul{{margin:6px 0 0;padding-left:20px}}li{{margin-bottom:5px}}
code{{font-family:ui-monospace,Consolas,monospace;font-size:12px;background:var(--bg);padding:1px 5px;border-radius:4px;border:1px solid var(--bd)}}
.g{{color:var(--g)}}.b{{color:var(--b)}}
</style></head><body><div class="wrap">
<h1>持有期 / 出场 A/B</h1>
<div class="sub">2026-09-21 · 真实回测引擎（滑点 0.1%×2 + 佣金最低¥5 + 印花税 0.05% + T+1 + 跌停顺延 + 波动率仓位缩放）
· 同一批 16 个信号日 · 输出隔离在 <code>.workbuddy/hold_exp/</code>，未碰生产产物</div>

<h2>一、结论（先说要紧的）</h2>
<div class="box warn">
<b>① 我上一轮的建议不成立：「缩短持有期」在真实成本引擎里没有可靠优势。</b><br>
组合均收益 base12 <b class="b">-0.769%</b> → h1 <b class="g">-0.395%</b> / h2 -0.367% / h3 -0.429%
（改善约 +0.35pp），但<b>配对 t 只有 +1.35 ~ +1.71，不显著</b>；
而 h5（持有 5 日）反而比 base12 更差（-0.849%）。<b>非单调 ⇒ 差异主要是噪声。</b><br>
<span style="color:var(--mut)">上一轮的 +0.56%/+0.81% 是「同一批成交、只换出场时点」的毛收益反事实，
没有计入最低 ¥5 佣金与不同成交集合的影响，被高估了。</span>
</div>
<div class="box good">
<b>② MA60 破位出场是有用的，不该移除。</b>关掉它之后 <code>trailing</code>（移动止盈 5%）接管 49 笔，
均值 <b class="b">-4.88%</b>、胜率仅 <b class="b">4.1%</b>、合计 <b class="b">-239 点</b> —— 比
<code>trend_break</code> 的 -170 点<b>更差</b>；组合均收益也从 -0.769% 恶化到 -0.921%，
12/15 个批次变差。<b>上一轮我暗示「MA60 破位可考虑移除」，这是错的。</b>
</div>
<div class="box">
<b>③ 唯一稳定的可见收益：更短持有 → 回撤更小。</b>
平均单批回撤 base12 <b>-1.677%</b> → h1 <b class="g">-1.097%</b>（收窄 0.58pp），
且 h1/h2/h3 都优于 base12，h5 更差。方向一致但幅度仍在噪声内。
</div>
<div class="box warn">
<b>④ 四个 arm 一致指向同一件事：这 16 个信号日没有可靠 alpha。</b>
所有 arm 的组合均收益为负、超额收益 ≈ 0 或为负（-0.42% ~ +0.02%）。
调持有期、调出场都改变不了这一点 —— <b>问题在选股信号的强度，不在出场参数</b>。
</div>

<h2>二、可比口径对照表</h2>
<div class="sub" style="margin:0 0 8px">⚠️ 出场打开的 arm 会把一次持仓拆成多条成交记录（分批止盈），
所以「笔均」在 arm 之间不可比。下表按 <b>(批次, 代码)</b> 聚合成「一条持仓一个收益」并做数量加权。</div>
{tbl(["方案", "批次", "持仓数", "持仓均%", "持仓中位%", "持仓胜率%", "持仓市值加权%",
      "组合均%", "回撤均%", "超额均%"], main_rows)}

<h2>三、批次级配对检验（与生产现状比，同一信号日）</h2>
{tbl(["方案", "共同批次", "Δ组合均%（正=更好）", "配对 t", "胜 / 负"], pair_rows)}
<div class="box">
|t| &lt; 2 一律视为不显著。除 h1 的 +1.71 稍稍接近外，其余都在噪声内；
<code>h12_notrend</code> 则是明确变差（4 胜 12 负）。
</div>

<h2>四、出场构成：关掉 MA60 破位后谁接管</h2>
{tbl(["方案", "出场原因", "笔数", "均值", "总贡献（点）"], exit_rows)}
<div class="box">
base12 的 Σ = +47 点；h12_notrend 的 Σ = +9 点。
关键差异就是 <code>trend_break</code>(-170) 被 <code>trailing</code>(-239) 取代。
纯固定持有的 arm 只会有 <code>max_hold</code> 一种出场（符合设计）。
</div>

<h2>五、这个方法本身的限制</h2>
<ul>
<li>只有 16 个信号日、每 arm 100~150 条持仓；批次级配对 n=15~16 → 任何 &lt; 0.5pp 的差异都测不出来。</li>
<li>各 arm 的「未走完」批次（越晚的信号日 + 越长的持有期）会被截断在数据末端，
不同 arm 的截断程度不同 —— 这是组合口径仍然存在的残余偏差。</li>
<li>本轮用的是<strong>当前本地 k_data</strong>（与生产当时的数据存在复权再基准差异），
所以 base12 只能复现到 <code>-0.769%</code> vs 生产的 <code>-0.797%</code>（接近但非逐笔一致）。</li>
<li><b>因此：不要因为这张表就去改配置。</b>要得到可下的结论，需要把信号日扩到 3~6 个月
（≥200~300 条持仓），并固定一份数据快照。</li>
</ul>
</div></body></html>"""

OUT.write_text(html, encoding="utf-8")
print("WROTE", OUT)
for arm, label in ARMS:
    S, T = D[arm]
    pos = POS[arm]
    comp = S[S["num_trades"] > 0]
    print(f"{arm:<12} pos={len(pos):>4} posmean={pos['ret'].mean():+.3f} "
          f"port={comp['total_return'].mean():+.3f} dd={comp['max_drawdown'].mean():+.3f}")
