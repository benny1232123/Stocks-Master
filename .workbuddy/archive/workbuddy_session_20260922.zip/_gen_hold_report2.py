# -*- coding: utf-8 -*-
"""持有期 A/B —— 改用「权益曲线末端」作为主口径（消除 trades 只含已平仓的截断偏差）。"""
import glob
import json
import math
import re
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
OUTROOT = ROOT / ".workbuddy" / "hold_exp"
OUT = ROOT / ".workbuddy" / "hold_ab_20260921.html"
ARMS = [("base12", "生产现状（出场全开 + 持有 12 日）"),
        ("h1", "纯固定持有 1 日（关全部出场）"),
        ("h2", "纯固定持有 2 日"),
        ("h3", "纯固定持有 3 日"),
        ("h5", "纯固定持有 5 日"),
        ("h12_notrend", "出场全开但关掉 MA60 破位")]

rows, eq = [], {}
for arm, label in ARMS:
    d = OUTROOT / arm
    per = {}
    for f in sorted(glob.glob(str(d / "Multi-Backtest-*-equity.csv"))):
        tag = re.search(r"(\d{8})", Path(f).name).group(1)
        try:
            e = pd.read_csv(f)
        except Exception:
            continue
        if e.empty or "total" not in e.columns:
            continue
        e["total"] = pd.to_numeric(e["total"], errors="coerce")
        e = e.dropna(subset=["total"])
        if e.empty:
            continue
        # 初始资金 100000；末端 total → 该批最终 P&L
        per[tag] = {"ret": float(e["total"].iloc[-1]) / 100000.0 - 1,
                    "last": str(e["date"].iloc[-1])[:10],
                    "rows": len(e)}
        if "drawdown" in e.columns:
            per[tag]["dd"] = float(pd.to_numeric(e["drawdown"], errors="coerce").min())
    eq[arm] = per
    r = pd.Series({k: v["ret"] * 100 for k, v in per.items()})
    dd = pd.Series({k: v.get("dd", float("nan")) for k, v in per.items()}).dropna()
    rows.append({
        "arm": arm, "label": label, "批次": len(per),
        "批均%": round(r.mean(), 3), "批中位%": round(r.median(), 3),
        "正收益批次": f"{int((r>0).sum())}/{len(r)}",
        "最差%": round(r.min(), 3), "最好%": round(r.max(), 3),
        "平均回撤%": round(dd.mean(), 3) if len(dd) else None,
    })

T = pd.DataFrame(rows)
print(T.to_string(index=False))

# 批次级配对（共同信号日）
base = pd.Series({k: v["ret"] for k, v in eq["base12"].items()})
pairs = []
for arm, label in ARMS[1:]:
    a = pd.Series({k: v["ret"] for k, v in eq[arm].items()})
    j = pd.concat([base.rename("b"), a.rename("a")], axis=1).dropna()
    dd = (j["a"] - j["b"]) * 100
    t = dd.mean() / (dd.std() / math.sqrt(len(dd))) if dd.std() else float("nan")
    pairs.append({"arm": arm, "label": label, "n": len(j),
                  "Δ批均%": round(dd.mean(), 3), "t": round(t, 2),
                  "胜/负": f"{int((dd>0).sum())}/{int((dd<0).sum())}"})
P = pd.DataFrame(pairs)
print()
print(P.to_string(index=False))

# 截断检查
print()
print("各 arm 每批权益曲线末端日期（判断是否被数据末端截断）：")
for arm, _ in ARMS:
    print(f"  {arm:<12}", " ".join(f"{k[-4:]}:{v['last'][5:]}" for k, v in eq[arm].items()))


def tbl(head, rws):
    th = "".join(f"<th>{h}</th>" for h in head)
    tr = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rws)
    return f"<table><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table>"


main_rows = []
for _, r in T.iterrows():
    hl = ' style="background:rgba(127,127,127,.10)"' if r["arm"] == "base12" else ""
    main_rows.append([f'<span{hl}>{r["label"]}</span>', r["批次"], f'{r["批均%"]:+.3f}',
                      f'{r["批中位%"]:+.3f}', r["正收益批次"], f'{r["最差%"]:+.2f}',
                      f'{r["最好%"]:+.2f}', f'{r["平均回撤%"]:+.3f}'])

pair_rows = [[r["label"], r["n"], f'{r["Δ批均%"]:+.3f}', f'{r["t"]:+.2f}', r["胜/负"]]
             for _, r in P.iterrows()]

trunc_rows = [[arm, str(len(eq[arm])),
               " ".join(f'{k[-4:]}→{v["last"][5:]}' for k, v in list(eq[arm].items())[:4]) + " …"]
              for arm, _ in ARMS]

best = T.loc[T["批均%"].idxmax()]
ddbest = T.loc[T["平均回撤%"].idxmax()]

html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>持有期 / 出场 A/B 2026-09-21</title>
<style>
:root{{--bg:#faf9f6;--card:#fff;--fg:#1c1c1a;--mut:#6b6a65;--bd:#e3e1da;--g:#c0392b;--b:#2e7d32;--w:#8a6d18;}}
@media (prefers-color-scheme:dark){{:root{{--bg:#1b1b19;--card:#232320;--fg:#f0efe9;--mut:#9b9a93;--bd:#3a3a35;--g:#e8695a;--b:#6bbf6f;--w:#d0b055;}}}}
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 20px 64px;background:var(--bg);color:var(--fg);font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;font-size:14px;line-height:1.65}}
.wrap{{max-width:1000px;margin:0 auto}}
h1{{font-size:20px;font-weight:500;margin:0 0 4px}}
.sub{{color:var(--mut);font-size:13px;margin-bottom:24px}}
h2{{font-size:15px;font-weight:500;margin:32px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--bd)}}
table{{width:100%;border-collapse:collapse;font-size:12.5px;background:var(--card);border:1px solid var(--bd);border-radius:10px;overflow:hidden}}
th,td{{padding:7px 9px;text-align:left;border-bottom:1px solid var(--bd)}}
th{{font-weight:500;font-size:12px;color:var(--mut)}}
tr:last-child td{{border-bottom:none}}
td:nth-child(n+2){{font-variant-numeric:tabular-nums;text-align:right}}
.box{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px 18px;margin:12px 0}}
.box.warn{{border-color:var(--w)}}.box.good{{border-color:var(--g)}}
ul{{margin:6px 0 0;padding-left:20px}}li{{margin-bottom:5px}}
code{{font-family:ui-monospace,Consolas,monospace;font-size:12px;background:var(--bg);padding:1px 5px;border-radius:4px;border:1px solid var(--bd)}}
.g{{color:var(--g)}}.b{{color:var(--b)}}
</style></head><body><div class="wrap">
<h1>持有期 / 出场 A/B（真实回测引擎）</h1>
<div class="sub">2026-09-21 · 滑点 0.1%×2 + 佣金最低¥5 + 印花税 0.05% + T+1 + 跌停顺延 + 波动率仓位缩放
· 同一批 16 个信号日 · 输出隔离在 <code>.workbuddy/hold_exp/</code>，未碰生产产物</div>

<h2>一、最重要的更新：上一轮的建议被这次 A/B 否掉了</h2>
<div class="box warn">
<b>「缩短持有期能改善收益」不成立。</b>
用真实引擎跑，所有方案的批次均收益都是负的：
生产现状 <b class="b">{T.loc[0,'批均%']:+.3f}%</b>、
h1 <b class="g">{T.loc[1,'批均%']:+.3f}%</b>、h2 {T.loc[2,'批均%']:+.3f}%、
h3 {T.loc[3,'批均%']:+.3f}%、h5 <b class="b">{T.loc[4,'批均%']:+.3f}%</b>。
缩短到 1~3 日确实略好（+0.3~0.4pp），但 <b>配对 t 只有 {P.loc[P['arm']=='h1','t'].iloc[0]:+.2f}，不显著</b>；
缩到 5 日反而更差。这种非单调说明<b>差异主要是噪声</b>。<br>
<span style="color:var(--mut)">上一轮的 +0.56%/+0.81% 是毛收益反事实，没计最低 ¥5 佣金，
也没考虑成交集合与截断差异 —— 被高估了。</span>
</div>
<div class="box good">
<b>MA60 破位出场有用，不应移除。</b>关掉后由 <code>trailing</code>（移动止盈 5%）接管 49 笔，
均值 <b class="b">-4.88%</b>、胜率 <b class="b">4.1%</b>、合计 <b class="b">-239 点</b>，
比 <code>trend_break</code> 的 -170 点更差；批次均收益恶化到 <b class="b">{T.loc[5,'批均%']:+.3f}%</b>，
{P.loc[P['arm']=='h12_notrend','胜/负'].iloc[0]} 个批次变差。上一轮我的暗示是错的。
</div>
<div class="box">
<b>唯一稳定可见的收益：更短持有 → 回撤更小。</b>
平均单批回撤：生产现状 <b>{T.loc[0,'平均回撤%']:+.3f}%</b> →
h1 <b class="g">{T.loc[1,'平均回撤%']:+.3f}%</b> / h2 {T.loc[2,'平均回撤%']:+.3f}% /
h3 {T.loc[3,'平均回撤%']:+.3f}%，而 h5 {T.loc[4,'平均回撤%']:+.3f}% 更差。
</div>
<div class="box warn">
<b>所有方案一致指向：这 16 个信号日没有可靠 alpha。</b>
六个方案的批次均收益全部为负（{T['批均%'].min():+.2f}% ~ {T['批均%'].max():+.2f}%），
正收益批次都在一半左右。调持有期、调出场都改变不了这一点 ——
<b>瓶颈在选股信号的强度</b>，不在出场参数。
</div>

<h2>二、主口径：批次最终 P&amp;L（权益曲线末端，消除截断偏差）</h2>
<div class="sub" style="margin:0 0 8px">
⚠️ 成交记录只包含<b>已平仓</b>的持仓，长持有期的方案在数据末端仍持仓 → 会被漏掉，
所以「笔均」在方案之间不可比。改用每批<b>权益曲线末端 total</b> 作为该信号日的最终 P&amp;L。</div>
{tbl(["方案", "批次", "批均%", "批中位%", "正收益批次", "最差%", "最好%", "平均回撤%"], main_rows)}

<h2>三、批次级配对检验（与生产现状比，同一信号日）</h2>
{tbl(["方案", "共同批次", "Δ批均%（正=更好）", "配对 t", "胜 / 负"], pair_rows)}
<div class="box">|t| &lt; 2 一律视为不显著。全部方案都没能通过这道门槛；
<code>h12_notrend</code> 是唯一方向明确变差的（{P.loc[P['arm']=='h12_notrend','胜/负'].iloc[0]}）。</div>

<h2>四、截断透明度（各方案每批权益曲线看到哪一天）</h2>
<div class="sub" style="margin:0 0 8px">
窗口长度由 <code>end_pad = 信号日 + (持有期+15) 天</code> 决定，所以短持有方案的曲线更早结束。
但退出后组合已是纯现金、权益恒定，<b>曲线末端 total 仍等于该批的已实现 P&amp;L</b>，
因此主口径不受影响。（真正需要注意的是成交记录口径 —— 见第二节说明。）</div>
{tbl(["方案", "批次数", "各批权益末端（信号日→末端日期）"], trunc_rows)}

<h2>五、结论与下一步</h2>
<ul>
<li><b>不要改持有期配置、不要移除 MA60 破位</b>——本轮 A/B 不支持这两个动作。</li>
<li>真正该解决的是<b>信号强度</b>：16 个信号日 × 6 个方案，批次均收益全负。
这与此前「全样本笔均 +0.04%、95%CI 横跨零点」的结论一致。</li>
<li>要得到能改配置的证据，需要：(a) 把信号日扩到 3~6 个月（≥200~300 条持仓）；
(b) 固定一份数据快照避免复权再基准差异；(c) 预设判据（如「Δ批均 ≥ 0.5pp 且 t ≥ 2」）再跑。</li>
<li><b>仍然成立的 P0</b>：统一两套止损口径（回测 15% vs 清单 5.45%，120/120 不一致）——
这不需要更多样本就能修，且是明确的一致性缺陷。</li>
</ul>
</div></body></html>"""

OUT.write_text(html, encoding="utf-8")
print("WROTE", OUT)
