"""Retry 20260916 fusion (was transiently empty due to WinError 10053 K-line blip).
Replicates rerun_fusion_offline.py offline patches; loops up to 3 attempts with
fetch_levels=True, then falls back to fetch_levels=False so the DAL is always
restored (selection/weights = the fix; only stop/profit levels may be omitted).
"""
import os, sys, time
from pathlib import Path

ROOT = Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
os.environ["SECTOR_MAP_ONDEMAND"] = "0"

import smcore.data.session as _session_mod
import smcore.strategy.fusion as _fusion
import smcore.strategy.fundamental as _fundamental
import smcore.strategy.regime_filter as _regime_mod
import smcore.strategy.name_lookup as _name_lookup_mod
import smcore.strategy.sectors as _sectors_mod
import smcore.strategies.boll as _boll_mod
import smcore.strategies.relativity as _rel_mod
import smcore.strategies.theme as _theme_mod
from smcore.utils.code import format_stock_code
from smcore.strategy.fusion import fuse_signals, save_action_list

for _m in (_session_mod, _fundamental, _name_lookup_mod, _sectors_mod,
          _boll_mod, _rel_mod, _theme_mod):
    try:
        _m.login = lambda: False
    except Exception:
        pass

def _cache_only_fundamentals(codes, *a, **k):
    out = {}
    for c in codes:
        out[str(c).strip()] = _fundamental._load_fund_cache(str(c).strip())
    return out

_fundamental.fetch_fundamentals_batch = _cache_only_fundamentals
_regime_mod._get_hs300_close = lambda: None
_fusion.lookup_stock_name = lambda c: _name_lookup_mod._get_stock_name_map().get(
    format_stock_code(c), "")

import pandas as pd
date = "20260916"
last = None
for attempt in range(1, 4):
    try:
        df, msg = fuse_signals(date, total_capital=100000, max_picks=15,
                               fetch_levels=True)
    except Exception as e:  # noqa: BLE001
        last = f"attempt{attempt} exc: {type(e).__name__}:{str(e)[:200]}"
        print(last, flush=True)
        time.sleep(3)
        continue
    if df is not None and not df.empty:
        save_action_list(df, date, placeholder_when_empty=True)
        print(f"OK attempt{attempt} rows={len(df)}", flush=True)
        break
    last = f"attempt{attempt} empty"
    print(last, flush=True)
    time.sleep(3)
else:
    try:
        df, msg = fuse_signals(date, total_capital=100000, max_picks=15,
                               fetch_levels=False)
        if df is not None and not df.empty:
            save_action_list(df, date, placeholder_when_empty=True)
            print(f"FALLBACK fetch_levels=False rows={len(df)}", flush=True)
        else:
            save_action_list(pd.DataFrame(), date, placeholder_when_empty=True)
            print("FALLBACK empty -> placeholder", flush=True)
    except Exception as e:  # noqa: BLE001
        print(f"FALLBACK exc: {type(e).__name__}:{str(e)[:200]}", flush=True)
