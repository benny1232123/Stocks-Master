# -*- coding: utf-8 -*-
"""持有期 / 出场 A/B（离线、隔离输出，不碰生产产物）。

对同一批 16 个信号日的 DAL，用**真实回测引擎**（含滑点/佣金/印花税/T+1/跌停顺延/
波动率仓位缩放）跑 6 个 arm：

  base12      生产现状：出场全开 + hold=12（回归校验，应与现有 Multi-Backtest 一致）
  h1/h2/h3/h5 纯固定持有：关闭全部出场（只剩 max_hold 兜底）
  h12_notrend 出场全开但关掉 MA60 破位

输出写 .workbuddy/hold_exp/<arm>/，绝不写 stock_data/。
"""
import contextlib
import glob
import io
import os
import shutil
import sys
import traceback
from datetime import date, datetime
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
os.environ["SECTOR_MAP_ONDEMAND"] = "0"          # 导入 smcore 前设：板块映射只走本地缓存
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUTROOT = ROOT / ".workbuddy" / "hold_exp"
LOG = ROOT / ".workbuddy" / "_hold_exp_out.txt"

ARMS = {
    "base12": dict(hold=12, exits=True, trend=True),
    "h1": dict(hold=1, exits=False, trend=True),
    "h2": dict(hold=2, exits=False, trend=True),
    "h3": dict(hold=3, exits=False, trend=True),
    "h5": dict(hold=5, exits=False, trend=True),
    "h12_notrend": dict(hold=12, exits=True, trend=False),
}

# ── 1) 离线化 fetch_daily_k（纯本地 k_data；引擎/boll 都按名导入，须逐模块打）──
import importlib  # noqa: E402

kl = importlib.import_module("smcore.data.kline")


def _local_fetch(code, start=None, end=None, *a, **k):
    try:
        d = kl.read_kline_cache(str(code).zfill(6), base_dir=SD / "k_data")
    except Exception:
        d = pd.DataFrame()
    if d is None or d.empty or "date" not in d.columns:
        return pd.DataFrame()
    d = d.copy()
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d.dropna(subset=["date"])
    if start is not None:
        d = d[d["date"] >= pd.Timestamp(start)]
    if end is not None:
        d = d[d["date"] <= pd.Timestamp(end)]
    return d.sort_values("date").reset_index(drop=True)


_patched = []
for mname in ("smcore.data.kline", "smcore.backtest.engine",
              "smcore.strategy.boll_levels", "smcore.strategy.factor_scoring"):
    try:
        m = importlib.import_module(mname)
        if hasattr(m, "fetch_daily_k"):
            m.fetch_daily_k = _local_fetch
            _patched.append(mname)
    except Exception:
        pass

import scripts.daily_backtest as DB  # noqa: E402

_ORIG_RUN = DB.run_forward_signal_backtest

lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


p("离线化 fetch_daily_k 的模块:", _patched)

# ── 2) 收集信号日 ──
lists = []
for f in sorted(glob.glob(str(SD / "Daily-Action-List-*.csv"))):
    name = Path(f).name
    tag = name[len("Daily-Action-List-"):-len(".csv")]
    if len(tag) != 8 or not tag.isdigit():
        continue
    lists.append((Path(f), datetime.strptime(tag, "%Y%m%d").date()))
p(f"信号日 {len(lists)} 个：{lists[0][1]} .. {lists[-1][1]}")

# ── 3) 逐 arm 跑 ──
for arm, cfg in ARMS.items():
    outdir = OUTROOT / arm
    if outdir.exists():
        shutil.rmtree(outdir, ignore_errors=True)
    outdir.mkdir(parents=True, exist_ok=True)

    orig = _ORIG_RUN

    def _wrapper(sub, _cfg=cfg, _orig=orig, **kw):
        kw = dict(kw)
        kw["hold_days"] = _cfg["hold"]
        kw["enable_exits"] = _cfg["exits"]
        if not _cfg["trend"]:
            kw["trend_exit_ma"] = 0
        return _orig(sub, **kw)

    DB.run_forward_signal_backtest = _wrapper
    ok = err = 0
    for path, sd in lists:
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):
                r = DB._backtest_one(path, sd, cfg["hold"], out_dir=outdir)
            ok += 1 if r else 0
        except Exception as exc:
            err += 1
            p(f"  !! {arm} {sd} 失败: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    DB.run_forward_signal_backtest = orig
    summ = glob.glob(str(outdir / "Multi-Backtest-*-summary.csv"))
    p(f"[{arm:<11}] 成功 {ok} 失败 {err} 产出 summary {len(summ)} 个")
    for f in glob.glob(str(outdir / "Multi-Backtest-*-trades.csv")):
        if Path(f).stat().st_size == 0:
            print("  (空 trades)", Path(f).name)

# ── 4) 汇总 ──
p("")
p("=" * 104)
p("汇总：各 arm 在同一批 16 个信号日上的表现")
p("=" * 104)
rows = []
det = {}
for arm in ARMS:
    d = OUTROOT / arm
    sfs = sorted(glob.glob(str(d / "Multi-Backtest-*-summary.csv")))
    if not sfs:
        continue
    S = pd.concat([pd.read_csv(f, dtype=str) for f in sfs], ignore_index=True)
    for c in ("total_return", "cash_pct", "max_drawdown", "sharpe", "num_trades",
              "bench_return", "excess_return", "win_rate"):
        if c in S.columns:
            S[c] = pd.to_numeric(S[c], errors="coerce")
    fs = sorted(glob.glob(str(d / "Multi-Backtest-*-trades.csv")))
    Tl = []
    for f in fs:
        try:
            t = pd.read_csv(f, dtype=str)
        except Exception:
            continue
        if t.empty or "return_pct" not in t.columns:
            continue
        Tl.append(t)
    T = pd.concat(Tl, ignore_index=True) if Tl else pd.DataFrame()
    if not T.empty:
        T["return_pct"] = pd.to_numeric(T["return_pct"], errors="coerce")
        T["buy_price"] = pd.to_numeric(T["buy_price"], errors="coerce")
        T["qty"] = pd.to_numeric(T["qty"], errors="coerce")
        T["_v"] = T["qty"] * T["buy_price"]
    det[arm] = (S, T)
    comp = S[S["num_trades"] > 0] if "num_trades" in S.columns else S
    rows.append({
        "arm": arm,
        "批次": len(comp),
        "笔数": len(T),
        "笔均%": round(T["return_pct"].mean(), 3) if len(T) else None,
        "笔中位%": round(T["return_pct"].median(), 3) if len(T) else None,
        "笔胜率%": round(100 * (T["return_pct"] > 0).mean(), 1) if len(T) else None,
        "加权笔均%": round((T["return_pct"] * T["_v"]).sum() / T["_v"].sum(), 3)
        if len(T) and T["_v"].sum() else None,
        "组合均%": round(comp["total_return"].mean(), 3) if len(comp) else None,
        "组合中位%": round(comp["total_return"].median(), 3) if len(comp) else None,
        "现金占比%": round(comp["cash_pct"].mean(), 1) if "cash_pct" in comp else None,
        "回撤均%": round(comp["max_drawdown"].mean(), 3) if "max_drawdown" in comp else None,
        "基准均%": round(comp["bench_return"].mean(), 3) if "bench_return" in comp else None,
        "超额均%": round(comp["excess_return"].mean(), 3) if "excess_return" in comp else None,
    })
A = pd.DataFrame(rows)
p(A.to_string(index=False))

p("")
p("── 出场结构（仅出场打开的 arm）──")
for arm in ("base12", "h12_notrend"):
    S, T = det.get(arm, (None, None))
    if T is None or T.empty or "exit_reason" not in T.columns:
        continue
    g = T.groupby("exit_reason")["return_pct"].agg(n="count", mean="mean", total="sum")
    g["win%"] = T.groupby("exit_reason")["return_pct"].apply(lambda s: round(100 * (s > 0).mean(), 1))
    p(f"  [{arm}]   总点数 Σ={T['return_pct'].sum():+.0f}")
    p(g.round(2).to_string())

p("")
p("── 批次级明细（组合 total_return，看单日一致性）──")
for arm in ARMS:
    S, T = det.get(arm, (None, None))
    if S is None:
        continue
    S = S.copy()
    S["_tag"] = S["date"].astype(str)
    p(f"  [{arm}] " + " ".join(
        f"{r['_tag'][-4:]}:{r['total_return']:+.2f}" for _, r in S.iterrows()))

LOG.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", LOG)
