"""探针 4：定位同花顺指数历史K端点的可用区间上限（二分）。"""
import datetime as _dt
import os
import sys

sys.path.insert(0, r"E:\Stocks-Master")
os.environ.setdefault("HITHINK_FINANCE_API_KEY", "sk-fuyao-5ZAyYPbdnL8A3rjehEj0vgM8Iz-g_-6C")

import requests

KEY = os.environ["HITHINK_FINANCE_API_KEY"]
BASE = "https://fuyao.aicubes.cn"
SH = _dt.timezone(_dt.timedelta(hours=8))
END = _dt.date(2026, 9, 12)


def ms(d):
    return int(_dt.datetime(d.year, d.month, d.day, tzinfo=SH).timestamp() * 1000)


def probe_days(days, thscode="000300.SH"):
    start = END - _dt.timedelta(days=days)
    r = requests.get(BASE + "/api/a-share-index/prices/historical",
                     params={"thscode": thscode, "interval": "1d", "start": ms(start), "end": ms(END)},
                     headers={"X-api-key": KEY}, timeout=30)
    b = r.json()
    item = (b.get("data") or {}).get("item") or []
    print(f"  {days:5d} 自然日 ({start}~{END}) -> code={b.get('code')} item_len={len(item)} "
          f"{'OK' if item else 'EMPTY'}")
    return len(item)


for d in (365, 500, 540, 550, 555, 560, 570, 600, 730, 900, 1200, 2000, 2400):
    probe_days(d)

print("\n=== 个股历史K 是否也有同样上限？(600519.SH) ===")
for d in (365, 730, 1500, 2400):
    r = requests.get(BASE + "/api/a-share/prices/historical",
                     params={"thscode": "600519.SH", "interval": "1d",
                             "start": ms(END - _dt.timedelta(days=d)), "end": ms(END), "adjust": "forward"},
                     headers={"X-api-key": KEY}, timeout=30)
    b = r.json()
    item = (b.get("data") or {}).get("item") or []
    print(f"  {d:5d} 自然日 -> code={b.get('code')} item_len={len(item)} {'OK' if item else 'EMPTY'}")
