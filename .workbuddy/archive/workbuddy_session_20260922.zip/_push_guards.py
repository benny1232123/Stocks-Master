"""推送 notify_holdings_analysis.py 的「自包含守卫」增量（token 无 workflow scope，
故守卫内建到脚本而非 workflow，见函数注释）。"""
import hashlib
import json
import pathlib
import subprocess
import sys

REPO = "benny1232123/Stocks-Master"
ROOT = pathlib.Path(__file__).resolve().parents[1]
PATH = "scripts/notify_holdings_analysis.py"

MSG = (
    "fix(holdings): K 线/基本面守卫内建到报告脚本（不依赖 workflow 接线）\n\n"
    "daily-holdings.yml 原先没有任何 K 线准备步骤，报告靠 build_stock_analysis 内部\n"
    "fetch_daily_k 现抓；海外 runner 抓到旧 bar 时 RSI/MACD/布林/现价全部失真而报告\n"
    "照常推送（静默）。本次把守卫内建到脚本自身，使修复不依赖 workflow plumbing：\n\n"
    "- _refresh_klines(codes, as_of)：定向刷新持仓 K 线（force_refresh，<20 只秒级）\n"
    "  并逐只复核信号日 bar。缺 bar 时 ① 打 ::error:: 注解 ② 在报告顶部插入\n"
    "  「数据滞后告警」横幅（用户直接可见），但**不**退出非零，保证报告仍落盘。\n"
    "- _refresh_fundamentals(codes)：HOLDINGS_FUND_REFRESH（默认 1）下只回填**缺失**的\n"
    "  基本面缓存（已缓存不重复联网），修「缺缓存 -> 综合分塌成纯技术面」。\n"
    "- ALLOW_STALE_DATA=1：跳过 K 线刷新与新鲜度复核（补跑历史日/非交易日）。\n"
    "- 两个开关在**调用时**读环境，便于单次运行覆盖与测试。\n"
)


def gh(args, payload=None):
    cmd = ["gh", "api"] + args
    inp = None
    if payload is not None:
        cmd += ["--input", "-"]
        inp = json.dumps(payload)
    return subprocess.run(cmd, input=inp, capture_output=True, text=True, cwd=str(ROOT))


def jget(args):
    r = gh(args)
    if r.returncode != 0:
        print("FAIL read:", args, r.stderr.strip()[:300])
        sys.exit(1)
    return json.loads(r.stdout)


head = jget([f"repos/{REPO}/git/ref/heads/master"])["object"]["sha"]
base = jget([f"repos/{REPO}/git/commits/{head}"])["tree"]["sha"]
print("remote head:", head)
print("base tree  :", base)

text = (ROOT / PATH).read_text(encoding="utf-8")
local_sha = hashlib.sha256(text.encode("utf-8")).hexdigest()
print("local sha256:", local_sha[:16])

blob = json.loads(gh([f"repos/{REPO}/git/blobs", "--method", "POST"],
                     {"content": text, "encoding": "utf-8"}).stdout)["sha"]
tree = json.loads(gh([f"repos/{REPO}/git/trees", "--method", "POST"],
                     {"base_tree": base, "tree": [
                         {"path": PATH, "mode": "100644", "type": "blob", "sha": blob}]}).stdout)["sha"]
commit = json.loads(gh([f"repos/{REPO}/git/commits", "--method", "POST"],
                       {"message": MSG, "tree": tree, "parents": [head]}).stdout)["sha"]
r = gh([f"repos/{REPO}/git/refs/heads/master", "--method", "PATCH"],
       {"sha": commit, "force": False})
if r.returncode != 0:
    print("FAIL ref:", r.stdout.strip()[:300])
    sys.exit(1)
print("PUSH_OK", commit)

# 复核：远程文件内容与本地一致
import base64  # noqa: E402

c = jget([f"repos/{REPO}/contents/{PATH}", "--jq", ".content"])
remote_text = base64.b64decode(c).decode("utf-8")
print("remote sha256:", hashlib.sha256(remote_text.encode("utf-8")).hexdigest()[:16])
print("MATCH", remote_text == text)
