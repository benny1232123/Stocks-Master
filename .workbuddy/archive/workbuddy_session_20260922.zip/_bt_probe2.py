# -*- coding: utf-8 -*-
"""回测体检 ②：批次级 summary + 出场原因 + 基准/成本口径（只读离线）。"""
import glob
import re
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_bt_probe2_out.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


def safe_read(f):
    try:
        return pd.read_csv(f, dtype=str)
    except Exception:
        return None


# ── A) 批次级 summary ──
p("=" * 118)
p("A) Multi-Backtest-*-summary.csv 批次级（含基准/口径列）")
p("=" * 118)
sums = []
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-summary.csv"))):
    d = safe_read(f)
    if d is None or d.empty:
        continue
    d["_batch"] = re.search(r"(\d{8})", Path(f).name).group(1)
    sums.append(d)
S = pd.concat(sums, ignore_index=True)
cols = ["_batch", "num_trades", "hold_days", "total_return", "bench_return", "excess_return",
        "win_rate", "avg_return", "avg_win", "avg_loss", "profit_factor", "max_drawdown",
        "sharpe", "cash_pct", "capital_scale", "exit_mode", "size_mode", "vol_mode"]
cols = [c for c in cols if c in S.columns]
p(S[cols].to_string(index=False))

p("")
for col in ("total_return", "bench_return", "excess_return", "cash_pct", "avg_win", "avg_loss",
            "profit_factor", "win_rate"):
    if col in S.columns:
        v = pd.to_numeric(S[col], errors="coerce").dropna()
        if len(v):
            p(f"  {col:<15} mean={v.mean():+8.3f} median={v.median():+8.3f} "
              f"min={v.min():+8.3f} max={v.max():+8.3f} n={len(v)}")

# 只取「窗口走完」的批次（hold_days 达满 12）
if "hold_days" in S.columns:
    hd = pd.to_numeric(S["hold_days"], errors="coerce")
    full = S[hd >= 12]
    p("")
    p(f"  ── 仅「窗口走完」(hold_days>=12) 的 {len(full)} 个批次 ──")
    for col in ("total_return", "bench_return", "excess_return", "win_rate", "avg_return"):
        if col in full.columns:
            v = pd.to_numeric(full[col], errors="coerce").dropna()
            if len(v):
                p(f"     {col:<15} mean={v.mean():+8.3f}%  median={v.median():+8.3f}%")

if "size_mode" in S.columns:
    p("")
    p(f"  固定口径列: exit_mode={S['exit_mode'].iloc[0]}  size_mode={S['size_mode'].iloc[0]}"
      f"  vol_mode={S['vol_mode'].iloc[0]}  signal_mode={S['signal_mode'].iloc[0]}"
      f"  strategies={S['strategies'].iloc[0]}")
if "codes_count" in S.columns:
    p(f"  codes_count: {sorted(set(S['codes_count'].dropna()))}")

# ── B) 出场原因 ──
p("")
p("=" * 118)
p("B) 出场原因（exit_reason）")
p("=" * 118)
frames = []
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv"))):
    d = safe_read(f)
    if d is None or d.empty or "return_pct" not in d.columns:
        continue
    d["_batch"] = re.search(r"(\d{8})", Path(f).name).group(1)
    frames.append(d)
T = pd.concat(frames, ignore_index=True)
T["return_pct"] = pd.to_numeric(T["return_pct"], errors="coerce")
if "exit_reason" in T.columns:
    g = T.groupby("exit_reason")["return_pct"].agg(
        count="count", mean="mean", median="median", win=lambda s: 100 * (s > 0).mean())
    p(g.sort_values("count", ascending=False).to_string())

if "buy_date" in T.columns and "sell_date" in T.columns:
    T["_hold"] = (pd.to_datetime(T["sell_date"], errors="coerce")
                  - pd.to_datetime(T["buy_date"], errors="coerce")).dt.days
    sub = T.dropna(subset=["_hold", "return_pct"])
    p("")
    p("  持有自然日 vs 收益：")
    for k, grp in sub.groupby("_hold")["return_pct"].agg(["count", "mean"]).iterrows():
        p(f"     hold={int(k):>3}  n={int(grp['count']):<5} mean={grp['mean']:+.3f}%")
    p(f"  相关(hold, return) = {sub['_hold'].corr(sub['return_pct']):.4f}")

# 头尾收益解剖
p("")
p("  收益分布解剖（全部 120 笔）：")
r = T["return_pct"].dropna()
p(f"    平均盈利 {r[r>0].mean():+.2f}% (n={int((r>0).sum())})  "
  f"平均亏损 {r[r<0].mean():+.2f}% (n={int((r<0).sum())})")
p(f"    最大 5 笔盈利: {[round(x,2) for x in sorted(r, reverse=True)[:5]]}")
p(f"    最大 5 笔亏损: {[round(x,2) for x in sorted(r)[:5]]}")

# ── C) 成本口径 ──
p("")
p("=" * 118)
p("C) 成本/滑点口径（daily_backtest.py）")
p("=" * 118)
src = (ROOT / "scripts" / "daily_backtest.py").read_text(encoding="utf-8")
for i, ln in enumerate(src.splitlines(), 1):
    low = ln.lower()
    if any(k in low for k in ("commission", "stamp", "slippage", "印花", "滑点", "费率", "手续费",
                              "buy_cost", "sell_cost")) and not ln.strip().startswith("#"):
        p(f"  L{i}: {ln.strip()[:150]}")

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
