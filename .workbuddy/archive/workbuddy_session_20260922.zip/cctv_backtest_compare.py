# -*- coding: utf-8 -*-
"""CCTV 新旧池子次日收益率回测对比（验收闭环：NLP 是否提升选股质量）。

- 新池 = stock_data/CCTV-Sector-Stock-Pool-*.csv（Tier-1 NLP 重跑）
- 旧池 = .workbuddy/cctv_rerun_backup/CCTV-Sector-Stock-Pool-*.csv（重跑前）
- 指标: 组合平均次日收益率（等权，每池取前 20 只，与 run_backtest 一致）
- K 线: fetch_daily_k 默认读本地 k_data 缓存，覆盖区间不联网
"""
import sys
import io
import csv
from datetime import datetime, timedelta
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
sys.path.insert(0, r"E:\Stocks-Master")

from smcore.data.kline import fetch_daily_k

ROOT = Path(r"E:\Stocks-Master")
NEW_DIR = ROOT / "stock_data"
OLD_DIR = ROOT / ".workbuddy" / "cctv_rerun_backup"


def next_day_return(code, signal_date):
    """信号日次一交易日的收益率（照搬 cctv._next_day_return，走本地缓存）。"""
    try:
        start = datetime.strptime(signal_date, "%Y%m%d")
        end = start + timedelta(days=20)
        df = fetch_daily_k(code, start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d"), adjust="qfq")
        if df is None or len(df) < 2:
            return None
        c0 = float(df.iloc[0]["close"])
        c1 = float(df.iloc[1]["close"])
        if c0 == 0:
            return None
        return (c1 - c0) / c0
    except Exception:
        return None


def load_pool(path):
    with open(path, encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    return [str(r["股票代码"]).zfill(6) for r in rows if r.get("股票代码")]


def eval_pool(dates):
    """返回 {date: {ret, n, pool_size, missing}}，每池取前20只。"""
    out = {}
    for d in dates:
        new_path = NEW_DIR / f"CCTV-Sector-Stock-Pool-{d}.csv"
        if not new_path.exists():
            continue
        codes = load_pool(new_path)[:20]
        rets = []
        for c in codes:
            r = next_day_return(c, d)
            if r is not None:
                rets.append(r)
        out[d] = {"ret": sum(rets) / len(rets) if rets else None, "n": len(rets), "pool_size": len(codes)}
    return out


def main():
    dates = sorted(p.name.replace("CCTV-Sector-Stock-Pool-", "").replace(".csv", "") for p in NEW_DIR.glob("CCTV-Sector-Stock-Pool-*.csv"))
    dates = [d for d in dates if (OLD_DIR / f"CCTV-Sector-Stock-Pool-{d}.csv").exists()]
    print(f"对比日期: {len(dates)} 个 ({dates[0]} ~ {dates[-1]})")

    new_map = eval_pool(dates)
    old_map = eval_pool(dates)  # 复用 eval_pool 但需指向旧目录
    # 旧目录单独评估
    old_map = {}
    for d in dates:
        old_path = OLD_DIR / f"CCTV-Sector-Stock-Pool-{d}.csv"
        if not old_path.exists():
            continue
        codes = load_pool(old_path)[:20]
        rets = []
        for c in codes:
            r = next_day_return(c, d)
            if r is not None:
                rets.append(r)
        old_map[d] = {"ret": sum(rets) / len(rets) if rets else None, "n": len(rets), "pool_size": len(codes)}

    # 汇总
    rows = []
    for d in dates:
        nm, om = new_map.get(d), old_map.get(d)
        if not nm or not om or nm["ret"] is None or om["ret"] is None:
            continue
        rows.append((d, om["ret"], nm["ret"], nm["ret"] - om["ret"], om["n"], nm["n"], om["pool_size"], nm["pool_size"]))

    n_win = sum(1 for r in rows if r[3] > 0)
    avg_new = sum(r[2] for r in rows) / len(rows)
    avg_old = sum(r[1] for r in rows) / len(rows)
    print(f"\n有效日期(新旧均有收益): {len(rows)}")
    print(f"组合平均次日收益: 旧={avg_old:+.4f} ({avg_old*100:+.2f}%)  新={avg_new:+.4f} ({avg_new*100:+.2f}%)")
    print(f"提升: {avg_new-avg_old:+.4f} ({avg_new*100-avg_old*100:+.2f}pp)")
    print(f"新跑赢旧: {n_win}/{len(rows)} ({n_win/len(rows)*100:.0f}%)")

    # 打印前10行明细
    print("\n日期       旧收益    新收益    差值      旧n 新n 旧池 新池")
    for r in sorted(rows)[:10]:
        print(f"{r[0]}  {r[1]*100:+6.2f}%  {r[2]*100:+6.2f}%  {(r[3])*100:+6.2f}%  {r[4]:3d} {r[5]:3d} {r[6]:3d} {r[7]:3d}")


if __name__ == "__main__":
    main()
