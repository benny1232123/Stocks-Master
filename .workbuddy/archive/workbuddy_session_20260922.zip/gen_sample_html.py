"""Generate a sample holdings-analysis HTML using the REAL render functions
from scripts/notify_holdings_analysis.py (smcore imports stubbed, since we
only need the pure HTML rendering)."""
import os

SRC = r"E:\Stocks-Master\scripts\notify_holdings_analysis.py"
OUT = r"E:\Stocks-Master\.workbuddy\holdings_analysis_sample.html"

# Load module source, drop the heavy smcore imports so we can exec standalone.
with open(SRC, encoding="utf-8") as f:
    lines = f.readlines()
clean = [ln for ln in lines if not ln.strip().startswith("from smcore")]
ns: dict = {"__name__": "sample", "__file__": SRC}
exec("".join(clean), ns)
render_stock_html = ns["render_stock_html"]
build_html_report = ns["build_html_report"]


def mk(code, close, prev, ma5, ma10, ma20, ma60, up, lo, rsi, dif, dea, hist,
       k, d, j, sig, fund=None):
    return {
        "code": code,
        "latest": {
            "close": close, "upper": up, "lower": lo,
            "ma5": ma5, "ma10": ma10, "ma20": ma20, "ma60": ma60,
            "rsi": rsi, "dif": dif, "dea": dea, "macd_hist": hist,
            "k_val": k, "d_val": d, "j_val": j, "signal_text": sig,
        },
        "metrics": {"signal_text": sig},
        "series": {"rows": [{"close": prev}, {"close": close}]},
        "fundamentals": fund,
    }


stocks = [
    mk("600519", 1708.0, 1666.0, 1680, 1650, 1600, 1500, 1760, 1500,
       65, 12, 8, 8, 72, 60, 88, "突破上轨·强势",
       {"pe": 32.5, "pb": 9.8, "mkt_cap": 21450, "roe": 31.2,
        "gross_margin": 91.5, "revenue_growth": 17.3, "turnover": 0.32}),
    mk("000001", 10.85, 11.21, 11.0, 11.3, 11.5, 12.0, 11.9, 10.4,
       28, -0.3, -0.1, -0.4, 18, 25, -5, "跌破下轨·弱势",
       {"pe": 4.6, "pb": 0.52, "mkt_cap": 2108, "roe": 11.0,
        "gross_margin": 28.0, "revenue_growth": 2.1, "turnover": 0.55}),
    mk("300750", 185.3, 184.0, 183, 180, 178, 175, 192, 168,
       55, 3, 2, 2, 60, 55, 70, "布林中轨上方·震荡偏多",
       None),  # no fundamentals -> "暂无基本面数据"
]

sections = "\n".join(render_stock_html(s) for s in stocks)
html = build_html_report(
    "20260825", "akshare", f"持仓 {len(stocks)} 只 ｜ 多头 1 / 空头 1 / 震荡 1",
    sections,
)
with open(OUT, "w", encoding="utf-8") as f:
    f.write(html)
print("wrote", OUT, os.path.getsize(OUT), "bytes")
