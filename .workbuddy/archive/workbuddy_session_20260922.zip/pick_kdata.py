# 筛选真正该入库的 k_data：本地末日期 >= 远端基准(193c543)末日期，或本地新增文件。
# 目的：绝不用本地旧数据覆盖远端 CI 已更新的新数据。
import subprocess, sys, os

BASE = sys.argv[1] if len(sys.argv) > 1 else "193c543"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

status = subprocess.run(
    ["git", "status", "--porcelain", "stock_data/k_data"],
    capture_output=True, text=True, cwd=ROOT,
).stdout.splitlines()
paths = [l[3:].strip() for l in status if l[:2].strip() in ("M", "??", "A")]


def last_date_from_blob(sha):
    out = subprocess.run(["git", "cat-file", "blob", sha], capture_output=True, cwd=ROOT).stdout
    txt = out.decode("utf-8-sig", errors="ignore").strip().splitlines()
    return txt[-1].split(",")[0].strip() if txt else ""


def last_date_local(p):
    try:
        with open(os.path.join(ROOT, p), encoding="utf-8-sig", errors="ignore") as f:
            lines = [x for x in f.read().splitlines() if x.strip()]
        return lines[-1].split(",")[0].strip() if lines else ""
    except OSError:
        return ""


include, skip = [], []
for p in paths:
    ls = subprocess.run(["git", "ls-tree", BASE, p], capture_output=True, text=True, cwd=ROOT).stdout.strip()
    if not ls:
        include.append(p)  # 新增文件
        continue
    base_sha = ls.split()[2]
    b, l = last_date_from_blob(base_sha), last_date_local(p)
    if l and b and l >= b:
        include.append(p)
    else:
        skip.append((p, b, l))

with open(os.path.join(ROOT, ".workbuddy", "_kdata_include.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(include) + "\n")
with open(os.path.join(ROOT, ".workbuddy", "_kdata_skip.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(f"{p}\t远端{b}\t本地{l}" for p, b, l in skip) + "\n")

print(f"总计 {len(paths)} | 入库 {len(include)} | 跳过(本地更旧) {len(skip)}")
for p, b, l in skip[:5]:
    print(f"  跳过 {p}: 远端 {b} > 本地 {l}")
