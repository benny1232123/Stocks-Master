"""position_sizing_recommendation 单测：目标权重三口径 + 硬上限语义（纯内存、无网络）。

覆盖：
① 目标口径优先级：per_code_targets > target_equity_ratio/N > target_weight_pct
② target_equity_ratio 缺 n_holdings 时退化为固定口径（向后兼容）
③ 硬上限：显式 hard_cap_pct 优先；否则 = 目标 × hard_cap_multiple（ceiling 封顶）
④ ★ 超硬上限 → capped_trim=True 且 aim_weight == 硬上限（只削超限部分，不一步砍到目标）
⑤ 正常超配（未超上限）→ aim_weight == 政策目标、capped_trim=False
⑥ 加仓 / 无价 分支；默认配置在「4 只」下的实际取值
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from smcore.analysis import position_sizing_recommendation  # noqa: E402
from smcore.config.defaults import POSITION_SIZING_CONFIG  # noqa: E402

PORT = 100000.0
fails = []


def mk(close, sgn="neutral"):
    latest = {"close": close}
    if sgn == "strong":
        latest.update(rsi=25, ma5=11, ma10=10, ma20=9, lower=close * 0.98)
        latest.update(dif=0.5, dea=0.3, macd_hist=0.2, k_val=60, d_val=55, j_val=70)
        latest.update(dist_to_lower_pct=1.0)
    elif sgn == "weak":
        latest.update(rsi=75, ma5=9, ma10=10, ma20=11, upper=close * 1.02)
        latest.update(dif=-0.5, dea=-0.3, macd_hist=-0.2, k_val=40, d_val=45, j_val=30)
        latest.update(dist_to_upper_pct=-3.0)
    else:
        latest.update(rsi=50, ma5=10, ma10=10, ma20=10)
        latest.update(dif=0.0, dea=0.0, macd_hist=0.0, k_val=50, d_val=50, j_val=50)
    return {"code": "600000", "latest": latest, "metrics": {}, "fundamentals": None}


def sizing(cfg, qty, close=10.0, sgn="neutral", n=None, adaptive=None):
    return position_sizing_recommendation(
        mk(close, sgn), {"qty": qty, "cost": 9.0}, PORT, cfg=cfg, n_holdings=n,
        adaptive=adaptive,
    )


def chk(tag, got, want):
    if got != want:
        fails.append(f"{tag}: 期望 {want!r}，实际 {got!r}")


def cfg_of(**kw):
    """从真实默认配置派生一份，避免测试与生产配置脱节。"""
    c = dict(POSITION_SIZING_CONFIG)
    c.update(kw)
    return c


# ① equity_ratio：总仓位 80% ÷ 4 只 = 20%/只；上限 = 20 × 1.5 = 30
c = cfg_of(target_equity_ratio=0.80, hard_cap_pct=None)
r = sizing(c, 100, n=4)
chk("① target_weight", r["target_weight"], 20.0)
chk("① target_source", r["target_source"], "equity_ratio")
chk("① hard_cap_weight", r["hard_cap_weight"], 30.0)
chk("① capped_trim", r["capped_trim"], False)

# ② per_code_targets 压过比例口径
c = cfg_of(target_equity_ratio=0.80, hard_cap_pct=None, per_code_targets={"600000": 12.0})
r = sizing(c, 100, n=4)
chk("② target_weight", r["target_weight"], 12.0)
chk("② target_source", r["target_source"], "per_code")

# ③ target_equity_ratio=None → 固定口径 target_weight_pct
c = cfg_of(target_equity_ratio=None, target_weight_pct=9.0, hard_cap_pct=None)
r = sizing(c, 100, n=4)
chk("③ target_weight", r["target_weight"], 9.0)
chk("③ target_source", r["target_source"], "fixed_pct")

# ④ 比例口径但未传 n_holdings → 退化为固定口径（向后兼容：老调用点不传 N 不会静默变目标）
c = cfg_of(target_equity_ratio=0.80, target_weight_pct=8.0, hard_cap_pct=None)
r = sizing(c, 100, n=None)
chk("④ target_weight", r["target_weight"], 8.0)
chk("④ target_source", r["target_source"], "fixed_pct")

# ⑤ 显式 hard_cap_pct 优先于「目标 × 倍数」
c = cfg_of(target_equity_ratio=0.80, hard_cap_pct=22.0)
r = sizing(c, 100, n=4)
chk("⑤ hard_cap_weight", r["hard_cap_weight"], 22.0)
chk("⑤ cap_below_target", r["cap_below_target"], False)

# ⑥ 显式上限 < 目标 → cap_below_target=True（配置自相矛盾的可见化告警）
c = cfg_of(target_equity_ratio=0.80, hard_cap_pct=15.0)
r = sizing(c, 100, n=4)
chk("⑥ cap_below_target", r["cap_below_target"], True)

# ⑦ ★ 超硬上限：当前 32% > 上限 30% → 只减到上限（aim=30），不是一步砍到目标 20%
c = cfg_of(target_equity_ratio=0.80, hard_cap_pct=None)
r = sizing(c, 3200, n=4)
chk("⑦ current_weight", r["current_weight"], 32.0)
chk("⑦ capped_trim", r["capped_trim"], True)
chk("⑦ action", r["action"], "减仓")
chk("⑦ aim_weight", r["aim_weight"], 30.0)
chk("⑦ delta_weight", r["delta_weight"], -2.0)
chk("⑦ delta_qty", r["delta_qty"], -200)          # 2,000 元 / 10 元 = 200 股
chk("⑦ target_weight", r["target_weight"], 20.0)   # 政策目标仍如实回报

# ⑧ 超配但未超上限：当前 24% < 上限 30%，目标 20% → aim=目标、capped_trim=False
r = sizing(c, 2400, n=4)
chk("⑧ capped_trim", r["capped_trim"], False)
chk("⑧ aim_weight", r["aim_weight"], 20.0)
chk("⑧ delta_weight", r["delta_weight"], -4.0)

# ⑨ 欠配 + 强票 → 加仓
r = sizing(c, 100, sgn="strong", n=4)
chk("⑨ action", r["action"], "加仓")
chk("⑨ aim_weight", r["aim_weight"], 20.0)

# ⑩ 无价 → 未知，且新增字段齐备（前端取值不会 KeyError）
r = position_sizing_recommendation(
    {"code": "600000", "latest": {}}, {"qty": 100}, PORT, cfg=c, n_holdings=4
)
chk("⑩ action", r["action"], "未知")
chk("⑩ aim_weight", r["aim_weight"], None)
chk("⑩ capped_trim", r["capped_trim"], False)
chk("⑩ target_source", r["target_source"], None)

# ⑪ ceiling 兜底：总仓位 100% ÷ 1 只 → 目标 100% > ceiling 35 → 上限取 max(35, 100) = 100
c = cfg_of(target_equity_ratio=1.0, hard_cap_pct=None, hard_cap_ceiling_pct=35.0)
r = sizing(c, 100, n=1)
chk("⑪ target_weight", r["target_weight"], 100.0)
chk("⑪ hard_cap_weight", r["hard_cap_weight"], 100.0)
chk("⑪ cap_below_target", r["cap_below_target"], False)

# ⑫ 生产默认配置在「本账户 4 只」下的真实取值：70% ÷ 4 = 17.5%/只，上限 26.25%
c = cfg_of()
r = sizing(c, 100, n=4)
chk("⑫ target_weight", r["target_weight"], 17.5)
chk("⑫ hard_cap_weight", r["hard_cap_weight"], 26.25)
chk("⑫ target_source", r["target_source"], "equity_ratio")

# ⑬ 同一账户加到 6 只：目标自动降到 11.67%（与只数解耦，无需改配置）
r = sizing(c, 100, n=6)
chk("⑬ target_weight", r["target_weight"], round(70.0 / 6, 2))

# ⑭ ★ 自适应（风险平价倾斜）：低波票的倾斜目标可超「政策目标 × 倍数」——
#    硬上限须以 max(政策目标, 倾斜后目标) 为基准，否则目标自身越线、报告恒要求减仓。
#    回归场景：600269 政策 13.53%、风险平价倾斜后 21.40% > 13.53×1.5=20.29（旧实现恒减仓）。
c = cfg_of()
_ctx = {"enabled": True, "source": "adaptive_regime", "equity_ratio": 0.541,
        "weight_frac": {"600000": 0.3956}, "weight_method": "risk_parity_erc"}
_tilt = 0.541 * 100 * 0.3956                    # 21.40%
r = sizing(c, 100, n=4, adaptive=_ctx)
chk("⑭ target_weight", r["target_weight"], round(_tilt, 2))
chk("⑭ target_source", r["target_source"], "adaptive")
chk("⑭ hard_cap_weight", r["hard_cap_weight"], round(min(_tilt * 1.5, 35.0), 2))
chk("⑭ cap_below_target", r["cap_below_target"], False)   # 回归：修好后必须为 False

print("=" * 62)
if fails:
    for f in fails:
        print("  [FAIL]", f)
    raise SystemExit(1)
print("  全部断言通过（14 组）：目标三口径 / 上限推导 / 超限只减到上限 / 兼容退化 / 自适应倾斜")
print("=" * 62)
