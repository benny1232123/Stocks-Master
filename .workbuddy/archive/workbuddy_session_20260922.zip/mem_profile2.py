"""干净进程只跑 backend.main，测真实启动基线 + 列出实际加载的第三方包。"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, r"E:\Stocks-Master")
os.environ.setdefault("KLINE_BACKEND", "akshare")
os.environ.setdefault("RENDER_LITE", "1")
os.environ.setdefault("TDX_ENABLED", "0")


def rss_mb() -> float:
    import ctypes
    from ctypes import wintypes

    class PMC(ctypes.Structure):
        _fields_ = [
            ("cb", wintypes.DWORD),
            ("PageFaultCount", wintypes.DWORD),
            ("PeakWorkingSetSize", ctypes.c_size_t),
            ("WorkingSetSize", ctypes.c_size_t),
            ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
            ("QuotaPagedPoolUsage", ctypes.c_size_t),
            ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
            ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
            ("PagefileUsage", ctypes.c_size_t),
            ("PeakPagefileUsage", ctypes.c_size_t),
        ]

    c = PMC()
    c.cb = ctypes.sizeof(PMC)
    ctypes.windll.psapi.GetProcessMemoryInfo(
        ctypes.windll.kernel32.GetCurrentProcess(), ctypes.byref(c), c.cb
    )
    return c.WorkingSetSize / 1024 / 1024


before = rss_mb()
from backend.main import app  # noqa: E402,F401

after = rss_mb()
print(f"真实启动基线 RSS = {after:.1f} MB  (导入增量 {after - before:.1f} MB)")

# 统计已加载的第三方顶层包
STDLIB_HINT = {
    "os", "sys", "re", "json", "time", "types", "typing", "abc", "enum", "io",
    "collections", "functools", "itertools", "datetime", "pathlib", "warnings",
    "threading", "uuid", "glob", "contextlib", "inspect", "importlib", "logging",
    "traceback", "copy", "math", "random", "string", "textwrap", "unicodedata",
    "hashlib", "hmac", "base64", "urllib", "http", "socket", "ssl", "email",
    "csv", "sqlite3", "struct", "codecs", "encodings", "weakref", "operator",
    "pickle", "shutil", "tempfile", "subprocess", "signal", "platform", "stat",
    "errno", "getpass", "gettext", "locale", "calendar", "zoneinfo", "zipfile",
    "tarfile", "gzip", "bz2", "lzma", "argparse", "asyncio", "concurrent",
    "multiprocessing", "queue", "heapq", "bisect", "array", "ctypes", "decimal",
    "fractions", "numbers", "statistics", "secrets", "pprint", "difflib",
    "dis", "ast", "token", "tokenize", "linecache", "gc", "atexit", "site",
    "builtins", "__future__", "dataclasses", "asyncio", "selectors", "traceback",
    "_thread", "_socket", "_ssl", "binascii", "zlib", "xml", "html", "wsgiref",
    "mimetypes", "uuid", "base64", "cProfile", "pstats", "unittest", "doctest",
}

tops: dict[str, int] = {}
for name, mod in list(sys.modules.items()):
    if not mod:
        continue
    top = name.split(".")[0]
    if top in STDLIB_HINT or top.startswith("_"):
        continue
    tops[top] = tops.get(top, 0) + 1

# 排除项目自身
for own in ("smcore", "backend", "scripts", "tests"):
    tops.pop(own, None)

print("\n实际加载的第三方顶层包（模块数）:")
for k, v in sorted(tops.items(), key=lambda x: -x[1]):
    print(f"  {k:22} {v}")
