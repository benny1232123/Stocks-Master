"""探针：拉取同花顺快照/指数/估值原始 JSON，确认字段名（用于 quote.py 字段映射）。"""
import json
import os
import sys

sys.path.insert(0, r"E:\Stocks-Master")

KEY = os.getenv("HITHINK_FINANCE_API_KEY") or "sk-fuyao-5ZAyYPbdnL8A3rjehEj0vgM8Iz-g_-6C"
os.environ["HITHINK_FINANCE_API_KEY"] = KEY

import requests

BASE = "https://fuyao.aicubes.cn"
H = {"X-api-key": KEY}


def probe(path, params, label):
    print("=" * 70)
    print(f"[{label}] GET {path} params={params}")
    try:
        r = requests.get(BASE + path, params=params, headers=H, timeout=20)
        body = r.json()
        print("code =", body.get("code"), "| message =", body.get("message"))
        data = body.get("data")
        if isinstance(data, dict):
            print("data keys:", list(data.keys()))
            item = data.get("item")
            if isinstance(item, list):
                print("item len =", len(item))
                if item:
                    print("item[0] =", json.dumps(item[0], ensure_ascii=False, indent=2)[:1200])
            else:
                print("data sample:", json.dumps(data, ensure_ascii=False)[:900])
        else:
            print("data:", str(data)[:600])
    except Exception as e:
        print("ERROR:", repr(e))


probe("/api/a-share/prices/snapshot", {"thscodes": "600519.SH,000001.SZ"}, "个股快照")
probe("/api/a-share-index/prices/snapshot", {"thscodes": "000300.SH,000001.SH"}, "指数快照")
probe("/api/a-share/valuations/snapshot", {"thscodes": "600519.SH"}, "估值快照")
