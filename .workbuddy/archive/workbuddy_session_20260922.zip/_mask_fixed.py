# -*- coding: utf-8 -*-
"""mask_fixed arm：用**修复后的** factor_timing 逻辑在 60 天样本重跑融合。
复用 .workbuddy/hist_pools/ 因子池（已生成）。离线化同 _hist_ab.py。
输出：.workbuddy/hist_ab/mask_fixed/Daily-Action-List-<date>.csv
唯一变量 = 修复后的 factor_timing_mask_from_points（enabled=True，代码已改）。
"""
import argparse
import contextlib
import dataclasses
import glob
import importlib
import io
import os
import sys
import time
import traceback
from collections import Counter
from pathlib import Path

# 全局兜底：任何未捕获异常都写进日志（带 traceback），避免静默挂掉丢失已落盘 DAL。
def _exchook(et, ev, tb):
    try:
        with open(str(ROOT / ".workbuddy" / "_mask_fixed_err.txt"), "a", encoding="utf-8") as fh:
            fh.write("UNCAUGHT: " + "".join(traceback.format_exception(et, ev, tb)))
    except Exception:
        pass
sys.excepthook = _exchook

import numpy as np
import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
os.environ["SECTOR_MAP_ONDEMAND"] = "0"
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
HIST_POOLS = ROOT / ".workbuddy" / "hist_pools"
AB = ROOT / ".workbuddy" / "hist_ab"
OUTDIR = AB / "mask_fixed"
OUTDIR.mkdir(parents=True, exist_ok=True)
LOG = ROOT / ".workbuddy" / "_mask_fixed_log.txt"
lines = []
def p(*a):
    s = " ".join(str(x) for x in a); lines.append(s); print(s, flush=True)

ap = argparse.ArgumentParser(); ap.add_argument("--days", type=int, default=60)
args = ap.parse_args()

# ── 离线化 ──
kl = importlib.import_module("smcore.data.kline")
_T0 = time.time()
_BIG = pd.concat([pd.read_parquet(f) for f in sorted((SD / "k_data").glob("*.parquet"))], ignore_index=True)
_BIG["code"] = _BIG["code"].astype(str).str.zfill(6)
_BIG["date"] = pd.to_datetime(_BIG["date"], errors="coerce")
_BIG = _BIG.dropna(subset=["date"])
_BY_CODE = {c: g.sort_values("date").reset_index(drop=True) for c, g in _BIG.groupby("code", sort=False)}
print(f"[预载] {len(_BIG)} 行 / {len(_BY_CODE)} 只  用时 {time.time()-_T0:.0f}s", flush=True)
def _lf(code, start=None, end=None, *a, **k):
    d = _BY_CODE.get(str(code).zfill(6))
    if d is None or d.empty: return pd.DataFrame()
    if start is not None: d = d[d["date"] >= pd.Timestamp(start)]
    if end is not None: d = d[d["date"] <= pd.Timestamp(end)]
    return d.reset_index(drop=True)
for mn in ("smcore.data.kline","smcore.backtest.engine","smcore.strategy.boll_levels","smcore.strategy.factor_scoring"):
    try:
        m = importlib.import_module(mn)
        if hasattr(m,"fetch_daily_k"): m.fetch_daily_k = _lf
    except Exception: pass

import smcore.strategy.fusion as FU
try:
    from smcore.strategy.market import MarketProfile
    _MF = {f.name for f in dataclasses.fields(MarketProfile)}
except Exception:
    MarketProfile,_MF = None,set()
_DEF = {"regime":"震荡轮动","regime_strength":0.5,"trend":"side","volatility_level":"mid",
        "volatility_pct":0.0,"volatility_pctile":0.5,"breadth_score":0.5,"activity_ratio":1.0,"hs300_ret20":0.0}
def _fixed_profile(*a,**k):
    return MarketProfile(**{kk:vv for kk,vv in _DEF.items() if kk in _MF}) if MarketProfile else None
FU.compute_market_profile = _fixed_profile
try:
    import smcore.strategy.market as MK; MK.compute_market_profile = _fixed_profile
except Exception: pass
try:
    fm = importlib.import_module("smcore.strategy.fundamental")
    fm.fetch_fundamentals_batch = lambda codes,*a,**k: {c:(fm._load_fund_cache(c) if hasattr(fm,"_load_fund_cache") else None) for c in codes}
except Exception: pass
try:
    nlm = importlib.import_module("smcore.strategy.name_lookup")
    nlm.lookup_stock_name = lambda c,*a,**k: (nlm._get_stock_name_map() or {}).get(str(c).zfill(6),"")
except Exception: pass
try:
    importlib.import_module("smcore.strategy.regime_filter")._get_hs300_close = lambda *a,**k: None
except Exception: pass
for mn in ("smcore.data.session","smcore.strategy.sectors","smcore.strategy.name_lookup","smcore.strategy.fundamental"):
    try:
        m = importlib.import_module(mn)
        if hasattr(m,"login"): m.login = lambda *a,**k: False
    except Exception: pass

import smcore.strategy.adaptive_weights as AW
import smcore.strategy.factor_timing as FT

# ★ 性能：记忆化 conviction_points（与生产同口径，只读 stock_data；与 arm 无关）
_pts_cache = {}
def _cached_aft(weights, signal_date=None):
    try:
        if "pts" not in _pts_cache:
            _pts_cache["pts"] = FT.conviction_points()
        masked = FT.apply_mask(weights, signal_date=signal_date, points=_pts_cache["pts"])
        pct = {s: round(float(masked.get(s,0.0))) for s in AW.ALL_STRATEGIES}
        d = 100 - sum(pct.values())
        if d != 0:
            anchor = max(pct, key=pct.get); pct[anchor] = max(0, pct[anchor]+d)
        return pct
    except Exception:
        return weights
AW._apply_factor_timing = _cached_aft

import csv
from smcore.strategy.picks_loader import _load_scored_picks as _PROD_LOAD
from smcore.utils.code import format_stock_code
def _hist_load(factor, date_yyyymmdd, *, max_stale_days=3):
    pth = HIST_POOLS / f"Stock-Selection-{factor}-{date_yyyymmdd}.csv"
    if not pth.exists(): return _PROD_LOAD(factor, date_yyyymmdd, max_stale_days=max_stale_days)
    picks = {}
    with pth.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            c = format_stock_code(row.get("股票代码",""))
            if not c: continue
            try: sc = float(row.get("综合分") or 0)
            except (TypeError,ValueError): sc = 0.0
            picks[c] = {"name": str(row.get("股票名称") or ""), "score": sc}
    return picks, date_yyyymmdd
FU._load_scored_picks = _hist_load
p("[离线] 补丁就绪；factor_timing 已为**修复后**版本（enabled=True 即用修复逻辑）")

# ── 信号日 ──
parts=[]
for f in sorted((SD/"k_data").glob("*.parquet")):
    d=pd.read_parquet(f, columns=["code","date","open","close"])
    d["date"]=pd.to_datetime(d["date"],errors="coerce")
    d=d[(d["date"]>=pd.Timestamp("2026-01-01"))&(d["date"]<=pd.Timestamp("2026-10-10"))]
    if not d.empty: parts.append(d)
K=pd.concat(parts,ignore_index=True); K["code"]=K["code"].astype(str).str.zfill(6)
CAL=sorted(K["date"].dropna().unique()); IDX={pd.Timestamp(d).strftime("%Y%m%d"):i for i,d in enumerate(CAL)}
OPENF=K.pivot_table(index="date",columns="code",values="open",aggfunc="last")
CLOSEF=K.pivot_table(index="date",columns="code",values="close",aggfunc="last")
all_days=[pd.Timestamp(d).strftime("%Y%m%d") for d in CAL]; end="20260917"
sig=[d for d in all_days if d<=end][-args.days:]
p(f"[信号日] {len(sig)} 个：{sig[0]} .. {sig[-1]}")

AW.CONFIG.setdefault("factor_timing",{})["enabled"]=True
dfs={}; t0=time.time()
for i,day in enumerate(sig,1):
    f=OUTDIR/f"Daily-Action-List-{day}.csv"
    if f.exists():
        d=pd.read_csv(f,dtype=str)
        if not d.empty:
            d["code"]=d["股票代码"].astype(str).str.zfill(6); dfs[day]=d
        continue
    buf=io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            df,rep=FU.fuse_signals(day)
        if df is None or df.empty: continue
        df=df.copy(); df["code"]=df["股票代码"].astype(str).str.zfill(6)
        df.to_csv(f,index=False,encoding="utf-8-sig"); dfs[day]=df
    except Exception as exc:
        p(f"  !! {day}: {type(exc).__name__}: {exc}")
    if i % 10 == 0: p(f"  [mask_fixed] {i}/{len(sig)}  {time.time()-t0:.0f}s")
p(f"  [mask_fixed] 完成 {len(dfs)} 天  用时 {time.time()-t0:.0f}s")

# ── 汇总 ──
def fwd(day,h,codes):
    ei=IDX.get(day)
    if ei is None or ei+1+h>=len(CAL): return pd.Series(dtype=float)
    o,c=OPENF.iloc[ei+1],CLOSEF.iloc[ei+1+h]
    cc=[str(x).zfill(6) for x in codes]; o,c=o.reindex(cc),c.reindex(cc)
    m=o.notna()&c.notna()&(o>0); return ((c[m]/o[m]-1)*100).astype(float)
def mkt(day,h):
    ei=IDX.get(day)
    if ei is None or ei+1+h>=len(CAL): return None
    o,c=OPENF.iloc[ei+1],CLOSEF.iloc[ei+1+h]
    m=o.notna()&c.notna()&(o>0); return float(((c[m]/o[m]-1)*100).mean()) if m.any() else None

p(""); p("="*90); p("mask_fixed 前向收益（DAL 等权，次日开盘买→持有 H 日收盘卖）")
p("="*90); p(f"  {'H':>3}{'天数':>6}{'绝对均%':>10}{'超额均%':>11}{'胜率%':>8}")
res={}
for h in (1,2,3,5):
    a_,e_=[],[]
    for day,df in dfs.items():
        r=fwd(day,h,list(df["code"])); mk=mkt(day,h)
        if r.empty or mk is None: continue
        a_.append(r.mean()); e_.append(r.mean()-mk)
    if a_:
        res[h]=(a_,e_); p(f"  {h:>3}{len(a_):>6}{np.mean(a_):>10.2f}{np.mean(e_):>11.2f}{100*np.mean([x>0 for x in a_]):>8.1f}")

# 构成
p(""); p("="*90); p("mask_fixed 构成（每日单策略命中数 / 天）+ 实测 edge")
p("="*90)
EDGE={"Skew60":6.70,"VRatio10_60":4.76,"CVAmt60":2.54,"VRatio20_120":1.65,"Vol20":0.82,
      "PVCorr20":0.18,"DistLo10":-1.31,"Skew20":-1.72,"CVAmt20":-3.76,"PVCorr60":-10.72,"Illiq20":-9.90,"DistLo60":0.0}
c=Counter(); nd=max(len(dfs),1)
for day,df in dfs.items():
    if "来源策略" in df.columns:
        for v in df["来源策略"].astype(str):
            if "/" not in v: c[v]+=1
p(f"  {'因子':<15}{'实测edge':>9}{'mask_fixed/天':>14}")
for k in sorted(c, key=lambda x:-EDGE.get(x,0)):
    p(f"  {k:<15}{EDGE.get(k,float('nan')):>9.2f}{c.get(k,0)/nd:>14.2f}")

LOG.write_text("\n".join(lines),encoding="utf-8"); print("WROTE",LOG)
