# -*- coding: utf-8 -*-
"""出场审计报告生成（自包含 HTML，数据现场计算）。"""
import glob
import math
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "exit_audit_20260921.html"

try:
    from smcore.backtest.engine import _COMM_MIN, _COMM_RATE, _STAMP_RATE  # noqa: E402
except Exception:
    _COMM_RATE, _COMM_MIN, _STAMP_RATE = 0.00025, 5.0, 0.0005

from smcore.data.kline import read_kline_cache  # noqa: E402

SLIP = 0.001
_kc: dict[str, pd.DataFrame] = {}


def kof(code):
    code = str(code).zfill(6)
    if code not in _kc:
        try:
            k = read_kline_cache(code, base_dir=SD / "k_data")
        except Exception:
            k = pd.DataFrame()
        if not k.empty and "date" in k.columns:
            k = k.copy()
            k["date"] = pd.to_datetime(k["date"], errors="coerce")
            for c in ("open", "low", "close"):
                if c in k.columns:
                    k[c] = pd.to_numeric(k[c], errors="coerce")
            k = k.dropna(subset=["date"]).sort_values("date").reset_index(drop=True)
        _kc[code] = k
    return _kc[code]


frames = []
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv"))):
    try:
        d = pd.read_csv(f, dtype=str)
    except Exception:
        continue
    if d.empty or "return_pct" not in d.columns:
        continue
    d["_batch"] = re.search(r"(\d{8})", Path(f).name).group(1)
    frames.append(d)
T = pd.concat(frames, ignore_index=True)
for c in ("return_pct", "buy_price", "sell_price", "qty"):
    T[c] = pd.to_numeric(T[c], errors="coerce")
T["_val"] = T["qty"] * T["buy_price"]


def friction_pct(amount):
    return (2 * SLIP * amount + max(amount * _COMM_RATE, _COMM_MIN)
            + max(amount * _COMM_RATE, _COMM_MIN) + amount * _STAMP_RATE) / amount * 100


T["_fric"] = T["_val"].apply(friction_pct)
fric_med = T["_fric"].median()

# 恒定子样本反事实
HZ = [1, 2, 3, 5, 8, 12]


def fwd(r, H):
    k = kof(r["code"])
    if k.empty:
        return None
    idx = k.index[k["date"] <= pd.Timestamp(r["buy_date"])]
    if len(idx) == 0:
        return None
    i = idx[-1]
    j = i + H
    if j >= len(k) or pd.isna(k.loc[j, "close"]):
        return None
    return (k.loc[j, "close"] / r["buy_price"] - 1) * 100


rows = []
for _, r in T.iterrows():
    vs = [fwd(r, h) for h in HZ]
    if all(v is not None for v in vs):
        rows.append({"actual": r["return_pct"], **{f"r{h}": vs[n] for n, h in enumerate(HZ)}})
C = pd.DataFrame(rows)

# 两套止损
srows = []
for _, r in T.iterrows():
    k = kof(r["code"])
    idx = k.index[k["date"] <= pd.Timestamp(r["buy_date"])]
    if k.empty or len(idx) == 0:
        continue
    i = idx[-1]
    if i < 21:
        continue
    dret = k.loc[i - 19:i, "close"].pct_change().dropna()
    if len(dret) < 5:
        continue
    s = float(dret.std())
    srows.append({"sigma": s, "bt": max(0.06, min(8.0 * s, 0.15)),
                  "bl": max(0.04, min(2.5 * s, 0.12))})
S = pd.DataFrame(srows)

# trend_break 入场距 MA60
tb_rows = []
for _, r in T.iterrows():
    k = kof(r["code"])
    if k.empty:
        continue
    idx = k.index[k["date"] <= pd.Timestamp(r["buy_date"])]
    if len(idx) == 0:
        continue
    i = idx[-1]
    if i < 60:
        continue
    ma = k.loc[i - 59:i, "close"].mean()
    tb_rows.append({"exit": r["exit_reason"], "ret": r["return_pct"],
                    "dist": (r["buy_price"] / ma - 1) * 100})
B = pd.DataFrame(tb_rows)
tb = B[B["exit"] == "trend_break"]


def tbl(head, rows_):
    th = "".join(f"<th>{h}</th>" for h in head)
    tr = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows_)
    return f"<table><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table>"


sub_rows = []
for h in HZ:
    v = C[f"r{h}"]
    net = v.mean() - fric_med
    sub_rows.append([f"固定持有 {h} 交易日", f"{v.mean():+.2f}%", f"{v.median():+.2f}%",
                     f"{100*(v>0).mean():.1f}%", f"{v.std():.2f}",
                     f"{net:+.2f}%", "◀ 最优" if h == 1 else ""])
sub_rows.insert(0, ["<b>实际回测（当前出场策略）</b>", f"<b>{C['actual'].mean():+.2f}%</b>",
                    f"{C['actual'].median():+.2f}%", f"{100*(C['actual']>0).mean():.1f}%",
                    f"{C['actual'].std():.2f}", "—（已含摩擦）", ""])

path_rows = []
for code, batch in (("002855", "20260904"),):
    r = T[(T["code"] == code) & (T["_batch"] == batch)].iloc[0]
    stop_px = r["buy_price"] * 0.85
    k = kof(code)
    for i in k.index[k["date"] >= pd.Timestamp(r["buy_date"])][:6]:
        day = k.loc[i]
        prev = k.loc[i - 1, "close"]
        chg = 100 * (day["close"] / prev - 1)
        pinned = abs(day["low"] - day["close"]) < 1e-9
        hit = day["low"] <= stop_px
        path_rows.append([str(day["date"].date()), f"{day['open']:.2f}", f"{day['low']:.2f}",
                          f"{day['close']:.2f}", f"{chg:+.2f}%",
                          "是" if hit else "—", "是" if pinned else "—"])

ma_rows = []
for e, g in B.groupby("exit"):
    ma_rows.append([e, f"{len(g)}", f"{g['dist'].median():+.2f}%",
                    f"{g['dist'].quantile(.25):+.2f}%", f"{g['dist'].quantile(.75):+.2f}%",
                    f"{100*(g['dist']<0).mean():.0f}%"])

# trend_break 专属反事实（不能拿恒定子样本的数字代替）
tb_codes = T[T["exit_reason"] == "trend_break"]
TB = {}
for h in (1, 2, 5):
    vs = [v for v in (fwd(r, h) for _, r in tb_codes.iterrows()) if v is not None]
    TB[f"t{h}"] = float(np.mean(vs)) if vs else float("nan")
TB["n"] = len(tb_codes)

html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>出场审计报告 2026-09-21</title>
<style>
:root{{--bg:#faf9f6;--card:#fff;--fg:#1c1c1a;--mut:#6b6a65;--bd:#e3e1da;--bad:#2e7d32;--good:#c0392b;--warn:#8a6d18;}}
@media (prefers-color-scheme:dark){{:root{{--bg:#1b1b19;--card:#232320;--fg:#f0efe9;--mut:#9b9a93;--bd:#3a3a35;--bad:#6bbf6f;--good:#e8695a;--warn:#d0b055;}}}}
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 20px 64px;background:var(--bg);color:var(--fg);font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;font-size:14px;line-height:1.65}}
.wrap{{max-width:920px;margin:0 auto}}
h1{{font-size:20px;font-weight:500;margin:0 0 4px}}
.sub{{color:var(--mut);font-size:13px;margin-bottom:24px}}
h2{{font-size:15px;font-weight:500;margin:32px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--bd)}}
table{{width:100%;border-collapse:collapse;font-size:13px;background:var(--card);border:1px solid var(--bd);border-radius:10px;overflow:hidden}}
th,td{{padding:7px 10px;text-align:left;border-bottom:1px solid var(--bd)}}
th{{font-weight:500;font-size:12px;color:var(--mut)}}
tr:last-child td{{border-bottom:none}}
td:nth-child(n+2){{font-variant-numeric:tabular-nums}}
.box{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px 18px;margin:12px 0}}
.box.warn{{border-color:var(--warn)}}
.box.bad{{border-color:var(--bad)}}
ul{{margin:6px 0 0;padding-left:20px}}li{{margin-bottom:5px}}
code{{font-family:ui-monospace,Consolas,monospace;font-size:12px;background:var(--bg);padding:1px 5px;border-radius:4px;border:1px solid var(--bd)}}
.g{{color:var(--good)}}.b{{color:var(--bad)}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}}
.mc{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px 16px}}
.mc .k{{font-size:12px;color:var(--mut)}}.mc .v{{font-size:20px;font-weight:500;margin:2px 0}}
.mc .s{{font-size:12px;color:var(--mut)}}
</style></head><body><div class="wrap">
<h1>出场审计报告</h1>
<div class="sub">2026-09-21 · 只读诊断，未改生产代码 · 样本 {len(T)} 笔 / {T['_batch'].nunique()} 个信号日</div>

<h2>一、结论</h2>
<div class="grid">
<div class="mc"><div class="k">回测实际止损（中位）</div><div class="v">15.00%</div><div class="s">clamp(8×日σ, 6%, 15%) · 饱和 {100*(S['bt']>=0.1499).mean():.0f}%</div></div>
<div class="mc"><div class="k">清单展示止损（中位）</div><div class="v">5.45%</div><div class="s">clamp(2.5×日σ, 4%, 12%) · 饱和 {100*(S['bl']>=0.1199).mean():.0f}%</div></div>
<div class="mc"><div class="k">两套不一致</div><div class="v">100%</div><div class="s">平均差 +{(S['bt']-S['bl']).mean()*100:.2f}pp</div></div>
<div class="mc"><div class="k">单笔摩擦成本</div><div class="v">{fric_med:.2f}%</div><div class="s">滑点0.1%×2 + 佣金(最低¥5) + 印花税0.05%</div></div>
</div>
<div class="box warn">
<b>一句话：出场层不是主要矛盾，但系统里确实有三个真问题。</b>
按固定持有期做反事实，<b>持有 1 天</b>在同一批 {len(C)} 笔上的毛收益是
<b class="g">{C['r1'].mean():+.2f}%</b>（胜率 {100*(C['r1']>0).mean():.0f}%），
而当前出场策略只有 <b class="b">{C['actual'].mean():+.2f}%</b>；
持有 ≥4 天全面转负。<b>真正的杠杆是持有期，不是止损位</b>。
</div>

<h2>二、三个真问题</h2>

<h3>1 · 同一个止损，系统里有两个不同的数</h3>
{tbl(["口径", "公式", "中位取值", "饱和率", "代码位置"],
     [["回测引擎实际使用", "clamp(8.0 × 日σ, 6%, 15%)", f"{100*S['bt'].median():.2f}%",
       f"{100*(S['bt']>=0.1499).mean():.0f}%", "daily_backtest.py L419-427"],
      ["清单/DAL 展示给用户", "clamp(2.5 × 日σ, 4%, 12%)", f"{100*S['bl'].median():.2f}%",
       f"{100*(S['bl']>=0.1199).mean():.0f}%", "boll_levels.py L76-80"]])}
<div class="box">
两处用的是<b>同一个 <code>vol20</code></b>（近 20 日日收益 σ，<b>未年化</b>），但系数（8.0 vs 2.5）
与上下限（[6%,15%] vs [4%,12%]）完全不同 ⇒ <b>{len(S)}/{len(S)} 笔两套止损都不相等</b>，
平均相差 <b>+{(S['bt']-S['bl']).mean()*100:.2f}pp</b>。<br>
后果：你在清单/网站上看到的「止损价（下轨）」不是回测/监控真正执行的止损；
{100*(S['bt']>=0.1499).mean():.0f}% 的标的在回测里其实是被 15% 上限止损保护（中位数已顶到上限）。
</div>

<h3>2 · 「止损最多亏 15%」不成立 —— 连续跌停会击穿</h3>
<div class="box">
{tbl(["日期", "开盘", "最低", "收盘", "日涨跌", "触及止损", "钉在最低"], path_rows)}
买入 2026-09-07 @19.239，止损价 19.239×0.85 = <b>16.353</b>。<br>
09-09 已 -10.00% 钉在最低（跌停）；09-10、09-11 连续跌停，止损虽已触及但
<b>卖单无法成交 → 引擎清除出场意图、顺延次日</b>；直到 09-14 才以开盘价 12.80 成交
（×0.999 滑点 = 12.787）⇒ <b class="b">实际 -33.54%，是设定止损的 2.2 倍</b>。<br>
<span style="color:var(--mut)">其余 4 笔 stop_hard 全部精确成交在止损位（16.737×0.85×0.999 = 14.212 ✓），
gap-aware 止损本身工作正常；问题只在「连续跌停」这一尾部情形，而它恰好贡献了 -94 点中的 -33.5 点。</span>
</div>

<h3>3 · MA60 破位出场：不是错，是「太晚」+「被用在错误的对象上」</h3>
{tbl(["出场原因", "笔数", "入场距 MA60 中位", "p25", "p75", "买在 MA60 下方占比"], ma_rows)}
<div class="box">
<code>trend_break</code> 的 {len(tb)} 笔里，入场时距 MA60 的中位数只有
<b class="b">{tb['dist'].median():+.2f}%</b>，而其他出场的组是 +5% ~ +43%。
其中 <b>{100*(tb['dist']<0).mean():.0f}%</b> 的仓位在<b>买入时就已在 MA60 下方</b> ⇒ 次日开盘必触发破位。<br>
反事实：这 {len(tb)} 笔若不出场，持到 1 日约 <b>{TB['t1']:+.2f}%</b>、
持到 2 日 <b>{TB['t2']:+.2f}%</b>、持到 5 日 <b>{TB['t5']:+.2f}%</b>
（实际 -2.82%）—— 也就是说，<b>破位出场 ≈ 持到 5 天的效果，它并没有比继续持有更差</b>；
真正的浪费在于这些仓位从买入起就注定亏损，<b>该缩短的是持有期，不是调 MA60 参数</b>。
</div>

<h2>三、固定持有期反事实（恒定子样本 n={len(C)}，扣除摩擦后）</h2>
{tbl(["口径", "毛均值", "中位", "胜率", "标准差", "净额估算", ""], sub_rows)}
<div class="box warn">
恒定子样本 = 在 1/2/3/5/8/12 日全程都有行情的那些笔（去掉批次窗口偏差），
全部口径在同一批标的上比较。净额 = 毛均值 − 单笔摩擦 {fric_med:.2f}%。<br>
<b>持有 1 日净额 ≈ {C['r1'].mean()-fric_med:+.2f}%</b>，优于当前出场策略的
{C['actual'].mean():+.2f}%（该值已含摩擦）。<br>
⚠️ n={len(C)} 的均值 95% 置信区间约 ±{1.96*C['r1'].std()/math.sqrt(len(C)):.2f}pp，
<b>与当前策略的差距尚未达到统计显著</b>；方向（短持有更好）在
全样本与恒定子样本两处独立一致，但<b>必须先用带成本的正式回测验证</b>再改配置。
</div>

<h2>四、买入定价时点（已核实）</h2>
<div class="box">
{len(T)}/{len(T)} 笔的 <code>buy_price</code> 都等于<b>买入日当日开盘价 × 1.001</b>
（比值中位 1.001）⇒ 「信号日<b>次日开盘</b>成交 + 0.1% 滑点」，与
<code>engine.py L595</code> 一致。含义：<b>信号日收盘 → 次日开盘之间的跳空全部由策略承担</b>，
而 alpha 又只存在于进场后 1-2 天，进场时点本身就在消耗 edge。
</div>
</div></body></html>"""

OUT.write_text(html, encoding="utf-8")
print("WROTE", OUT)
print(f"n={len(C)} actual={C['actual'].mean():+.3f} r1={C['r1'].mean():+.3f} "
      f"r2={C['r2'].mean():+.3f} r3={C['r3'].mean():+.3f} r5={C['r5'].mean():+.3f} "
      f"r8={C['r8'].mean():+.3f} r12={C['r12'].mean():+.3f}")
print(f"friction median={fric_med:.3f}%  bt_stop med={100*S['bt'].median():.2f} "
      f"boll_stop med={100*S['bl'].median():.2f} mismatch={100*(S['bt']!=S['bl']).mean():.0f}%")
print(f"tb n={len(tb)} dist_med={tb['dist'].median():+.2f}% below={100*(tb['dist']<0).mean():.0f}%")
