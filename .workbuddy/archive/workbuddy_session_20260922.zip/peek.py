import subprocess, base64, sys

date = sys.argv[1]  # e.g. 0917
path = "stock_data/Multi-Backtest-2026%s-summary.csv" % date
out = subprocess.run(
    ["gh", "api", "repos/benny1232123/Stocks-Master/contents/" + path, "--jq", ".content"],
    capture_output=True, text=True, timeout=60)
if out.returncode != 0:
    print("ERR rc=%s %s" % (out.returncode, out.stderr[:300]))
    sys.exit()
b64 = out.stdout.strip()
try:
    raw = base64.b64decode(b64).decode("utf-8")
except Exception:
    print("decode fail; head:", b64[:80])
    sys.exit()
lines = raw.splitlines()
print("=== %s : %d lines ===" % (path, len(lines)))
for l in lines[:40]:
    print(l)
