"""验证 render_stock / render_stock_html 正确接入 sizing 区块（不联网：news surface 走本地读）。"""
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from smcore.config.defaults import POSITION_SIZING_CONFIG
from smcore.analysis import position_sizing_recommendation, recommendation_from_analysis

def rich_analysis(close, sgn):
    latest = {"close": close, "upper": close*1.05, "lower": close*0.95, "middle": close,
              "ma5": close, "ma10": close, "ma20": close, "ma60": close,
              "rsi": 25 if sgn=="strong" else (75 if sgn=="weak" else 50),
              "dif": 0.5 if sgn!="weak" else -0.5, "dea": 0.3 if sgn!="weak" else -0.3,
              "macd_hist": 0.2 if sgn!="weak" else -0.2,
              "k_val": 60, "d_val": 55, "j_val": 70}
    metrics = {"dist_to_lower_pct": 1.0, "dist_to_upper_pct": -3.0, "signal_text": "测试", "bandwidth": 5.0}
    return {"code": "600000", "latest": latest, "metrics": metrics,
            "fundamentals": None,
            "series": {"rows": [{"close": close*0.99}, {"close": close}]}}

import scripts.notify_holdings_analysis as N
a = rich_analysis(10.0, "strong")
pos = {"qty": 100, "cost": 9.0, "name": "测试银行"}
sizing = position_sizing_recommendation(
    a, pos, 100000.0, cfg=POSITION_SIZING_CONFIG, n_holdings=1
)

md = N.render_stock(a, pos, sizing)
html = N.render_stock_html(a, pos, sizing)

print("MD 含'仓位调整':", "⚖️ 仓位调整" in md or "仓位调整" in md)
print("HTML 含'仓位调整':", "仓位调整" in html)
print("HTML 含 delta 金额:", "¥" in html and "股" in html)
print("sizing.action =", sizing["action"], "| current→target =",
      f'{sizing["current_weight"]}%→{sizing["target_weight"]}%')
print("---- MD 片段 ----")
for line in md.splitlines():
    if "仓位调整" in line or "持仓建议" in line:
        print(line)
print("---- HTML 片段 ----")
import re
for m in re.findall(r'<div class="rec[^"]*">.*?</div>', html, re.S):
    if "仓位" in m or "建议" in m:
        print(m[:160])
