"""把未受保护的 `import akshare as ak` 替换为 ak_compat 的 get_ak() 调用。

保持每处原有缩进与文件行尾（CRLF/LF 各自保留），函数内自带 import 以最小化改动。
"""
from __future__ import annotations

import pathlib
import re

ROOT = pathlib.Path(r"E:\Stocks-Master")

TARGETS = [
    "smcore/dashboard.py",
    "smcore/data/index.py",
    "smcore/selection.py",
    "smcore/risk/external.py",
    "smcore/strategies/cctv.py",
    "smcore/strategies/momentum.py",
    "smcore/strategies/relativity.py",
    "smcore/strategies/theme.py",
]

PATTERN = re.compile(r"([ \t]*)import akshare as ak\b")

for rel in TARGETS:
    path = ROOT / rel
    raw = path.read_bytes()
    eol = "\r\n" if b"\r\n" in raw else "\n"
    eol_name = "CRLF" if eol == "\r\n" else "LF"
    src = raw.decode("utf-8")

    hits = len(PATTERN.findall(src))
    if hits == 0:
        print(f"  {rel:38} 无匹配（可能已处理）")
        continue

    def _repl(m, _eol=eol):
        return (
            f"{m.group(1)}from smcore.utils.ak_compat import get_ak"
            f"{_eol}{m.group(1)}ak = get_ak()"
        )

    new_src = PATTERN.sub(_repl, src)
    if new_src == src:
        print(f"  {rel:38} 未变更")
        continue

    path.write_bytes(new_src.encode("utf-8"))
    print(f"  {rel:38} 替换 {hits} 处  (行尾 {eol_name})")

print("\n=== 复查：smcore 内剩余裸 import akshare ===")
SKIP = {"__pycache__"}
left = []
for path in sorted((ROOT / "smcore").rglob("*.py")):
    if any(p in SKIP for p in path.parts):
        continue
    txt = path.read_text(encoding="utf-8", errors="ignore")
    for i, line in enumerate(txt.splitlines(), 1):
        if "import akshare" in line:
            left.append(f"{path.relative_to(ROOT)}:{i}: {line.strip()}")
for item in left:
    print(f"  {item}")
if not left:
    print("  （无）")
