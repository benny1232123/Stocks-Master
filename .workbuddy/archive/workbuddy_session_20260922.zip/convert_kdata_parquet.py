"""一次性迁移：stock_data/k_data 全部 *_qfq_full.csv → 按代码前缀分桶的 parquet。

设计（见 smcore/data/kline.py 的 read_kline_cache/write_kline_cache）：
  单只股票全部历史 K 线存于 qfq_b{XX}.parquet，列 code,date,open,high,low,close,volume,amount。
  文件数 4372 → ~25；体积 ~691M → ~250M；回测全市场扫描仍≈每股票一次文件读取（谓词下推）。

本脚本按桶聚合后每桶只写一次（不逐股重写），并做：
  1) 总行数一致性：parquet 各桶行数之和 == 全部 CSV 行数之和
  2) 真值抽查：600519（茅台）2025-06-26 收盘 == 1363.95（akshare 交叉验证真值）
  3) 打印桶数 / 总行数 / parquet 总体积

不删除任何 CSV（删除由后续显式 git rm 步骤完成，便于回滚）。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

ROOT = Path("E:/Stocks-Master")
SRC = ROOT / "stock_data" / "k_data"

sys.path.insert(0, str(ROOT))
from smcore.data.kline import DAILY_K_COLUMNS  # noqa: E402


def main() -> int:
    csvs = sorted(SRC.glob("*_qfq_full.csv"))
    if not csvs:
        print("没有找到 *_qfq_full.csv，无需迁移。")
        return 0
    print(f"源 CSV 数: {len(csvs)}")

    total_csv_rows = 0
    buckets: dict[str, list[pd.DataFrame]] = {}
    for i, f in enumerate(csvs, 1):
        code = f.name.split("_")[0]
        df = pd.read_csv(f)
        missing = [c for c in DAILY_K_COLUMNS if c not in df.columns]
        if missing:
            print(f"[WARN] {f.name} 缺列 {missing}，跳过")
            continue
        df = df[DAILY_K_COLUMNS].copy()
        df.insert(0, "code", code)
        total_csv_rows += len(df)
        buckets.setdefault(code[:2], []).append(df)
        if i % 500 == 0:
            print(f"  读取进度 {i}/{len(csvs)} ...")

    print(f"CSV 总行数: {total_csv_rows}")
    print(f"桶数: {len(buckets)}")

    total_parquet_rows = 0
    for prefix, frames in buckets.items():
        big = pd.concat(frames, ignore_index=True)
        big = big.sort_values(["code", "date"]).reset_index(drop=True)
        big.to_parquet(SRC / f"qfq_b{prefix}.parquet", index=False)
        total_parquet_rows += len(big)

    print(f"Parquet 总行数: {total_parquet_rows}")

    # 校验 1：行数一致
    if total_parquet_rows != total_csv_rows:
        print(f"[FAIL] 行数不一致：CSV={total_csv_rows} parquet={total_parquet_rows}")
        return 1
    print("[OK] 总行数一致")

    # 校验 2：茅台真值抽查
    pf = SRC / "qfq_b60.parquet"
    if pf.exists():
        m = pd.read_parquet(pf, filters=[("code", "==", "600519")])
        row = m[m["date"] == "2025-06-26"]
        if row.empty:
            print("[WARN] 茅台 2025-06-26 不在 parquet 中，跳过真值抽查")
        else:
            v = float(row["close"].iloc[0])
            if abs(v - 1363.95) < 0.01:
                print(f"[OK] 茅台 2025-06-26 收盘={v} == 真值 1363.95")
            else:
                print(f"[FAIL] 茅台 2025-06-26 收盘={v} != 真值 1363.95")
                return 1

    # 体积
    parquet_size = sum((SRC / f"qfq_b{p}.parquet").stat().st_size for p in buckets)
    print(f"Parquet 总体积: {parquet_size/1e6:.1f} MB")
    print("迁移完成（CSV 未删除，待显式 git rm）。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
