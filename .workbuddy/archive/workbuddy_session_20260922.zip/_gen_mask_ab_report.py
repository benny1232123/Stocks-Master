# -*- coding: utf-8 -*-
"""mask A/B 报告（嵌入汇总原文 + 结论表）。"""
import html as _h
from pathlib import Path

ROOT = Path(r"E:\Stocks-Master")
S = ROOT / ".workbuddy" / "_mask_ab_summary.txt"
OUT = ROOT / ".workbuddy" / "mask_ab_20260921.html"

fwd_rows = [
    ("mask_on（生产现状）", 1, 14, "-0.20", "-0.15", "28.6"),
    ("mask_off（关掉该层）", 1, 14, "<b>-0.11</b>", "<b>-0.07</b>", "<b>42.9</b>"),
    ("mask_on", 2, 14, "-0.51", "-0.42", "21.4"),
    ("mask_off", 2, 14, "<b>-0.31</b>", "<b>-0.21</b>", "<b>28.6</b>"),
    ("mask_on", 3, 13, "-0.82", "-0.39", "7.7"),
    ("mask_off", 3, 13, "<b>-0.64</b>", "<b>-0.21</b>", "<b>23.1</b>"),
    ("mask_on", 5, 11, "-1.40", "-0.48", "0.0"),
    ("mask_off", 5, 11, "<b>-1.15</b>", "<b>-0.23</b>", "0.0"),
]
pair_rows = [
    ("H=1", 14, "+0.081", "+0.71", "8 / 6"),
    ("H=2", 14, "+0.202", "+1.63", "10 / 4"),
    ("H=3", 13, "+0.180", "+1.50", "9 / 4"),
    ("H=5", 11, "+0.250", "+1.50", "6 / 5"),
]
comp_rows = [
    ("Skew60", "+6.70", "1.60", "7.33", "×4.58", "g"),
    ("VRatio10_60", "+4.76", "1.20", "6.33", "×5.28", "g"),
    ("CVAmt60", "+2.54", "3.13", "4.27", "×1.36", ""),
    ("VRatio20_120", "+1.65", "6.60", "2.13", "×0.32", "b"),
    ("Vol20", "+0.82", "2.87", "6.80", "×2.37", "g"),
    ("PVCorr20", "+0.18", "2.73", "0.07", "×0.02", "b"),
    ("DistLo10", "−1.31", "1.73", "3.00", "×1.73", "b"),
    ("Skew20", "−1.72", "5.20", "0.80", "×0.15", "g"),
    ("CVAmt20", "−3.76", "5.80", "2.33", "×0.40", "g"),
    ("Illiq20", "−9.90", "1.20", "1.07", "×0.89", ""),
    ("PVCorr60", "−10.72", "1.93", "3.00", "×1.55", "b"),
]


def rows(lst, cls=()):
    out = []
    for r in lst:
        cls_ = locals().get("cls")
        tds = "".join(f"<td>{c}</td>" for c in r)
        out.append(f"<tr>{tds}</tr>")
    return "".join(out)


comp_html = "".join(
    f'<tr><td>{a}</td><td>{b}</td><td>{c}</td><td>{d}</td>'
    f'<td class="{e}">{f}</td></tr>' for a, b, c, d, f, e in comp_rows)

html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>factor_timing mask A/B 2026-09-21</title>
<style>
:root{{--bg:#faf9f6;--card:#fff;--fg:#1c1c1a;--mut:#6b6a65;--bd:#e3e1da;--g:#c0392b;--b:#2e7d32;--w:#8a6d18;}}
@media (prefers-color-scheme:dark){{:root{{--bg:#1b1b19;--card:#232320;--fg:#f0efe9;--mut:#9b9a93;--bd:#3a3a35;--g:#e8695a;--b:#6bbf6f;--w:#d0b055;}}}}
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 20px 64px;background:var(--bg);color:var(--fg);font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;font-size:14px;line-height:1.65}}
.wrap{{max-width:1020px;margin:0 auto}}
h1{{font-size:20px;font-weight:500;margin:0 0 4px}}
.sub{{color:var(--mut);font-size:13px;margin-bottom:24px}}
h2{{font-size:15px;font-weight:500;margin:32px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--bd)}}
h3{{font-size:14px;font-weight:500;margin:20px 0 8px}}
.box{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px 18px;margin:12px 0}}
.box.warn{{border-color:var(--w)}}.box.good{{border-color:var(--g)}}
table{{width:100%;border-collapse:collapse;font-size:13px;background:var(--card);border:1px solid var(--bd);border-radius:10px;overflow:hidden;margin:10px 0}}
th,td{{padding:7px 10px;text-align:left;border-bottom:1px solid var(--bd)}}
th{{font-weight:500;font-size:12px;color:var(--mut)}}
tr:last-child td{{border-bottom:none}}
td:nth-child(n+3){{font-variant-numeric:tabular-nums;text-align:right}}
pre{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:12px 14px;overflow:auto;font-family:ui-monospace,Consolas,monospace;font-size:12px;line-height:1.5}}
ul{{margin:6px 0 0;padding-left:20px}}li{{margin-bottom:5px}}
code{{font-family:ui-monospace,Consolas,monospace;font-size:12px;background:var(--bg);padding:1px 5px;border-radius:4px;border:1px solid var(--bd)}}
.g{{color:var(--g)}}.b{{color:var(--b)}}
</style></head><body><div class="wrap">
<h1><code>factor_timing</code> mask 的 A/B</h1>
<div class="sub">2026-09-21 · 离线重跑融合 · 唯一变量 = <code>adaptive_weights_config.json::factor_timing.enabled</code>
（True=生产 / False=关闭） · 15 个信号日各产 50 只/天 · 输出隔离 <code>.workbuddy/mask_ab/</code></div>

<h2>一、结论</h2>
<div class="box good">
<b>① mask 确实按「与 edge 相反」的方向重排了选股构成 —— 这条已确证。</b>
关掉后，正 edge 最强的 <code>Skew60</code>(+6.70) 从 <b>1.60 → 7.33</b> 只/天（×4.6）、
<code>VRatio10_60</code>(+4.76) 从 <b>1.20 → 6.33</b>（×5.3）、<code>Vol20</code> ×2.4；
同时负 edge 的 <code>Skew20</code>(−1.72) ×0.15、<code>CVAmt20</code>(−3.76) ×0.40、
<code>PVCorr20</code>(n=1) ×0.02 被大幅压缩。
</div>
<div class="box warn">
<b>② 但收益改善幅度在 14 天上不显著。</b>
四个持有期<b>方向全部一致（mask_off 更好）</b>，幅度 +0.08 ~ +0.25pp，
但配对 t 只有 <b>0.71 ~ 1.63</b> —— 达不到 |t|≥2。
⇒ 这是<b>强方向性证据 + 清晰的机制</b>，还不足以称为"已证明的修复"。
</div>
<div class="box warn">
<b>③ 两个 arm 都仍然跑输全市场。</b>
超额收益 mask_on −0.15/−0.42/−0.39/−0.48pp、mask_off −0.07/−0.21/−0.21/−0.23pp（H=1/2/3/5）。
关掉 mask <b>减小了</b>负超额，但<b>没有产生 alpha</b>。
把这层关掉只是"少亏一点"，不是"变好"。
</div>

<h2>二、前向收益对照（口径 = 信号日次日开盘买 → 持有 H 日收盘卖）</h2>
<table><thead><tr><th>arm</th><th>H（交易日）</th><th>天数</th><th>绝对均%</th><th>超额均%</th><th>胜率%</th></tr></thead>
<tbody>{rows(fwd_rows)}</tbody></table>

<h2>三、逐日配对（mask_off − mask_on，同信号日）</h2>
<table><thead><tr><th>持有期</th><th>n</th><th>均值 Δ(pp)</th><th>配对 t</th><th>off 更好 / 更差</th></tr></thead>
<tbody>{rows(pair_rows)}</tbody></table>
<div class="box">方向 4/4 一致为正；H=2/3/5 的 t 在 1.5 附近。样本 = 15 个信号日、
每天 50 只，属于<b>小样本 + 单一行情段</b>，H≥3 更只有 11~13 天（数据末端 2026-09-21 限制）。
</div>

<h2>四、构成重排（每日单策略命中数，两 arm 同为 50 行/天）</h2>
<table><thead><tr><th>因子</th><th>实测 edge</th><th>mask_on /天</th><th>mask_off /天</th><th>倍数</th></tr></thead>
<tbody>{comp_html}</tbody></table>
<div class="box">
<span class="g">绿色</span> = 构成朝 edge 方向重排（正 edge 增加 / 负 edge 减少）；
<span class="b">绿色</span> 反之。绝大部分变化与 edge 同向，<b>证明 mask 的净效应是"惩罚好因子"</b>。
两个例外（<code>PVCorr60</code> −10.72 反而 ×1.55、<code>VRatio20_120</code> +1.65 反而 ×0.32）
说明它不是简单的"随机"，而是被那套 10 天信念 IC 判据系统性带偏。
</div>

<h2>五、顺带发现的运维成本</h2>
<div class="box warn">
<code>mask_on</code> 这一 arm 慢了约一个数量级：<code>apply_mask</code> →
<code>factor_timing.conviction_points()</code> <b>每个信号日都重算全历史因果 edge</b>
（模块 docstring 自己也承认"全历史口径较重"）。16 天 mask_on 约 16 分钟，mask_off 几乎瞬时。
<b>这层不只是逻辑可疑，还是整条链路唯一的重度计算瓶颈。</b>
</div>

<h2>六、原始汇总输出</h2>
<pre>{_h.escape(S.read_text(encoding="utf-8"))}</pre>

<h2>七、建议</h2>
<ul>
<li><b>不要只凭这份 A/B 就改生产配置</b>（t 不显著）。但可以把
<code>factor_timing.enabled</code> 列为<b>待验证的第一候选</b>。</li>
<li>下一步做<b>长样本确认</b>：<code>zoo_factor_strategy.py --date</code> 实测 22 秒/天，
回填 60 个交易日（≈22 分钟）+ 离线重跑融合（mask_off 很快），
把 n 从 15 提到 ~60 再看 t。</li>
<li>无论开关，都应修 <code>factor_timing_mask_from_points</code> 的判据：
把「IC 不显著 → 清零」反转为「证据不足 → 保留；有证据且显著为负 → 清零」，
并给窗口内点数加下限（当前 n=2~3 也在参与判定）。</li>
</ul>
<div class="box warn">⚠️ 本轮<b>只读</b>：未改任何生产配置，未 commit 融合产物。</div>
</div></body></html>"""

OUT.write_text(html, encoding="utf-8")
print("WROTE", OUT, len(html))
