import subprocess, time, csv, io, base64, json, os, re, sys

SLUG = "benny1232123/Stocks-Master"
WF = "daily-pick.yml"
# 13 个需重跑的日期（审计结论：8 陈旧 legacy + 5 无回测文件）
DATES = ["20260827","20260828","20260831","20260901","20260902","20260903",
         "20260904","20260907","20260908","20260909","20260910","20260911","20260915"]
STATE_FILE = r"E:\Stocks-Master\.workbuddy\realign_drive_state.json"
A_BATCH = ["pvcorr","cvamt","skew","vratio","distlo","vol20","illiq"]
LEGACY = ["cctv","theme","boll","relativity","momentum"]
PER_DATE_TIMEOUT = 150*60


def gh(args, tries=3):
    last = (None, "", "")
    for _ in range(tries):
        r = subprocess.run(["gh"] + args, capture_output=True, text=True)
        if r.returncode == 0:
            return r.returncode, r.stdout, r.stderr
        last = (r.returncode, r.stdout, r.stderr)
        time.sleep(8)
    return last


def load_state():
    if os.path.exists(STATE_FILE):
        try:
            return json.load(open(STATE_FILE, encoding="utf-8"))
        except Exception:
            pass
    return {"done": [], "failed": [], "current": None}


def save_state(s):
    json.dump(s, open(STATE_FILE, "w", encoding="utf-8"), indent=2, ensure_ascii=False)


def classify(s):
    s = (s or "").lower()
    if not s:
        return "EMPTY"
    leg = any(t in s for t in LEGACY)
    ab = any(t in s for t in A_BATCH)
    if leg and not ab:
        return "STALE"
    if ab and not leg:
        return "OK"
    return "AMBIG"


def fetch_strategies(date):
    code, out, err = gh(["api", f"repos/{SLUG}/contents/stock_data/Multi-Backtest-{date}-summary.csv", "--jq", ".content"])
    if code != 0 or not out.strip():
        return None
    try:
        raw = base64.b64decode(out.strip()).decode("utf-8-sig")
    except Exception:
        return "DECODE_ERR"
    try:
        row = next(csv.DictReader(io.StringIO(raw)))
        return row.get("strategies", "")
    except Exception:
        return "CSV_ERR"


def dispatch(date):
    code, out, err = gh(["workflow", "run", WF, "-r", "master", "-f", f"signal_date={date}"])
    if code != 0:
        return None, f"dispatch rc={code}: {err.strip()}"
    m = re.search(r"actions/runs/(\d+)", out)
    if m:
        return m.group(1), None
    # fallback: 等一致性后从 run list 取最新 workflow_dispatch
    time.sleep(20)
    code, out, err = gh(["run", "list", "--workflow", WF, "--json", "databaseId,createdAt,event,status", "--limit", "5"])
    if code == 0:
        try:
            runs = json.loads(out)
            for r in runs:
                if r.get("event") == "workflow_dispatch":
                    return str(r["databaseId"]), None
        except Exception:
            pass
    return None, f"dispatch 成功但取不到 run id: {out.strip()[-200:]}"


def wait_run(run_id, timeout):
    deadline = time.time() + timeout
    while time.time() < deadline:
        code, out, err = gh(["run", "view", run_id, "--json", "status,conclusion"])
        if code == 0:
            try:
                d = json.loads(out)
                st, con = d.get("status", ""), d.get("conclusion", "")
                if st == "completed":
                    return con or "completed", None
                if st in ("failure", "timed_out", "cancelled"):
                    return None, f"run {st}"
            except Exception:
                pass
        time.sleep(60)
    return None, "wait timeout"


def run_active(run_id):
    code, out, err = gh(["run", "view", str(run_id), "--json", "status"])
    if code == 0:
        try:
            return json.loads(out).get("status", "") in ("queued", "pending", "in_progress", "waiting", "requested")
        except Exception:
            return False
    return False


def main():
    st = load_state()
    print(f"[{time.strftime('%H:%M:%S')}] start; done={len(st['done'])} failed={len(st['failed'])}", flush=True)
    for date in DATES:
        if date in st["done"]:
            print(f"[{time.strftime('%H:%M:%S')}] {date} 已 done，跳过", flush=True)
            continue
        if date in st["failed"]:
            print(f"[{time.strftime('%H:%M:%S')}] {date} 之前 failed，跳过（需人工）", flush=True)
            continue
        # 接管在途 run（断点续跑用），避免重复派发
        cur = st.get("current")
        if isinstance(cur, dict) and cur.get("date") == date and run_active(cur.get("run")):
            run_id = str(cur["run"])
            print(f"[{time.strftime('%H:%M:%S')}] {date} 接管在途 run={run_id}", flush=True)
        else:
            # 派发
            run_id, e = dispatch(date)
        if run_id is None:
            print(f"[{time.strftime('%H:%M:%S')}] {date} dispatch 失败: {e}", flush=True)
            st["failed"].append(date); save_state(st)
            continue
        print(f"[{time.strftime('%H:%M:%S')}] {date} dispatched run={run_id}", flush=True)
        st["current"] = {"date": date, "run": run_id}; save_state(st)
        con, e = wait_run(run_id, PER_DATE_TIMEOUT)
        st.pop("current", None); save_state(st)
        if con is None:
            print(f"[{time.strftime('%H:%M:%S')}] {date} run 异常: {e}", flush=True)
            st["failed"].append(date); save_state(st)
            continue
        # 核验回测
        time.sleep(10)
        strat = fetch_strategies(date)
        if strat is None:
            print(f"[{time.strftime('%H:%M:%S')}] {date} run={con} 但无回测文件", flush=True)
            st["failed"].append(date); save_state(st)
            continue
        cls = classify(strat)
        print(f"[{time.strftime('%H:%M:%S')}] {date} run={con} strategies={strat} -> {cls}", flush=True)
        if cls == "OK":
            st["done"].append(date)
        else:
            st["failed"].append(date)
        save_state(st)
    print(f"[{time.strftime('%H:%M:%S')}] DONE. done={st['done']} failed={st['failed']}", flush=True)


if __name__ == "__main__":
    main()
