"""演示 notify_holdings_analysis.py 的 pos_map 多批次建仓 bug。
复现当前（buggy）逻辑 vs 修正（聚合）逻辑，在「同一代码两笔买入」场景下对比。
"""
import pandas as pd

# 模拟 FIFO 输出的 pos_df：代码 600000 分两笔买入，均未卖出
pos_df = pd.DataFrame([
    {"代码": "600000", "买入日期": "2026-01-05", "数量": 1000.0, "成本价": 10.0},
    {"代码": "600000", "买入日期": "2026-03-10", "数量": 500.0,  "成本价": 11.0},
])
close = 12.0  # 假设现价

def resolve_name(c):
    return {"name": "浦发银行"}

# ---------- 当前（buggy）逻辑：pos_map[c] = 最后一行覆盖 ----------
pos_map_bug = {}
for _, prow in pos_df.iterrows():
    c = str(prow.get("代码", "")).strip()
    cost = prow.get("成本价"); qty = prow.get("数量")
    pos_map_bug[c] = {
        "name": resolve_name(c).get("name", ""),
        "cost": float(cost) if cost not in (None, "") else None,
        "qty": float(qty) if qty not in (None, "") else None,
        "buy_date": str(prow.get("买入日期", "")),
    }
codes_bug = [str(c) for c in pos_df["代码"].tolist()]

# 单只 PnL（与 _stock_pnl 同公式）
def pnl_of(pos, close):
    qty = pos["qty"]; cost = pos["cost"]
    return (close - cost) * qty, (close - cost) / cost * 100

bug_pos = pos_map_bug["600000"]
bug_pnl, bug_pct = pnl_of(bug_pos, close)
bug_total_qty = sum(pos_map_bug[c]["qty"] for c in codes_bug)  # codes 重复 -> 末笔×2

print("=== BUGGY（当前线上行为）===")
print(f"  报告显示 600000: 数量={bug_pos['qty']} 成本={bug_pos['cost']} 买入日={bug_pos['buy_date']}")
print(f"  单只浮动盈亏 = {bug_pnl:.0f} 元 ({bug_pct:.1f}%)")
print(f"  组合汇总用到的数量(因 codes 重复) = {bug_total_qty}")
print(f"  真实应为: 数量=1500 成本(加权)={(1000*10+500*11)/1500:.3f} 盈亏={(close-(1000*10+500*11)/1500)*1500:.0f} 元")
print()

# ---------- 修正逻辑：按代码聚合（加权成本 / 总数量 / 最早买入日）----------
pos_map_fix = {}
for _, prow in pos_df.iterrows():
    c = str(prow.get("代码", "")).strip()
    cost = float(prow.get("成本价")); qty = float(prow.get("数量")); bd = str(prow.get("买入日期", ""))
    if c not in pos_map_fix:
        pos_map_fix[c] = {"name": resolve_name(c).get("name", ""), "cost": cost, "qty": qty, "buy_date": bd, "lots": 1}
    else:
        p = pos_map_fix[c]; nq = p["qty"] + qty
        p["cost"] = (p["cost"] * p["qty"] + cost * qty) / nq
        p["qty"] = nq
        if bd and (not p["buy_date"] or bd < p["buy_date"]):
            p["buy_date"] = bd
        p["lots"] = p.get("lots", 1) + 1
codes_fix = list(dict.fromkeys(pos_df["代码"].tolist()))  # 去重

fix_pos = pos_map_fix["600000"]
fix_pnl, fix_pct = pnl_of(fix_pos, close)
fix_total_qty = sum(pos_map_fix[c]["qty"] for c in codes_fix)

print("=== FIXED（聚合后）===")
print(f"  报告显示 600000: 数量={fix_pos['qty']:.0f} 成本={fix_pos['cost']:.3f} 买入日={fix_pos['buy_date']} (lots={fix_pos['lots']})")
print(f"  单只浮动盈亏 = {fix_pnl:.0f} 元 ({fix_pct:.1f}%)")
print(f"  组合汇总用到的数量 = {fix_total_qty:.0f}  (与真实一致)")
