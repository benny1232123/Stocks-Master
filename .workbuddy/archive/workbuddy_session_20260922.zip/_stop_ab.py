# -*- coding: utf-8 -*-
"""止损口径 A/B：新默认（透传 DAL，boll 口径 clamp(2.5σ,[4%,12%])）
vs 旧口径（clamp(8σ,[6%,15%])）。其余参数完全一致（hold=12、出场全开）。"""
import contextlib
import glob
import io
import os
import shutil
import sys
import traceback
from datetime import datetime
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
os.environ["SECTOR_MAP_ONDEMAND"] = "0"
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUTROOT = ROOT / ".workbuddy" / "stop_ab"
LOG = ROOT / ".workbuddy" / "_stop_ab_out.txt"

ARMS = {"stop_dal": "dal", "stop_legacy": "legacy"}

import importlib  # noqa: E402

kl = importlib.import_module("smcore.data.kline")


def _local_fetch(code, start=None, end=None, *a, **k):
    try:
        d = kl.read_kline_cache(str(code).zfill(6), base_dir=SD / "k_data")
    except Exception:
        d = pd.DataFrame()
    if d is None or d.empty or "date" not in d.columns:
        return pd.DataFrame()
    d = d.copy()
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d.dropna(subset=["date"])
    if start is not None:
        d = d[d["date"] >= pd.Timestamp(start)]
    if end is not None:
        d = d[d["date"] <= pd.Timestamp(end)]
    return d.sort_values("date").reset_index(drop=True)


for mname in ("smcore.data.kline", "smcore.backtest.engine",
              "smcore.strategy.boll_levels", "smcore.strategy.factor_scoring"):
    try:
        m = importlib.import_module(mname)
        if hasattr(m, "fetch_daily_k"):
            m.fetch_daily_k = _local_fetch
    except Exception:
        pass

import scripts.daily_backtest as DB  # noqa: E402

lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


lists = []
for f in sorted(glob.glob(str(SD / "Daily-Action-List-*.csv"))):
    tag = Path(f).name[len("Daily-Action-List-"):-len(".csv")]
    if len(tag) == 8 and tag.isdigit():
        lists.append((Path(f), datetime.strptime(tag, "%Y%m%d").date()))

for arm, src in ARMS.items():
    outdir = OUTROOT / arm
    if outdir.exists():
        shutil.rmtree(outdir, ignore_errors=True)
    outdir.mkdir(parents=True, exist_ok=True)
    os.environ["BACKTEST_STOP_SOURCE"] = src
    ok = err = 0
    stops_seen = []
    for path, sd in lists:
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):
                r = DB._backtest_one(path, sd, 12, out_dir=outdir)
            ok += 1 if r else 0
            for ln in buf.getvalue().splitlines():
                if "止损口径" in ln:
                    stops_seen.append(ln.strip())
        except Exception as exc:
            err += 1
            p(f"  !! {arm} {sd}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    p(f"[{arm:<12}] 源={src} 成功 {ok} 失败 {err}")
    if stops_seen[:2]:
        p("   样例: " + " | ".join(stops_seen[:2]))

# ── 汇总（权益曲线口径）──
p("")
p("=" * 100)
p("止损口径 A/B 结果（hold=12、出场全开，唯一差异 = 止损来源）")
p("=" * 100)
res = {}
for arm in ARMS:
    d = OUTROOT / arm
    per, dd = {}, {}
    for f in sorted(glob.glob(str(d / "Multi-Backtest-*-equity.csv"))):
        tag = Path(f).name[len("Multi-Backtest-"):-len("-equity.csv")]
        try:
            e = pd.read_csv(f)
        except Exception:
            continue
        if e.empty or "total" not in e.columns:
            continue
        e["total"] = pd.to_numeric(e["total"], errors="coerce").dropna()
        if e.empty:
            continue
        per[tag] = float(e["total"].iloc[-1]) / 100000.0 - 1
        if "drawdown" in e.columns:
            dd[tag] = float(pd.to_numeric(e["drawdown"], errors="coerce").min())
    res[arm] = (pd.Series(per) * 100, pd.Series(dd))
    # 出场构成
    tl = []
    for f in sorted(glob.glob(str(d / "Multi-Backtest-*-trades.csv"))):
        try:
            t = pd.read_csv(f, dtype=str)
        except Exception:
            continue
        if not t.empty and "return_pct" in t.columns:
            tl.append(t)
    T = pd.concat(tl, ignore_index=True) if tl else pd.DataFrame()
    stops = {}
    if not T.empty:
        T["return_pct"] = pd.to_numeric(T["return_pct"], errors="coerce")
        for k, g in T.groupby("exit_reason"):
            stops[k] = (len(g), round(g["return_pct"].mean(), 2))
    p(f"[{arm}] 批次 {len(per)}  批均 {res[arm][0].mean():+.3f}%  "
      f"批中位 {res[arm][0].median():+.3f}%  正收益批次 {int((res[arm][0]>0).sum())}/{len(per)}  "
      f"最差 {res[arm][0].min():+.2f}%  平均回撤 {res[arm][1].mean():+.3f}%")
    p(f"   出场构成: " + "  ".join(
        f"{k}={v[0]}笔/{v[1]:+.1f}%" for k, v in sorted(stops.items(), key=lambda x: -x[1][0])))

a, b = res["stop_dal"][0], res["stop_legacy"][0]
j = pd.concat([a.rename("dal"), b.rename("legacy")], axis=1).dropna()
dd = j["dal"] - j["legacy"]
t = dd.mean() / (dd.std() / (len(dd) ** 0.5)) if dd.std() else float("nan")
p("")
p(f"配对检验（新 dal − 旧 legacy，同信号日 n={len(j)}）: Δ={dd.mean():+.3f}pp  t={t:+.2f}  "
  f"胜/负 {int((dd>0).sum())}/{int((dd<0).sum())}")

LOG.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", LOG)
