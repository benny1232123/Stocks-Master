"""每日持仓个股分析推送。

读取当前 FIFO 持仓 → 逐只 build_stock_analysis → 生成报告
→ 落盘 stock_data/holdings_analysis_YYYYMMDD.md（兼容）+ .html（美观版）
→ 多通道推送：SMTP 邮件 / PushPlus 微信（任一配置即推送；都不配仅落盘）。

设计为「可本地手动跑，也可挂 CI 每日自动跑」（同一条命令）。

环境变量：
- TODAY / SIGNAL_DATE : 信号日 YYYYMMDD（默认今天）
- KLINE_BACKEND       : 建议 akshare（CI 海外 Runner 稳定）
- SUPABASE_URL/KEY    : 持仓数据源（auto 模式，与 daily-pick 共用 secrets）
- TRADES_BACKEND      : json | supabase | auto（默认 auto）
- SMTP_HOST/PORT/USER/PASS/TO : 邮件推送（缺任意 → 跳过邮件）

退出码：0 = 正常（含空持仓）；1 = 致命错误（持仓读取失败等）。
"""
from __future__ import annotations

import html as html_escape_mod
import os
import sys
from datetime import date

# 允许从仓库根目录直接运行（python scripts/notify_holdings_analysis.py）
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from smcore.storage.trades_repo import get_trade_repository
from smcore.holdings import compute_fifo_positions, load_trades
from smcore.analysis import build_stock_analysis, recommendation_from_analysis
from smcore.config.defaults import STOCK_DATA_DIR
from smcore.notify.email import send_email
from smcore.stock_names import resolve as _resolve_name
from smcore.data.kline import fetch_daily_k
import pandas as pd

# 本地手动跑时从仓库根 .env 读环境变量（SUPABASE_*/SMTP_* 等）。
# CI 用 GitHub secrets 注入，不依赖此；dotenv 缺失也不影响运行。
try:
    from dotenv import load_dotenv

    load_dotenv()
except Exception:
    pass


def _today_str() -> str:
    for key in ("TODAY", "SIGNAL_DATE"):
        val = (os.getenv(key) or "").strip()
        if val:
            return val
    return date.today().strftime("%Y%m%d")


def fmt_num(v, digits: int = 2, default: str = "—") -> str:
    if v is None:
        return default
    try:
        return f"{float(v):.{digits}f}"
    except (TypeError, ValueError):
        return default


def fmt_money(v, digits: int = 0, default: str = "—") -> str:
    """带千分位的金额（¥）。"""
    if v is None:
        return default
    try:
        return f"¥{float(v):,.{digits}f}"
    except (TypeError, ValueError):
        return default


def _stock_pnl(analysis: dict, pos: dict | None):
    """计算单只票的持仓盈亏。返回 (pnl, pct, today_pnl, has_cost)。

    - pnl / pct：基于成本价（缺失则 None）
    - today_pnl：当日浮动盈亏（基于序列末两根收盘价 × 数量）
    """
    has_cost = False
    pnl = pct = None
    latest = analysis.get("latest", {}) or {}
    close = latest.get("close")
    qty = (pos or {}).get("qty")
    cost = (pos or {}).get("cost")
    if qty is not None and cost not in (None, ""):
        try:
            qty = float(qty)
            cost = float(cost)
            if qty and cost:
                pnl = (close - cost) * qty if close is not None else None
                pct = (close - cost) / cost * 100 if close is not None else None
                has_cost = True
        except (TypeError, ValueError):
            pass

    today_pnl = None
    rows = (analysis.get("series", {}) or {}).get("rows", []) or []
    if qty is not None and len(rows) >= 2:
        try:
            cur = rows[-1].get("close")
            prev = rows[-2].get("close")
            if cur is not None and prev:
                today_pnl = (float(cur) - float(prev)) * float(qty)
        except (TypeError, ValueError):
            today_pnl = None
    return pnl, pct, today_pnl, has_cost


def build_portfolio_summary(stock_list: list[tuple[dict, dict | None]]) -> dict:
    """从 (analysis, pos) 列表聚合组合层盈亏。"""
    total_value = total_cost = today_pnl = 0.0
    have_cost = False
    for analysis, pos in stock_list:
        if analysis.get("error"):
            continue
        latest = analysis.get("latest", {}) or {}
        close = latest.get("close")
        qty = (pos or {}).get("qty")
        if close is None or not qty:
            continue
        try:
            qty = float(qty)
            value = float(close) * qty
        except (TypeError, ValueError):
            continue
        total_value += value
        cost = (pos or {}).get("cost")
        if cost not in (None, ""):
            try:
                cost = float(cost)
                if cost and qty:
                    total_cost += cost * qty
                    have_cost = True
            except (TypeError, ValueError):
                pass
        rows = (analysis.get("series", {}) or {}).get("rows", []) or []
        if len(rows) >= 2:
            cur = rows[-1].get("close")
            prev = rows[-2].get("close")
            if cur is not None and prev:
                try:
                    today_pnl += (float(cur) - float(prev)) * qty
                except (TypeError, ValueError):
                    pass

    out = {"total_value": total_value, "total_cost": total_cost if have_cost else None, "today_pnl": today_pnl}
    if have_cost and total_cost:
        out["total_pnl"] = total_value - total_cost
        out["total_pnl_pct"] = (total_value - total_cost) / total_cost * 100
    else:
        out["total_pnl"] = None
        out["total_pnl_pct"] = None
    prev_total = total_value - today_pnl
    out["today_pnl_pct"] = (today_pnl / prev_total * 100) if prev_total else None
    return out


def _rec_cls(action: str) -> str:
    """持仓建议 → CSS 配色类（A股：红=偏多/加仓，绿=偏空/减仓）。"""
    return {
        "加仓": "bull", "持有偏多": "bull",
        "减仓": "bear", "减仓偏空": "bear",
        "持有观望": "neutral", "未知": "neutral",
    }.get(action, "neutral")


def build_recommendation_history(codes: list[str], pos_map: dict, n_days: int = 5) -> dict | None:
    """回看最近 n_days 个交易日，每只持仓股在各日的持仓建议。

    返回 {dates, matrix, names}，其中
    matrix[date][code] = {action, reason, score, close}。

    口径说明：历史日的「技术面」用本地缓存 K 线按 as_of 截断计算；
    「基本面/资金面」无历史序列，统一取当前缓存值（各日固定）。
    这样各日建议口径一致，对比表反映的是技术面演变，而不是
    "纯技术面 vs 三维度综合"的口径差（后者会让当日建议出现虚假跳变）。
    """
    from datetime import timedelta

    # 取交易日历（任一持仓股的本地缓存 K 线尾部即可，A股交易日一致）
    cal = None
    for code in codes:
        try:
            df = fetch_daily_k(code, date.today() - timedelta(days=400), date.today())
            if not df.empty:
                dts = pd.to_datetime(df["date"], errors="coerce").dropna()
                cal = sorted({d.strftime("%Y-%m-%d") for d in dts})
                if len(cal) >= 2:
                    break
        except Exception:
            continue
    if not cal or len(cal) < 2:
        return None

    window = cal[-n_days:]
    names: dict[str, str] = {}
    matrix: dict[str, dict] = {}
    for d in window:
        y, m, dd = (int(x) for x in d.split("-"))
        as_of = date(y, m, dd)
        row: dict[str, dict] = {}
        for code in codes:
            names[code] = (pos_map.get(code, {}) or {}).get("name", "") or ""
            try:
                # 基本面无历史序列 → 用当前缓存，保证与当日建议口径一致
                a = build_stock_analysis(code, as_of=as_of, with_fundamentals=True)
                rec = recommendation_from_analysis(a)
                close = (a.get("latest", {}) or {}).get("close")
                row[code] = {
                    "action": rec.get("action", "未知"),
                    "reason": rec.get("reason", ""),
                    "score": rec.get("score"),
                    "close": close,
                }
            except Exception as exc:
                row[code] = {"action": "未知", "reason": str(exc)[:40], "score": None, "close": None}
        matrix[d] = row
    return {"dates": window, "matrix": matrix, "names": names}


def render_compare_html(hist: dict) -> str:
    dates = hist["dates"]
    names = hist["names"]
    matrix = hist["matrix"]
    head = "".join(f"<th>{d[5:]}</th>" for d in dates)
    rows = []
    for code, nm in names.items():
        cells = []
        for d in dates:
            c = matrix.get(d, {}).get(code, {})
            cls = _rec_cls(c.get("action", "未知"))
            px = c.get("close")
            px_html = f'<span class="px">{fmt_num(px)}</span>' if px is not None else ""
            cells.append(f'<td><span class="tag {cls}">{c.get("action", "未知")}</span>{px_html}</td>')
        rows.append(f'<tr><td class="name">{code} {nm}</td>{"".join(cells)}</tr>')
    return (
        f'<div class="card"><h3 style="font-size:15px;margin-bottom:6px">'
        f'📅 近 {len(dates)} 天持仓建议对比</h3>'
        f'<table class="cmp"><tr><th>股票</th>{head}</tr>{"".join(rows)}</table>'
        f'<div class="state" style="margin-top:8px">单元格 = 当日三维度综合建议'
        f'（技术面随日变化；基本面/资金面无历史序列，取当前缓存、各日固定）。'
        f'红=偏多/加仓，绿=偏空/减仓，下方数字为当日收盘价。仅供参考，不构成投资建议。</div></div>'
    )


def render_compare_md(hist: dict) -> str:
    dates = hist["dates"]
    names = hist["names"]
    matrix = hist["matrix"]
    head = "| 股票 | " + " | ".join(d[5:] for d in dates) + " |"
    sep = "| --- | " + " | ".join("---" for _ in dates) + " |"
    rows = []
    for code, nm in names.items():
        cells = []
        for d in dates:
            c = matrix.get(d, {}).get(code, {})
            px = c.get("close")
            px_s = f"（{fmt_num(px)}）" if px is not None else ""
            cells.append(f"{c.get('action', '未知')}{px_s}")
        rows.append(f"| {code} {nm} | " + " | ".join(cells) + " |")
    return f"## 📅 近 {len(dates)} 天持仓建议对比\n\n{head}\n{sep}\n" + "\n".join(rows) + "\n"


def render_stock(analysis: dict, pos: dict | None = None) -> str:
    """把单只票的分析字典渲染成 Markdown 段落。

    pos: 来自 FIFO 持仓的 {name, cost, qty, buy_date}（可选）。
    """
    code = analysis.get("code", "")
    if analysis.get("error"):
        return f"### {code}\n\n⚠️ 分析失败：{analysis['error']}\n"

    latest = analysis.get("latest", {}) or {}
    metrics = analysis.get("metrics", {}) or {}
    close = latest.get("close")
    up, lo, mid = latest.get("upper"), latest.get("lower"), latest.get("middle")
    ma5, ma10, ma20, ma60 = (
        latest.get("ma5"),
        latest.get("ma10"),
        latest.get("ma20"),
        latest.get("ma60"),
    )
    rsi = latest.get("rsi")
    dif, dea, hist = latest.get("dif"), latest.get("dea"), latest.get("macd_hist")
    k, d, j = latest.get("k_val"), latest.get("d_val"), latest.get("j_val")
    sig = metrics.get("signal_text") or latest.get("signal_text") or "—"

    # 持仓信息
    name = (pos or {}).get("name", "") if pos else ""
    pnl, pct, today_pnl, has_cost = _stock_pnl(analysis, pos)

    # 趋势
    trend = "—"
    if close is not None and ma20 is not None and ma60 is not None:
        if close > ma20 > ma60:
            trend = "多头（价>MA20>MA60）"
        elif close < ma20 < ma60:
            trend = "空头（价<MA20<MA60）"
        else:
            trend = "震荡"

    # 布林带位置
    band_pos = "—"
    if close is not None and up is not None and lo is not None and up > lo:
        bpos = (close - lo) / (up - lo) * 100
        band_pos = f"{bpos:.1f}%（上轨{fmt_num(up)} / 下轨{fmt_num(lo)} / 中轨{fmt_num(mid)}）"

    # MACD 状态
    macd_state = "—"
    if dif is not None and dea is not None and hist is not None:
        if dif > 0 and hist > 0:
            macd_state = "金叉区·多头动能"
        elif dif < 0 and hist < 0:
            macd_state = "死叉区·空头动能"
        elif hist > 0:
            macd_state = "红柱·转强"
        else:
            macd_state = "绿柱·偏弱"

    # KDJ 状态
    kdj_state = "—"
    if k is not None and d is not None and j is not None:
        if j > 100:
            kdj_state = f"超买(J>100) K={k:.0f} D={d:.0f} J={j:.0f}"
        elif j < 0:
            kdj_state = f"超卖(J<0) K={k:.0f} D={d:.0f} J={j:.0f}"
        else:
            kdj_state = f"K={k:.0f} D={d:.0f} J={j:.0f}"

    title = f"### {code} {name}" if name else f"### {code}"
    rec = recommendation_from_analysis(analysis)
    _faces_md = rec.get("faces") or {}
    _face_parts = []
    for _lbl, _key in (("技术", "technical"), ("基本面", "fundamental"), ("资金", "capital")):
        _v = _faces_md.get(_key)
        _face_parts.append(f"{_lbl} {_v:+.2f}" if _v is not None else f"{_lbl} —")
    _faces_line = " ｜ ".join(_face_parts)
    lines = [
        title,
        "",
        f"- **Boll 信号**：{sig}",
        f"- **现价**：{fmt_num(close)} ｜ **趋势**：{trend}",
        f"- **持仓建议**：{rec.get('action')}（{rec.get('reason')}）",
        f"- **三维打分**：{_faces_line}（各面 [-1,+1]，正=偏多，负=偏空）",
    ]
    if pos:
        cost = (pos or {}).get("cost")
        qty = (pos or {}).get("qty")
        cost_str = fmt_num(cost) if cost not in (None, "") else "—"
        qty_str = fmt_num(qty, 0) if qty not in (None, "") else "—"
        pos_line = f"- **持仓**：成本 {cost_str} ｜ 数量 {qty_str}"
        if has_cost and pnl is not None:
            sign = "+" if pnl >= 0 else ""
            pct_sign = "+" if pct >= 0 else ""
            pos_line += f" ｜ **盈亏** {sign}{fmt_money(pnl)}（{pct_sign}{pct:.2f}%）"
        if today_pnl is not None:
            tsign = "+" if today_pnl >= 0 else ""
            pos_line += f" ｜ 当日 {tsign}{fmt_money(today_pnl)}"
        lines.append(pos_line)
    lines += [
        f"- **均线**：MA5={fmt_num(ma5)} MA10={fmt_num(ma10)} MA20={fmt_num(ma20)} MA60={fmt_num(ma60)}",
        f"- **布林带位置**：{band_pos}",
        f"- **RSI(14)**：{fmt_num(rsi, 1)}",
        f"- **MACD**：DIF={fmt_num(dif)} DEA={fmt_num(dea)} 柱={fmt_num(hist)} → {macd_state}",
        f"- **KDJ**：{kdj_state}",
    ]

    # 基本面 / 资金面
    fund = analysis.get("fundamentals")
    lines += _fund_panel_md(fund)

    lines.append("")
    return "\n".join(lines)


# ───────────────────────── HTML 美观报告（PushPlus / 本地预览）─────────────────────────
# 内联 CSS，无外部依赖；涨=红、跌=绿（A股习惯）。PushPlus template=html 会在微信里渲染成文章。
_HTML_STYLE = """
*{box-sizing:border-box;margin:0;padding:0}
body{background:#eef0f3;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;color:#1f2329;padding:16px}
.wrap{max-width:680px;margin:0 auto}
.top{background:linear-gradient(135deg,#2b5876,#4e4376);color:#fff;border-radius:16px;padding:18px 20px;margin-bottom:14px;box-shadow:0 4px 14px rgba(43,88,118,.25)}
.top h1{font-size:20px;font-weight:700;letter-spacing:.5px}
.meta{font-size:13px;opacity:.9;margin-top:6px}
.card{background:#fff;border-radius:14px;padding:14px 16px;margin-bottom:12px;box-shadow:0 1px 4px rgba(0,0,0,.06)}
.card-head{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.title{display:flex;flex-direction:column;line-height:1.15}
.code{font-size:19px;font-weight:700;letter-spacing:.5px}
.name{font-size:12px;color:#8a9099;font-weight:500;margin-top:1px}
.badge{font-size:12px;padding:3px 11px;border-radius:20px;font-weight:600}
.badge.bull{background:#fff1f0;color:#d4380d}
.badge.bear{background:#f6ffed;color:#389e0d}
.badge.neutral{background:#f0f1f3;color:#5a6068}
.price{font-size:19px;font-weight:700;margin-left:auto}
.chg{font-size:13px;font-weight:600;padding:3px 9px;border-radius:8px}
.chg.bull{background:#fff1f0;color:#d4380d}
.chg.bear{background:#f6ffed;color:#389e0d}
.chg.neutral{color:#5a6068}
.sig{font-size:13px;color:#5a6068;margin:8px 0 4px}
.boll{margin:8px 0 4px}
.boll-track{height:9px;background:linear-gradient(90deg,#389e0d,#fadb14,#d4380d);border-radius:6px;position:relative}
.boll-mark{position:absolute;top:50%;width:15px;height:15px;background:#fff;border:3px solid #2b5876;border-radius:50%;transform:translate(-50%,-50%)}
.boll-lab{font-size:11px;color:#8a9099;margin-top:5px}
.metrics{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0 4px}
.m{background:#f7f8fa;border-radius:9px;padding:6px 10px;min-width:62px}
.ml{display:block;font-size:11px;color:#8a9099}
.mv{display:block;font-size:15px;font-weight:600;margin-top:2px}
.mv.warn{color:#d4380d}
.mv.cool{color:#389e0d}
.state{font-size:12px;color:#5a6068;margin:4px 0 8px}
.chips{display:flex;flex-wrap:wrap;gap:6px}
.chip{font-size:11px;background:#eef2ff;color:#3b5bdb;padding:3px 9px;border-radius:20px}
.chip.dim{background:#f0f1f3;color:#a0a6ad}
.fund{margin:10px 0 2px;padding:11px 13px;background:#fafcff;border:1px solid #eef3fb;border-radius:11px}
.fund-grid{display:flex;flex-wrap:wrap;gap:14px}
.fg{flex:1;min-width:120px}
.fgh{font-size:11px;color:#3b5bdb;font-weight:700;letter-spacing:.5px;margin-bottom:5px}
.fg-row{display:flex;justify-content:space-between;font-size:13px;padding:2px 0;border-bottom:1px dashed #f0f1f3}
.fg-row span{color:#8a9099}
.fg-row b{font-weight:600}
.fund-note{font-size:12px;color:#5a6068;margin-top:9px;line-height:1.6}
.fund-note b{color:#2b5876}
.flag{display:inline-block;font-size:11px;font-weight:600;padding:1px 7px;border-radius:6px;margin:2px 4px 2px 0}
.flag.good{background:#f6ffed;color:#389e0d}
.flag.bad{background:#fff1f0;color:#d4380d}
.flag.mid{background:#f0f1f3;color:#5a6068}
.pos{display:flex;flex-wrap:wrap;gap:14px;margin:10px 0 2px;padding:9px 12px;background:#fafbfc;border-radius:10px}
.pos-item{display:flex;align-items:baseline;gap:5px}
.pos-item .pl{font-size:11px;color:#8a9099}
.pos-item b{font-size:14px;font-weight:700}
.pnl.bull{color:#d4380d}
.pnl.bear{color:#389e0d}
.err{color:#d4380d;font-size:13px;margin-top:6px}
.rec{font-size:13px;font-weight:600;margin:8px 0 4px;padding:7px 11px;border-radius:9px}
.rec.bull{background:#fff1f0;color:#d4380d}
.rec.bear{background:#f6ffed;color:#389e0d}
.rec.neutral{background:#f0f1f3;color:#5a6068}
.faces{display:flex;flex-wrap:wrap;gap:8px;margin-top:6px;font-weight:400;font-size:12px}
.face{padding:2px 8px;border-radius:20px;background:#fff;opacity:.95}
.face.up{background:#ffece8;color:#d4380d}
.face.down{background:#eafbe6;color:#389e0d}
.face.flat{background:#f0f1f3;color:#5a6068}
.face.dim{background:#f7f8f9;color:#a0a6ad}
.cmp{width:100%;border-collapse:collapse;margin-top:6px;font-size:13px;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.06)}
.cmp th,.cmp td{padding:9px 8px;text-align:center;border-bottom:1px solid #f0f1f3}
.cmp th{background:#f7f8fa;color:#5a6068;font-weight:600}
.cmp td.name{text-align:left;font-weight:600}
.cmp .tag{display:inline-block;font-size:12px;font-weight:700;padding:2px 8px;border-radius:7px}
.cmp .tag.bull{background:#fff1f0;color:#d4380d}
.cmp .tag.bear{background:#f6ffed;color:#389e0d}
.cmp .tag.neutral{background:#f0f1f3;color:#5a6068}
.cmp .tag.unknown{background:#f0f1f3;color:#a0a6ad}
.cmp .px{display:block;font-size:11px;color:#8a9099;margin-top:2px}
.sum{background:linear-gradient(135deg,#1f3b57,#3a5a7a);color:#fff;border-radius:16px;padding:16px 20px;margin-bottom:14px;box-shadow:0 4px 14px rgba(31,59,87,.28)}
.sum h2{font-size:16px;font-weight:700;margin-bottom:10px}
.sum-grid{display:flex;flex-wrap:wrap;gap:10px 26px}
.sum-cell{display:flex;flex-direction:column}
.sum-cell .sl{font-size:11px;opacity:.8}
.sum-cell .sv{font-size:19px;font-weight:700;margin-top:2px}
.sum-cell .sv.bull{color:#ff9c8a}
.sum-cell .sv.bear{color:#9be7a8}
.foot{font-size:11px;color:#a0a6ad;text-align:center;margin-top:12px;line-height:1.7}
"""


# ───────────────────────── 基本面 / 资金面面板 ─────────────────────────
def _fund_flags(fund: dict) -> list[tuple[str, str]]:
    """根据基本面数据生成 (文本, 等级) 标签列表，等级 good/bad/mid。"""
    flags: list[tuple[str, str]] = []
    pb = fund.get("pb")
    if pb is not None:
        if pb < 1:
            flags.append((f"破净 PB {pb:.2f}", "bad" if pb < 0.7 else "mid"))
        elif pb > 5:
            flags.append((f"高 PB {pb:.2f}", "bad"))
    pe = fund.get("pe")
    if pe is not None:
        if pe < 0:
            flags.append(("亏损 负PE", "bad"))
        elif pe > 50:
            flags.append((f"高估值 PE {pe:.1f}", "bad"))
        elif pe < 15:
            flags.append((f"低估值 PE {pe:.1f}", "good"))
    roe = fund.get("roe")
    if roe is not None:
        if roe >= 0.12:
            flags.append((f"盈利优 ROE {roe*100:.1f}%", "good"))
        elif roe >= 0.08:
            flags.append((f"盈利中 ROE {roe*100:.1f}%", "mid"))
        else:
            flags.append((f"盈利弱 ROE {roe*100:.1f}%", "bad"))
    gm = fund.get("gross_margin")
    if gm is not None:
        if gm >= 0.40:
            flags.append((f"高毛利 {gm*100:.0f}%", "good"))
        elif gm >= 0.20:
            flags.append((f"毛利中 {gm*100:.0f}%", "mid"))
        else:
            flags.append((f"低毛利 {gm*100:.0f}%", "bad"))
    to = fund.get("turnover")
    if to is not None:
        if to >= 3:
            flags.append((f"交投活跃 换手 {to:.1f}%", "mid"))
        elif to < 1.5:
            flags.append((f"交投清淡 换手 {to:.1f}%", "mid"))
    return flags


def _fund_panel_html(fund: dict) -> str:
    """生成基本面/资金面 HTML 子面板；无数据时返回占位提示。"""
    if not isinstance(fund, dict) or fund.get("error") or not any(
        fund.get(k) is not None for k in ("pe", "pb", "roe", "mkt_cap", "turnover")
    ):
        return '<div class="fund"><div class="fund-note">暂无基本面数据（缓存未命中或联网失败）。</div></div>'

    def row(label: str, val: str) -> str:
        return f'<div class="fg-row"><span>{label}</span><b>{val}</b></div>'

    pe = fund.get("pe")
    pb = fund.get("pb")
    ps = fund.get("ps")
    pcf = fund.get("pcf")
    mc = fund.get("mkt_cap")
    roe = fund.get("roe")
    gm = fund.get("gross_margin")
    to = fund.get("turnover")
    amt = fund.get("amount_20")
    amt_yi = (amt / 1e8) if amt is not None else None

    val_block = (
        (row("PE", fmt_num(pe)) if pe is not None else "")
        + (row("PB", fmt_num(pb)) if pb is not None else "")
        + (row("PS", fmt_num(ps)) if ps is not None else "")
        + (row("PCF", fmt_num(pcf)) if pcf is not None else "")
        + (row("总市值", f"{fmt_num(mc)}亿") if mc is not None else "")
    )
    qual_block = (
        (row("ROE", f"{fmt_num(roe*100,1)}%") if roe is not None else "")
        + (row("毛利率", f"{fmt_num(gm*100,1)}%") if gm is not None else "")
    )
    flow_block = (
        (row("换手率", f"{fmt_num(to,2)}%") if to is not None else "")
        + (row("20日成交额", f"{fmt_num(amt_yi,2)}亿") if amt_yi is not None else "")
    )
    flags = _fund_flags(fund)
    note = (
        "估值点评："
        + "".join(f'<span class="flag {lv}">{txt}</span>' for txt, lv in flags)
        if flags
        else "估值点评：数据不足"
    )
    return f"""
    <div class="fund">
      <div class="fund-grid">
        <div class="fg"><div class="fgh">估值</div>{val_block}</div>
        <div class="fg"><div class="fgh">质量</div>{qual_block}</div>
        <div class="fg"><div class="fgh">资金面</div>{flow_block}</div>
      </div>
      <div class="fund-note">{note}</div>
    </div>"""


def _fund_panel_md(fund: dict) -> list[str]:
    """生成基本面 Markdown 行（含估值点评）。"""
    if not isinstance(fund, dict) or fund.get("error"):
        return ["- **基本面/资金面**：暂无数据"]
    specs = [
        ("PE", "pe", lambda v: fmt_num(v)),
        ("PB", "pb", lambda v: fmt_num(v)),
        ("PS", "ps", lambda v: fmt_num(v)),
        ("PCF", "pcf", lambda v: fmt_num(v)),
        ("总市值", "mkt_cap", lambda v: f"{fmt_num(v)}亿"),
        ("ROE", "roe", lambda v: f"{fmt_num(v*100,1)}%"),
        ("毛利率", "gross_margin", lambda v: f"{fmt_num(v*100,1)}%"),
        ("换手率", "turnover", lambda v: f"{fmt_num(v,2)}%"),
    ]
    parts = [f"{label}={fmt(fund[key])}" for label, key, fmt in specs if fund.get(key) is not None]
    if not parts:
        return ["- **基本面/资金面**：暂无数据"]
    lines = ["- **基本面/资金面**：" + " ／ ".join(parts)]
    flags = _fund_flags(fund)
    if flags:
        lines.append("  - 估值点评：" + "、".join(txt for txt, _ in flags))
    return lines


def build_fundamentals_compare(today: str, holdings: list[dict]) -> tuple[str, str]:
    """跨持仓基本面对比表。holdings: [{code, name, analysis}]。返回 (html, md)。"""
    rows_html: list[str] = []
    rows_md: list[str] = []
    for h in holdings:
        code = h.get("code", "")
        name = h.get("name", "")
        fund = (h.get("analysis") or {}).get("fundamentals")
        if not isinstance(fund, dict) or fund.get("error"):
            rows_html.append(
                f'<tr><td class="name">{code} {name}</td>'
                f'<td colspan="6" style="color:#a0a6ad">暂无基本面数据</td></tr>'
            )
            rows_md.append(f"| {code} {name} | - | - | - | - | - | - | 暂无 |")
            continue
        flags = _fund_flags(fund)
        note = "、".join(t for t, _ in flags) if flags else "—"
        pe = fmt_num(fund.get("pe"))
        pb = fmt_num(fund.get("pb"))
        roe = f"{fmt_num(fund['roe']*100,1)}%" if fund.get("roe") is not None else "—"
        gm = f"{fmt_num(fund['gross_margin']*100,1)}%" if fund.get("gross_margin") is not None else "—"
        mc = fmt_num(fund.get("mkt_cap")) if fund.get("mkt_cap") is not None else "—"
        to = f"{fmt_num(fund['turnover'],2)}%" if fund.get("turnover") is not None else "—"
        rows_html.append(
            f'<tr><td class="name">{code} {name}</td>'
            f"<td>{pe}</td><td>{pb}</td><td>{roe}</td><td>{gm}</td>"
            f'<td>{mc}</td><td>{to}</td>'
            f'<td style="text-align:left;font-size:12px;color:#5a6068">{note}</td></tr>'
        )
        rows_md.append(f"| {code} {name} | {pe} | {pb} | {roe} | {gm} | {mc} | {to} | {note} |")
    html = f"""
    <div class="card">
      <div class="card-head"><span class="code">📊 跨持仓基本面对比</span></div>
      <table class="cmp">
        <tr><th>股票</th><th>PE</th><th>PB</th><th>ROE</th><th>毛利率</th><th>市值(亿)</th><th>换手</th><th>点评</th></tr>
        {''.join(rows_html)}
      </table>
    </div>"""
    md = (
        f"## 跨持仓基本面对比（{today}）\n\n"
        f"| 股票 | PE | PB | ROE | 毛利率 | 市值(亿) | 换手 | 点评 |\n"
        f"|---|---|---|---|---|---|---|---|\n"
        + "\n".join(rows_md)
        + "\n"
    )
    return html, md


def render_stock_html(analysis: dict, pos: dict | None = None) -> str:
    """把单只票的分析字典渲染成好看的 HTML 卡片。

    pos: 来自 FIFO 持仓的 {name, cost, qty, buy_date}（可选）。
    """
    code = analysis.get("code", "")
    if analysis.get("error"):
        return (
            f'<div class="card"><div class="card-head"><span class="code">{code}</span></div>'
            f'<div class="err">⚠️ 分析失败：{analysis["error"]}</div></div>'
        )

    latest = analysis.get("latest", {}) or {}
    metrics = analysis.get("metrics", {}) or {}
    close = latest.get("close")
    up, lo = latest.get("upper"), latest.get("lower")
    ma5, ma10, ma20, ma60 = (
        latest.get("ma5"), latest.get("ma10"), latest.get("ma20"), latest.get("ma60")
    )
    rsi = latest.get("rsi")
    dif, dea, hist = latest.get("dif"), latest.get("dea"), latest.get("macd_hist")
    k, d, j = latest.get("k_val"), latest.get("d_val"), latest.get("j_val")
    sig = metrics.get("signal_text") or latest.get("signal_text") or "—"

    # 趋势 + 颜色
    trend, trend_cls = "震荡", "neutral"
    if close is not None and ma20 is not None and ma60 is not None:
        if close > ma20 > ma60:
            trend, trend_cls = "多头", "bull"
        elif close < ma20 < ma60:
            trend, trend_cls = "空头", "bear"

    # 当日涨跌幅（取序列末两根收盘价）
    chg_pct, chg_cls = None, "neutral"
    rows = (analysis.get("series", {}) or {}).get("rows", []) or []
    if len(rows) >= 2 and rows[-1].get("close") is not None and rows[-2].get("close"):
        try:
            cur = float(rows[-1]["close"])
            prev = float(rows[-2]["close"])
            if prev:
                chg_pct = (cur - prev) / prev * 100
                chg_cls = "bull" if chg_pct >= 0 else "bear"
        except (TypeError, ValueError):
            pass

    # 持仓信息（名称 / 成本价 / 数量 / 盈亏）
    name = (pos or {}).get("name", "") if pos else ""
    pnl, pct, today_pnl, has_cost = _stock_pnl(analysis, pos)

    # 布林带位置
    band_pos = None
    if close is not None and up is not None and lo is not None and up > lo:
        band_pos = max(0.0, min(100.0, (close - lo) / (up - lo) * 100))

    macd_state = "—"
    if dif is not None and dea is not None and hist is not None:
        if dif > 0 and hist > 0:
            macd_state = "金叉·多头动能"
        elif dif < 0 and hist < 0:
            macd_state = "死叉·空头动能"
        elif hist > 0:
            macd_state = "红柱转强"
        else:
            macd_state = "绿柱偏弱"
    kdj_state = "—"
    if k is not None and d is not None and j is not None:
        if j > 100:
            kdj_state = f"超买 J={j:.0f}"
        elif j < 0:
            kdj_state = f"超卖 J={j:.0f}"
        else:
            kdj_state = f"K={k:.0f} D={d:.0f} J={j:.0f}"

    def _m(label: str, val, cls: str = "") -> str:
        return (
            f'<div class="m"><span class="ml">{label}</span>'
            f'<span class="mv {cls}">{fmt_num(val)}</span></div>'
        )

    rsi_cls = ""
    if rsi is not None:
        rsi_cls = "warn" if rsi > 70 else ("cool" if rsi < 30 else "")

    # 基本面标签
    fund = analysis.get("fundamentals")
    chips: list[str] = []
    if isinstance(fund, dict) and not fund.get("error"):
        if fund.get("pe") is not None:
            chips.append(("PE", fmt_num(fund["pe"])))
        if fund.get("pb") is not None:
            chips.append(("PB", fmt_num(fund["pb"])))
        if fund.get("mkt_cap") is not None:
            chips.append(("市值", f'{fmt_num(fund["mkt_cap"])}亿'))
        if fund.get("roe") is not None:
            chips.append(("ROE", f'{fmt_num(fund["roe"], 1)}%'))
        if fund.get("gross_margin") is not None:
            chips.append(("毛利", f'{fmt_num(fund["gross_margin"], 1)}%'))
        if fund.get("revenue_growth") is not None:
            chips.append(("营收增速", f'{fmt_num(fund["revenue_growth"], 1)}%'))
        if fund.get("turnover") is not None:
            chips.append(("换手", f'{fmt_num(fund["turnover"], 2)}%'))
    chip_html = (
        "".join(f'<span class="chip">{l} {v}</span>' for l, v in chips)
        if chips
        else '<span class="chip dim">暂无基本面数据</span>'
    )
    fund_html = _fund_panel_html(fund)

    bar_html = ""
    if band_pos is not None:
        bar_html = (
            f'<div class="boll"><div class="boll-track">'
            f'<div class="boll-mark" style="left:{band_pos:.1f}%"></div></div>'
            f'<div class="boll-lab">布林带位置 {band_pos:.0f}%（下轨 {fmt_num(lo)} → 上轨 {fmt_num(up)}）</div></div>'
        )

    chg_html = (
        f'<span class="chg {chg_cls}">{"+" if chg_pct >= 0 else ""}{chg_pct:.2f}%</span>'
        if chg_pct is not None
        else ""
    )

    # 持仓行（成本 / 数量 / 持仓盈亏 / 当日浮动盈亏）
    pos_html = ""
    if pos:
        cost = pos.get("cost")
        qty = pos.get("qty")
        cost_str = fmt_num(cost) if cost not in (None, "") else "—"
        qty_str = fmt_num(qty, 0) if qty not in (None, "") else "—"
        items = [
            f'<span class="pos-item"><span class="pl">成本</span><b>{cost_str}</b></span>',
            f'<span class="pos-item"><span class="pl">数量</span><b>{qty_str}</b></span>',
        ]
        if has_cost and pnl is not None:
            pnl_cls = "bull" if pnl >= 0 else "bear"
            items.append(
                f'<span class="pos-item"><span class="pl">持仓盈亏</span>'
                f'<b class="pnl {pnl_cls}">{"+" if pnl >= 0 else ""}{fmt_money(pnl)}'
                f'（{"+" if pct >= 0 else ""}{pct:.2f}%）</b></span>'
            )
        if today_pnl is not None:
            tcls = "bull" if today_pnl >= 0 else "bear"
            items.append(
                f'<span class="pos-item"><span class="pl">当日</span>'
                f'<b class="pnl {tcls}">{"+" if today_pnl >= 0 else ""}{fmt_money(today_pnl)}</b></span>'
            )
        pos_html = f'<div class="pos">{"".join(items)}</div>'

    # 持仓建议（技术面 + 基本面 + 资金面 三维度综合）
    rec = recommendation_from_analysis(analysis)
    _rec_cls = {
        "加仓": "bull", "持有偏多": "bull",
        "减仓": "bear", "减仓偏空": "bear",
        "持有观望": "neutral", "未知": "neutral",
    }.get(rec.get("action"), "neutral")
    _faces = rec.get("faces") or {}

    def _face_html(label: str, key: str) -> str:
        v = _faces.get(key)
        if v is None:
            return f'<span class="face dim">{label} 无数据</span>'
        cls = "up" if v > 0.02 else ("down" if v < -0.02 else "flat")
        return f'<span class="face {cls}">{label} {v:+.2f}</span>'

    faces_html = (
        '<div class="faces">'
        + _face_html("技术面", "technical")
        + _face_html("基本面", "fundamental")
        + _face_html("资金面", "capital")
        + "</div>"
    )
    # 理由可能含 '<'（如"空头排列(价<MA20<MA60)"），必须 HTML 转义，否则被浏览器当标签吞掉后半段
    _rec_action = html_escape_mod.escape(str(rec.get("action") or ""))
    _rec_reason = html_escape_mod.escape(str(rec.get("reason") or ""))
    rec_html = (
        f'<div class="rec {_rec_cls}">📌 持仓建议：{_rec_action}'
        f'　｜　{_rec_reason}{faces_html}</div>'
    )

    return f"""
    <div class="card">
      <div class="card-head">
        <div class="title"><span class="code">{code}</span><span class="name">{name}</span></div>
        <span class="badge {trend_cls}">{trend}</span>
        <span class="price">{fmt_num(close)}</span>
        {chg_html}
      </div>
      <div class="sig">Boll 信号：{sig}</div>
      {pos_html}
      {rec_html}
      {bar_html}
      <div class="metrics">
        {_m("MA5", ma5)} {_m("MA10", ma10)} {_m("MA20", ma20)} {_m("MA60", ma60)}
        {_m("RSI", rsi, rsi_cls)} {_m("DIF", dif)} {_m("DEA", dea)} {_m("MACD柱", hist)}
        {_m("K", k)} {_m("D", d)} {_m("J", j)}
      </div>
      <div class="state">MACD：{macd_state} ｜ KDJ：{kdj_state}</div>
      {fund_html}
    </div>"""


def build_html_report(today: str, backend: str, summary_line: str, sections_html: str, summary_card: str = "") -> str:
    return f"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>持仓个股分析 {today}</title><style>{_HTML_STYLE}</style></head>
<body><div class="wrap">
  <div class="top"><h1>📊 持仓个股分析日报</h1>
    <div class="meta">📅 {today} ｜ 数据源 {backend} ｜ {summary_line}</div></div>
  {summary_card}
  {sections_html}
  <div class="foot">Stocks-Master 自动生成 · 技术面 Boll/MACD/RSI/KDJ/MA + 基本面/资金面<br>
  仅供研究参考，不构成投资建议</div>
</div></body></html>"""


def render_summary_html(summary: dict, count: int) -> str:
    """顶部组合汇总卡片。"""
    if not summary:
        return ""
    tv = summary.get("total_value") or 0.0
    tc = summary.get("total_cost")
    pnl = summary.get("total_pnl")
    pnl_pct = summary.get("total_pnl_pct")
    today_pnl = summary.get("today_pnl")
    today_pct = summary.get("today_pnl_pct")

    def _cell(label, value, cls=""):
        return (
            f'<div class="sum-cell"><span class="sl">{label}</span>'
            f'<span class="sv {cls}">{value}</span></div>'
        )

    cells = [_cell("持仓市值", fmt_money(tv))]
    if tc is not None:
        cells.append(_cell("持仓成本", fmt_money(tc)))
    if pnl is not None:
        pcls = "bull" if pnl >= 0 else "bear"
        pval = f"{'+' if pnl >= 0 else ''}{fmt_money(pnl)}"
        if pnl_pct is not None:
            pval += f" ({'+' if pnl_pct >= 0 else ''}{pnl_pct:.2f}%)"
        cells.append(_cell("累计盈亏", pval, pcls))
    tcls = "bull" if today_pnl >= 0 else "bear"
    tval = f"{'+' if today_pnl >= 0 else ''}{fmt_money(today_pnl)}"
    if today_pct is not None:
        tval += f" ({'+' if today_pct >= 0 else ''}{today_pct:.2f}%)"
    cells.append(_cell("当日浮动", tval, tcls))

    return (
        f'<div class="sum"><h2>💼 组合概览 ｜ {count} 只持仓</h2>'
        f'<div class="sum-grid">{"".join(cells)}</div></div>'
    )


def render_summary_md(summary: dict, count: int) -> str:
    if not summary:
        return ""
    tv = summary.get("total_value") or 0.0
    tc = summary.get("total_cost")
    pnl = summary.get("total_pnl")
    pnl_pct = summary.get("total_pnl_pct")
    today_pnl = summary.get("today_pnl")
    today_pct = summary.get("today_pnl_pct")
    lines = [f"## 💼 组合概览（{count} 只持仓）", f"- **持仓市值**：{fmt_money(tv)}"]
    if tc is not None:
        lines.append(f"- **持仓成本**：{fmt_money(tc)}")
    if pnl is not None:
        s = "+" if pnl >= 0 else ""
        p = f"{s}{pnl_pct:.2f}%" if pnl_pct is not None else ""
        lines.append(f"- **累计盈亏**：{s}{fmt_money(pnl)}（{p}）")
    ts = "+" if today_pnl >= 0 else ""
    tp = f"{ts}{today_pct:.2f}%" if today_pct is not None else ""
    lines.append(f"- **当日浮动**：{ts}{fmt_money(today_pnl)}（{tp}）")
    return "\n".join(lines) + "\n"


def main() -> int:
    today = _today_str()
    log_lines: list[str] = []
    fund_cmp_html = fund_cmp_md = ""

    # 1) 读取持仓
    try:
        repo = get_trade_repository()
        trades = load_trades()
        pos_df, _closed = compute_fifo_positions(trades)
    except Exception as exc:  # 持仓读取失败属致命
        print(f"[FATAL] 读取持仓失败: {exc}")
        return 1

    backend = repo.backend_name
    log_lines.append(f"持仓数据源: {backend} | 交易记录: {len(trades)} 条")

    if pos_df.empty:
        log_lines.append("当前无持仓，跳过个股分析")
        md = (
            f"# 持仓个股分析日报占位\n\n> 数据源：{backend}\n\n"
            f"**当前无持仓**（FIFO 计算结果为空），无需推送个股分析。\n"
        )
        html = build_html_report(
            today, backend, "无持仓",
            '<div class="card"><div class="sig">当前无持仓，无需推送个股分析。</div></div>',
        )
    else:
        # 构建持仓基础信息（代码 -> 名称/成本价/数量/买入日期）
        pos_map: dict[str, dict] = {}
        for _, prow in pos_df.iterrows():
            c = str(prow.get("代码", "")).strip()
            if not c:
                continue
            cost = prow.get("成本价")
            qty = prow.get("数量")
            buy_date = prow.get("买入日期", "")
            nm = ""
            try:
                nm = _resolve_name(c).get("name", "") or ""
            except Exception:
                nm = ""
            pos_map[c] = {
                "name": nm,
                "cost": float(cost) if cost not in (None, "") else None,
                "qty": float(qty) if qty not in (None, "") else None,
                "buy_date": str(buy_date) if buy_date else "",
            }

        codes = [str(c) for c in pos_df["代码"].tolist()]
        log_lines.append(f"当前持仓 {len(codes)} 只: {', '.join(codes)}")

        sections: list[str] = []
        sections_html: list[str] = []
        stock_list: list[tuple] = []
        holdings_meta: list[dict] = []
        ok, failed = 0, 0
        for code in codes:
            pos = pos_map.get(code)
            try:
                analysis = build_stock_analysis(code)
            except Exception as exc:
                failed += 1
                log_lines.append(f"分析 {code} 异常: {exc}")
                sections.append(f"### {code} {(pos or {}).get('name', '')}\n\n⚠️ 分析异常：{exc}\n")
                sections_html.append(
                    f'<div class="card"><div class="card-head"><span class="code">{code}</span>'
                    f'</div><div class="err">⚠️ 分析异常：{exc}</div></div>'
                )
                continue
            if analysis.get("error"):
                failed += 1
            else:
                ok += 1
            stock_list.append((analysis, pos))
            holdings_meta.append({"code": code, "name": (pos or {}).get("name", ""), "analysis": analysis})
            sections.append(render_stock(analysis, pos))
            sections_html.append(render_stock_html(analysis, pos))

        summary = build_portfolio_summary(stock_list)
        summary_line = f"成功 {ok} 只 / 失败 {failed} 只 / 共 {len(codes)} 只"
        summary_md = render_summary_md(summary, len(codes))
        summary_html = render_summary_html(summary, len(codes))
        md = (
            f"# 持仓个股分析日报 · {today}\n\n"
            f"> 数据源：{backend} ｜ {summary_line}\n\n"
            + (summary_md + "\n" if summary_md else "")
            + "\n".join(sections)
            + f"\n---\n\n_本报告由 Stocks-Master 自动生成（技术面 Boll/MACD/RSI/KDJ/MA + 基本面/资金面）。\n"
            f"仅供研究参考，不构成投资建议。生成时间 {today}。_\n"
        )
        html = build_html_report(today, backend, summary_line, "\n".join(sections_html), summary_html)

        # 近几天持仓建议对比（嵌入报告 + 单独落盘便于邮件附件）
        compare_html = compare_md = ""
        n_recent = int((os.getenv("RECENT_DAYS") or "5").strip() or 5)
        try:
            hist = build_recommendation_history(codes, pos_map, n_days=n_recent)
            if hist:
                compare_html = render_compare_html(hist)
                compare_md = render_compare_md(hist)
                sections_html.append(compare_html)
                md = md.rstrip() + "\n\n" + compare_md
                html = build_html_report(today, backend, summary_line, "\n".join(sections_html), summary_html)
        except Exception as exc:
            log_lines.append(f"近几天建议对比生成失败: {exc}")

        # 跨持仓基本面对比（嵌入报告 + 单独落盘便于邮件附件）
        try:
            fund_cmp_html, fund_cmp_md = build_fundamentals_compare(today, holdings_meta)
            if fund_cmp_html:
                sections_html.append(fund_cmp_html)
                md = md.rstrip() + "\n\n" + fund_cmp_md
                html = build_html_report(today, backend, summary_line, "\n".join(sections_html), summary_html)
        except Exception as exc:
            log_lines.append(f"跨持仓基本面对比生成失败: {exc}")

    # 2) 落盘（Markdown 兼容 + HTML 美观版）
    md_path = STOCK_DATA_DIR / f"holdings_analysis_{today}.md"
    html_path = STOCK_DATA_DIR / f"holdings_analysis_{today}.html"
    md_path.parent.mkdir(parents=True, exist_ok=True)
    md_path.write_text(md, encoding="utf-8")
    html_path.write_text(html, encoding="utf-8")

    # 对比报告单独落盘（供邮件附件 / 单独查看）
    compare_html_path = STOCK_DATA_DIR / f"holdings_rec_compare_{today}.html"
    compare_md_path = STOCK_DATA_DIR / f"holdings_rec_compare_{today}.md"
    if compare_html:
        compare_html_doc = (
            f"<!doctype html><html><head><meta charset=\"utf-8\">"
            f"<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            f"<title>持仓建议对比 {today}</title><style>{_HTML_STYLE}</style></head>"
            f"<body><div class=\"wrap\">"
            f"<div class=\"top\"><h1>📅 持仓建议对比 · {today}</h1>"
            f"<div class=\"meta\">📊 数据源 {backend} ｜ 近 {n_recent} 个交易日</div></div>"
            f"{compare_html}"
            f"<div class=\"foot\">Stocks-Master 自动生成 · 技术面综合持仓建议<br>仅供参考，不构成投资建议</div>"
            f"</div></body></html>"
        )
        compare_html_path.write_text(compare_html_doc, encoding="utf-8")
        compare_md_path.write_text(f"# 持仓建议对比 · {today}\n\n> 数据源：{backend}\n\n" + compare_md, encoding="utf-8")

    # 跨持仓基本面对比单独落盘（供邮件附件 / 单独查看）
    fund_cmp_html_path = STOCK_DATA_DIR / f"holdings_fund_compare_{today}.html"
    fund_cmp_md_path = STOCK_DATA_DIR / f"holdings_fund_compare_{today}.md"
    if fund_cmp_html:
        fund_cmp_html_doc = (
            f"<!doctype html><html><head><meta charset=\"utf-8\">"
            f"<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            f"<title>跨持仓基本面对比 {today}</title><style>{_HTML_STYLE}</style></head>"
            f"<body><div class=\"wrap\">"
            f"<div class=\"top\"><h1>📊 跨持仓基本面对比 · {today}</h1>"
            f"<div class=\"meta\">📊 数据源 {backend}</div></div>"
            f"{fund_cmp_html}"
            f"<div class=\"foot\">Stocks-Master 自动生成 · 基本面/资金面对比<br>仅供参考，不构成投资建议</div>"
            f"</div></body></html>"
        )
        fund_cmp_html_path.write_text(fund_cmp_html_doc, encoding="utf-8")
        fund_cmp_md_path.write_text(f"# 跨持仓基本面对比 · {today}\n\n> 数据源：{backend}\n\n" + fund_cmp_md, encoding="utf-8")

    print("\n".join(log_lines))
    print(f"[OK] 报告已落盘:\n  - {md_path}\n  - {html_path}")

    # 3) 邮件推送（HTML 正文 + HTML 报告附件 + 对比附件；未配 SMTP 仅落盘）
    subject = f"【持仓日报】{today} · 持仓个股分析"
    attachments = [str(html_path)]
    if compare_html:
        attachments.append(str(compare_html_path))
    if fund_cmp_html:
        attachments.append(str(fund_cmp_html_path))
    if send_email(subject, md, log_lines=log_lines, html_content=html, extra_attachment_paths=attachments):
        print("[OK] 已通过邮件推送（HTML 正文 + 报告/对比附件）")
    else:
        print("[INFO] 未配置 SMTP，仅落盘报告（不推送）")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
