# -*- coding: utf-8 -*-
"""回测体检 ⑥（去混淆）：仓位效应 vs 股价水平效应；计划权重 vs 实际成交的一致性。"""
import glob
import re
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_bt_probe6_out.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


def safe_read(f):
    try:
        return pd.read_csv(f, dtype=str)
    except Exception:
        return None


recs = []
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv"))):
    t = safe_read(f)
    if t is None or t.empty or "return_pct" not in t.columns:
        continue
    tag = re.search(r"(\d{8})", Path(f).name).group(1)
    dal = SD / f"Daily-Action-List-{tag}.csv"
    if not dal.exists():
        continue
    d = safe_read(dal)
    if d is None or d.empty:
        continue
    d = d.rename(columns={"股票代码": "code"})
    for c in ("code",):
        d[c] = d[c].astype(str).str.zfill(6)
        t[c] = t[c].astype(str).str.zfill(6)
    m = t.merge(d, on="code", how="left")
    m["_batch"] = tag
    recs.append(m)

M = pd.concat(recs, ignore_index=True)
for c in ("return_pct", "qty", "buy_price", "权重", "综合评分", "建议仓位%"):
    if c in M.columns:
        M[c] = pd.to_numeric(M[c], errors="coerce")
M["_value"] = M["qty"] * M["buy_price"]

p("=" * 92)
p("去混淆：收益 到底跟 股价 / 股数 / 下注金额 哪个相关？")
p("=" * 92)
for c in ("buy_price", "qty", "_value", "权重", "建议仓位%"):
    if c in M.columns:
        sub = M.dropna(subset=[c, "return_pct"])
        r = sub[c].corr(sub["return_pct"])
        n = len(sub)
        t = r * (n - 2) ** 0.5 / (1 - r ** 2) ** 0.5 if abs(r) < 1 else float("nan")
        p(f"  corr({c:<10}, return) = {r:+.4f}   n={n}   t={t:+.2f}  "
          f"{'(显著)' if abs(t) > 2 else ''}")

p("")
p("  控制股价后的「下注金额」效应（股价四分位内做金额-收益相关）：")
if "buy_price" in M.columns:
    sub = M.dropna(subset=["buy_price", "_value", "return_pct"])
    sub = sub.assign(_pq=pd.qcut(sub["buy_price"], 4, duplicates="drop"))
    for k, g in sub.groupby("_pq", observed=True):
        r = g["_value"].corr(g["return_pct"])
        p(f"    股价档 {str(k):<26} n={len(g):<4} 金额-收益相关={r:+.3f}  "
          f"金额均值={g['_value'].mean():,.0f}")

p("")
p("  控制下注金额后的「股价」效应（金额四分位内做股价-收益相关）：")
if "buy_price" in M.columns:
    sub = M.dropna(subset=["buy_price", "_value", "return_pct"])
    sub = sub.assign(_vq=pd.qcut(sub["_value"], 4, duplicates="drop"))
    for k, g in sub.groupby("_vq", observed=True):
        r = g["buy_price"].corr(g["return_pct"])
        p(f"    金额档 {str(k):<26} n={len(g):<4} 股价-收益相关={r:+.3f}  "
          f"股价均值={g['buy_price'].mean():.2f}")

p("")
p("=" * 92)
p("计划 vs 成交：模型的「建议仓位%」有没有被忠实执行？")
p("=" * 92)
if "权重" in M.columns and "_value" in M.columns:
    sub = M.dropna(subset=["权重", "_value"])
    p(f"  corr(计划权重, 实际下注金额) = {sub['权重'].corr(sub['_value']):+.4f}")
    p("  计划权重分档 → 实际金额 / 真实收益：")
    sub = sub.assign(_wq=pd.qcut(sub["权重"], 4, duplicates="drop"))
    g = sub.groupby("_wq", observed=True).agg(
        n=("权重", "count"), 计划权重均值=("权重", "mean"),
        实际金额均值=("_value", "mean"),
        真实收益均值=("return_pct", "mean"))
    p(g.round(2).to_string())

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
