#!/bin/bash
# 后台编排: 探测 baostock 10030 端口 → 恢复后跑 fund_cache_fill.py → 循环直到补齐
cd /e/Stocks-Master || exit 1
LOG=.workbuddy/fund_fill_run.log
PY=E:/Anaconda/python.exe

port_ok() {
  timeout 6 bash -c 'echo > /dev/tcp/baostock.com/10030' 2>/dev/null
}

remaining() {
  "$PY" -c "
import glob, json
n=0
for f in glob.glob('stock_data/fundamental_cache/*.json'):
    try:
        d=json.load(open(f,encoding='utf-8'))
    except Exception:
        n+=1; continue
    if 'turnover' not in d or 'amount_20' not in d: n+=1
print(n)"
}

for pass in $(seq 1 40); do
  if port_ok; then
    echo "[$(date '+%F %T')] pass=$pass 端口已恢复, 开始补齐" | tee -a "$LOG"
    "$PY" .workbuddy/fund_cache_fill.py 2>&1 | grep -vE "接收数据异常|^\[WinError|FutureWarning|df = pd.concat" >> "$LOG"
    R=$(remaining)
    echo "[$(date '+%F %T')] pass=$pass 结束, 剩余 $R 只" | tee -a "$LOG"
    if [ "$R" -eq 0 ]; then
      echo "[$(date '+%F %T')] 全部补齐完成" | tee -a "$LOG"
      exit 0
    fi
    echo "[$(date '+%F %T')] 退避 120s 再试" | tee -a "$LOG"
    sleep 120
  else
    echo "[$(date '+%F %T')] pass=$pass 端口未通, 等 60s" >> "$LOG"
    sleep 60
  fi
done
echo "[$(date '+%F %T')] 达到最大轮数 40, 仍有缺口, 手动处理" | tee -a "$LOG"
exit 3
