# -*- coding: utf-8 -*-
"""探明 k_data 覆盖（能否做「全市场等权」基准）+ 池文件可用范围。"""
import glob
import re
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_kd_probe.txt"
lines = []

kd = SD / "k_data"
codes = set()
rows = {}
for f in sorted(kd.glob("*.parquet")):
    try:
        d = pd.read_parquet(f, columns=None)
    except Exception as exc:
        lines.append(f"  [err] {f.name}: {exc}")
        continue
    col = "code" if "code" in d.columns else ("股票代码" if "股票代码" in d.columns else d.columns[0])
    rows[f.name] = (len(d), d[col].nunique())
    codes |= set(d[col].astype(str).str.zfill(6).unique())
lines.append(f"k_data 文件: {list(rows)}")
for k, v in rows.items():
    lines.append(f"  {k}: rows={v[0]}  uniq_code={v[1]}")
lines.append(f"k_data 覆盖唯一代码数 = {len(codes)}")
lines.append(f"样例: {sorted(codes)[:12]}")

# 一个 bucket 的列名
f0 = sorted(kd.glob("*.parquet"))[0]
d0 = pd.read_parquet(f0)
lines.append(f"bucket 列: {list(d0.columns)}")
lines.append(d0.head(3).to_string(index=False)[:600])

# 池文件覆盖
pool = {}
for f in sorted(glob.glob(str(SD / "Stock-Selection-*.csv"))):
    m = re.match(r"Stock-Selection-(.+?)-(\d{8})\.csv$", Path(f).name)
    if not m:
        continue
    pool.setdefault(m.group(1), []).append(m.group(2))
lines.append("")
lines.append("本地因子池文件（按因子）：")
for k in sorted(pool):
    ds = sorted(pool[k])
    lines.append(f"  {k:<16} n={len(ds):<4} {ds[0]}..{ds[-1]}" if ds else f"  {k:<16} n=0")

OUT.write_text("\n".join(lines), encoding="utf-8")
print("\n".join(lines))
