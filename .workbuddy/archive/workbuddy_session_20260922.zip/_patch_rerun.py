# -*- coding: utf-8 -*-
"""修 rerun_backtest_history.py 的两处隐性分叉：

1) `HOLD_DAYS = "10"` 硬编码 vs 生产 CI 的 `daily-pick.yml: HOLD_DAYS="12"`
   → 全量重回测的持有期与日常回测不同，两批结果混进同一面板不可比。
   改为 setdefault("12")（调用方显式指定时尊重调用方）。
2) docstring 里的信号日范围/数量是写死的旧值（38 个 / 20260610~20260731），
   改成不写死的说明。

每处 count(old) 断言 == 1。
"""
import pathlib
import sys

T = pathlib.Path(r"E:\Stocks-Master") / "scripts" / "rerun_backtest_history.py"

REPL = [
    (
        "- LOOKBACK_DAYS=200：覆盖全部 38 个信号日（DAL 跨度 20260610~20260731）。\n",
        "- LOOKBACK_DAYS=200：覆盖仓内全部 Daily-Action-List 信号日（不写死日期范围）。\n"
        "- HOLD_DAYS 取生产 CI 同值（daily-pick.yml = 12），避免与日常回测口径分叉。\n",
    ),
    (
        'os.environ["LOOKBACK_DAYS"] = "200"\n'
        'os.environ["HOLD_DAYS"] = "10"\n'
        'os.environ["BACKTEST_MIN_STRATEGIES"] = "2"\n'
        'os.environ["PREPULL_INTERVAL"] = "0.2"\n'
        'os.environ["BACKTEST_INLINE_FILTER"] = "1"\n',
        'os.environ["LOOKBACK_DAYS"] = "200"\n'
        "# ⚠️ 必须与生产 CI 一致：daily-pick.yml 的回测步骤 env 是 HOLD_DAYS=\"12\"。\n"
        "# 此处曾硬编码 \"10\"，会让「全量重回测」的持有期与日常回测不同，\n"
        "# 两批结果混进同一个回测面板后不可比。改用 setdefault：调用方显式指定时尊重调用方。\n"
        'os.environ.setdefault("HOLD_DAYS", "12")\n'
        'os.environ.setdefault("BACKTEST_MIN_STRATEGIES", "2")\n'
        'os.environ.setdefault("PREPULL_INTERVAL", "0.2")\n'
        'os.environ.setdefault("BACKTEST_INLINE_FILTER", "1")\n',
    ),
]

src = T.read_text(encoding="utf-8")
for i, (old, new) in enumerate(REPL, 1):
    n = src.count(old)
    if n != 1:
        print(f"FAIL #{i}: expected 1 hit, got {n}")
        sys.exit(1)
    src = src.replace(old, new)
    print(f"OK #{i}")
T.write_text(src, encoding="utf-8")
print("WROTE", T)
