# -*- coding: utf-8 -*-
"""探针：k_data 现有 qfq 基线（akshare 口径）vs hithink qfq 的实际偏差。

回答两个问题：
 A. 同一批历史日期上，两源 qfq 收盘价差多少？（= 若今后用 hithink 增量追加，接缝处会跳多少）
 B. 换到 hithink 全量重拉，是否"必须"？（阈值看 KLINE_DRIFT_TOL）
另测 hithink 单只全历史取数耗时，用于估算 4380 只重拉的总时长。

只读：不写任何 k_data / 缓存。
"""
import os
import sys
import time
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
for line in (ROOT / ".env").read_text(encoding="utf-8", errors="ignore").splitlines():
    line = line.strip()
    if line and not line.startswith("#") and "=" in line:
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())

import pandas as pd  # noqa: E402

from smcore.data.kline import list_kline_codes, read_kline_cache, KLINE_DRIFT_TOL  # noqa: E402
from smcore.data import hithink as hk  # noqa: E402

out = []
out.append(f"KLINE_DRIFT_TOL = {KLINE_DRIFT_TOL}")


def fetch_chunked(code6, d1: date, d2: date) -> pd.DataFrame:
    """个股历史 K 按 2000 自然日分片拼接（全历史 2015→今 超出单次上限）。"""
    frames = []
    cur = d1
    while cur <= d2:
        end = min(cur + timedelta(days=2000), d2)
        df = hk.fetch_historical_k(code6, cur, end, "qfq")
        if df is not None and not df.empty:
            frames.append(df)
        cur = end + timedelta(days=1)
    if not frames:
        return pd.DataFrame()
    all_df = pd.concat(frames, ignore_index=True)
    return all_df.drop_duplicates(subset=["date"]).sort_values("date").reset_index(drop=True)


codes = list_kline_codes()
n = len(codes)
step = max(1, n // 40)
sample = codes[::step][:40]
out.append(f"universe={n}  sample={len(sample)}  (every {step})")

rows = []
seam_rows = []
t0 = time.time()
for i, c in enumerate(sample):
    try:
        cached = read_kline_cache(c)
        if cached.empty:
            continue
        cached["date"] = cached["date"].astype(str)
        c_last = str(cached["date"].max())
        c_first = str(cached["date"].min())
        d_first = date.fromisoformat(c_first)
        d_last = date.fromisoformat(c_last)

        # A. 同锚点（end = 缓存末日）比对
        h = fetch_chunked(c, d_first, d_last)
        if h.empty:
            rows.append((c, None, None, 0, "hithink empty"))
            continue
        h["date"] = h["date"].astype(str)
        m = cached[["date", "close"]].merge(h[["date", "close"]], on="date", suffixes=("_c", "_h"))
        if m.empty:
            rows.append((c, None, None, 0, "no overlap"))
            continue
        rel = ((m["close_h"] - m["close_c"]).abs() / m["close_c"].replace(0, pd.NA)).dropna()
        rows.append((c, float(rel.median()), float(rel.max()), len(m), ""))

        # B. 接缝跳变：hithink 锚在"今天"时，缓存末日的值 / 缓存值 - 1
        h2 = fetch_chunked(c, max(d_first, d_last - timedelta(days=30)), date.today())
        if not h2.empty:
            h2["date"] = h2["date"].astype(str)
            sub = h2[h2["date"] == c_last]
            if not sub.empty:
                cv = float(cached.loc[cached["date"] == c_last, "close"].iloc[0])
                hv = float(sub["close"].iloc[0])
                if cv:
                    seam_rows.append((c, c_last, cv, hv, hv / cv - 1.0))
    except Exception as e:  # noqa: BLE001
        rows.append((c, None, None, 0, f"ERR {e!r}"))

elapsed = time.time() - t0
ok = [r for r in rows if r[1] is not None]
out.append(f"compared={len(ok)}  failed/skip={len(rows) - len(ok)}  elapsed={elapsed:.1f}s")
if ok:
    med = sorted(r[1] for r in ok)
    mx = sorted(r[2] for r in ok)
    out.append(f"[A] 同锚点 rel_diff  median: p50={med[len(med)//2]:.3e} p90={med[int(len(med)*0.9)]:.3e} max={med[-1]:.3e}")
    out.append(f"[A] 单票最大 rel_diff:           p50={mx[len(mx)//2]:.3e} p90={mx[int(len(mx)*0.9)]:.3e} max={mx[-1]:.3e}")
    over = [r for r in ok if r[2] > KLINE_DRIFT_TOL]
    out.append(f"[A] 超过 KLINE_DRIFT_TOL({KLINE_DRIFT_TOL}) 的票数 = {len(over)}/{len(ok)}")
    over01 = [r for r in ok if r[2] > 0.001]
    out.append(f"[A] 超过 0.1% 的票数 = {len(over01)}/{len(ok)}")
    out.append("[A] 最大偏差 top10:")
    for r in sorted(ok, key=lambda x: -x[2])[:10]:
        out.append(f"    {r[0]}  max_rel={r[2]:.4e} median_rel={r[1]:.4e} overlap_n={r[3]}")

if seam_rows:
    s = [abs(x[4]) for x in seam_rows]
    out.append(f"[B] 接缝跳变 |ratio-1|: n={len(s)} p50={sorted(s)[len(s)//2]:.3e} max={max(s):.3e}")
    for c, d, cv, hv, rr in sorted(seam_rows, key=lambda x: -abs(x[4]))[:8]:
        out.append(f"    {c} @{d} cache={cv:.4f} hithink={hv:.4f} ratio-1={rr:+.4e}")
else:
    out.append("[B] 无接缝样本")

out.append("--- 重拉成本估算 ---")
out.append(f"本次共 {len(sample)} 只 / {elapsed:.1f}s → 平均 {elapsed / max(1, len(sample)):.2f}s/只")
out.append(f"×4380 只 ≈ {elapsed / max(1, len(sample)) * 4380 / 60:.1f} 分钟（单线程串行，未含重试/落盘）")

txt = "\n".join(out)
(ROOT / ".workbuddy" / "probe_kdata_drift.txt").write_text(txt, encoding="utf-8")
print(txt)
