# -*- coding: utf-8 -*-
"""查融合排序机制：把「自适应权重」与「因子池真实 edge」对齐，检验权重是否指错方向。

fusion.py L296-301：单只票的 综合评分 = Σ(命中因子的自适应权重) [+ 因子分]，
再按 综合评分 降序取 TOP_N ⇒ **选股完全由「命中哪个因子 × 该因子权重」决定**。
若权重与该因子的真实 edge 反向，选股层就会系统性挑出差票（即上一轮实测的「反向筛选」）。
"""
import glob
import math
import os
import re
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
os.environ["SECTOR_MAP_ONDEMAND"] = "0"
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_weight_align.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


# ── 离线化 ──
import importlib  # noqa: E402

kl = importlib.import_module("smcore.data.kline")


def _lf(code, start=None, end=None, *a, **k):
    try:
        d = kl.read_kline_cache(str(code).zfill(6), base_dir=SD / "k_data")
    except Exception:
        d = None
    if d is None or getattr(d, "empty", True) or "date" not in getattr(d, "columns", []):
        return pd.DataFrame()
    d = d.copy()
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d.dropna(subset=["date"])
    if start is not None:
        d = d[d["date"] >= pd.Timestamp(start)]
    if end is not None:
        d = d[d["date"] <= pd.Timestamp(end)]
    return d.sort_values("date").reset_index(drop=True)


for mn in ("smcore.data.kline", "smcore.backtest.engine", "smcore.strategy.boll_levels",
           "smcore.strategy.factor_scoring"):
    try:
        m = importlib.import_module(mn)
        if hasattr(m, "fetch_daily_k"):
            m.fetch_daily_k = _lf
    except Exception:
        pass

# ── 1) 取当前自适应权重 ──
p("=" * 100)
p("1) 当前自适应策略权重（compute_adaptive_allocation，离线）")
p("=" * 100)
W, EDGE, COLD = {}, {}, None
try:
    from smcore.strategy.adaptive_weights import compute_adaptive_allocation

    edge, adaptive_pct, cash_pct, cold = compute_adaptive_allocation()
    COLD = cold
    p(f"  cold_start={cold}  cash_pct={cash_pct}")
    for k in sorted(adaptive_pct, key=lambda x: -adaptive_pct[x]):
        e = edge.get(k) if isinstance(edge, dict) else None
        p(f"    {k:<16} 权重 {adaptive_pct[k]:>6.2f}   edge={e}")
    W = {k: float(v) for k, v in adaptive_pct.items()}
except Exception as exc:
    import traceback
    p(f"  !! compute_adaptive_allocation 失败: {type(exc).__name__}: {exc}")
    p(traceback.format_exc()[:1500])

# ── 2) 重算各因子池超额（H=3 / H=12）──
p("")
p("=" * 100)
p("2) 各因子池超额（池等权 − 全市场等权，同信号日配对）")
p("=" * 100)
D0, D1 = pd.Timestamp("2026-08-10"), pd.Timestamp("2026-10-10")
parts = []
for f in sorted((SD / "k_data").glob("*.parquet")):
    d = pd.read_parquet(f, columns=["code", "date", "open", "close"])
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d[(d["date"] >= D0) & (d["date"] <= D1)]
    if not d.empty:
        parts.append(d)
K = pd.concat(parts, ignore_index=True)
K["code"] = K["code"].astype(str).str.zfill(6)
CAL = sorted(K["date"].dropna().unique())
OPEN = K.pivot_table(index="date", columns="code", values="open", aggfunc="last")
CLOSE = K.pivot_table(index="date", columns="code", values="close", aggfunc="last")
IDX = {pd.Timestamp(d).strftime("%Y%m%d"): i for i, d in enumerate(CAL)}

sig = sorted({re.search(r"(\d{8})", Path(f).name).group(1)
              for f in glob.glob(str(SD / "Daily-Action-List-*.csv"))})
DAL = {}
for f in glob.glob(str(SD / "Daily-Action-List-*.csv")):
    tag = re.search(r"(\d{8})", Path(f).name).group(1)
    d = pd.read_csv(f, dtype=str)
    if not d.empty and "股票代码" in d.columns:
        d["code"] = d["股票代码"].astype(str).str.zfill(6)
        DAL[tag] = d


def fwd(ei, h, codes=None):
    xi = ei + h
    if ei >= len(CAL) or xi >= len(CAL):
        return pd.Series(dtype=float)
    o, c = OPEN.iloc[ei], CLOSE.iloc[xi]
    if codes is not None:
        o, c = o.reindex(codes), c.reindex(codes)
    m = o.notna() & c.notna() & (o > 0)
    return ((c[m] / o[m] - 1) * 100).astype(float)


ACTIVE = ["pvcorr20", "pvcorr60", "cvamt20", "cvamt60", "skew20", "skew60",
          "vratio20_120", "vratio10_60", "distlo10", "distlo60", "vol20", "illiq20"]
LAB = {"pvcorr20": "PVCorr20", "pvcorr60": "PVCorr60", "cvamt20": "CVAmt20",
       "cvamt60": "CVAmt60", "skew20": "Skew20", "skew60": "Skew60",
       "vratio20_120": "VRatio20_120", "vratio10_60": "VRatio10_60",
       "distlo10": "DistLo10", "distlo60": "DistLo60", "vol20": "Vol20",
       "illiq20": "Illiq20"}

pool = defaultdict(dict)
for f in glob.glob(str(SD / "Stock-Selection-*.csv")):
    m = re.match(r"Stock-Selection-(.+?)-(\d{8})\.csv$", Path(f).name)
    if m and m.group(2) in sig:
        pool[m.group(1)][m.group(2)] = f


def pcodes(lab, day):
    f = pool.get(lab, {}).get(day)
    if not f:
        return set()
    d = pd.read_csv(f, dtype=str)
    return set(d["股票代码"].astype(str).str.zfill(6)) if not d.empty else set()


EX = {}
for sid in ACTIVE:
    lab = LAB[sid]
    row = {}
    for h in (3, 12):
        diffs = []
        for day in sig:
            if day not in IDX:
                continue
            ei = IDX[day] + 1
            mk = fwd(ei, h)
            cs = pcodes(lab, day)
            if mk.empty or not cs:
                continue
            pr = fwd(ei, h, codes=sorted(cs))
            if len(pr) < 3:
                continue
            diffs.append(pr.mean() - mk.mean())
        row[h] = float(np.mean(diffs)) if diffs else float("nan")
    EX[sid] = row
    p(f"  {lab:<15} H=3 {row[3]:+6.2f}   H=12 {row[12]:+6.2f}   权重 {W.get(sid, float('nan')):>6.2f}"
      if sid in W else f"  {lab:<15} H=3 {row[3]:+6.2f}   H=12 {row[12]:+6.2f}")

# ── 3) 权重 vs edge 相关性 ──
p("")
p("=" * 100)
p("3) ★自适应权重 与 因子真实 edge 是否同向？")
p("=" * 100)
common = [s for s in ACTIVE if s in W and not math.isnan(EX[s][3])]
if len(common) >= 5:
    w = pd.Series({s: W[s] for s in common})
    e3 = pd.Series({s: EX[s][3] for s in common})
    e12 = pd.Series({s: EX[s][12] for s in common})
    p(f"  n={len(common)} 因子")
    p(f"  corr(权重, H=3 edge)  = {w.corr(e3):+.4f}")
    p(f"  corr(权重, H=12 edge) = {w.corr(e12):+.4f}")
    p("  （负相关 ⇒ 权重给『真实 edge 更差』的因子更多权重 ⇒ 选股层系统性反向）")
    p("")
    p(f"  {'因子':<15}{'权重':>8}{'权重排名':>9}{'H=3 edge':>10}{'H=3排名':>9}{'H=12 edge':>10}")
    wr = w.rank(ascending=False)
    er = e3.rank(ascending=False)
    for s in sorted(common, key=lambda x: -W[x]):
        p(f"  {LAB[s]:<15}{W[s]:>8.2f}{int(wr[s]):>9}{e3[s]:>+10.2f}{int(er[s]):>9}{e12[s]:>+10.2f}")

# ── 4) 用 DAL 的「进 DAL 率」反推隐式权重的上限（交叉验证）──
p("")
p("=" * 100)
p("4) 交叉验证：进 DAL 率排序 vs 权重排序")
p("=" * 100)
conv = {}
for sid in ACTIVE:
    lab = LAB[sid]
    inn, tot = 0, 0
    for day in sig:
        cs = pcodes(lab, day)
        if not cs or day not in DAL:
            continue
        sel = set(DAL[day]["code"])
        inn += len(cs & sel)
        tot += len(cs)
    conv[sid] = inn / tot if tot else float("nan")
c = pd.Series(conv)
w2 = pd.Series({s: W[s] for s in ACTIVE if s in W})
j = pd.concat([w2.rename("w"), c.rename("conv")], axis=1).dropna()
if len(j) >= 5:
    p(f"  corr(权重, 进DAL率) = {j['w'].corr(j['conv']):+.4f}  （应接近 +1，验证 综合评分≈权重 的推断）")
    p("  " + j.sort_values("conv", ascending=False).round(3).to_string().replace("\n", "\n  "))

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
