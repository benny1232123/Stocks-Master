# -*- coding: utf-8 -*-
"""factor_timing mask 的 A/B：同一批信号日，只切 adaptive_weights_config 的
`factor_timing.enabled`（True=生产现状 / False=关闭该层），比较生成 DAL 的前向收益。

离线：把 fusion 链路的 6 个联网点全部本地化（见 offline-refusion-backtest skill）。
输出隔离到 .workbuddy/mask_ab/<arm>/，不碰 stock_data/。
用法：python _mask_ab.py [--days N]
"""
import argparse
import contextlib
import dataclasses
import glob
import importlib
import io
import os
import re
import sys
import traceback
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
os.environ["SECTOR_MAP_ONDEMAND"] = "0"
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUTROOT = ROOT / ".workbuddy" / "mask_ab"
LOG = ROOT / ".workbuddy" / "_mask_ab_out.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


# ── 1) fetch_daily_k 纯本地 ──
kl = importlib.import_module("smcore.data.kline")


def _lf(code, start=None, end=None, *a, **k):
    try:
        d = kl.read_kline_cache(str(code).zfill(6), base_dir=SD / "k_data")
    except Exception:
        d = None
    if d is None or getattr(d, "empty", True) or "date" not in getattr(d, "columns", []):
        return pd.DataFrame()
    d = d.copy()
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d.dropna(subset=["date"])
    if start is not None:
        d = d[d["date"] >= pd.Timestamp(start)]
    if end is not None:
        d = d[d["date"] <= pd.Timestamp(end)]
    return d.sort_values("date").reset_index(drop=True)


for mn in ("smcore.data.kline", "smcore.backtest.engine", "smcore.strategy.boll_levels",
           "smcore.strategy.factor_scoring"):
    try:
        m = importlib.import_module(mn)
        if hasattr(m, "fetch_daily_k"):
            m.fetch_daily_k = _lf
    except Exception:
        pass

# ── 2) market profile 固定化（确定性）──
import smcore.strategy.fusion as FU  # noqa: E402

try:
    from smcore.strategy.market import MarketProfile
    _FIELDS = {f.name for f in dataclasses.fields(MarketProfile)}
except Exception:
    MarketProfile, _FIELDS = None, set()

_DEF = {
    "regime": "震荡轮动", "regime_strength": 0.5, "trend": "side",
    "volatility_level": "mid", "volatility_pct": 0.0, "volatility_pctile": 0.5,
    "breadth_score": 0.5, "activity_ratio": 1.0, "hs300_ret20": 0.0,
}


def _fixed_profile(*a, **k):
    if MarketProfile is None:
        return None
    return MarketProfile(**{kk: vv for kk, vv in _DEF.items() if kk in _FIELDS})


FU.compute_market_profile = _fixed_profile
try:
    import smcore.strategy.market as MK
    MK.compute_market_profile = _fixed_profile
except Exception:
    pass

# ── 3) 基本面 / 名称 / 板块 / baostock 全部离线 ──
try:
    fm = importlib.import_module("smcore.strategy.fundamental")
    fm.fetch_fundamentals_batch = lambda codes, *a, **k: {
        c: (fm._load_fund_cache(c) if hasattr(fm, "_load_fund_cache") else None) for c in codes
    }
except Exception as exc:
    p(f"  [warn] fundamental patch: {exc}")

try:
    nlm = importlib.import_module("smcore.strategy.name_lookup")
    nlm.lookup_stock_name = lambda c, *a, **k: (nlm._get_stock_name_map() or {}).get(
        str(c).zfill(6), "")
    nlm.login = lambda *a, **k: False
except Exception as exc:
    p(f"  [warn] name_lookup patch: {exc}")

try:
    rf = importlib.import_module("smcore.strategy.regime_filter")
    rf._get_hs300_close = lambda *a, **k: None
except Exception:
    pass

try:
    sess = importlib.import_module("smcore.data.session")
    sess.login = lambda *a, **k: False
except Exception:
    pass

for mn in ("smcore.strategy.sectors", "smcore.strategy.name_lookup", "smcore.strategy.fundamental"):
    try:
        mod = importlib.import_module(mn)
        if hasattr(mod, "login"):
            mod.login = lambda *a, **k: False
    except Exception:
        pass

import smcore.strategy.adaptive_weights as AW  # noqa: E402

p("离线化完成；factor_timing CONFIG = " + str(AW.CONFIG.get("factor_timing")))

# ── 4) 前向收益工具（全市场基准）──
D0, D1 = pd.Timestamp("2026-08-10"), pd.Timestamp("2026-10-10")
parts = []
for f in sorted((SD / "k_data").glob("*.parquet")):
    d = pd.read_parquet(f, columns=["code", "date", "open", "close"])
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d[(d["date"] >= D0) & (d["date"] <= D1)]
    if not d.empty:
        parts.append(d)
K = pd.concat(parts, ignore_index=True)
K["code"] = K["code"].astype(str).str.zfill(6)
CAL = sorted(K["date"].dropna().unique())
OPEN = K.pivot_table(index="date", columns="code", values="open", aggfunc="last")
CLOSE = K.pivot_table(index="date", columns="code", values="close", aggfunc="last")
IDX = {pd.Timestamp(d).strftime("%Y%m%d"): i for i, d in enumerate(CAL)}


def fwd(day, h, codes=None):
    ei = IDX.get(day)
    if ei is None or ei + h >= len(CAL):
        return pd.Series(dtype=float)
    o, c = OPEN.iloc[ei + 1], CLOSE.iloc[ei + 1 + h]
    if codes is not None:
        o, c = o.reindex([str(x).zfill(6) for x in codes]), c.reindex([str(x).zfill(6) for x in codes])
    m = o.notna() & c.notna() & (o > 0)
    return ((c[m] / o[m] - 1) * 100).astype(float)


def mkt(day, h):
    ei = IDX.get(day)
    if ei is None or ei + h >= len(CAL):
        return None
    o, c = OPEN.iloc[ei + 1], CLOSE.iloc[ei + 1 + h]
    m = o.notna() & c.notna() & (o > 0)
    return float(((c[m] / o[m] - 1) * 100).mean()) if m.any() else None


# ── 5) 跑 A/B ──
ap = argparse.ArgumentParser()
ap.add_argument("--days", type=int, default=0, help="只用最近 N 个信号日（0=全部）")
args = ap.parse_args()

sig = sorted({re.search(r"(\d{8})", Path(f).name).group(1)
              for f in glob.glob(str(SD / "Daily-Action-List-*.csv"))})
if args.days:
    sig = sig[-args.days:]
p(f"信号日 {len(sig)} 个：{sig[0]}..{sig[-1]}")

ARMS = {"mask_on": True, "mask_off": False}
store = {}
for arm, on in ARMS.items():
    d = OUTROOT / arm
    d.mkdir(parents=True, exist_ok=True)
    AW.CONFIG.setdefault("factor_timing", {})["enabled"] = on
    p("")
    p("=" * 96)
    p(f"arm={arm}  factor_timing.enabled={on}")
    p("=" * 96)
    dfs = {}
    for day in sig:
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):
                df, rep = FU.fuse_signals(day)
            if df is None or df.empty:
                p(f"  {day}: 空清单（{str(rep)[:60]}）")
                continue
            df = df.copy()
            df["code"] = df["股票代码"].astype(str).str.zfill(6)
            dfs[day] = df
            df.to_csv(d / f"Daily-Action-List-{day}.csv", index=False, encoding="utf-8-sig")
            srcs = []
            if "来源策略" in df.columns:
                srcs = df["来源策略"].astype(str).tolist()
            p(f"  {day}: {len(df)} 只  来源组合样例 {srcs[:3]}")
        except Exception as exc:
            p(f"  !! {day}: {type(exc).__name__}: {exc}")
            p(traceback.format_exc()[-800:])
    store[arm] = dfs

# ── 6) 汇总 ──
p("")
p("=" * 96)
p(f"汇总：DAL 等权组合的前向收益（含费用前，口径 = 次日开盘买 → 持有 H 日收盘卖）")
p("=" * 96)
p(f"  {'arm':<10}{'H':>4}{'天数':>6}{'绝对均%':>10}{'超额均%':>10}{'胜率%':>8}")
for arm in ARMS:
    for h in (1, 3, 5):
        abs_, exc_ = [], []
        for day, df in store[arm].items():
            r = fwd(day, h, list(df["code"]))
            mk = mkt(day, h)
            if r.empty or mk is None:
                continue
            abs_.append(r.mean())
            exc_.append(r.mean() - mk)
        if abs_:
            p(f"  {arm:<10}{h:>4}{len(abs_):>6}{np.mean(abs_):>10.2f}"
              f"{np.mean(exc_):>10.2f}{100*np.mean([x > 0 for x in abs_]):>8.1f}")

p("")
p("── 逐日配对（H=3，mask_off − mask_on）──")
rows = []
for day in sig:
    a, b = store.get("mask_on", {}).get(day), store.get("mask_off", {}).get(day)
    if a is None or b is None:
        continue
    ra, rb = fwd(day, 3, list(a["code"])), fwd(day, 3, list(b["code"]))
    if ra.empty or rb.empty:
        continue
    rows.append({"day": day, "on": ra.mean(), "off": rb.mean(), "d": rb.mean() - ra.mean()})
D = pd.DataFrame(rows)
if not D.empty:
    p("  " + D.round(2).to_string(index=False).replace("\n", "\n  "))
    p(f"  均值 Δ={D['d'].mean():+.3f}pp  中位 Δ={D['d'].median():+.3f}pp  "
      f"（off 更好 {int((D['d']>0).sum())} / 更差 {int((D['d']<0).sum())}）")

p("")
p("── 各 arm 的来源策略构成（单策略命中）──")
for arm in ARMS:
    from collections import Counter
    c = Counter()
    for day, df in store[arm].items():
        for v in df.get("来源策略", pd.Series(dtype=str)).astype(str):
            if "/" not in v:
                c[v] += 1
    p(f"  [{arm}] " + "  ".join(f"{k}={v}" for k, v in c.most_common()))

LOG.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", LOG)
