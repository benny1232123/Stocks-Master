import subprocess, base64, csv, io
from collections import Counter
SLUG = "benny1232123/Stocks-Master"
for d in ["20260827", "20260828", "20260914", "20260901", "20260915"]:
    r = subprocess.run(["gh", "api", f"repos/{SLUG}/contents/stock_data/Daily-Action-List-{d}.csv", "--jq", ".content"], capture_output=True, text=True)
    if r.returncode != 0 or not r.stdout.strip():
        print(f"{d}: NO DAL"); continue
    raw = base64.b64decode(r.stdout.strip()).decode("utf-8-sig")
    rows = list(csv.DictReader(io.StringIO(raw)))
    col = next((c for c in rows[0].keys() if "来源策略" in c or c == "策略"), None)
    vals = Counter()
    for row in rows:
        v = row.get(col, "")
        for s in str(v).split("/"):
            s = s.strip()
            if s:
                vals[s] += 1
    print(f"{d}: rows={len(rows)} col={col} 来源策略集合={dict(vals)}")
