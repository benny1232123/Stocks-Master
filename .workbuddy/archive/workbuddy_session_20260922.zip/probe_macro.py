"""临时探针：探测本环境哪些宏观数据源可达，决定动态更新方案。"""
import threading, time, traceback

def probe(name, fn, timeout=15):
    box = {}
    def run():
        try:
            box["r"] = fn()
        except Exception as e:  # noqa
            box["e"] = e
    t = threading.Thread(target=run, daemon=True)
    t.start()
    t.join(timeout)
    if t.is_alive():
        return f"{name}: TIMEOUT(>{timeout}s)"
    if "e" in box:
        return f"{name}: ERR {type(box['e']).__name__}: {str(box['e'])[:120]}"
    r = box["r"]
    try:
        if hasattr(r, "shape"):
            head = f"df{getattr(r,'shape',None)} cols={list(r.columns)[:8]}"
            if not r.empty:
                last = r.iloc[-1]
                head += " last=" + ",".join(f"{c}={last[c]}" for c in r.columns[:6] if c in last)
        else:
            head = repr(r)[:160]
    except Exception as e:  # noqa
        head = f"repr-err {e}"
    return f"{name}: OK {head}"

import akshare as ak
print("== FX / 中行折算价 ==")
print(probe("currency_boc_sina 美元", lambda: ak.currency_boc_sina(symbol="美元")))
print(probe("currency_boc_sina 日元", lambda: ak.currency_boc_sina(symbol="日元")))
print("== SHIBOR ==")
print(probe("macro_china_shibor_all", lambda: ak.macro_china_shibor_all()))
print(probe("rate_interbank Shibor 隔夜", lambda: ak.rate_interbank(market="上海银行间同业拆放利率", symbol="Shibor", indicator="隔夜")))
print("== LPR ==")
print(probe("lpr_market_report 1y", lambda: ak.lpr_market_report(period=1)))
print("== 债券 ==")
print(probe("bond_zh_us_rate", lambda: ak.bond_zh_us_rate(search="中国10年国债收益率")))
print("== 景气/物价 ==")
print(probe("macro_china_pmi_yearly", lambda: ak.macro_china_pmi_yearly()))
print(probe("macro_china_cpi_yearly", lambda: ak.macro_china_cpi_yearly()))
print(probe("macro_china_ppi_yearly", lambda: ak.macro_china_ppi_yearly()))
