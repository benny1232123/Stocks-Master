"""用 new_macro_block.txt 替换 dashboard.py 中旧的 fetch_macro_snapshot 整段。"""
import io, sys

ROOT = "E:/Stocks-Master"
path = f"{ROOT}/smcore/dashboard.py"
with io.open(path, encoding="utf-8") as f:
    src = f.read()

start_marker = "def fetch_macro_snapshot() -> dict[str, Any] | None:"
end_marker = "\n\ndef _fetch_shibor_multi"

si = src.find(start_marker)
ei = src.find(end_marker)
assert si != -1, "未找到 fetch_macro_snapshot 起点"
assert ei != -1, "未找到 _fetch_shibor_multi 终点"

with io.open(f"{ROOT}/.workbuddy/new_macro_block.txt", encoding="utf-8") as f:
    block = f.read().rstrip("\n") + "\n"

new_src = src[:si] + block + src[ei:]  # ei 以 \n\ndef 开头，block 末尾已留换行

# 确保 import json as _json 存在
if "import json as _json" not in new_src:
    new_src = new_src.replace("import requests\n", "import requests\nimport json as _json\n", 1)

with io.open(path, "w", encoding="utf-8") as f:
    f.write(new_src)
print("patched dashboard.py: replaced fetch_macro_snapshot region")
print("start", si, "end", ei, "new_len", len(new_src))
