# -*- coding: utf-8 -*-
"""信号有效性体检（全离线）。

核心问题：12 个价格因子**本身**有没有 edge，还是**融合/排序层**把 edge 稀释掉了？

方法（统一口径：信号日次日开盘买入，持有 H 个交易日后收盘卖出）：
  基准 = 当日**全市场**等权前向收益（k_data 覆盖 4380 只，只用两头都有价的股票）
  因子池 = Stock-Selection-<Factor>-<date>.csv 的成员等权前向收益
  融合名单 = Daily-Action-List-<date>.csv 等权前向收益
  决定性检验 = 同一因子池内「进入 DAL」vs「未进入 DAL」的前向收益差
                （若未入选的更好 ⇒ 融合层在**反向筛选**，因子有 edge 但被丢掉）
"""
import glob
import re
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_signal_health.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


HZ = (1, 3, 5, 12)
D0, D1 = pd.Timestamp("2026-08-10"), pd.Timestamp("2026-10-10")

# ── 1) 载入窗口内的全市场行情 ──
p("=" * 104)
p("0) 载入 k_data 窗口切片")
p("=" * 104)
parts = []
for f in sorted((SD / "k_data").glob("*.parquet")):
    d = pd.read_parquet(f, columns=["code", "date", "open", "close"])
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d[(d["date"] >= D0) & (d["date"] <= D1)]
    if not d.empty:
        parts.append(d)
K = pd.concat(parts, ignore_index=True)
K["code"] = K["code"].astype(str).str.zfill(6)
K = K.dropna(subset=["date"])
p(f"  窗口内 {len(K)} 行 / {K['code'].nunique()} 只 / "
  f"{K['date'].min().date()} ~ {K['date'].max().date()}")

CAL = sorted(K["date"].unique())
OPEN = K.pivot_table(index="date", columns="code", values="open", aggfunc="last")
CLOSE = K.pivot_table(index="date", columns="code", values="close", aggfunc="last")
IDX = {pd.Timestamp(d).strftime("%Y%m%d"): i for i, d in enumerate(CAL)}
p(f"  交易日历 {len(CAL)} 天")


def fwd_returns(entry_day_idx: int, horizon: int, codes=None) -> pd.Series:
    """返回 {code: 收益%}；entry 用 entry_day_idx 的开盘、exit 用其后第 horizon 个交易日的收盘。"""
    ei, xi = entry_day_idx, entry_day_idx + horizon
    if ei >= len(CAL) or xi >= len(CAL):
        return pd.Series(dtype=float)
    o = OPEN.iloc[ei]
    c = CLOSE.iloc[xi]
    if codes is not None:
        o = o.reindex(codes)
        c = c.reindex(codes)
    m = o.notna() & c.notna() & (o > 0)
    return ((c[m] / o[m] - 1) * 100).astype(float)


# ── 2) 收集信号日与各来源 ──
sig_days = []
for f in sorted(glob.glob(str(SD / "Daily-Action-List-*.csv"))):
    m = re.search(r"Daily-Action-List-(\d{8})\.csv$", Path(f).name)
    if m:
        sig_days.append(m.group(1))

POOLS = defaultdict(dict)
for f in sorted(glob.glob(str(SD / "Stock-Selection-*.csv"))):
    m = re.match(r"Stock-Selection-(.+?)-(\d{8})\.csv$", Path(f).name)
    if m and m.group(2) in sig_days:
        POOLS[m.group(1)][m.group(2)] = f

DAL = {}
for f in sorted(glob.glob(str(SD / "Daily-Action-List-*.csv"))):
    m = re.search(r"Daily-Action-List-(\d{8})\.csv$", Path(f).name)
    if not m:
        continue
    d = pd.read_csv(f, dtype=str)
    if d.empty or "股票代码" not in d.columns:
        continue
    d = d.copy()
    d["code"] = d["股票代码"].astype(str).str.zfill(6)
    if "综合评分" in d.columns:
        d["综合评分"] = pd.to_numeric(d["综合评分"], errors="coerce")
    if "命中策略数" in d.columns:
        d["命中策略数"] = pd.to_numeric(d["命中策略数"], errors="coerce")
    DAL[m.group(1)] = d

p("")
p(f"  信号日 {len(sig_days)} 个：{sig_days[0]}..{sig_days[-1]}")
p(f"  本地因子池：{len(POOLS)} 个因子 × 各 {sorted(len(v) for v in POOLS.values())} 天")


def pool_codes(factor, day):
    f = POOLS.get(factor, {}).get(day)
    if not f:
        return set()
    d = pd.read_csv(f, dtype=str)
    if d.empty or "股票代码" not in d.columns:
        return set()
    return set(d["股票代码"].astype(str).str.zfill(6))


# ── 3) 每因子池 vs 全市场 ──
p("")
p("=" * 104)
p("1) 因子池是否存在 edge（池等权 − 全市场等权，同信号日配对）")
p("=" * 104)
hdr = f"  {'因子':<14}{'天数':>5}" + "".join(f"{'H=' + str(h):>11}" for h in HZ) \
      + f"{'池均只数':>9}{'进DAL率':>9}"
p(hdr)
result = {}
for factor in sorted(POOLS):
    row = {}
    for h in HZ:
        diffs, absr = [], []
        for day in sig_days:
            if day not in IDX:
                continue
            ei = IDX[day] + 1
            mk = fwd_returns(ei, h)
            if mk.empty:
                continue
            cs = pool_codes(factor, day)
            if not cs:
                continue
            pr = fwd_returns(ei, h, codes=sorted(cs))
            if len(pr) < 3:
                continue
            mkr = mk.mean()
            diffs.append(pr.mean() - mkr)
            absr.append(pr.mean())
        row[h] = (diffs, absr)
    n_days = len(row[HZ[0]][0]) if row.get(HZ[0]) else 0
    cells = []
    for h in HZ:
        dd = row.get(h, ([], []))[0]
        cells.append(f"{np.mean(dd):+.2f}" if dd else "—")
    # 池大小 + 进入 DAL 比例
    sizes, conv = [], []
    for day in sig_days:
        cs = pool_codes(factor, day)
        if not cs:
            continue
        sizes.append(len(cs))
        if day in DAL:
            conv.append(len(cs & set(DAL[day]["code"])) / max(len(cs), 1))
    p(f"  {factor:<14}{n_days:>5}" + "".join(f"{c:>11}" for c in cells)
      + f"{(np.mean(sizes) if sizes else 0):>9.1f}"
      + f"{(100*np.mean(conv) if conv else 0):>8.1f}%")
    result[factor] = row

# ── 4) 融合名单 vs 市场 ──
p("")
p("=" * 104)
p("2) 融合名单（DAL）vs 全市场")
p("=" * 104)
p(f"  {'':<14}{'天数':>5}" + "".join(f"{'H=' + str(h):>11}" for h in HZ))
for h in HZ:
    diffs, absr = [], []
    for day in sig_days:
        if day not in IDX or day not in DAL:
            continue
        ei = IDX[day] + 1
        mk = fwd_returns(ei, h)
        if mk.empty:
            continue
        cs = list(DAL[day]["code"])
        dr = fwd_returns(ei, h, codes=cs)
        if len(dr) < 3:
            continue
        diffs.append(dr.mean() - mk.mean())
        absr.append(dr.mean())
    if diffs:
        p(f"  {'DAL 实际选股':<14}{len(diffs):>5}{np.mean(diffs):>+11.2f}"
          f"   （绝对值均 {np.mean(absr):+.2f}%）")

# ── 5) 决定性检验：池内 进/未进 DAL ──
p("")
p("=" * 104)
p("3) ★决定性检验：同一因子池内「进了 DAL」vs「没进 DAL」的前向收益（H=3）")
p("=" * 104)
p(f"  {'因子':<14}{'池内入选':>9}{'入选均%':>10}{'落选':>7}{'落选均%':>10}{'差(入选-落选)':>15}")
for factor in sorted(POOLS):
    inn, out = [], []
    for day in sig_days:
        if day not in IDX or day not in DAL:
            continue
        cs = pool_codes(factor, day)
        if not cs:
            continue
        ei = IDX[day] + 1
        rr = fwd_returns(ei, 3, codes=sorted(cs))
        if len(rr) < 4:
            continue
        selected = set(DAL[day]["code"])
        for code, v in rr.items():
            (inn if code in selected else out).append(v)
    if inn and out:
        p(f"  {factor:<14}{len(inn):>9}{np.mean(inn):>+10.2f}{len(out):>7}"
          f"{np.mean(out):>+10.2f}{np.mean(inn)-np.mean(out):>+15.2f}")

# ── 6) DAL 内部：命中策略数 / 综合评分 分位（H=3） ──
p("")
p("=" * 104)
p("4) DAL 内部结构（H=3，口径同前）")
p("=" * 104)
recs = []
for day in sig_days:
    if day not in IDX or day not in DAL:
        continue
    ei = IDX[day] + 1
    d = DAL[day]
    rr = fwd_returns(ei, 3, codes=list(d["code"]))
    if rr.empty:
        continue
    for _, r in d.iterrows():
        if r["code"] in rr.index:
            recs.append({"day": day, "code": r["code"], "ret": rr[r["code"]],
                         "hit": r.get("命中策略数"), "score": r.get("综合评分"),
                         "src": r.get("来源策略"), "weight": r.get("权重")})
R = pd.DataFrame(recs)
p(f"  样本 {len(R)} 笔 / {R['day'].nunique()} 天")
if not R.empty:
    p("  ── 按命中策略数 ──")
    g = R.dropna(subset=["hit"]).groupby("hit")["ret"].agg(n="count", mean="mean",
                                                            win=lambda s: 100 * (s > 0).mean())
    p("    " + g.round(2).to_string().replace("\n", "\n    "))
    p("  ── 按综合评分四分位 ──")
    R["_q"] = pd.qcut(R["score"], 4, duplicates="drop")
    g2 = R.groupby("_q", observed=True)["ret"].agg(n="count", mean="mean",
                                                  win=lambda s: 100 * (s > 0).mean())
    p("    " + g2.round(2).to_string().replace("\n", "\n    "))
    corr = R["score"].corr(R["ret"])
    p(f"  corr(综合评分, H=3 收益) = {corr:+.4f}")
    p("  ── 按来源策略（单个因子独立出现时） ──")
    solo = R[~R["src"].astype(str).str.contains("/")].dropna(subset=["src"])
    if not solo.empty:
        g3 = solo.groupby("src")["ret"].agg(n="count", mean="mean",
                                            win=lambda s: 100 * (s > 0).mean())
        p("    " + g3.sort_values("mean").round(2).to_string().replace("\n", "\n    "))

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
