import subprocess, time, json, datetime

RUN = "35426046447"
SENTINEL = "E:/Stocks-Master/.workbuddy/_realign35426046447_done.txt"

def gh_view(tries=6):
    for _ in range(tries):
        try:
            r = subprocess.run(
                ["gh", "run", "view", RUN, "--json", "status,conclusion,updatedAt,url"],
                capture_output=True, text=True, timeout=60)
            if r.returncode == 0 and r.stdout.strip():
                return r.stdout.strip()
        except Exception:
            pass
        time.sleep(15)
    return None

start = datetime.datetime.utcnow()
result = None
while True:
    out = gh_view()
    if out:
        try:
            d = json.loads(out)
        except Exception:
            d = {}
        st = d.get("status", "")
        if st in ("completed", "failure", "cancelled", "skipped", "timed_out"):
            result = {"status": st, "conclusion": d.get("conclusion"), "updatedAt": d.get("updatedAt"), "url": d.get("url")}
            break
    elapsed = (datetime.datetime.utcnow() - start).total_seconds()
    if elapsed > 3 * 3600:
        result = {"status": "WATCH_TIMEOUT", "last_raw": out}
        break
    time.sleep(60)

with open(SENTINEL, "w", encoding="utf-8") as f:
    f.write(json.dumps(result, ensure_ascii=False, indent=2))
print("REALIGN_TERMINAL", json.dumps(result, ensure_ascii=False))
