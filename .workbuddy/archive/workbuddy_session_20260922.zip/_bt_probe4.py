# -*- coding: utf-8 -*-
"""回测体检 ④（决定性）：把 DAL 的「模型自打分」与真实前向收益对齐，检验排序是否有效。

思路：Multi-Backtest-{信号日}-trades.csv 的 _batch 就是信号日 → 与该日
Daily-Action-List-{信号日}.csv 按代码 join，得到每笔成交的：
  命中策略数 / 综合评分 / 权重 / 因子分  ← 模型自评
  return_pct                            ← 真实结果
然后检验：这些"分数"到底有没有预测力（相关 + 分组均值）。
"""
import glob
import re
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_bt_probe4_out.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


def safe_read(f):
    try:
        return pd.read_csv(f, dtype=str)
    except Exception:
        return None


# ── A) 全量 DAL 里每个基础策略的出场频率 ──
p("=" * 92)
p("A) 12 策略菜单的实际出场频率（全部 16 个 DAL）")
p("=" * 92)
dals = sorted(glob.glob(str(SD / "Daily-Action-List-*.csv")))
from collections import Counter  # noqa: E402

cnt = Counter()
days = 0
hit_counts = Counter()
base_sets = []
for f in dals:
    d = safe_read(f)
    if d is None or d.empty or "来源策略" not in d.columns:
        continue
    days += 1
    s = set()
    for v in d["来源策略"].dropna().astype(str):
        for t in re.split(r"[/|,;\s]+", v):
            t = t.strip()
            if t:
                cnt[t] += 1
                s.add(t)
    base_sets.append(s)
    if "命中策略数" in d.columns:
        for v in d["命中策略数"].dropna().astype(str):
            hit_counts[v] += 1
p(f"  DAL 天数 = {days}")
p(f"  各策略在「多少个信号日」里出现过（共 {days} 天）：")
for k, v in cnt.most_common():
    p(f"    {k:<34} {v:>3} 天  ({100*v/days:5.1f}%)")
p(f"  出现过的不同 token 数 = {len(cnt)}")
if base_sets:
    union = set().union(*base_sets)
    p(f"  16 天并集里出现过的策略 = {sorted(union)}  n={len(union)}")
    inter = set.intersection(*base_sets)
    p(f"  每天都出现的策略 = {sorted(inter)}  n={len(inter)}")
p(f"  单日「命中策略数」分布 = {dict(sorted(hit_counts.items()))}")

# ── B) DAL 模型评分 vs 真实收益 ──
p("")
p("=" * 92)
p("B) 模型自评分 vs 真实前向收益（决定性检验）")
p("=" * 92)
recs = []
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv"))):
    t = safe_read(f)
    if t is None or t.empty or "return_pct" not in t.columns:
        continue
    tag = re.search(r"(\d{8})", Path(f).name).group(1)
    dal = SD / f"Daily-Action-List-{tag}.csv"
    if not dal.exists():
        continue
    d = safe_read(dal)
    if d is None or d.empty:
        continue
    d = d.rename(columns={"股票代码": "code"})
    d["code"] = d["code"].astype(str).str.zfill(6)
    t["code"] = t["code"].astype(str).str.zfill(6)
    m = t.merge(d, on="code", how="left", suffixes=("", "_dal"))
    m["_batch"] = tag
    recs.append(m)

M = pd.concat(recs, ignore_index=True)
M["return_pct"] = pd.to_numeric(M["return_pct"], errors="coerce")
p(f"  可对齐成交 = {len(M)} 笔（覆盖 {M['_batch'].nunique()} 个信号日）")

for col in ("命中策略数", "综合评分", "权重", "因子分"):
    if col not in M.columns:
        p(f"  [缺列] {col}")
        continue
    M[col] = pd.to_numeric(M[col], errors="coerce")
    sub = M.dropna(subset=[col, "return_pct"])
    if len(sub) < 5:
        p(f"  {col}: 有效样本不足 ({len(sub)})")
        continue
    r = sub[col].corr(sub["return_pct"])
    p(f"  ── {col} ──  有效 n={len(sub)}  相关={r:+.4f}  "
      f"均值={sub[col].mean():.3f}")
    try:
        q = pd.qcut(sub[col], min(4, sub[col].nunique()), duplicates="drop")
        g = sub.groupby(q, observed=True)["return_pct"].agg(
            n="count", mean="mean", win=lambda s: 100 * (s > 0).mean())
        p(g.round(3).to_string().replace("\n", "\n    "))
    except Exception as exc:
        p(f"    分组失败: {exc}")

# 命中策略数专门看（共识假设）
if "命中策略数" in M.columns:
    m2 = M.dropna(subset=["命中策略数", "return_pct"])
    p("")
    p("  △ 共识假设：命中策略数越多是否越好？")
    g = m2.groupby("命中策略数")["return_pct"].agg(
        n="count", mean="mean", median="median", win=lambda s: 100 * (s > 0).mean())
    p(g.round(3).to_string())

# ── C) 与基准对比（走完窗口批次） ──
p("")
p("=" * 92)
p("C) 结论性对照")
p("=" * 92)
p(f"  等权笔均         : {M['return_pct'].mean():+.3f}%")
p(f"  市值加权笔均     : "
  f"{(M['return_pct'] * pd.to_numeric(M.get('qty'), errors='coerce') * pd.to_numeric(M.get('buy_price'), errors='coerce')).sum() / (pd.to_numeric(M.get('qty'), errors='coerce') * pd.to_numeric(M.get('buy_price'), errors='coerce')).sum():+.3f}%")

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
