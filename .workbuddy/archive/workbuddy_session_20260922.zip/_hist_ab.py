# -*- coding: utf-8 -*-
"""长样本 mask A/B：回填历史因子池 → 离线重跑融合（mask_on / mask_off）→ 汇总。

可断点续跑：
  - 因子池缺失的日期才重新生成（.workbuddy/hist_pools/）
  - DAL 已存在的 (arm, date) 跳过（.workbuddy/hist_ab/<arm>/）
用法：python _hist_ab.py [--days 60] [--skip-pools]
"""
import argparse
import contextlib
import dataclasses
import glob
import importlib
import io
import os
import re
import sys
import time
import traceback
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
os.environ["SECTOR_MAP_ONDEMAND"] = "0"
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
HIST_POOLS = ROOT / ".workbuddy" / "hist_pools"
AB = ROOT / ".workbuddy" / "hist_ab"
LOG = ROOT / ".workbuddy" / "_hist_ab_out.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s, flush=True)


ap = argparse.ArgumentParser()
ap.add_argument("--days", type=int, default=60)
ap.add_argument("--skip-pools", action="store_true")
args = ap.parse_args()
HIST_POOLS.mkdir(parents=True, exist_ok=True)
AB.mkdir(parents=True, exist_ok=True)

# ── 1) 离线化 ──
kl = importlib.import_module("smcore.data.kline")

# ★ 关键性能修复：把 k_data 的 7 个 parquet 桶**一次性预载**进内存并按 code 建索引。
# 否则 `_compute_boll_levels` 每只票都会 `read_parquet` 一次（~0.15s），
# 每天 ~480 只候选 = 70s+/天，60 天×2 arm 会拖到 2.5 小时。
_T0 = time.time()
_BIG = pd.concat([pd.read_parquet(f) for f in sorted((SD / "k_data").glob("*.parquet"))],
                 ignore_index=True)
_BIG["code"] = _BIG["code"].astype(str).str.zfill(6)
_BIG["date"] = pd.to_datetime(_BIG["date"], errors="coerce")
_BIG = _BIG.dropna(subset=["date"])
_BY_CODE = {c: g.sort_values("date").reset_index(drop=True)
            for c, g in _BIG.groupby("code", sort=False)}
_n_rows = len(_BIG)
del _BIG
print(f"[预载] k_data {_n_rows} 行 / {len(_BY_CODE)} 只  用时 {time.time()-_T0:.0f}s", flush=True)


def _lf(code, start=None, end=None, *a, **k):
    d = _BY_CODE.get(str(code).zfill(6))
    if d is None or d.empty:
        return pd.DataFrame()
    if start is not None:
        d = d[d["date"] >= pd.Timestamp(start)]
    if end is not None:
        d = d[d["date"] <= pd.Timestamp(end)]
    return d.reset_index(drop=True)


for mn in ("smcore.data.kline", "smcore.backtest.engine", "smcore.strategy.boll_levels",
           "smcore.strategy.factor_scoring"):
    try:
        m = importlib.import_module(mn)
        if hasattr(m, "fetch_daily_k"):
            m.fetch_daily_k = _lf
    except Exception:
        pass

import smcore.strategy.fusion as FU  # noqa: E402

try:
    from smcore.strategy.market import MarketProfile
    _MF = {f.name for f in dataclasses.fields(MarketProfile)}
except Exception:
    MarketProfile, _MF = None, set()
_DEF = {"regime": "震荡轮动", "regime_strength": 0.5, "trend": "side",
        "volatility_level": "mid", "volatility_pct": 0.0, "volatility_pctile": 0.5,
        "breadth_score": 0.5, "activity_ratio": 1.0, "hs300_ret20": 0.0}


def _fixed_profile(*a, **k):
    return MarketProfile(**{kk: vv for kk, vv in _DEF.items() if kk in _MF}) if MarketProfile else None


FU.compute_market_profile = _fixed_profile
try:
    import smcore.strategy.market as MK
    MK.compute_market_profile = _fixed_profile
except Exception:
    pass

try:
    fm = importlib.import_module("smcore.strategy.fundamental")
    fm.fetch_fundamentals_batch = lambda codes, *a, **k: {
        c: (fm._load_fund_cache(c) if hasattr(fm, "_load_fund_cache") else None) for c in codes}
except Exception:
    pass
try:
    nlm = importlib.import_module("smcore.strategy.name_lookup")
    nlm.lookup_stock_name = lambda c, *a, **k: (nlm._get_stock_name_map() or {}).get(str(c).zfill(6), "")
except Exception:
    pass
try:
    importlib.import_module("smcore.strategy.regime_filter")._get_hs300_close = lambda *a, **k: None
except Exception:
    pass
for mn in ("smcore.data.session", "smcore.strategy.sectors", "smcore.strategy.name_lookup",
           "smcore.strategy.fundamental"):
    try:
        m = importlib.import_module(mn)
        if hasattr(m, "login"):
            m.login = lambda *a, **k: False
    except Exception:
        pass

import smcore.strategy.adaptive_weights as AW  # noqa: E402
import smcore.strategy.factor_timing as FT  # noqa: E402

# ── 2) 性能：记忆化 factor_timing 的因果权重（纯函数，进程内复用）──
_cw_cache: dict = {}
_orig_cw, _orig_dr = FT._causal_weights, FT._day_records


def _cw(sd):
    if sd not in _cw_cache:
        _cw_cache[sd] = _orig_cw(sd)
    return _cw_cache[sd]


_dr_cache: dict = {}


def _dr(sd):
    if sd not in _dr_cache:
        _dr_cache[sd] = _orig_dr(sd)
    return _dr_cache[sd]


FT._causal_weights = _cw
FT._day_records = _dr

# ★ 关键性能修复（driver 内，语义等价）：
# `_apply_factor_timing` 每次调用都走 `apply_mask(weights, signal_date)`，而 `apply_mask`
# 内部会 `conviction_points()` —— **重算全部历史信号日的信念 IC 点**。历史从 16 天扩到 60 天后
# 这一步变成 O(60×) 的瓶颈（实测约 90s/信号日）。但 `conviction_points()` **与 signal_date 无关**
# （纯函数，只依赖 DAL/成交数据），故只需算一次、缓存复用。
_pts_cache: dict = {}


def _cached_aft(weights, signal_date=None):
    try:
        if "pts" not in _pts_cache:
            _pts_cache["pts"] = FT.conviction_points()
        masked = FT.apply_mask(weights, signal_date=signal_date, points=_pts_cache["pts"])
        pct = {s: round(float(masked.get(s, 0.0))) for s in AW.ALL_STRATEGIES}
        d = 100 - sum(pct.values())
        if d != 0:
            anchor = max(pct, key=pct.get)
            pct[anchor] = max(0, pct[anchor] + d)
        return pct
    except Exception:
        return weights


AW._apply_factor_timing = _cached_aft

# ── 3) 因子池加载：优先 hist_pools，其次生产目录 ──
import csv  # noqa: E402

from smcore.strategy.picks_loader import _load_scored_picks as _PROD_LOAD  # noqa: E402
from smcore.utils.code import format_stock_code  # noqa: E402


def _hist_load(factor, date_yyyymmdd, *, max_stale_days: int = 3):
    pth = HIST_POOLS / f"Stock-Selection-{factor}-{date_yyyymmdd}.csv"
    if not pth.exists():
        return _PROD_LOAD(factor, date_yyyymmdd, max_stale_days=max_stale_days)
    picks = {}
    with pth.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            c = format_stock_code(row.get("股票代码", ""))
            if not c:
                continue
            try:
                sc = float(row.get("综合分") or 0)
            except (TypeError, ValueError):
                sc = 0.0
            picks[c] = {"name": str(row.get("股票名称") or ""), "score": sc}
    return picks, date_yyyymmdd


FU._load_scored_picks = _hist_load
p("[离线] 全部补丁就绪；记忆化 factor_timing._causal_weights/_day_records")

# ── 4) 信号日 ──
parts = []
for f in sorted((SD / "k_data").glob("*.parquet")):
    d = pd.read_parquet(f, columns=["code", "date", "open", "close"])
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d[(d["date"] >= pd.Timestamp("2026-01-01")) & (d["date"] <= pd.Timestamp("2026-10-10"))]
    if not d.empty:
        parts.append(d)
K = pd.concat(parts, ignore_index=True)
K["code"] = K["code"].astype(str).str.zfill(6)
CAL = sorted(K["date"].dropna().unique())
IDX = {pd.Timestamp(d).strftime("%Y%m%d"): i for i, d in enumerate(CAL)}
OPENF = K.pivot_table(index="date", columns="code", values="open", aggfunc="last")
CLOSEF = K.pivot_table(index="date", columns="code", values="close", aggfunc="last")

all_days = [pd.Timestamp(d).strftime("%Y%m%d") for d in CAL]
end = "20260917"
sig = [d for d in all_days if d <= end][-args.days:]
p(f"[信号日] {len(sig)} 个：{sig[0]} .. {sig[-1]}")


# ── 5) 生成因子池 ──
if not args.skip_pools:
    import scripts.zoo_factor_strategy as ZF

    todo = [d for d in sig
            if len(list(HIST_POOLS.glob(f"Stock-Selection-*-{d}.csv"))) < 12]
    p(f"[因子池] 缺 {len(todo)}/{len(sig)} 天需生成（已有 {len(sig)-len(todo)} 天）")
    t0 = time.time()
    for i, d in enumerate(todo, 1):
        argv = sys.argv
        sys.argv = ["zoo", "--date", d, "--out-dir", str(HIST_POOLS)]
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):
                ZF.main()
        except Exception as exc:
            p(f"  !! {d}: {type(exc).__name__}: {exc}")
        finally:
            sys.argv = argv
        if i % 10 == 0 or i == len(todo):
            p(f"  池 {i}/{len(todo)}  {time.time()-t0:.0f}s")

# ── 6) 跑两 arm ──
def fwd(day, h, codes):
    ei = IDX.get(day)
    if ei is None or ei + 1 + h >= len(CAL):
        return pd.Series(dtype=float)
    o, c = OPENF.iloc[ei + 1], CLOSEF.iloc[ei + 1 + h]
    cc = [str(x).zfill(6) for x in codes]
    o, c = o.reindex(cc), c.reindex(cc)
    m = o.notna() & c.notna() & (o > 0)
    return ((c[m] / o[m] - 1) * 100).astype(float)


def mkt(day, h):
    ei = IDX.get(day)
    if ei is None or ei + 1 + h >= len(CAL):
        return None
    o, c = OPENF.iloc[ei + 1], CLOSEF.iloc[ei + 1 + h]
    m = o.notna() & c.notna() & (o > 0)
    return float(((c[m] / o[m] - 1) * 100).mean()) if m.any() else None


store = {}
for arm, on in (("mask_on", True), ("mask_off", False)):
    outdir = AB / arm
    outdir.mkdir(parents=True, exist_ok=True)
    AW.CONFIG.setdefault("factor_timing", {})["enabled"] = on
    dfs = {}
    t0 = time.time()
    for i, day in enumerate(sig, 1):
        f = outdir / f"Daily-Action-List-{day}.csv"
        if f.exists():
            d = pd.read_csv(f, dtype=str)
            if not d.empty:
                d["code"] = d["股票代码"].astype(str).str.zfill(6)
                dfs[day] = d
            continue
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):
                df, rep = FU.fuse_signals(day)
            if df is None or df.empty:
                continue
            df = df.copy()
            df["code"] = df["股票代码"].astype(str).str.zfill(6)
            df.to_csv(f, index=False, encoding="utf-8-sig")
            dfs[day] = df
        except Exception as exc:
            p(f"  !! {arm} {day}: {type(exc).__name__}: {exc}")
        if i % 10 == 0:
            p(f"  [{arm}] {i}/{len(sig)}  {time.time()-t0:.0f}s")
    store[arm] = dfs
    p(f"  [{arm}] 完成 {len(dfs)} 天  用时 {time.time()-t0:.0f}s")

# ── 7) 汇总 ──
p("")
p("=" * 100)
p("长样本 A/B：DAL 等权组合前向收益（次日开盘买 → 持有 H 日收盘卖）")
p("=" * 100)
p(f"  {'arm':<10}{'H':>4}{'天数':>6}{'绝对均%':>10}{'超额均%':>11}{'胜率%':>8}")
res = {}
for arm in store:
    for h in (1, 2, 3, 5):
        a_, e_ = [], []
        for day, df in store[arm].items():
            r = fwd(day, h, list(df["code"]))
            mk = mkt(day, h)
            if r.empty or mk is None:
                continue
            a_.append(r.mean())
            e_.append(r.mean() - mk)
        if a_:
            res[(arm, h)] = (a_, e_)
            p(f"  {arm:<10}{h:>4}{len(a_):>6}{np.mean(a_):>10.2f}{np.mean(e_):>11.2f}"
              f"{100*np.mean([x > 0 for x in a_]):>8.1f}")

p("")
p("=" * 100)
p("逐日配对（mask_off − mask_on，同信号日）")
p("=" * 100)
for h in (1, 2, 3, 5):
    rows = []
    for day in sorted(store["mask_on"]):
        if day not in store["mask_off"]:
            continue
        ra = fwd(day, h, list(store["mask_on"][day]["code"]))
        rb = fwd(day, h, list(store["mask_off"][day]["code"]))
        if ra.empty or rb.empty:
            continue
        rows.append((day, ra.mean(), rb.mean(), rb.mean() - ra.mean()))
    if not rows:
        continue
    D = pd.DataFrame(rows, columns=["day", "on", "off", "d"])
    t = D["d"].mean() / (D["d"].std() / np.sqrt(len(D))) if D["d"].std() else float("nan")
    p(f"  H={h}  n={len(D)}  均值Δ={D['d'].mean():+.3f}pp  中位Δ={D['d'].median():+.3f}pp  "
      f"t={t:+.2f}  off更好 {int((D['d']>0).sum())} / 更差 {int((D['d']<0).sum())}")

p("")
p("=" * 100)
p("构成对照（每日单策略命中数）+ 实测 edge")
p("=" * 100)
EDGE = {"Skew60": 6.70, "VRatio10_60": 4.76, "CVAmt60": 2.54, "VRatio20_120": 1.65,
        "Vol20": 0.82, "PVCorr20": 0.18, "DistLo10": -1.31, "Skew20": -1.72,
        "CVAmt20": -3.76, "PVCorr60": -10.72, "Illiq20": -9.90, "DistLo60": 0.0}
tab = {}
for arm in store:
    c = Counter()
    nd = max(len(store[arm]), 1)
    for day, df in store[arm].items():
        if "来源策略" in df.columns:
            for v in df["来源策略"].astype(str):
                if "/" not in v:
                    c[v] += 1
    tab[arm] = {k: v / nd for k, v in c.items()}
p(f"  {'因子':<15}{'实测edge':>9}{'mask_on/天':>11}{'mask_off/天':>12}{'倍数':>8}")
for k in sorted(set(tab.get("mask_on", {})) | set(tab.get("mask_off", {})),
                key=lambda x: -EDGE.get(x, 0)):
    a = tab.get("mask_on", {}).get(k, 0)
    b = tab.get("mask_off", {}).get(k, 0)
    p(f"  {k:<15}{EDGE.get(k, float('nan')):>9.2f}{a:>11.2f}{b:>12.2f}"
      f"{(b/a if a else float('inf')):>8.2f}")

LOG.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", LOG)
