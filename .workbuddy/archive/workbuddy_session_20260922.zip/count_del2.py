import subprocess, json, re

out = subprocess.run(
    ["gh", "api", "repos/benny1232123/Stocks-Master/git/trees/master?recursive=1"],
    capture_output=True, text=True, timeout=120)
data = json.loads(out.stdout)
print("truncated:", data.get("truncated"))
tree = data["tree"]
print("total tree entries:", len(tree))
paths = [t["path"] for t in tree if t["path"].startswith("stock_data/")]

def date_of(p):
    m = re.search(r"(\d{8})", p)
    return m.group(1) if m else "00000000"

CUT = "20260827"
bt_all = [p for p in paths if p.startswith("stock_data/Multi-Backtest-")]
dal_all = [p for p in paths if p.startswith("stock_data/Daily-Action-List-")]
bt_pre = [p for p in bt_all if date_of(p) < CUT]
dal_pre = [p for p in dal_all if date_of(p) < CUT]
print("DAL all:", len(dal_all), "| DAL pre-0827:", len(dal_pre))
print("BT  all:", len(bt_all),  "| BT  pre-0827:", len(bt_pre), "(dates:", len({date_of(p) for p in bt_pre}), ")")
print("TOTAL to delete (BT+DAL pre):", len(bt_pre) + len(dal_pre))
# sanity: any pre-0827 DAL whose date parses weird
weird = [p for p in dal_pre if date_of(p) == "00000000"]
print("weird DAL (no date):", len(weird), weird[:3])
