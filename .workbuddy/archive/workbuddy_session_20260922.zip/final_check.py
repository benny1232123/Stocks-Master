"""最终检查：render.yaml 解析 + 两个 requirements 的一致性。"""
from __future__ import annotations

import pathlib
import re

ROOT = pathlib.Path(r"E:\Stocks-Master")

print("=== render.yaml 解析 ===")
try:
    import yaml  # type: ignore

    doc = yaml.safe_load((ROOT / "render.yaml").read_text(encoding="utf-8"))
    svc = doc["services"][0]
    print(f"  ✅ YAML 解析成功")
    print(f"  name         = {svc['name']}")
    print(f"  plan         = {svc['plan']}")
    print(f"  buildCommand = {svc['buildCommand']}")
    print(f"  startCommand = {svc['startCommand']}")
    env = {e["key"]: e.get("value") for e in svc["envVars"]}
    print(f"  envVars      = {sorted(env)}")
    assert "requirements-cloud.txt" in svc["buildCommand"], "buildCommand 未指向云端依赖文件"
    print("  ✅ buildCommand 指向 requirements-cloud.txt")
except ImportError:
    print("  (pyyaml 未安装，退化为文本检查)")
    txt = (ROOT / "render.yaml").read_text(encoding="utf-8")
    assert "requirements-cloud.txt" in txt
    print("  ✅ 文本检查：buildCommand 指向 requirements-cloud.txt")


def parse_reqs(path: pathlib.Path) -> set[str]:
    out = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.split("#")[0].strip()
        if not line:
            continue
        name = re.split(r"[<>=~!\[]", line)[0].strip().lower()
        if name:
            out.add(name)
    return out


full = parse_reqs(ROOT / "requirements.txt")
cloud = parse_reqs(ROOT / "requirements-cloud.txt")

print("\n=== 两个依赖清单 ===")
print(f"  requirements.txt       ({len(full)}): {sorted(full)}")
print(f"  requirements-cloud.txt ({len(cloud)}): {sorted(cloud)}")

removed = sorted(full - cloud)
added = sorted(cloud - full)
print(f"\n  云端移除: {removed}")
print(f"  云端新增: {added or '（无）'}")

print("\n=== 云端清单必须保留的核心依赖 ===")
for must in ["fastapi", "uvicorn", "pandas", "httpx", "requests", "pyarrow", "baostock"]:
    ok = must in cloud
    print(f"  {'✅' if ok else '❌'} {must}")

print("\n=== 云端清单不应含有（已移除）===")
for bad in ["akshare", "backtrader", "matplotlib", "supabase", "pillow", "cos-python-sdk-v5"]:
    ok = bad not in cloud
    print(f"  {'✅' if ok else '❌'} {bad}")

print("\n=== CI workflow 是否仍指向 requirements.txt ===")
wf_dir = ROOT / ".github" / "workflows"
if wf_dir.exists():
    for wf in sorted(wf_dir.glob("*.yml")):
        txt = wf.read_text(encoding="utf-8", errors="ignore")
        hits = [m for m in re.findall(r"requirements[\w.-]*\.txt", txt)]
        print(f"  {wf.name}: {sorted(set(hits)) or '（未引用 requirements）'}")
else:
    print("  (未找到 .github/workflows)")
