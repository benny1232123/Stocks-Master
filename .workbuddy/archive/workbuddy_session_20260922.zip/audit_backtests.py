import subprocess, base64, csv, io, json, sys

SLUG = "benny1232123/Stocks-Master"
DATES = ["20260827","20260828","20260831","20260901","20260902","20260903",
         "20260904","20260907","20260908","20260909","20260910","20260911",
         "20260914","20260915","20260916","20260917"]
A_BATCH = ["pvcorr","cvamt","skew","vratio","distlo","vol20","illiq"]
LEGACY = ["cctv","theme","boll","relativity","momentum"]

def gh(args):
    r = subprocess.run(["gh"]+args, capture_output=True, text=True)
    return r.returncode, r.stdout, r.stderr

def classify(s):
    s = (s or "").lower()
    if not s:
        return "EMPTY"
    is_legacy = any(t in s for t in LEGACY)
    is_abatch = any(t in s for t in A_BATCH)
    if is_legacy and not is_abatch:
        return "STALE(legacy)"
    if is_abatch and not is_legacy:
        return "OK(A-batch)"
    return "AMBIGUOUS"

print(f"{'date':<12}{'status':<16}{'run_date':<12}strategies")
for d in DATES:
    code, out, err = gh(["api", f"repos/{SLUG}/contents/stock_data/Multi-Backtest-{d}-summary.csv", "--jq", ".content"])
    if code != 0 or not out.strip():
        print(f"{d:<12}{'NO FILE':<16}{'-':<12}(no backtest csv)")
        continue
    try:
        raw = base64.b64decode(out.strip()).decode("utf-8-sig")
    except Exception as e:
        print(f"{d:<12}{'DECODE ERR':<16}{'-':<12}{e}")
        continue
    row = next(csv.DictReader(io.StringIO(raw)))
    strat = row.get("strategies","")
    run_date = row.get("run_date","")
    print(f"{d:<12}{classify(strat):<16}{run_date:<12}{strat}")
