# -*- coding: utf-8 -*-
"""回测体检：定位「回测数据不太好」的结构性原因（全离线，只读）。

产出：
  1) 产物盘点：stock_data 顶层 / archive 下各类回测 CSV 的数量与最新日期
  2) 最近期末的 Multi-Backtest trades 汇总：逐笔收益分布 / 胜率 / 权重桶 / 来源策略桶
  3) 组合口径 vs 等权口径（隔离「权重」的影响）
  4) 持有期衰减（收益是否随持有天数递减）
  5) 按信号日的收益序列 vs 沪深300
"""
import glob
import os
import re
import statistics as st
import sys
from collections import defaultdict
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_bt_probe_out.txt"

lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


# ── 1) 产物盘点 ──
p("=" * 78)
p("1) 回测产物盘点（stock_data 顶层 + archive）")
p("=" * 78)
for label, pat in [
    ("顶层 Multi-Backtest-*-summary", str(SD / "Multi-Backtest-*-summary.csv")),
    ("顶层 Multi-Backtest-*-trades", str(SD / "Multi-Backtest-*-trades.csv")),
    ("顶层 Multi-Backtest-*-equity", str(SD / "Multi-Backtest-*-equity.csv")),
    ("archive v1 trades", str(SD / "archive" / "*" / "Multi-Backtest-*-trades.csv")),
    ("顶层 Daily-Action-List", str(SD / "Daily-Action-List-*.csv")),
    ("顶层 Historical-Backtest-summary", str(SD / "Historical-Backtest-*-summary.csv")),
]:
    fs = sorted(glob.glob(pat))
    dates = [m.group(1) for f in fs if (m := re.search(r"(\d{8})", Path(f).name))]
    p(f"  {label:<34} n={len(fs):<5} 最新={max(dates) if dates else '—'}")
    # 打印顶层目录名，便于确认结构
for sub in ("archive", "strategy_improve", "web_data"):
    d = SD / sub
    if d.is_dir():
        p(f"  [dir] stock_data/{sub}/ -> {len(list(d.iterdir()))} 项")

# ── 2) 汇总最近期末的 trades ──
p("")
p("=" * 78)
p("2) 逐笔成交（Multi-Backtest-*-trades.csv）分布")
p("=" * 78)
trade_files = sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv")))
if not trade_files:
    trade_files = sorted(glob.glob(str(SD / "archive" / "*" / "Multi-Backtest-*-trades.csv")))
p(f"  使用 {len(trade_files)} 个 trades 文件")
if trade_files:
    p(f"  日期跨度: {Path(trade_files[0]).name} .. {Path(trade_files[-1]).name}")

frames = []
for f in trade_files:
    try:
        df = pd.read_csv(f, dtype=str)
    except Exception as exc:
        p(f"  [skip] {Path(f).name}: {exc}")
        continue
    tag = re.search(r"Multi-Backtest-(\d{8})", Path(f).name).group(1)
    df["_batch"] = tag
    frames.append(df)

if not frames:
    p("  !! 无可用成交数据")
    OUT.write_text("\n".join(lines), encoding="utf-8")
    sys.exit(0)

T = pd.concat(frames, ignore_index=True)
p(f"  列: {list(T.columns)}")
rc = next((c for c in T.columns if c in ("return_pct", "收益%", "ret_pct", "return")), None)
p(f"  收益列 = {rc}")
if rc:
    T[rc] = pd.to_numeric(T[rc], errors="coerce")
    r = T[rc].dropna()
    p(f"  总笔数={len(T)}  有效收益={len(r)}")
    p(f"  mean={r.mean():.3f}%  median={r.median():.3f}%  std={r.std():.3f}%")
    p(f"  >0 占比={100 * (r > 0).mean():.1f}%  显著赢(>3%)={100 * (r > 3).mean():.1f}%"
      f"  显著输(<-3%)={100 * (r < -3).mean():.1f}%")
    p(f"  分位: p5={r.quantile(.05):.2f} p25={r.quantile(.25):.2f} "
      f"p50={r.median():.2f} p75={r.quantile(.75):.2f} p95={r.quantile(.95):.2f}")
    p(f"  均值贡献分解：平均盈利={r[r > 0].mean():.2f}%(n={int((r > 0).sum())}) "
      f"平均亏损={r[r < 0].mean():.2f}%(n={int((r < 0).sum())})")

    # 权重桶
    wc = next((c for c in T.columns if c in ("weight", "权重", "target_weight")), None)
    if wc:
        T[wc] = pd.to_numeric(T[wc], errors="coerce")
        q = T[wc].dropna()
        if len(q):
            hi, lo = q.quantile(.75), q.quantile(.25)
            sub = T.dropna(subset=[wc, rc])
            hi_m = sub[sub[wc] >= hi][rc].mean()
            lo_m = sub[sub[wc] <= lo][rc].mean()
            p(f"  权重桶: 高权重(>=p75={hi:.3f}) 平均 {hi_m:.3f}%  vs  "
              f"低权重(<=p25={lo:.3f}) 平均 {lo_m:.3f}%  → 差 {hi_m - lo_m:+.3f}pp")
            p(f"  权重-收益 相关: {sub[wc].corr(sub[rc]):.4f}")

    # 来源策略桶
    sc = next((c for c in T.columns if c in ("strategy", "策略", "source", "strategies")), None)
    if sc:
        p("  按来源策略：")
        g = T.dropna(subset=[rc]).groupby(sc)[rc].agg(["count", "mean", "median"])
        for k, row in g.sort_values("mean").iterrows():
            p(f"    {str(k)[:28]:<30} n={int(row['count']):<5} "
              f"mean={row['mean']:+.2f}%  median={row['median']:+.2f}%")

    # 持有期衰减
    hc = next((c for c in T.columns if c in ("hold_days", "持有天数", "days")), None)
    if hc:
        T[hc] = pd.to_numeric(T[hc], errors="coerce")
        sub = T.dropna(subset=[hc, rc])
        if len(sub):
            p("  持有期 vs 收益：")
            for d, row in sub.groupby(sub[hc].round().astype("Int64"))[rc].agg(
                    ["count", "mean"]).iterrows():
                p(f"    hold={d:>3} 天  n={int(row['count']):<5} mean={row['mean']:+.3f}%")

    p("  按批次（信号日）收益：")
    g = T.dropna(subset=[rc]).groupby("_batch")[rc].agg(["count", "mean", "median"])
    for k, row in g.tail(15).iterrows():
        p(f"    {k}  n={int(row['count']):<4} mean={row['mean']:+.3f}%  median={row['median']:+.3f}%")

# ── 5) daily_summary 对照 ──
p("")
p("=" * 78)
p("5) 网站口径 daily_summary.json")
p("=" * 78)
import json  # noqa: E402
ds = SD / "web_data" / "daily_summary.json"
if ds.exists():
    p(json.dumps(json.loads(ds.read_text(encoding="utf-8")), ensure_ascii=False, indent=1))

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
