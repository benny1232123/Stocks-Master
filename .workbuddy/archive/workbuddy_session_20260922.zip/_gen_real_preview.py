"""用**真实持仓 + 真实行情**（总资产=30000）生成持仓日报预览 HTML。

无副作用：不写 stock_data/、不发邮件、不推送；仅供确认新版口径的实际观感。
"""
import importlib
import os
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# 显式加载 .env —— shell 无 SUPABASE_* 时 TradeRepository 会 fallback 到
# 空的本地 trades.json（0 条），静默跑出「无持仓」的假结果。
_ENV = ROOT / ".env"
if _ENV.exists():
    for _ln in _ENV.read_text(encoding="utf-8").splitlines():
        _ln = _ln.strip()
        if not _ln or _ln.startswith("#") or "=" not in _ln:
            continue
        _k, _, _v = _ln.partition("=")
        _k, _v = _k.strip(), _v.strip().strip('"').strip("'")
        if _k and _k not in os.environ:
            os.environ[_k] = _v

os.environ["HOLDINGS_FUND_REFRESH"] = "0"     # 只读缓存，不联网回填基本面
os.environ.pop("ACCOUNT_CASH", None)         # 走配置里的 account_total = 30000
os.environ["RECENT_DAYS"] = "0"

from smcore.analysis import (  # noqa: E402
    adaptive_sizing_context, build_stock_analysis, position_sizing_recommendation,
)
from smcore.config.defaults import POSITION_SIZING_CONFIG  # noqa: E402
from smcore.holdings import compute_fifo_positions, load_trades  # noqa: E402

N = importlib.import_module("scripts.notify_holdings_analysis")

AS_OF = date(2026, 9, 21)
TODAY = "20260921"
OUT = ROOT / ".workbuddy" / f"holdings_preview_{TODAY}.html"

pos_df, _ = compute_fifo_positions(load_trades())
codes = list(dict.fromkeys(str(c) for c in pos_df["代码"].tolist()))

pos_map = {}
for _, r in pos_df.iterrows():
    c = str(r["代码"])
    q = float(r["数量"])
    try:
        _nm = N._resolve_name(c).get("name", "") or ""
    except Exception:
        _nm = ""
    p = pos_map.setdefault(c, {"name": _nm, "qty": 0.0, "cost": 0.0, "_amt": 0.0})
    p["qty"] += q
    p["_amt"] += float(r["成本价"]) * q
for p in pos_map.values():
    p["cost"] = p["_amt"] / p["qty"] if p["qty"] else 0.0
    p.pop("_amt", None)

entries = []
for c in codes:
    try:
        a = build_stock_analysis(c, as_of=AS_OF, fundamentals_offline=True)
    except Exception as exc:
        a = {"code": c, "error": f"{type(exc).__name__}: {exc}"}
    entries.append((c, a, pos_map[c]))

ok = [(c, a, p) for c, a, p in entries if not a.get("error")]
hv = sum(a["latest"]["close"] * p["qty"] for _, a, p in ok)
total, cash, basis = N._resolve_denominator(hv, POSITION_SIZING_CONFIG)
equity_total = total if basis != "holdings_only" else None
_ADAPTIVE = adaptive_sizing_context(
    codes, as_of=AS_OF, cfg=POSITION_SIZING_CONFIG,
    analyses={c: a for c, a, p in ok},
)

stock_list = [(a, p) for _, a, p in ok]
summary = N.build_portfolio_summary(stock_list)
summary["total_value"] = hv          # 与 sizing 分母口径一致（真实持仓市值）
summary["total_cost"] = sum(p["cost"] * p["qty"] for _, _, p in ok)
summary["total_pnl"] = hv - summary["total_cost"]
summary["total_pnl_pct"] = summary["total_pnl"] / summary["total_cost"] * 100

cards = []
for c, a, p in entries:
    if a.get("error"):
        cards.append(
            f'<div class="card"><div class="card-head"><span class="code">{c}</span></div>'
            f'<div class="err">⚠️ {a["error"]}</div></div>'
        )
        continue
    sizing = position_sizing_recommendation(
        a, p, total, cfg=POSITION_SIZING_CONFIG, n_holdings=len(codes),
        adaptive=_ADAPTIVE
    )
    cards.append(N.render_stock_html(a, p, sizing))

if _ADAPTIVE.get("enabled"):
    _an = (f"市场状态 <b>{_ADAPTIVE.get('regime')}</b>"
           f"（强度 {_ADAPTIVE.get('regime_strength')}）→ 总仓位目标 "
           f"<b>{(_ADAPTIVE.get('equity_ratio') or 0) * 100:.1f}%</b>；"
           f"个股权重方法 <b>{_ADAPTIVE.get('weight_method')}</b>")
else:
    _an = f"静态口径（自适应未启用：{_ADAPTIVE.get('note') or '—'}）"
cards.insert(0, f'<div class="card"><div class="sig">📊 自适应仓位：{_an}</div></div>')

news_html = N.render_news_surface_html(N.build_news_surface())
if news_html:
    cards.insert(0, news_html)

doc = N.build_html_report(
    TODAY, "真实持仓预览（本地离线生成）",
    f"成功 {len(ok)} 只 / 失败 {len(entries) - len(ok)} 只 / 共 {len(entries)} 只",
    "\n".join(cards),
    N.render_summary_html(summary, len(ok), cash=cash, equity_total=equity_total),
)
OUT.write_text(doc, encoding="utf-8")
print(f"分母[{basis}] = 持仓市值 {hv:,.0f} + 现金 {cash:,.0f} = 总资产 {total:,.0f}")
print(f"自适应仓位[{_ADAPTIVE['source']}]：regime {_ADAPTIVE['regime']}"
      f"（强度 {_ADAPTIVE['regime_strength']}）→ 总仓位 "f"{(_ADAPTIVE['equity_ratio'] or 0) * 100:.1f}%；权重法 {_ADAPTIVE['weight_method']}")
print("预览已写出:", OUT)
