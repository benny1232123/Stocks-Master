# -*- coding: utf-8 -*-
"""批量重跑历史 CCTV 日期（Tier-1 NLP 新代码）。

用法: python .workbuddy/cctv_rerun_all.py [--start YYYYMMDD] [--limit N] [--workers 2]
说明:
- 数据源 = 本地 *_news.csv 新闻缓存（历史 akshare 无法重拉，故只跑有缓存的日期）
- --disable-extra-news --disable-sw-industry 保证纯本地、无网络依赖
- 结果写入 stock_data/CCTV-*.csv，空个股池日期会落空文件标记
- 日志写入 .workbuddy/cctv_rerun.log，汇总写入 .workbuddy/cctv_rerun_summary.csv
"""
import argparse
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

PY = r"E:\Anaconda\python.exe"
ROOT = Path(r"E:\Stocks-Master")


def get_dates(start=None, limit=None):
    dates = sorted(p.name.replace("_news.csv", "") for p in (ROOT / "stock_data").glob("*_news.csv"))
    if start:
        dates = [d for d in dates if d >= start]
    if limit:
        dates = dates[:limit]
    return dates


def run_one(date_str):
    t0 = time.time()
    cmd = [
        PY, "-m", "smcore.strategies.cctv",
        "--date", date_str,
        "--disable-extra-news",
        "--disable-sw-industry",
        "--top-n", "15",
    ]
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=300, cwd=str(ROOT), encoding="utf-8", errors="replace"
        )
        out = (proc.stdout or "") + (proc.stderr or "")
        stock_pool = ROOT / "stock_data" / f"CCTV-Sector-Stock-Pool-{date_str}.csv"
        hot = ROOT / "stock_data" / f"CCTV-Hot-Sectors-{date_str}.csv"
        pool_count = None
        hot_count = None
        if stock_pool.exists():
            import csv
            with open(stock_pool, encoding="utf-8-sig") as f:
                pool_count = sum(1 for _ in csv.DictReader(f))
        if hot.exists():
            import csv
            with open(hot, encoding="utf-8-sig") as f:
                hot_count = sum(1 for _ in csv.DictReader(f))
        ok = proc.returncode == 0 and hot_count is not None and hot_count > 0
        return {
            "date": date_str, "ok": ok, "rc": proc.returncode, "pool_count": pool_count,
            "hot_count": hot_count, "elapsed": round(time.time() - t0, 1),
            "tail": (out.strip().splitlines()[-1] if out.strip() else ""),
        }
    except Exception as exc:
        return {"date": date_str, "ok": False, "rc": -1, "pool_count": None, "hot_count": None,
                "elapsed": round(time.time() - t0, 1), "tail": f"EXC: {exc}"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default="")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--workers", type=int, default=2)
    args = ap.parse_args()

    dates = get_dates(args.start, args.limit)
    print(f"待重跑日期: {len(dates)} 个 ({dates[0] if dates else '-'} ~ {dates[-1] if dates else '-'})", flush=True)

    log_path = ROOT / ".workbuddy" / "cctv_rerun.log"
    log_f = open(log_path, "a", encoding="utf-8")
    log_f.write(f"\n===== 批量重跑开始 {time.strftime('%Y-%m-%d %H:%M:%S')} workers={args.workers} =====\n")

    results = []
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(run_one, d): d for d in dates}
        for fut in as_completed(futs):
            r = fut.result()
            results.append(r)
            mark = "OK " if r["ok"] else "FAIL"
            line = (f"[{mark}] {r['date']} rc={r['rc']} 板块={r['hot_count']} 个股池={r['pool_count']} "
                    f"耗时={r['elapsed']}s {r['tail'][:80]}")
            print(line, flush=True)
            log_f.write(line + "\n")
            log_f.flush()

    results.sort(key=lambda x: x["date"])
    ok_n = sum(1 for r in results if r["ok"])
    nonempty_pool = sum(1 for r in results if r.get("pool_count"))
    nonempty_hot = sum(1 for r in results if r.get("hot_count"))
    print(f"\n完成: {ok_n}/{len(results)} OK；板块非空 {nonempty_hot}/{len(results)}；个股池非空 {nonempty_pool}/{len(results)}", flush=True)

    import csv
    summary_path = ROOT / ".workbuddy" / "cctv_rerun_summary.csv"
    with open(summary_path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["date", "ok", "rc", "pool_count", "hot_count", "elapsed", "tail"])
        w.writeheader()
        w.writerows(results)
    print(f"汇总: {summary_path}", flush=True)
    log_f.write(f"===== 完成 {ok_n}/{len(results)} OK, 个股池非空 {nonempty_pool} =====\n")
    log_f.close()


if __name__ == "__main__":
    main()
