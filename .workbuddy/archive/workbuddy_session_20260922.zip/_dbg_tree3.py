"""确认 404 是否由 .github/workflows/ 路径引起，并检查 token scope。"""
import json
import subprocess

REPO = "benny1232123/Stocks-Master"


def gh(args, payload=None, label=""):
    cmd = ["gh", "api"] + args
    inp = None
    if payload is not None:
        cmd += ["--input", "-"]
        inp = json.dumps(payload)
    r = subprocess.run(cmd, input=inp, capture_output=True, text=True)
    tag = "OK " if r.returncode == 0 else "ERR"
    print(f"[{tag}] {label}: {(r.stdout.strip() or r.stderr.strip())[:200]}")
    return r


head = json.loads(gh([f"repos/{REPO}/git/ref/heads/master"]).stdout)["object"]["sha"]
base = json.loads(gh([f"repos/{REPO}/git/commits/{head}"]).stdout)["tree"]["sha"]
wf_blob = "db4a9f24a266ef3c42eb287208deecb627cfbe0c"   # 上一轮已建好的 workflow blob

# T3: 只放 workflow 一个 entry
gh([f"repos/{REPO}/git/trees", "--method", "POST"],
   {"base_tree": base, "tree": [{"path": ".github/workflows/daily-holdings.yml",
                                 "mode": "100644", "type": "blob", "sha": wf_blob}]},
   "T3 只含 workflow entry")
gh([f"repos/{REPO}/git/trees", "--method", "POST"],
   {"base_tree": base, "tree": [{"path": ".github/zz_probe.yml",
                                 "mode": "100644", "type": "blob", "sha": wf_blob}]},
   "T4 .github/ 下非 workflows 路径")
# T5: 6 个 entry，但第 6 个换成普通路径（排除“数量”因素）
rb = json.loads(gh([f"repos/{REPO}/contents/Readme.md"]).stdout)["sha"]
six = [{"path": "Readme.md", "mode": "100644", "type": "blob", "sha": rb} for _ in range(5)]
six.append({"path": "zz_probe6.txt", "mode": "100644", "type": "blob", "sha": rb})
gh([f"repos/{REPO}/git/trees", "--method", "POST"], {"base_tree": base, "tree": six},
   "T5 6 entries 非 workflow")

print("\n--- gh auth status ---")
r = subprocess.run(["gh", "auth", "status"], capture_output=True, text=True)
print(r.stdout.strip() or r.stderr.strip())
