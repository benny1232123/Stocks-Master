"""检测关键文件的换行符风格，避免编辑后造出全文 diff。"""
from __future__ import annotations

import pathlib

for p in [
    r"E:\Stocks-Master\smcore\strategies\__init__.py",
    r"E:\Stocks-Master\backend\main.py",
    r"E:\Stocks-Master\render.yaml",
]:
    b = pathlib.Path(p).read_bytes()
    crlf = b.count(b"\r\n")
    lf = b.count(b"\n") - crlf
    print(f"{p}\n   size={len(b)}B  CRLF={crlf}  bare-LF={lf}  -> {'CRLF' if crlf and not lf else ('LF' if lf and not crlf else 'MIXED')}")
