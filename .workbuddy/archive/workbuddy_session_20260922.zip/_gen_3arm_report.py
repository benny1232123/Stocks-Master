# -*- coding: utf-8 -*-
"""三 arm 对比报告：mask_on(buggy) / mask_off(关) / mask_fixed(修复后)。
从 .workbuddy/hist_ab/<arm>/ 落盘 DAL 现算前向收益 + 构成，输出 HTML。
"""
import pathlib, glob, time
import numpy as np
import pandas as pd

ROOT = pathlib.Path(r"E:\Stocks-Master")
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "mask_3arm_20260921.html"

_T0 = time.time()
parts = []
for f in sorted((SD / "k_data").glob("*.parquet")):
    d = pd.read_parquet(f, columns=["code", "date", "open", "close"])
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d[(d["date"] >= pd.Timestamp("2026-01-01")) & (d["date"] <= pd.Timestamp("2026-10-10"))]
    if not d.empty:
        parts.append(d)
K = pd.concat(parts, ignore_index=True)
K["code"] = K["code"].astype(str).str.zfill(6)
CAL = sorted(K["date"].dropna().unique())
IDX = {pd.Timestamp(d).strftime("%Y%m%d"): i for i, d in enumerate(CAL)}
OPENF = K.pivot_table(index="date", columns="code", values="open", aggfunc="last")
CLOSEF = K.pivot_table(index="date", columns="code", values="close", aggfunc="last")
print(f"[行情] {len(CAL)} 日  用时 {time.time()-_T0:.0f}s", flush=True)


def fwd(day, h, codes):
    ei = IDX.get(day)
    if ei is None or ei + 1 + h >= len(CAL):
        return pd.Series(dtype=float)
    o, c = OPENF.iloc[ei + 1], CLOSEF.iloc[ei + 1 + h]
    cc = [str(x).zfill(6) for x in codes]
    m = o.reindex(cc).notna() & c.reindex(cc).notna() & (o.reindex(cc) > 0)
    return ((c.reindex(cc)[m] / o.reindex(cc)[m] - 1) * 100).astype(float)


def mkt(day, h):
    ei = IDX.get(day)
    if ei is None or ei + 1 + h >= len(CAL):
        return None
    o, c = OPENF.iloc[ei + 1], CLOSEF.iloc[ei + 1 + h]
    m = o.notna() & c.notna() & (o > 0)
    return float(((c[m] / o[m] - 1) * 100).mean()) if m.any() else None


def load(arm):
    dfs = {}
    for f in sorted(glob.glob(str(ROOT / ".workbuddy" / "hist_ab" / arm / "Daily-Action-List-*.csv"))):
        day = pathlib.Path(f).name[-12:-4]
        d = pd.read_csv(f, dtype=str)
        if d.empty:
            continue
        d["code"] = d["股票代码"].astype(str).str.zfill(6)
        dfs[day] = d
    return dfs


def fwd_table(dfs):
    res = {}
    for h in (1, 2, 3, 5):
        a_, e_ = [], []
        for day, df in dfs.items():
            r = fwd(day, h, list(df["code"]))
            mk = mkt(day, h)
            if r.empty or mk is None:
                continue
            a_.append(r.mean()); e_.append(r.mean() - mk)
        res[h] = (a_, e_) if a_ else None
    return res


def composition(dfs):
    from collections import Counter
    c = Counter(); nd = max(len(dfs), 1)
    for day, df in dfs.items():
        if "来源策略" in df.columns:
            for v in df["来源策略"].astype(str):
                if "/" not in v:
                    c[v] += 1
    return {k: c.get(k, 0) / nd for k in c}


EDGE = {"Skew60": 6.70, "VRatio10_60": 4.76, "CVAmt60": 2.54, "VRatio20_120": 1.65,
        "Vol20": 0.82, "PVCorr20": 0.18, "DistLo10": -1.31, "Skew20": -1.72,
        "CVAmt20": -3.76, "PVCorr60": -10.72, "Illiq20": -9.90, "DistLo60": 0.0}

arms = {"mask_on": "mask_on（buggy）", "mask_off": "mask_off（关闭）", "mask_fixed": "mask_fixed（修复后）"}
data = {k: load(k) for k in arms}
ftab = {k: fwd_table(v) for k, v in data.items()}
comp = {k: composition(v) for k, v in data.items()}

# ── 渲染 ──
def fwd_rows(res):
    out = []
    for h in (1, 2, 3, 5):
        a, e = res[h]
        if not a:
            continue
        wr = 100 * np.mean([x > 0 for x in a])
        out.append(f"<tr><td>H={h}</td><td>{len(a)}</td><td class='num'>{np.mean(a):+.2f}</td>"
                   f"<td class='num'>{np.mean(e):+.2f}</td><td class='num'>{wr:.1f}</td></tr>")
    return "\n".join(out)

def comp_rows():
    out = []
    keys = sorted(set().union(*[set(c) for c in comp.values()]), key=lambda x: -EDGE.get(x, 0))
    for k in keys:
        vals = [comp[a].get(k, 0) for a in arms]
        best = max(vals)
        cells = "".join(
            f"<td class='num {('pos' if v==best and best>0 else '')}'>{v:.2f}</td>" for v in vals)
        out.append(f"<tr><td>{k}</td><td class='num'>{EDGE.get(k,float('nan')):+.2f}</td>{cells}</tr>")
    return "\n".join(out)

HTML = f"""<!doctype html><html lang=zh><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>factor_timing 三 arm 对比</title>
<style>
*{{box-sizing:border-box}}
body{{font-family:-apple-system,'Segoe UI',Roboto,'PingFang SC','Microsoft YaHei',sans-serif;
background:#0f1115;color:#e6e8eb;margin:0;padding:32px;line-height:1.6}}
.wrap{{max-width:1100px;margin:0 auto}}
h1{{font-size:24px;margin:0 0 4px}}
.sub{{color:#8b929c;font-size:13px;margin-bottom:24px}}
.card{{background:#171a21;border:1px solid #262b35;border-radius:12px;padding:20px 22px;margin:18px 0}}
.card h2{{font-size:17px;margin:0 0 12px;color:#cdd3dc}}
table{{width:100%;border-collapse:collapse;font-size:13px;margin:8px 0}}
th,td{{padding:7px 10px;text-align:left;border-bottom:1px solid #232833}}
th{{color:#9aa3af;font-weight:600}}
td.num{{text-align:right;font-variant-numeric:tabular-nums}}
.pos{{color:#4ade80}}.neg{{color:#f87171}}
.note{{background:#1d2230;border-left:3px solid #3b82f6;padding:10px 14px;border-radius:6px;
font-size:13px;color:#c4ccd6;margin:12px 0}}
.tag{{display:inline-block;padding:2px 8px;border-radius:6px;font-size:12px;margin-left:8px}}
.tag.ok{{background:#14321f;color:#4ade80}}.tag.bad{{background:#3a1518;color:#f87171}}
.tag.warn{{background:#3a2a12;color:#fbbf24}}
</style></head><body><div class=wrap>
<h1>factor_timing mask：三 arm 前向对比</h1>
<div class=sub>离线重跑融合（零联网）· 60 信号日 × 50 只/天 · 唯一变量 = mask 判据
· mask_on=buggy（旧代码）/ mask_off=关闭 / mask_fixed=修复后（当前生产）· 生成于 2026-09-21</div>

<div class=note><b>核心结论：</b>① <b>buggy 最差</b>（惩罚好因子）；② <b>mask_fixed ≈ mask_off</b>
（都按 edge 保留好因子）——证明修复消除了误杀，且未引入更差行为；③ 三者超额<b>全为负</b>，
修复是<b>正确性修复</b>（让这层做它该做的：只杀真死因子），不是收益修复。</div>

<div class=card><h2>① 前向收益（DAL 等权 · 次日开盘买 → 持有 H 日收盘卖 · 超额 vs 全市场等权）</h2>
<table><tr><th>arm</th><th>H</th><th>天数</th><th>绝对均%</th><th>超额均%</th><th>胜率%</th></tr>
{''.join(f"<tr><td rowspan=4>{arms[a]}</td>{fwd_rows(ftab[a]).replace('<tr>','</tr><tr>').replace('</tr><tr><td>H','<td>H')}</tr>" for a in arms)}
</table>
</div>

<div class=card><h2>② 构成对照（每日单策略命中数 / 天）+ 实测 edge</h2>
<table><tr><th>因子</th><th>实测 edge</th><th>mask_on</th><th>mask_off</th><th>mask_fixed</th></tr>
{comp_rows()}
</table>
<div class=note><span class="tag ok">修复生效</span>mask_fixed 的构成与 mask_off 高度一致
（强正 edge 因子 Skew60/VRatio10_60 都被保留，而非像 buggy 那样被清零）；
buggy 列则反向（好因子被压、坏因子被留）。说明修复消除了"误杀好因子"的回路。</div>
</div>

<div class=card><h2>③ 判定</h2>
<table><tr><th>维度</th><th>buggy</th><th>mask_off</th><th>mask_fixed</th></tr>
<tr><td>机制正确性</td><td class=bad>反向筛选</td><td class=ok>对齐 edge</td><td class=ok>对齐 edge</td></tr>
<tr><td>前向 P&L</td><td class=neg>最差</td><td class=pos>基准</td><td>≈ off</td></tr>
<tr><td>风险</td><td>—</td><td>去掉一层</td><td>保留层但只杀真死因子</td></tr>
</table>
<div class=note><b>推荐：</b>生产 `enabled=true` 现跑 <b>mask_fixed</b>（修复后逻辑）——既保留这层"杀真死因子"
的正当职责，又不再误杀好因子。若仍保守，可设 `enabled=false`（=mask_off）作零风险 fallback；
二者预期收益相近，差异只在"是否额外抑制被证据证伪的坏因子"。</div>
</div></div></body></html>"""

OUT.write_text(HTML, encoding="utf-8")
print("WROTE", OUT, len(HTML), "bytes")
