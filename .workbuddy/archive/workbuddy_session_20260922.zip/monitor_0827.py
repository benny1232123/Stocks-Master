import subprocess, time, csv, io, json, base64, sys

RUN_ID = "35367630789"
SLUG = "benny1232123/Stocks-Master"
DATE = "20260827"
OUT = r"E:\Stocks-Master\.workbuddy\realign_0827_verify.txt"
A_BATCH = ["pvcorr", "cvamt", "skew", "vratio", "distlo", "vol20", "illiq"]
LEGACY = ["cctv", "theme", "boll", "relativity", "momentum"]


def gh(args):
    r = subprocess.run(["gh"] + args, capture_output=True, text=True)
    return r.returncode, r.stdout, r.stderr


def fetch_strategies():
    code, out, err = gh(["api", f"repos/{SLUG}/contents/stock_data/Multi-Backtest-{DATE}-summary.csv", "--jq", ".content"])
    if code != 0:
        return None, f"fetch failed rc={code}: {err.strip()}"
    try:
        raw = base64.b64decode(out.strip()).decode("utf-8-sig")
    except Exception as e:
        return None, f"b64/decode error: {e}"
    row = next(csv.DictReader(io.StringIO(raw)))
    return row.get("strategies", ""), None


def main():
    deadline = time.time() + 3 * 3600
    last = ""
    while time.time() < deadline:
        code, out, err = gh(["run", "view", RUN_ID, "--json", "status,conclusion"])
        status, conclusion = "?", ""
        if code == 0:
            try:
                d = json.loads(out)
                status = d.get("status", "")
                conclusion = d.get("conclusion", "")
            except Exception:
                pass
        msg = f"{time.strftime('%H:%M:%S')} status={status} conclusion={conclusion}"
        if msg != last:
            print(msg, flush=True)
            last = msg
        if status == "completed":
            strat, e = fetch_strategies()
            if e:
                verdict = f"RUN COMPLETED but fetch error: {e}"
            else:
                s = (strat or "").lower()
                is_legacy = any(t in s for t in LEGACY)
                is_abatch = any(t in s for t in A_BATCH)
                if is_legacy and not is_abatch:
                    verdict = f"FAIL: 仍为旧策略 strategies={strat}"
                elif is_abatch and not is_legacy:
                    verdict = f"PASS: 已重写为 A 批 strategies={strat}"
                else:
                    verdict = f"AMBIGUOUS: strategies={strat}"
            with open(OUT, "w", encoding="utf-8") as f:
                f.write(verdict + "\n")
            print("VERDICT:", verdict, flush=True)
            return
        if status in ("failure", "timed_out", "cancelled"):
            with open(OUT, "w", encoding="utf-8") as f:
                f.write(f"RUN {status.upper()}: conclusion={conclusion}\n")
            print("RUN", status, flush=True)
            return
        time.sleep(60)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("TIMEOUT: run did not finish within 3h\n")
    print("TIMEOUT", flush=True)


main()
