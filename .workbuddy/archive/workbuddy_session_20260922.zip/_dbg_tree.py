"""调试：为何 POST /git/trees 返回 404。"""
import json
import subprocess

REPO = "benny1232123/Stocks-Master"


def gh(args, payload=None, label="", quiet=False):
    cmd = ["gh", "api"] + args
    inp = None
    if payload is not None:
        cmd += ["--input", "-"]
        inp = json.dumps(payload)
    r = subprocess.run(cmd, input=inp, capture_output=True, text=True)
    if not quiet:
        print(f"--- {label} rc={r.returncode}")
        if payload is not None:
            print("  body:", (inp or "")[:160])
        if r.stdout.strip():
            print("  out:", r.stdout.strip()[:300])
        if r.stderr.strip():
            print("  err:", r.stderr.strip()[:400])
    return r


rd = gh([f"repos/{REPO}/git/ref/heads/master"], label="GET ref")
head = json.loads(rd.stdout)["object"]["sha"]
rd = gh([f"repos/{REPO}/git/commits/{head}"], label="GET commit")
base = json.loads(rd.stdout)["tree"]["sha"]
print("head:", head)
print("base tree:", base)

gh([f"repos/{REPO}/git/trees", "--method", "POST"],
   {"base_tree": base, "tree": []}, "A: base_tree + empty")

rd = gh([f"repos/{REPO}/contents/Readme.md"], label="GET readme", quiet=True)
readme_blob = json.loads(rd.stdout)["sha"]
print("readme blob:", readme_blob)
gh([f"repos/{REPO}/git/trees", "--method", "POST"],
   {"tree": [{"path": "Readme.md", "mode": "100644", "type": "blob", "sha": readme_blob}]},
   "B: no base_tree")

p = "E:/Stocks-Master/.workbuddy/_tree_body.json"
open(p, "w", encoding="utf-8").write(json.dumps({"base_tree": base, "tree": []}))
gh([f"repos/{REPO}/git/trees", "--method", "POST", "--input", p], None, "C: --input file")
