"""把 origin/master 残留的 8 个 k_data CSV 补进分桶 parquet，并删除 CSV。

背景: rebase 后 b4747bd 只删了"本地旧 master 有、origin 也有的"那批 CSV；
这 8 个代码(origin 的 6b8fde4 恢复、但本地旧 master 没有)不在 parquet 中，
若直接删会丢数据。这里把它们读入对应桶 parquet，再删 CSV，完成迁移。
"""
import os
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from collections import defaultdict

KDATA = "stock_data/k_data"
CODES = ["300488", "300499", "300938", "301046", "301119",
         "301206", "301595", "688039"]

SCHEMA = pa.schema([
    ("code", pa.large_string()),
    ("date", pa.large_string()),
    ("open", pa.float64()),
    ("high", pa.float64()),
    ("low", pa.float64()),
    ("close", pa.float64()),
    ("volume", pa.float64()),
    ("amount", pa.float64()),
])

bucket_rows = defaultdict(list)
for code in CODES:
    csv = f"{KDATA}/{code}_qfq_full.csv"
    df = pd.read_csv(csv)
    df["code"] = code
    df = df[["code", "date", "open", "high", "low", "close", "volume", "amount"]]
    df["date"] = df["date"].astype(str)
    bucket_rows[code[:2]].append(df)

for b, dfs in bucket_rows.items():
    pf = f"{KDATA}/qfq_b{b}.parquet"
    existing = pq.read_table(pf).to_pandas()
    new = pd.concat(dfs, ignore_index=True)
    combined = pd.concat([existing, new], ignore_index=True)
    combined = combined.drop_duplicates(subset=["code", "date"], keep="last")
    combined = combined.sort_values(["code", "date"]).reset_index(drop=True)
    tbl = pa.Table.from_pandas(combined, schema=SCHEMA, preserve_index=False)
    pq.write_table(tbl, pf)
    print(f"bucket {b}: {len(existing)} -> {len(combined)} rows (+{len(new)})")

for code in CODES:
    os.remove(f"{KDATA}/{code}_qfq_full.csv")
print("deleted 8 leftover CSVs")
