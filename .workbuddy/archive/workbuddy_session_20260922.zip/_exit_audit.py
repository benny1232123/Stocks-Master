# -*- coding: utf-8 -*-
"""出场审计：为什么 trend_break / stop_hard 在出血（只读离线）。

三个假设逐一验证：
  H1 标签掩蔽：退出判定顺序把 trend_break 排在 stop_pct / trailing 之前 → 同一出场
     被记成 trend_break，掩盖真实的止损/移动止盈触发。
  H2 结构性必死：入场价本身就低于 MA60 → 次日开盘即满足「收盘跌破 MA60」，无脑破位。
  H3 止损被跳空击穿：stop_hard 用 min(开盘, 止损价) 成交，跳空低开时实际亏损远超设定止损。
"""
import glob
import re
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_exit_audit_out.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


def safe_read(p_):
    try:
        return pd.read_csv(p_, dtype=str)
    except Exception:
        return None


# ── 载入成交 + DAL ──
frames = []
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv"))):
    d = safe_read(f)
    if d is None or d.empty or "return_pct" not in d.columns:
        continue
    d["_batch"] = re.search(r"(\d{8})", Path(f).name).group(1)
    dal = SD / f"Daily-Action-List-{d['_batch'].iloc[0]}.csv"
    if dal.exists():
        g = safe_read(dal)
        if g is not None and not g.empty:
            g = g.rename(columns={"股票代码": "code", "_stop": "stop_pct"})
            d["code"] = d["code"].astype(str).str.zfill(6)
            g["code"] = g["code"].astype(str).str.zfill(6)
            d = d.merge(g, on="code", how="left", suffixes=("", "_dal"))
    frames.append(d)
T = pd.concat(frames, ignore_index=True)
T["return_pct"] = pd.to_numeric(T["return_pct"], errors="coerce")
T["buy_price"] = pd.to_numeric(T["buy_price"], errors="coerce")
T["sell_price"] = pd.to_numeric(T["sell_price"], errors="coerce")
T["_hold"] = (pd.to_datetime(T["sell_date"]) - pd.to_datetime(T["buy_date"])).dt.days
p(f"成交 {len(T)} 笔；DAL 列: {[c for c in T.columns if c in ('stop_pct','权重','止盈价(上轨)','MA20','综合评分','来源策略')]}")

# ── 1) exit_reason × 持有天数 交叉表 ──
p("")
p("=" * 96)
p("1) exit_reason × 持有自然日 交叉表（笔数 / 平均收益%）")
p("=" * 96)
T["_hb"] = pd.cut(T["_hold"], [0, 1, 2, 3, 5, 8, 999],
                  labels=["1天", "2天", "3天", "4-5天", "6-8天", "9天+"])
ct = pd.crosstab(T["exit_reason"], T["_hb"])
p("  【笔数】")
p(ct.to_string())
p("")
p("  【平均收益%】")
p(T.pivot_table(index="exit_reason", columns="_hb", values="return_pct",
                aggfunc="mean", observed=True).round(2).to_string())

# ── 2) H2：入场价 vs MA60 ──
p("")
p("=" * 96)
p("2) H2 结构性必死：入场时收盘价与 MA60 的关系")
p("=" * 96)
try:
    from smcore.data.kline import read_kline_cache
except Exception as exc:
    p("  !! 无法 import read_kline_cache:", exc)
    read_kline_cache = None

ma_cache: dict[str, pd.DataFrame] = {}


def ma60_at(code: str, d: pd.Timestamp):
    if read_kline_cache is None:
        return None
    if code not in ma_cache:
        try:
            k = read_kline_cache(code, base_dir=SD / "k_data")
        except Exception:
            k = pd.DataFrame()
        if k.empty or "date" not in k.columns:
            ma_cache[code] = pd.DataFrame()
        else:
            k = k.copy()
            k["date"] = pd.to_datetime(k["date"], errors="coerce")
            k = k.dropna(subset=["date"]).sort_values("date")
            k["ma60"] = pd.to_numeric(k["close"], errors="coerce").rolling(60).mean()
            ma_cache[code] = k
    k = ma_cache[code]
    if k.empty:
        return None
    sub = k[k["date"] <= d]
    if sub.empty:
        return None
    return float(sub.iloc[-1]["ma60"]) if pd.notna(sub.iloc[-1]["ma60"]) else None


rows = []
for _, r in T.iterrows():
    bd = pd.Timestamp(r["buy_date"])
    m = ma60_at(str(r["code"]), bd)
    rows.append({
        "code": r["code"], "exit": r["exit_reason"], "ret": r["return_pct"],
        "buy": r["buy_price"], "ma60": m,
        "below_ma60_at_entry": (None if m is None else bool(r["buy_price"] < m)),
        "dist_pct": (None if (m is None or not m) else round((r["buy_price"] / m - 1) * 100, 2)),
    })
A = pd.DataFrame(rows)
ok = A.dropna(subset=["below_ma60_at_entry"])
p(f"  可计算 {len(ok)}/{len(A)} 笔（本地 k_data 覆盖）")
if len(ok):
    p(f"  ★ 入场价就已低于 MA60 的笔数 = {int(ok['below_ma60_at_entry'].sum())} / {len(ok)}"
      f"  ({100*ok['below_ma60_at_entry'].mean():.1f}%)")
    p("  按出场原因看「入场即破位」比例：")
    g = ok.groupby("exit")["below_ma60_at_entry"].agg(n="count", 破位率=lambda s: 100 * s.mean())
    p(g.round(1).to_string())
    p("")
    p("  入场距 MA60 的距离（% ，负=买在 MA60 下方）：")
    for e, gg in ok.groupby("exit"):
        v = gg["dist_pct"].dropna()
        if len(v):
            p(f"    {e:<20} n={len(v):<4} 中位={v.median():+7.2f}%  "
              f"p25={v.quantile(.25):+7.2f}%  p75={v.quantile(.75):+7.2f}%")

# ── 3) H3：stop_hard 是否被跳空击穿 ──
p("")
p("=" * 96)
p("3) H3 stop_hard 逐笔：设定止损 vs 实际亏损")
p("=" * 96)
sh = T[T["exit_reason"] == "stop_hard"].copy()
p(f"  stop_hard 共 {len(sh)} 笔")
if "stop_pct" in sh.columns:
    sh["stop_pct"] = pd.to_numeric(sh["stop_pct"], errors="coerce")
cols = ["_batch", "code", "buy_date", "sell_date", "_hold", "buy_price", "sell_price",
        "return_pct", "stop_pct"]
cols = [c for c in cols if c in sh.columns]
p(sh[cols].to_string(index=False))
if "stop_pct" in sh.columns:
    s = sh.dropna(subset=["stop_pct"])
    if len(s):
        p("")
        p("  设定止损 vs 实际：")
        for _, r in s.iterrows():
            stop_px = r["buy_price"] * (1 - abs(r["stop_pct"]))
            p(f"    {r['code']}  设定止损 -{abs(r['stop_pct'])*100:.1f}% "
              f"(价位 {stop_px:.2f})  实际成交 {r['sell_price']:.2f}  "
              f"实际亏损 {r['return_pct']:+.2f}%  "
              f"超出设定 {-(r['return_pct']) - abs(r['stop_pct'])*100:+.2f}pp")

p("")
p("  全部 120 笔中，亏损超过 -10% 的：")
worst = T.nsmallest(10, "return_pct")[
    [c for c in ["_batch", "code", "buy_date", "sell_date", "_hold", "buy_price",
                 "sell_price", "return_pct", "exit_reason"] if c in T.columns]]
p(worst.to_string(index=False))

# ── 4) H1：判定顺序 ──
p("")
p("=" * 96)
p("4) H1 判定顺序（engine.py 689-714）")
p("=" * 96)
p("  take_band → take_pct → trend_break → stop_pct → trailing → stop_band")
p("  ⇒ 同一根 bar 上若同时满足 trend_break 与 stop_pct/trailing，标签记 trend_break。")
tb = T[T["exit_reason"] == "trend_break"]
if len(tb):
    p(f"  trend_break {len(tb)} 笔：亏损 {int((tb['return_pct']<0).sum())} 笔 "
      f"({100*(tb['return_pct']<0).mean():.0f}%)，均值 {tb['return_pct'].mean():+.2f}%")
    p(f"    其中持有 <=2 天的 {int((tb['_hold']<=2).sum())} 笔、"
      f"3-5 天 {int(((tb['_hold']>=3)&(tb['_hold']<=5)).sum())} 笔、"
      f"6 天以上 {int((tb['_hold']>=6).sum())} 笔")
    p(f"    亏损幅度分布: 中位 {tb['return_pct'].median():+.2f}%  "
      f"p25 {tb['return_pct'].quantile(.25):+.2f}%  "
      f"p75 {tb['return_pct'].quantile(.75):+.2f}%")

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
