"""Diagnostic: does the Supabase `trades` table exist, and how many rows?

Uses plain REST (requests) so it works without the `supabase` package.
Reads SUPABASE_URL / SUPABASE_KEY from the repo .env. Never prints secrets.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

import requests

ENV = Path("E:/Stocks-Master/.env")


def load_env(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    if not path.exists():
        return out
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def main() -> int:
    env = load_env(ENV)
    url = (env.get("SUPABASE_URL") or os.getenv("SUPABASE_URL", "")).rstrip("/")
    key = env.get("SUPABASE_KEY") or os.getenv("SUPABASE_KEY", "")

    if not url or not key:
        print("[FATAL] .env 缺少 SUPABASE_URL / SUPABASE_KEY")
        return 1

    masked = url[:24] + "..." if len(url) > 24 else url
    print(f"SUPABASE_URL = {masked}")
    print(f"SUPABASE_KEY = {'*' * 8}{key[-4:] if len(key) > 4 else ''} (len={len(key)})")

    headers = {"apikey": key, "Authorization": f"Bearer {key}"}

    # 1) does the table exist?
    probe = f"{url}/rest/v1/trades?select=id&limit=1"
    try:
        r = requests.get(probe, headers=headers, timeout=20)
    except Exception as exc:
        print(f"[FATAL] 无法连接 Supabase: {exc}")
        return 1

    print(f"\n[GET trades?limit=1] status = {r.status_code}")
    if r.status_code == 200:
        print("✅ trades 表存在（可访问）")
    else:
        body = r.text[:400]
        print(f"❌ trades 表不可访问 / 不存在：{body}")
        if "does not exist" in body or r.status_code == 404 or r.status_code == 400:
            print("\n>>> 需要在 Supabase SQL Editor 执行建表 SQL（见 trades_repo.SUPABASE_SCHEMA_SQL）")
        return 1

    # 2) how many rows?
    cnt_headers = dict(headers)
    cnt_headers["Prefer"] = "count=exact"
    cnt_headers["Range"] = "0-0"
    r2 = requests.get(f"{url}/rest/v1/trades?select=*", headers=cnt_headers, timeout=20)
    total = r2.headers.get("Content-Range", "")
    rows = r2.json() if r2.status_code == 200 else []
    print(f"\n[count] Content-Range = {total or '(none)'}")
    print(f"[rows actually returned] {len(rows)}")

    if rows:
        print("\n样例记录:")
        for row in rows[:3]:
            print("  ", row)
    else:
        print("\n⚠️ trades 表存在但 0 行 —— 从未录入过任何交易")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
