# -*- coding: utf-8 -*-
"""修 `/api/backtests/latest` 的两个真问题（快照自我毒化 + 候选家族漏了现行产物）。

背景更正：前端并**没有**渲染该端点的 payload（`App.jsx:1080` 的 `latestBacktest`
只被赋值、从未使用），回测 Tab 实际由 `/api/backtests/daily-latest` +
`/api/backtests/daily-summary` 驱动，二者正常。所以这不是「坏掉的 Tab」，
而是**端点卫生问题 + 一个会误导后来人的空载荷地雷**：
  ① 端点优先返回 backtests_latest.json 快照，而 export_web_data 把「查不到」的
     空结果也写进去 → 之后永远命中 latest=null，不可能自愈；
  ② 候选家族是 Signal-Backtest-*/Trade-Backtest-*/*-portfolio-summary（旧的遗留产物），
     漏了现行管线产物 Multi-Backtest-*-summary.csv。

每处 count(old) 断言 == 1。
"""
import pathlib
import sys

ROOT = pathlib.Path(r"E:\Stocks-Master")
M = ROOT / "backend" / "main.py"
E = ROOT / "scripts" / "export_web_data.py"

REPL = [
    (M, """@app.get("/api/backtests/latest")
def latest_backtest() -> dict:
    snap = _web_snapshot("backtests_latest.json")
    if snap is not None:
        return snap
    latest = find_latest_file_any(
        [
            "Signal-Backtest-*-summary.csv",
            "Trade-Backtest-*-summary.csv",
            "*-portfolio-summary.csv",
        ]
    )
    if latest is None:
        return {"latest": None, "preview": {"rows": [], "columns": []}}

    return {"latest": latest.__dict__, "preview": preview_csv(latest.path)}
""", """@app.get("/api/backtests/latest")
def latest_backtest() -> dict:
    # ⚠️ 空快照不算命中（2026-09-21）：export_web_data 会把「查不到产物」的空结果
    # （{"latest": null, ...}）也写进 backtests_latest.json，而本端点原先"存在即返回"
    # → 快照**自我毒化**：之后每次都命中空快照，永远返回 null 且不可能自愈。
    # 故 latest 为空的快照一律视为 miss，继续走实时路径；export 侧也同步不写空载荷。
    snap = _web_snapshot("backtests_latest.json")
    if snap and snap.get("latest"):
        return snap
    latest = find_latest_file_any(
        [
            # 现行管线产物（daily-pick.yml → scripts/daily_backtest.py）
            "Multi-Backtest-*-summary.csv",
            # 以下为已退役家族：远端已 0 个文件，保留仅为兼容遗留产物目录
            "Signal-Backtest-*-summary.csv",
            "Trade-Backtest-*-summary.csv",
            "*-portfolio-summary.csv",
        ]
    )
    if latest is None:
        return {"latest": None, "preview": {"rows": [], "columns": []}}

    return {"latest": latest.__dict__, "preview": preview_csv(latest.path)}
"""),
    (E, """    if isinstance(obj, list):
        return [_sanitize(x) for x in obj]
    return obj
""", """    if isinstance(obj, list):
        return [_sanitize(x) for x in obj]
    return obj


def _is_empty_payload(obj) -> bool:
    \"\"\"空载荷判定：带 ``latest`` 键但 latest 为空（None/{}）→ 视为「本次没查到」。

    export 侧据此**跳过写盘**：否则会把「查不到」固化成永久快照，让
    ``latest_backtest()`` / ``artifacts`` / ``daily_full`` 永远读回空值
    （快照自我毒化）。不写盘 → 保留上一次有效快照或让后端走实时路径，二者都优于写 null。
    没有 ``latest`` 键的载荷（dashboard / portfolio 等）不受影响。
    \"\"\"
    return isinstance(obj, dict) and "latest" in obj and not obj.get("latest")
"""),
    (E, """            data = r.json()
            if sanitize:
                data = _sanitize(data)
            (OUT_DIR / name).write_text(
""", """            data = r.json()
            if sanitize:
                data = _sanitize(data)
            if _is_empty_payload(data):
                print(f"[export] 跳过写入 {name}（空载荷：latest 为空）"
                      f"——避免快照自我毒化，后端保留实时路径")
                continue
            (OUT_DIR / name).write_text(
"""),
]

cache: dict = {}
for path, old, new in REPL:
    src = cache.get(path) or path.read_text(encoding="utf-8")
    n = src.count(old)
    if n != 1:
        print(f"FAIL {path.name}: expected 1 hit, got {n}")
        print("--- old ---")
        print(old[:400])
        sys.exit(1)
    cache[path] = src.replace(old, new)
    print(f"OK {path.name}")
for path, src in cache.items():
    path.write_text(src, encoding="utf-8")
print("WROTE", ", ".join(str(p) for p in cache))
