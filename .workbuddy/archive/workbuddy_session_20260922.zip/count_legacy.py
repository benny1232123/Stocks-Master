import subprocess, json

out = subprocess.run(
    ["gh", "api", "repos/benny1232123/Stocks-Master/git/trees/master?recursive=1"],
    capture_output=True, text=True, timeout=120)
data = json.loads(out.stdout)
paths = [t["path"] for t in data["tree"]
         if t["path"].startswith("stock_data/Multi-Backtest-") and t["path"].endswith("-summary.csv")]
pre = [p for p in paths if p < "stock_data/Multi-Backtest-20260827"]
window = [p for p in paths if "stock_data/Multi-Backtest-20260827" <= p <= "stock_data/Multi-Backtest-20260917"]
print("TOTAL summary files:", len(paths))
print("PRE-0827 (legacy era):", len(pre))
print("WINDOW 0827-0917:", len(window))
print("PRE date range:", min(pre)[len("stock_data/Multi-Backtest-"):-len("-summary.csv")],
      "->", max(pre)[len("stock_data/Multi-Backtest-"):-len("-summary.csv")])
# also DAL legacy era count
dals = [t["path"] for t in data["tree"]
        if t["path"].startswith("stock_data/Daily-Action-List-") and t["path"].endswith(".csv")]
dal_pre = [p for p in dals if p < "stock_data/Daily-Action-List-20260827"]
print("DAL total:", len(dals), "DAL pre-0827:", len(dal_pre))
