# -*- coding: utf-8 -*-
"""持有期 A/B 的**可比起口径**汇总。

关键修正：出场打开的 arm 会把一次持仓拆成多条 trade 记录（take_partial 等），
所以「笔均」在 arm 之间不可比。本脚本按 (批次, 代码) 聚合成**每条持仓一个收益**
（数量加权），并做批次级配对检验。
"""
import glob
import math
import re
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
OUTROOT = ROOT / ".workbuddy" / "hold_exp"
OUT = ROOT / ".workbuddy" / "_hold_exp_summary.txt"
ARMS = ["base12", "h1", "h2", "h3", "h5", "h12_notrend"]

lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


D = {}
for arm in ARMS:
    d = OUTROOT / arm
    sfs = sorted(glob.glob(str(d / "Multi-Backtest-*-summary.csv")))
    S = pd.concat([pd.read_csv(f, dtype=str) for f in sfs], ignore_index=True) if sfs else pd.DataFrame()
    for c in ("total_return", "cash_pct", "max_drawdown", "sharpe", "num_trades",
              "bench_return", "excess_return"):
        if c in S.columns:
            S[c] = pd.to_numeric(S[c], errors="coerce")
    if "date" in S.columns:
        S["date"] = S["date"].astype(str).str[:8]
    tl = []
    for f in sorted(glob.glob(str(d / "Multi-Backtest-*-trades.csv"))):
        try:
            t = pd.read_csv(f, dtype=str)
        except Exception:
            continue
        if t.empty or "return_pct" not in t.columns:
            continue
        t["_batch"] = re.search(r"(\d{8})", Path(f).name).group(1)
        tl.append(t)
    T = pd.concat(tl, ignore_index=True) if tl else pd.DataFrame()
    if not T.empty:
        for c in ("return_pct", "qty", "buy_price"):
            T[c] = pd.to_numeric(T[c], errors="coerce")
        T["_v"] = T["qty"] * T["buy_price"]
    D[arm] = (S, T)

p("=" * 110)
p("A) 可比口径：按「持仓」聚合（同一批次同一代码 = 1 条持仓，收益按数量加权）")
p("=" * 110)
rows = []
POS = {}
for arm in ARMS:
    S, T = D[arm]
    pos = pd.DataFrame()
    if not T.empty:
        g = T.groupby(["_batch", "code"]).apply(
            lambda x: pd.Series({
                "ret": (x["return_pct"] * x["_v"]).sum() / x["_v"].sum() if x["_v"].sum() else x["return_pct"].mean(),
                "val": x["_v"].sum(),
                "n_rec": len(x),
                "reasons": "|".join(sorted(set(x["exit_reason"]))),
            }), include_groups=False).reset_index()
        pos = g
    POS[arm] = pos
    comp = S[S["num_trades"] > 0] if "num_trades" in S.columns else S
    rows.append({
        "arm": arm,
        "批次": len(comp),
        "持仓数": len(pos),
        "持仓均%": round(pos["ret"].mean(), 3) if len(pos) else None,
        "持仓中位%": round(pos["ret"].median(), 3) if len(pos) else None,
        "持仓胜率%": round(100 * (pos["ret"] > 0).mean(), 1) if len(pos) else None,
        "持仓市值加权%": round((pos["ret"] * pos["val"]).sum() / pos["val"].sum(), 3)
        if len(pos) and pos["val"].sum() else None,
        "组合均%": round(comp["total_return"].mean(), 3),
        "组合中位%": round(comp["total_return"].median(), 3),
        "现金%": round(comp["cash_pct"].mean(), 1),
        "回撤均%": round(comp["max_drawdown"].mean(), 3),
        "基准均%": round(comp["bench_return"].mean(), 3),
        "超额均%": round(comp["excess_return"].mean(), 3),
    })
p(pd.DataFrame(rows).to_string(index=False))

p("")
p("=" * 110)
p("B) 批次级配对检验（与 base12 比，同一信号日）")
p("=" * 110)
b0 = D["base12"][0].set_index("date")["total_return"]
p(f"  {'arm':<12}{'共同批次':>8}{'Δ组合均%':>12}{'t':>8}{'胜/负':>10}")
for arm in ARMS[1:]:
    b = D[arm][0].set_index("date")["total_return"]
    j = pd.concat([b0.rename("base"), b.rename("arm")], axis=1).dropna()
    if len(j) < 3:
        continue
    dd = j["arm"] - j["base"]
    t = dd.mean() / (dd.std() / math.sqrt(len(dd))) if dd.std() else float("nan")
    p(f"  {arm:<12}{len(j):>8}{dd.mean():>+12.3f}{t:>+8.2f}"
      f"{int((dd>0).sum()):>6}/{int((dd<0).sum()):<3}")

p("")
p("=" * 110)
p("C) 各 arm 的出场构成（看 MA60 破位移除后谁接管）")
p("=" * 110)
for arm in ARMS:
    S, T = D[arm]
    if T.empty or "exit_reason" not in T.columns:
        continue
    g = T.groupby("exit_reason")["return_pct"].agg(n="count", mean="mean", total="sum")
    g["win%"] = T.groupby("exit_reason")["return_pct"].apply(lambda s: round(100 * (s > 0).mean(), 1))
    p(f"  [{arm}] Σ={T['return_pct'].sum():+.0f}")
    p("    " + g.round(2).to_string().replace("\n", "\n    "))

p("")
p("=" * 110)
p("D) 关键对照：base12 vs h12_notrend（关掉 MA60 破位）")
p("=" * 110)
for arm in ("base12", "h12_notrend"):
    S, T = D[arm]
    pos = POS[arm]
    p(f"  [{arm}] 持仓 {len(pos)} 条  持仓均 {pos['ret'].mean():+.3f}%  "
      f"中位 {pos['ret'].median():+.3f}%  市值加权 {(pos['ret']*pos['val']).sum()/pos['val'].sum():+.3f}%  "
      f"组合均 {S[S['num_trades']>0]['total_return'].mean():+.3f}%")

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
