"""端到端验证 notify_holdings_analysis 的修复（全程离线，全部打桩）。

覆盖：
① 顺序 bug：旧代码在「边分析边渲染」循环里引用循环后才赋值的 portfolio_value
   → 首只票即 UnboundLocalError。本测试跑 main() 断言 rc==0 且报告非空、
   且渲染顺序 = FIFO 输出顺序（失败票夹中间，检出「失败卡片被提前」回归）。
② 现金口径：ACCOUNT_CASH 计入分母 → current_weight 变为真实占比。
③ 纯技术面标注：缺基本面缓存的票在 MD/HTML 被标注。
④ K 线守卫：_refresh_klines 识别 stale bar；ALLOW_STALE_DATA 逃生口生效。
⑤ 目标权重口径：target_equity_ratio ÷ 持有只数（main() 已接入）；超硬上限只减到上限
   （aim_weight = hard_cap），非一步砍到政策目标。
"""
import contextlib
import importlib
import io
import os
import sys
from datetime import date
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import pandas as pd  # noqa: E402

import scripts.notify_holdings_analysis as N  # noqa: E402

# ⚠️ _refresh_klines 内部是「调用时 from smcore.data.kline import fetch_daily_k」，
#    所以必须打**源模块**属性；只打 N.fetch_daily_k 会被静默绕过（真实联网）。
_KLINE = importlib.import_module("smcore.data.kline")


def set_kline(stub):
    """同时替换源模块属性（_refresh_klines 用）与模块级引用（对比表用）。"""
    _KLINE.fetch_daily_k = stub
    N.fetch_daily_k = stub


def empty_kline(*a, **k):
    return pd.DataFrame()


def bar_kline(dates):
    def _f(code, start, end, **kw):
        return pd.DataFrame({"date": dates, "close": [10.0] * len(dates)})
    return _f


def rich(code, close, sgn="strong", fund=True):
    latest = {
        "close": close, "upper": close * 1.05, "lower": close * 0.95, "middle": close,
        "ma5": close, "ma10": close, "ma20": close, "ma60": close,
        "rsi": 25 if sgn == "strong" else (75 if sgn == "weak" else 50),
        "dif": 0.5 if sgn != "weak" else -0.5, "dea": 0.3 if sgn != "weak" else -0.3,
        "macd_hist": 0.2 if sgn != "weak" else -0.2,
        "k_val": 60, "d_val": 55, "j_val": 70,
    }
    metrics = {"dist_to_lower_pct": 1.0, "dist_to_upper_pct": -3.0,
               "signal_text": "测试", "bandwidth": 5.0}
    return {
        "code": code, "latest": latest, "metrics": metrics,
        "fundamentals": ({"pe": 8.0, "pb": 0.9, "roe": 0.15, "gross_margin": 0.45,
                          "mkt_cap": 2000.0, "turnover": 2.0} if fund else None),
        "series": {"rows": [{"close": close * 0.99}, {"close": close}]},
    }


class _Repo:
    backend_name = "stub-json"


ANALYSES = {
    "600000": lambda: rich("600000", 10.0, "strong", fund=True),
    "000001": lambda: rich("000001", 20.0, "weak", fund=False),      # 缺基本面 → 纯技术
    "300750": lambda: {"code": "300750", "error": "测试：数据缺失"},  # 失败分支
}

# 显式指定 FIFO 输出顺序，把**失败票夹在中间** → 检出「失败卡片被提前」这类顺序回归
POS_ORDER = ["600000", "300750", "000001"]
_COST = {"600000": 9.0, "000001": 22.0, "300750": 50.0}
# 持仓市值刻意设为 15,000（600000: 500×10 + 000001: 500×20），
# 与配置 account_total=30000 拉开差距，才能区分「总资产口径」与「纯持仓口径」
_QTY = {"600000": 500, "000001": 500, "300750": 200}
HOLDINGS_VALUE = 500 * 10.0 + 500 * 20.0        # = 15,000


def fake_positions(_trades):
    df = pd.DataFrame([
        {"代码": c, "成本价": _COST[c], "数量": _QTY[c], "买入日期": "2026-01-05"}
        for c in POS_ORDER
    ])
    return df, pd.DataFrame()


N.get_trade_repository = lambda: _Repo()
N.load_trades = lambda: [{"date": "2026-01-05", "code": c, "name": "", "side": "buy",
                          "price": _COST[c], "qty": _QTY[c], "fee": 0} for c in POS_ORDER]
N.compute_fifo_positions = fake_positions
N.build_stock_analysis = lambda code, **kw: ANALYSES[code]()
N.send_email = lambda *a, **k: False
N.fund_cache_exists = lambda c: c == "600000"          # 000001 无缓存 → 纯技术面
N.build_news_surface = lambda *a, **k: {"has_data": False}
set_kline(empty_kline)                                  # 默认：无 bar → 全部 stale

# 自适应仓位默认**打桩为关闭** → main() 走确定性静态口径（用例1~7 均按静态断言）；
# 用例8 再临时换成自适应桩，验证 main() 的接线（regime→总仓位 + 倾斜权重 → 报告渲染）。
_STATIC_CTX = {
    "enabled": False, "source": "static", "regime": None, "regime_strength": None,
    "equity_ratio": 0.70, "weight_frac": {}, "weight_method": None,
    "note": "test: adaptive disabled",
}
N.adaptive_sizing_context = lambda *a, **k: dict(_STATIC_CTX)

TMP = Path(ROOT) / ".workbuddy" / "_holdtest_out"
TMP.mkdir(parents=True, exist_ok=True)
N.STOCK_DATA_DIR = TMP
os.environ["TODAY"] = "20260921"
os.environ["RECENT_DAYS"] = "0"          # 跳过「近 N 天对比」（另需 K 线序列）
os.environ["HOLDINGS_FUND_REFRESH"] = "0"  # 本测试必须全离线，关掉基本面联网回填
for _k in ("ACCOUNT_TOTAL", "ACCOUNT_CASH", "ALLOW_STALE_DATA"):
    os.environ.pop(_k, None)

fails = []


def run(tag):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = N.main()
    out = buf.getvalue()
    md = (TMP / "holdings_analysis_20260921.md").read_text(encoding="utf-8")
    html = (TMP / "holdings_analysis_20260921.html").read_text(encoding="utf-8")
    print(f"\n===== {tag} =====")
    print("rc =", rc)
    for line in out.splitlines():
        if any(k in line for k in ("组合分母", "纯技术面", "基本面缓存", "K 线", "跳过",
                                   "目标权重口径", "自适应仓位")):
            print("  log:", line)
    return rc, md, html, out


# ── 用例 1：ACCOUNT_BASIS=holdings → 强制纯持仓口径（压掉配置里的 account_total）──
os.environ["ACCOUNT_BASIS"] = "holdings"
rc1, md1, html1, out1 = run("用例1 ACCOUNT_BASIS=holdings（纯持仓口径）")
os.environ.pop("ACCOUNT_BASIS", None)
if rc1 != 0:
    fails.append(f"用例1 rc={rc1}（旧代码在此抛 UnboundLocalError）")
if "⚖️ 仓位调整" not in html1:
    fails.append("用例1 HTML 缺「仓位调整」区块")
if "纯技术面" not in html1 or "纯技术面" not in md1:
    fails.append("用例1 缺「纯技术面」标注")
if "仓位口径" not in md1:
    fails.append("用例1 缺「未配置账户口径」提示")
if "⚖️ 仓位口径" not in html1:
    fails.append("用例1 HTML 缺「未配置账户口径」提示")
if "300750" not in md1:
    fails.append("用例1 失败票未被渲染")
# K 线桩返回空 → 全部 stale → 必须有滞后横幅（且不阻塞落盘）
if "数据滞后告警" not in md1 or "数据滞后告警" not in html1:
    fails.append("用例1 缺「数据滞后告警」横幅（K 线守卫未接入报告）")
if f"组合分母[holdings_only]：持仓市值 {HOLDINGS_VALUE:,.0f} + 现金 0 = {HOLDINGS_VALUE:,.0f}" not in out1:
    fails.append(f"用例1 未退回纯持仓分母（期望 {HOLDINGS_VALUE:,.0f}）")
# ⚠️ 用带冒号的精确串，"总资产" 三个字也出现在口径提示文案里
if "**总资产**：" in md1:
    fails.append("用例1 纯持仓口径不该展示「总资产」行")
order = [md1.find(f"### {c}") for c in POS_ORDER]
if order != sorted(order) or -1 in order:
    fails.append(f"用例1 渲染顺序错乱（期望 {'<'.join(POS_ORDER)}）: {order}")
for c in POS_ORDER:
    if md1.count(f"### {c}") != 1:
        fails.append(f"用例1 {c} 标题出现 {md1.count(f'### {c}')} 次（应恰好 1 次）")

# ── 用例 2：env ACCOUNT_CASH 应**压过**配置 account_total → 分母 = 15000 + 70000 ──
os.environ["ACCOUNT_CASH"] = "70000"
rc2, md2, html2, out2 = run("用例2 ACCOUNT_CASH=70000（env 优先于配置）")
os.environ.pop("ACCOUNT_CASH", None)
if rc2 != 0:
    fails.append(f"用例2 rc={rc2}")
if "组合分母[account_cash]：持仓市值 15,000 + 现金 70,000 = 85,000" not in out2:
    fails.append("用例2 env ACCOUNT_CASH 未压过配置 account_total（期望分母 85,000）")
if "**总资产**：" not in md2 or "**账户现金**：" not in md2:
    fails.append("用例2 汇总卡片未展示现金/总资产")
if "当前 5.9%" not in md2:               # 600000: 5000/85000 = 5.88% → 1 位小数
    fails.append("用例2 600000 current_weight 未按含现金分母计算（期望 5.9%）")
if "仓位口径" in md2:
    fails.append("用例2 已配置现金却仍提示「未配置账户口径」")

# ── 用例 3：K 线守卫本身 ──
AS_OF = date(2026, 9, 21)
set_kline(bar_kline(["2026-09-18"]))
stale_a, maxb_a = N._refresh_klines(["600000"], AS_OF)
if stale_a != ["600000"] or maxb_a != "2026-09-18":
    fails.append(f"用例3a 旧 bar 未识别为 stale: {stale_a} / {maxb_a}")
set_kline(bar_kline(["2026-09-18", "2026-09-21"]))
stale_b, maxb_b = N._refresh_klines(["600000"], AS_OF)
if stale_b != [] or maxb_b != "2026-09-21":
    fails.append(f"用例3b 含信号日 bar 却报 stale: {stale_b} / {maxb_b}")

# ── 用例 4：ALLOW_STALE_DATA=1 逃生口 ──
set_kline(empty_kline)
os.environ["ACCOUNT_BASIS"] = "holdings"
os.environ["ALLOW_STALE_DATA"] = "1"
rc4, md4, html4, out4 = run("用例4 ALLOW_STALE_DATA=1")
os.environ.pop("ALLOW_STALE_DATA", None)
os.environ.pop("ACCOUNT_BASIS", None)
if rc4 != 0:
    fails.append(f"用例4 rc={rc4}")
if "数据滞后告警" in md4:
    fails.append("用例4 逃生口打开却仍报「数据滞后告警」")
if "跳过 K 线定向刷新" not in out4:
    fails.append("用例4 逃生口未生效（日志无跳过标记）")

# ── 用例 5：不设 env → 走 POSITION_SIZING_CONFIG.account_total（用户已设 30000）──
from smcore.config.defaults import POSITION_SIZING_CONFIG as _PSC  # noqa: E402

if _PSC.get("account_total") != 30000.0:
    fails.append(f"配置 account_total 应为 30000.0，实为 {_PSC.get('account_total')!r}")
if _PSC.get("account_cash") != 0.0:
    fails.append(f"配置 account_cash 应回落到 0.0（总资产口径优先），实为 {_PSC.get('account_cash')!r}")
rc5, md5, html5, out5 = run("用例5 走配置 account_total=30000")
if rc5 != 0:
    fails.append(f"用例5 rc={rc5}")
# 总资产口径：分母 = 30000（固定），现金 = 30000 − 15000 = 15000（反推）
if "组合分母[account_total]：持仓市值 15,000 + 现金 15,000 = 30,000" not in out5:
    fails.append("用例5 未采用配置 account_total=30000（期望分母 30,000、现金反推 15,000）")
if "**账户现金**：" not in md5 or "**总资产**：" not in md5:
    fails.append("用例5 汇总未展示账户现金/总资产")
if "仓位口径" in md5:
    fails.append("用例5 已配置账户总资产却仍提示「未配置账户口径」")
if "当前 16.7%" not in md5:      # 600000: 5000/30000 = 16.67% → 渲染为 1 位小数
    fails.append("用例5 600000 current_weight 未按总资产分母计算（期望 当前 16.7%）")

# ── 用例 6：_resolve_denominator 优先级（env > 配置；total > cash > pct > 纯持仓）──
_hv = 15000.0
os.environ["ACCOUNT_TOTAL"] = "30000"
os.environ["ACCOUNT_CASH"] = "70000"          # 两个 env 都给 → total 优先
_t, _c, _b = N._resolve_denominator(_hv, _PSC)
if (_t, _c, _b) != (30000.0, 15000.0, "account_total"):
    fails.append(f"用例6a env total 应压过 env cash: {(_t, _c, _b)}")
os.environ.pop("ACCOUNT_TOTAL", None)
_t, _c, _b = N._resolve_denominator(_hv, _PSC)   # env cash 压过配置 total
if (_t, _c, _b) != (85000.0, 70000.0, "account_cash"):
    fails.append(f"用例6b env cash 未压过配置 total: {(_t, _c, _b)}")
os.environ.pop("ACCOUNT_CASH", None)
_t, _c, _b = N._resolve_denominator(_hv, _PSC)   # 无 env → 配置 total
if (_t, _c, _b) != (30000.0, 15000.0, "account_total"):
    fails.append(f"用例6c 无 env 时未取配置 total: {(_t, _c, _b)}")
_t, _c, _b = N._resolve_denominator(_hv, dict(_PSC, account_total=0.0, account_cash_pct=0.25))
if (_t, _c, _b) != (20000.0, 5000.0, "account_cash_pct"):
    fails.append(f"用例6d 未落到 pct 口径: {(_t, _c, _b)}")
_t, _c, _b = N._resolve_denominator(_hv, dict(_PSC, account_total=0.0))
if (_t, _c, _b) != (_hv, 0.0, "holdings_only"):
    fails.append(f"用例6e 全无配置时未退回纯持仓口径: {(_t, _c, _b)}")
os.environ["ACCOUNT_BASIS"] = "holdings"          # ACCOUNT_BASIS 压掉一切
_t, _c, _b = N._resolve_denominator(_hv, _PSC)
os.environ.pop("ACCOUNT_BASIS", None)
if (_t, _c, _b) != (_hv, 0.0, "holdings_only"):
    fails.append(f"用例6f ACCOUNT_BASIS=holdings 未压过配置 total: {(_t, _c, _b)}")

# ── 用例 7：静态目标口径（target_equity_ratio ÷ 持有只数）已接入 main() ──
# （自适应已打桩关闭 → 走静态口径）3 只持仓 → 每票目标 = 70% ÷ 3 = 23.33%；
# 上限 = min(23.33 × 1.5, ceiling 35) = 35.0%
if "目标权重口径[equity_ratio]" not in out5:
    fails.append("用例7 main() 未走 target_equity_ratio 口径（日志缺「目标权重口径[equity_ratio]」）")
if "每票目标 23.33%" not in out5:
    fails.append("用例7 每票目标应为 23.33%（70% ÷ 3 只），实际日志: "
                 + next((l for l in out5.splitlines() if "目标权重口径" in l), "<无>"))
if "单票硬上限 35.0%" not in out5:
    fails.append("用例7 单票硬上限应为 35.0%（= min(目标×1.5, ceiling 35)）")
# ★ 超限只减到上限：用例1 纯持仓口径（分母 15,000）下 000001 = 10,000/15,000 = 66.7% > 上限 35%
#   → 报告须显示「→ 上限 35.0%」，而不是一步砍到政策目标 23.3%
if "→ 上限 35.0%" not in md1:
    fails.append("用例7 超限票未按「只减到上限」渲染（期望出现「→ 上限 35.0%」）")
if "目标 23.3%" not in md1:
    fails.append("用例7 超限票未同时标注目标（期望「目标 23.3%」）")
# 未超限的票仍应显示「→ 目标」（600000 在用例1 下 33.3% < 上限 35%）
if "→ 目标" not in md1:
    fails.append("用例7 未超限票未按「→ 目标」渲染")

# ── 用例 8：自适应仓位接线（regime→总仓位 + 组合优化层→单票权重）已在 main() 生效 ──
# 桩：总仓位 60%（下行防御档）、倾斜权重 {600000: 0.60, 000001: 0.20, 300750: 0.20}
#   → 政策目标 = 60% ÷ 3 = 20.0%；各票目标 = 60% × frac = 36% / 12% / 12%
#   → 硬上限 = min(生效目标×1.5, ceiling 35)（不足则抬到目标）
#     600000: min(36×1.5,35)=35 < 36 → 抬到 36；000001: min(12×1.5,35)=18
# 纯持仓分母(15,000)下 000001 = 10,000/15,000 = 66.7% > 18% → 只减到「上限 18.0%」
N.adaptive_sizing_context = lambda *a, **k: {
    "enabled": True, "source": "adaptive_regime", "regime": "下行防御",
    "regime_strength": 0.30, "equity_ratio": 0.60,
    "weight_frac": {"600000": 0.60, "000001": 0.20, "300750": 0.20},
    "weight_method": "risk_parity_erc", "note": "",
}
os.environ["ACCOUNT_BASIS"] = "holdings"
rc8, md8, html8, out8 = run("用例8 自适应仓位（regime+倾斜权重）")
os.environ.pop("ACCOUNT_BASIS", None)
if rc8 != 0:
    fails.append(f"用例8 rc={rc8}")
if "目标权重口径[adaptive]" not in out8:
    fails.append("用例8 main() 未走自适应口径（日志缺 目标权重口径[adaptive]）")
if "自适应仓位" not in md8 or "自适应仓位" not in html8:
    fails.append("用例8 报告缺「自适应仓位」说明横幅")
if "下行防御" not in md8:
    fails.append("用例8 自适应横幅未展示 regime（期望 下行防御）")
if "每票目标 36.0%" not in out8:
    fails.append("用例8 倾斜权重未生效（600000 期望目标 36.0%）："
                 + next((l for l in out8.splitlines() if "目标权重口径" in l), "<无>"))
if "→ 上限 18.0%" not in md8:      # 000001 生效目标 12% × 1.5 = 18%
    fails.append("用例8 超限票未按「只减到上限 18.0%」渲染")
if "目标 12.0%" not in md8:
    fails.append("用例8 超限票未标注生效目标 12.0%")

print("\n================== 结论 ==================")
if fails:
    for f in fails:
        print("  [FAIL]", f)
    raise SystemExit(1)
print("  全部断言通过：")
print("   ① main() 端到端可跑（顺序 bug 已修）、渲染顺序 = FIFO 顺序")
print("   ② 分母口径三档（account_total / account_cash / holdings_only）+ 优先级 + env 覆盖")
print("   ③ 缺基本面的票被标注「纯技术面」")
print("   ④ K 线守卫：stale 识别 / 滞后横幅 / 逃生口")
print("   ⑤ 配置 account_total=30000 生效（分母=30000，现金=总资产−持仓 自动反推）")
print("   ⑥ 静态目标口径 = target_equity_ratio ÷ 持有只数；超硬上限只减到上限（非一步砍到目标）")
print("   ⑦ 自适应仓位：regime→总仓位 + 组合优化层→单票权重，已接入 main() 并渲染横幅")
print("  报告样例:", TMP)

