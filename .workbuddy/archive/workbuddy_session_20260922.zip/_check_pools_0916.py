from pathlib import Path

ROOT = Path(r"E:\Stocks-Master")
factors = ["PVCorr20","PVCorr60","CVAmt20","CVAmt60","Skew20","Skew60",
           "VRatio20_120","VRatio10_60","DistLo10","DistLo60","Vol20","Illiq20"]
date = "20260916"
out = []
for f in factors:
    p = ROOT / "stock_data" / f"Stock-Selection-{f}-{date}.csv"
    if p.exists():
        lines = [l for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]
        out.append(f"{f}: {max(0, len(lines)-1)} rows")
    else:
        out.append(f"{f}: MISSING")
Path(r"E:\Stocks-Master\.workbuddy\_check_pools_0916_out.txt").write_text(
    "\n".join(out), encoding="utf-8")
