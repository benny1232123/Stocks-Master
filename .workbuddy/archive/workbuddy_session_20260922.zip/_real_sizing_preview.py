"""用真实持仓 + account_total=30000 预演「仓位调整」结果（无副作用：不落盘/不发邮件/不推送）。"""
import importlib
import os
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# 显式加载 .env —— shell 无 SUPABASE_* 时 TradeRepository 会 fallback 到
# 空的本地 trades.json（0 条），静默跑出「无持仓」的假结果。
_ENV = ROOT / ".env"
if _ENV.exists():
    for _ln in _ENV.read_text(encoding="utf-8").splitlines():
        _ln = _ln.strip()
        if not _ln or _ln.startswith("#") or "=" not in _ln:
            continue
        _k, _, _v = _ln.partition("=")
        _k, _v = _k.strip(), _v.strip().strip('"').strip("'")
        if _k and _k not in os.environ:
            os.environ[_k] = _v

os.environ["HOLDINGS_FUND_REFRESH"] = "0"      # 只读缓存，不联网回填基本面
os.environ.pop("ACCOUNT_CASH", None)          # 强制走配置里的 account_total

from smcore.analysis import (  # noqa: E402
    adaptive_sizing_context, build_stock_analysis, fundamentals_available,
    position_sizing_recommendation,
)
from smcore.config.defaults import POSITION_SIZING_CONFIG  # noqa: E402
from smcore.holdings import compute_fifo_positions, load_trades  # noqa: E402

N = importlib.import_module("scripts.notify_holdings_analysis")

AS_OF = date(2026, 9, 21)
pos_df, _ = compute_fifo_positions(load_trades())
codes = list(dict.fromkeys(str(c) for c in pos_df["代码"].tolist()))

# 按代码聚合（多批次建仓 → 总量 + 数量加权平均成本）
pos_map = {}
for _, r in pos_df.iterrows():
    c = str(r["代码"])
    q = float(r["数量"])
    try:
        _nm = N._resolve_name(c).get("name", "") or ""
    except Exception:
        _nm = ""
    p = pos_map.setdefault(c, {"name": _nm, "qty": 0.0, "cost": 0.0, "_amt": 0.0})
    p["qty"] += q
    p["_amt"] += float(r["成本价"]) * q
for p in pos_map.values():
    p["cost"] = p["_amt"] / p["qty"] if p["qty"] else 0.0
    p.pop("_amt", None)

rows = []
for c in codes:
    try:
        a = build_stock_analysis(c, as_of=AS_OF, fundamentals_offline=True)
    except Exception as exc:
        a = {"code": c, "error": f"{type(exc).__name__}: {exc}"}
    rows.append((c, a, pos_map[c]))

hv = sum(a["latest"]["close"] * pos["qty"] for _, a, pos in rows if not a.get("error"))
total, cash, basis = N._resolve_denominator(hv, POSITION_SIZING_CONFIG)
print(f"持仓市值 {hv:,.0f} + 现金 {cash:,.0f} = 总资产(分母) {total:,.0f}  [口径 {basis}]")
print(f"当前仓位比 = {hv / total * 100:.1f}%（现金 {cash / total * 100:.1f}%）")
_ADAPTIVE = adaptive_sizing_context(
    codes, as_of=AS_OF, cfg=POSITION_SIZING_CONFIG,
    analyses={c: a for c, a, _ in rows if not a.get("error")},
)
print(f"自适应仓位[{_ADAPTIVE['source']}]：regime {_ADAPTIVE['regime']}"
      f"（强度 {_ADAPTIVE['regime_strength']}）→ 总仓位 "f"{(_ADAPTIVE['equity_ratio'] or 0) * 100:.1f}%；权重法 {_ADAPTIVE['weight_method']}"
      + (f"｜note: {_ADAPTIVE['note']}" if _ADAPTIVE.get("note") else ""))
for _c in codes:
    _f = (_ADAPTIVE.get("weight_frac") or {}).get(_c)
    print(f"    {_c}: 权重占比 {_f * 100:.1f}%" if _f else f"    {_c}: 未分配（退等权）")

# 目标口径：per_code_targets > target_equity_ratio/N > target_weight_pct
_probe = None
for c, a, pos in rows:
    if a.get("error"):
        continue
    _probe = position_sizing_recommendation(
        a, pos, total, cfg=POSITION_SIZING_CONFIG, n_holdings=len(codes),
        adaptive=_ADAPTIVE
    )
    break
if _probe:
    print(f"目标口径[{_probe['target_source']}]：本票目标 {_probe['target_weight']}%；"
          f"单票硬上限 {_probe['hard_cap_weight']}%"
          f"（超限只减到上限，不一步砍到目标）")
print()
hdr = (f"{'代码':<8}{'名称':<10}{'数量':>7}{'成本':>8}{'现价':>8}{'市值':>10}"
       f"{'当前%':>8}{'目标%':>7}{'Δ%':>8}{'Δ股数':>8}  动作 / 基本面")
print(hdr)
print("-" * len(hdr))
for c, a, pos in rows:
    if a.get("error"):
        print(f"{c:<8}{'-':<10}{pos['qty']:>7.0f}{pos['cost']:>8.2f}{'ERR':>8}  {a['error']}")
        continue
    close = a["latest"]["close"]
    sizing = position_sizing_recommendation(
        a, pos, total, cfg=POSITION_SIZING_CONFIG, n_holdings=len(codes),
        adaptive=_ADAPTIVE
    )
    fund = "有基本面" if fundamentals_available(a) else "纯技术面"
    act = sizing["action"] + ("(仅到上限)" if sizing.get("capped_trim") else "")
    print(f"{c:<8}{pos['name'] or '-':<10}{pos['qty']:>7.0f}{pos['cost']:>8.2f}{close:>8.2f}"
          f"{close * pos['qty']:>10,.0f}{sizing['current_weight']:>8.2f}{sizing['target_weight']:>7.2f}"
          f"{sizing['delta_weight']:>8.2f}{sizing['delta_qty']:>8d}  {act} / {fund}")
print()
for c, a, pos in rows:
    if a.get("error"):
        continue
    sizing = position_sizing_recommendation(
        a, pos, total, cfg=POSITION_SIZING_CONFIG, n_holdings=len(codes),
        adaptive=_ADAPTIVE
    )
    print(f"  {c}: {sizing['reason']}")
