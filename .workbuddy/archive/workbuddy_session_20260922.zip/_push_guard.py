import subprocess, json, base64, sys

REPO = "benny1232123/Stocks-Master"
BASE = "d7a1cf5de614dc76ae5192f279bb1813cb6a0e2e"  # current remote master tip
FILE_PATH = "smcore/strategy/news_surface.py"
LOCAL = r"E:\Stocks-Master\smcore\strategy\news_surface.py"
LOG = r"E:\Stocks-Master\.workbuddy\_push_guard.log"

def gh(method, path, body=None):
    cmd = ["gh", "api", "-X", method]
    if body is not None:
        cmd += ["--input", "-"]
    cmd += ["repos/%s/%s" % (REPO, path)]
    stdin = json.dumps(body).encode("utf-8") if body is not None else None
    r = subprocess.run(cmd, input=stdin, capture_output=True)
    out = r.stdout.decode("utf-8", "replace")
    err = r.stderr.decode("utf-8", "replace")
    return r.returncode, out, err

lines = []
def log(s):
    lines.append(s)
    print(s)

# 1) base tree sha
rc, out, err = gh("GET", "git/commits/%s" % BASE, None)
if rc != 0:
    log("GET base commit FAILED rc=%d err=%s" % (rc, err[:300])); raise SystemExit(1)
base_tree = json.loads(out)["tree"]["sha"]
log("base_tree=%s" % base_tree)

# 2) create blob
with open(LOCAL, "rb") as f:
    content = f.read()
b64 = base64.b64encode(content).decode("ascii")
rc, out, err = gh("POST", "git/blobs", {"content": b64, "encoding": "base64"})
if rc != 0:
    log("POST blob FAILED rc=%d err=%s" % (rc, err[:300])); raise SystemExit(1)
blob_sha = json.loads(out)["sha"]
log("blob_sha=%s" % blob_sha)

# 3) create tree (replace single file on top of base_tree)
rc, out, err = gh("POST", "git/trees", {
    "base_tree": base_tree,
    "tree": [{"path": FILE_PATH, "mode": "100644", "type": "blob", "sha": blob_sha}],
})
if rc != 0:
    log("POST tree FAILED rc=%d err=%s" % (rc, err[:300])); raise SystemExit(1)
tree_sha = json.loads(out)["sha"]
log("tree_sha=%s" % tree_sha)

# 4) create commit
msg = ("fix(news_surface): 新闻面板强制对齐最新选股日，杜绝日期漂移\n\n"
       "build_news_surface() 现默认以 Daily-Action-List 最新文件日(as_of)为准，"
       "_resolve_file 在指定日后回退到不晚于该日的最新 CCTV 文件，"
       "确保新闻日期始终 == 选股日，绝不展示领先选股日的新闻。")
rc, out, err = gh("POST", "git/commits", {
    "message": msg, "tree": tree_sha, "parents": [BASE],
})
if rc != 0:
    log("POST commit FAILED rc=%d err=%s" % (rc, err[:300])); raise SystemExit(1)
commit_sha = json.loads(out)["sha"]
log("commit_sha=%s" % commit_sha)

# 5) update master ref (fast-forward, non-force since parent == current tip)
rc, out, err = gh("PATCH", "git/refs/heads/master", {"sha": commit_sha, "force": False})
if rc != 0:
    log("PATCH ref FAILED rc=%d err=%s" % (rc, err[:300])); raise SystemExit(1)
log("PUSH OK -> master now at %s" % commit_sha)

with open(LOG, "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")
