# -*- coding: utf-8 -*-
"""A 方案报告：历史回测全量重建（新统一止损口径）+ 顺带定位的「回测 Tab 空」根因。"""
import glob
import json
import re
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
SD = ROOT / "stock_data"
BK = ROOT / ".workbuddy" / "_bt_backup_20260921"
OUT = ROOT / ".workbuddy" / "rebuild_history_20260921.html"


def load_sum(d):
    fs = sorted(glob.glob(str(Path(d) / "Multi-Backtest-*-summary.csv")))
    S = pd.concat([pd.read_csv(f, dtype=str) for f in fs], ignore_index=True) if fs else pd.DataFrame()
    for c in ("total_return", "max_drawdown", "win_rate", "num_trades", "excess_return"):
        if c in S.columns:
            S[c] = pd.to_numeric(S[c], errors="coerce")
    if "date" in S.columns:
        S["date"] = S["date"].astype(str).str[:8]
    return S


def load_tr(d):
    tl = []
    for f in sorted(glob.glob(str(Path(d) / "Multi-Backtest-*-trades.csv"))):
        try:
            t = pd.read_csv(f, dtype=str)
        except Exception:
            continue
        if t.empty or "return_pct" not in t.columns:
            continue
        tl.append(t)
    T = pd.concat(tl, ignore_index=True) if tl else pd.DataFrame()
    if not T.empty:
        T["return_pct"] = pd.to_numeric(T["return_pct"], errors="coerce")
    return T


OS_, NS_ = load_sum(BK), load_sum(SD)
OT, NT = load_tr(BK), load_tr(SD)
o = OS_.set_index("date")["total_return"]
n = NS_.set_index("date")["total_return"]
J = pd.concat([o.rename("old"), n.rename("new")], axis=1)
J["d"] = J["new"] - J["old"]
fs = json.loads((SD / "web_data" / "daily_summary.json").read_text(encoding="utf-8"))
bl = json.loads((SD / "web_data" / "backtests_latest.json").read_text(encoding="utf-8"))


def tbl(head, rows_):
    th = "".join(f"<th>{h}</th>" for h in head)
    tr = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows_)
    return f"<table><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table>"


main_rows = [
    ["批次数", len(OS_), len(NS_)],
    ["组合均收益", f"{OS_[OS_['num_trades']>0]['total_return'].mean():+.3f}%",
     f"{NS_[NS_['num_trades']>0]['total_return'].mean():+.3f}%"],
    ["组合中位", f"{OS_[OS_['num_trades']>0]['total_return'].median():+.3f}%",
     f"{NS_[NS_['num_trades']>0]['total_return'].median():+.3f}%"],
    ["正收益批次", f"{int((OS_[OS_['num_trades']>0]['total_return']>0).sum())}/15",
     f"{int((NS_[NS_['num_trades']>0]['total_return']>0).sum())}/15"],
    ["平均回撤", f"{OS_[OS_['num_trades']>0]['max_drawdown'].mean():+.3f}%",
     f"{NS_[NS_['num_trades']>0]['max_drawdown'].mean():+.3f}%"],
    ["成交记录数", len(OT), len(NT)],
    ["笔均收益", f"{OT['return_pct'].mean():+.3f}%", f"{NT['return_pct'].mean():+.3f}%"],
    ["stop_mode", "（该列当时还不存在）", "dal_boll(2.5σ,[4%,12%]) ×16"],
]

ex_old = OT.groupby("exit_reason")["return_pct"].agg(n="count", mean="mean", total="sum")
ex_new = NT.groupby("exit_reason")["return_pct"].agg(n="count", mean="mean", total="sum")
ex_rows = []
for k in sorted(set(ex_old.index) | set(ex_new.index)):
    a = ex_old.loc[k] if k in ex_old.index else None
    b = ex_new.loc[k] if k in ex_new.index else None
    ex_rows.append([k,
                    f"{int(a['n']) if a is not None else 0} / {a['mean']:+.2f}%" if a is not None else "0 / —",
                    f"{int(a['total']):+.0f}" if a is not None else "0",
                    f"{int(b['n']) if b is not None else 0} / {b['mean']:+.2f}%" if b is not None else "0 / —",
                    f"{int(b['total']):+.0f}" if b is not None else "0"])

batch_rows = [[d, f"{r['old']:+.2f}", f"{r['new']:+.2f}",
               f"{r['d']:+.2f}" if pd.notna(r["d"]) else "—"]
              for d, r in J.iterrows()]

html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>A 方案：历史回测全量重建 2026-09-21</title>
<style>
:root{{--bg:#faf9f6;--card:#fff;--fg:#1c1c1a;--mut:#6b6a65;--bd:#e3e1da;--g:#c0392b;--b:#2e7d32;--w:#8a6d18;}}
@media (prefers-color-scheme:dark){{:root{{--bg:#1b1b19;--card:#232320;--fg:#f0efe9;--mut:#9b9a93;--bd:#3a3a35;--g:#e8695a;--b:#6bbf6f;--w:#d0b055;}}}}
*{{box-sizing:border-box}}
body{{margin:0;padding:32px 20px 64px;background:var(--bg);color:var(--fg);font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;font-size:14px;line-height:1.65}}
.wrap{{max-width:980px;margin:0 auto}}
h1{{font-size:20px;font-weight:500;margin:0 0 4px}}
.sub{{color:var(--mut);font-size:13px;margin-bottom:24px}}
h2{{font-size:15px;font-weight:500;margin:32px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--bd)}}
table{{width:100%;border-collapse:collapse;font-size:13px;background:var(--card);border:1px solid var(--bd);border-radius:10px;overflow:hidden}}
th,td{{padding:7px 10px;text-align:left;border-bottom:1px solid var(--bd)}}
th{{font-weight:500;font-size:12px;color:var(--mut)}}
tr:last-child td{{border-bottom:none}}
td:nth-child(n+2){{font-variant-numeric:tabular-nums;text-align:right}}
.box{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px 18px;margin:12px 0}}
.box.warn{{border-color:var(--w)}}.box.good{{border-color:var(--g)}}
ul{{margin:6px 0 0;padding-left:20px}}li{{margin-bottom:5px}}
code{{font-family:ui-monospace,Consolas,monospace;font-size:12px;background:var(--bg);padding:1px 5px;border-radius:4px;border:1px solid var(--bd)}}
.g{{color:var(--g)}}.b{{color:var(--b)}}
pre{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:12px 14px;overflow:auto;font-size:12px;line-height:1.5}}
</style></head><body><div class="wrap">
<h1>A 方案：历史回测全量重建</h1>
<div class="sub">2026-09-21 · 用统一后的止损口径（透传 DAL · boll 2.5σ/[4%,12%]）重跑全部 16 个信号日 ·
HOLD_DAYS=12（与生产 CI 一致）· 离线本地 k_data · 旧产物已备份到
<code>.workbuddy/_bt_backup_20260921/</code></div>

<h2>一、重建结果对照</h2>
{tbl(["指标", "重建前（8σ / 15%）", "重建后（DAL boll 口径）"], main_rows)}
<div class="box">
逐批次 Δ：均值 <b class="g">+0.137pp</b>、中位 +0.040pp，新更好 <b>10</b> / 更差 <b>5</b> / 相同 1。<br>
方向与之前的专项 A/B 一致（那次 +0.059pp / t=+1.00）：<b>略好但都在噪声内</b>。
<b>这次重建的意义是口径一致，不是收益提升</b> —— 现在清单/网站/监控/回测四者终于用同一个止损。
</div>

<h2>二、出场构成变化（说明内部发生了什么）</h2>
{tbl(["出场原因", "旧 笔数/单笔均值", "旧 总点数", "新 笔数/单笔均值", "新 总点数"], ex_rows)}
<div class="box">
核心变化：更紧的止损把 <code>trend_break</code> 的深亏单提前截住 ——
<code>trend_break</code> 从 56 笔 <b>-2.82%</b> 变成 48 笔 <b>-1.70%</b>（总额 -158 → -82 点）；
代价是 <code>stop_hard</code> 从 5 笔暴涨到 <b>26 笔</b>（-94 → -209 点），
但单笔均值从 <b class="b">-18.78%</b> 收窄到 <b class="g">-8.05%</b>。
两者相抵后总额从 +5 点变成 <b>+22 点</b>。
</div>

<h2>三、逐批次对照（组合 total_return %）</h2>
{tbl(["信号日", "重建前", "重建后", "Δ"], batch_rows)}

<h2>四、网站口径快照已刷新</h2>
<div class="box">
<code>export_web_data.py</code> 重跑后 <code>daily_summary.json</code>：
组合均 <b>{fs['avg_return']}%</b>（原 -0.85%）、中位 {fs['median_return']}%、
胜率 {fs['avg_win_rate']}%、成交 {fs['total_trades']} 笔、笔均 <b>{fs['avg_trade_return']}%</b>、
基准 {fs['benchmark_return']}%、超额 <b>{fs['excess_return']}%</b>、最差日 {fs['worst_day']['date']}（{fs['worst_day']['return']}%）。
</div>

<h2>五、⚠️ 顺带定位到「回测 Tab 首屏空」的双重根因（P2，尚未修）</h2>
<div class="box warn">
<code>backtests_latest.json</code> 重建后仍是空：
<pre>{json.dumps(bl, ensure_ascii=False)}</pre>
读了 <code>backend/main.py::latest_backtest()</code>（L412-427）后两个原因都清楚了：
<ol>
<li><b>端点还在找已退役的产物家族</b>：它搜 <code>Signal-Backtest-*</code> /
<code>Trade-Backtest-*</code> / <code>*-portfolio-summary</code>，而现行管线只产出
<code>Multi-Backtest-*</code>（远端实测这三族 <b>0 个文件</b>，Multi-Backtest 51 个）。</li>
<li><b>快照自我毒化</b>：端点优先返回 <code>backtests_latest.json</code> 快照，
而 <code>export_web_data</code> 把这次「查不到」的空结果也写了进去 →
下次读取直接命中 <code>latest: null</code>，<b>永远返回空，不可能自愈</b>。</li>
</ol>
建议的最小修法（两行级）：① <code>latest_backtest()</code> 把 <code>latest</code> 为空的快照当 miss，
继续走实时路径；② <code>export_web_data.py</code> 在 <code>latest</code> 为空时<b>不写快照</b>，避免写入毒丸。
是否要接着修，等你点头（它会动到 backend 端点行为）。
</div>

<h2>六、注意事项</h2>
<ul>
<li><b>本地产物未入库</b>：按仓库约定（CI 是 stock_data 的唯一写入方、每日 force-push 覆盖），
重建结果只落在本地；远端面板会随 CI 逐日产出新口径批次而逐步对齐，
若要远端也立刻一致，需要在 CI 侧触发历史重跑。</li>
<li><code>scripts/rerun_backtest_history.py</code> 已修掉 <code>HOLD_DAYS</code> 硬编码 10 的分叉
（改 setdefault 12，与 <code>daily-pick.yml</code> 一致），已推送 <code>7cd8567f</code>。</li>
<li>09-17 批次距今天仅 4 天，本轮仍是不完整窗口（与重建前一致，不影响对照）。</li>
</ul>
</div></body></html>"""

OUT.write_text(html, encoding="utf-8")
print("WROTE", OUT)
print("delta mean", round(J["d"].mean(), 3), "n_better", int((J["d"] > 0).sum()),
      "n_worse", int((J["d"] < 0).sum()))
