# -*- coding: utf-8 -*-
"""止损口径定量核对（本地 k_data，零联网）。

系统里同时存在两套「波动率自适应止损」，都基于同一个 vol20，但系数/区间不同：
  A) 回测引擎用：stop = clamp(VOL_STOP_MULT(8.0)  × vol20, 6%, 15%)   ← daily_backtest.py L419-427
  B) 清单/DAL 展示：stop = clamp(stop_pct_vol_mult(2.5) × vol20, 4%, 12%) ← boll_levels.py L76-80
其中 vol20 = 近 20 日**日收益 std（未年化）**（boll_levels.py L66-71）。
本脚本取每笔成交「买入日」当日的 vol20，算两套止损各自的取值与饱和率。
"""
import glob
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_stop_sat_out.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


from smcore.data.kline import read_kline_cache  # noqa: E402

_kc: dict[str, pd.DataFrame] = {}


def closes(code):
    code = str(code).zfill(6)
    if code not in _kc:
        try:
            k = read_kline_cache(code, base_dir=SD / "k_data")
        except Exception:
            k = pd.DataFrame()
        if not k.empty and "date" in k.columns:
            k = k.copy()
            k["date"] = pd.to_datetime(k["date"], errors="coerce")
            k["close"] = pd.to_numeric(k["close"], errors="coerce")
            k = k.dropna(subset=["date", "close"]).sort_values("date").reset_index(drop=True)
        _kc[code] = k
    return _kc[code]


frames = []
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv"))):
    try:
        d = pd.read_csv(f, dtype=str)
    except Exception:
        continue
    if d.empty or "return_pct" not in d.columns:
        continue
    d["_batch"] = re.search(r"(\d{8})", Path(f).name).group(1)
    frames.append(d)
T = pd.concat(frames, ignore_index=True)
T["buy_price"] = pd.to_numeric(T["buy_price"], errors="coerce")

rows = []
for _, r in T.iterrows():
    k = closes(r["code"])
    if k.empty:
        continue
    i = k.index[k["date"] <= pd.Timestamp(r["buy_date"])]
    if len(i) == 0:
        continue
    i = i[-1]
    if i < 21:
        continue
    dret = k.loc[i - 19:i, "close"].pct_change().dropna()
    if len(dret) < 5:
        continue
    sd_d = float(dret.std())
    bt = max(0.06, min(8.0 * sd_d, 0.15))
    bl = max(0.04, min(2.5 * sd_d, 0.12))
    rows.append({"code": r["code"], "_batch": r["_batch"], "sigma_daily": sd_d,
                 "sigma_ann": sd_d * np.sqrt(252), "bt_stop": bt, "boll_stop": bl})

A = pd.DataFrame(rows)
p("=" * 96)
p(f"样本：{len(A)} 笔（买入日当日的 20 日已实现波动）")
p("=" * 96)
p(f"  日 σ  : 中位 {A['sigma_daily'].median()*100:.2f}%  "
  f"p10 {A['sigma_daily'].quantile(.1)*100:.2f}%  p90 {A['sigma_daily'].quantile(.9)*100:.2f}%")
p(f"  年化σ : 中位 {A['sigma_ann'].median()*100:.1f}%  "
  f"p10 {A['sigma_ann'].quantile(.1)*100:.1f}%  p90 {A['sigma_ann'].quantile(.9)*100:.1f}%")
p("")
p("  ── A) 回测引擎止损 = clamp(8.0 × 日σ, 6%, 15%) ──")
p(f"     取值分布: 6%档 {int((A['bt_stop']<=0.0601).sum())}  中间 {int(((A['bt_stop']>0.0601)&(A['bt_stop']<0.1499)).sum())}"
  f"  15%档(饱和) {int((A['bt_stop']>=0.1499).sum())}")
p(f"     ★ 饱和率 = {100*(A['bt_stop']>=0.1499).mean():.1f}%   "
  f"（要求 8×日σ<15% → 日σ<1.875% → 年化<29.8%）")
p(f"     中位数取值 = {100*A['bt_stop'].median():.2f}%")
p("")
p("  ── B) 清单/DAL 展示止损 = clamp(2.5 × 日σ, 4%, 12%) ──")
p(f"     取值分布: 4%档 {int((A['boll_stop']<=0.0401).sum())}  中间 {int(((A['boll_stop']>0.0401)&(A['boll_stop']<0.1199)).sum())}"
  f"  12%档(饱和) {int((A['boll_stop']>=0.1199).sum())}")
p(f"     饱和率 = {100*(A['boll_stop']>=0.1199).mean():.1f}%   中位数取值 = {100*A['boll_stop'].median():.2f}%")
p("")
p(f"  ★ 两套止损不一致的笔数 = {int((A['bt_stop'] != A['boll_stop']).sum())}/{len(A)} "
  f"({100*(A['bt_stop'] != A['boll_stop']).mean():.1f}%)")
p(f"  ★ 平均差值（回测 − 清单）= {100*(A['bt_stop'] - A['boll_stop']).mean():+.2f}pp")
p("")
p("  举例（前 10 笔）：")
p(A.head(10).assign(
    sigma_daily=lambda d: (d["sigma_daily"] * 100).round(2),
    sigma_ann=lambda d: (d["sigma_ann"] * 100).round(1),
    bt_stop=lambda d: (d["bt_stop"] * 100).round(2),
    boll_stop=lambda d: (d["boll_stop"] * 100).round(2),
)[["code", "_batch", "sigma_daily", "sigma_ann", "bt_stop", "boll_stop"]].to_string(index=False))

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
