import os, sys
from pathlib import Path

ROOT = Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
os.environ["SECTOR_MAP_ONDEMAND"] = "0"

import smcore.data.session as _session_mod
import smcore.strategy.fundamental as _fundamental
import smcore.strategy.name_lookup as _name_lookup_mod
import smcore.strategy.sectors as _sectors_mod
import smcore.strategy.regime_filter as _regime_mod
import smcore.strategies.boll as _boll_mod
import smcore.strategies.relativity as _rel_mod
import smcore.strategies.theme as _theme_mod

for _m in (_session_mod, _fundamental, _name_lookup_mod, _sectors_mod,
          _boll_mod, _rel_mod, _theme_mod):
    try:
        _m.login = lambda: False
    except Exception:
        pass

_regime_mod._get_hs300_close = lambda: None

try:
    import baostock as bs

    class _BsLoginOK:
        error_code = "0"
        error_msg = ""

    bs.login = lambda: _BsLoginOK()
except Exception:
    pass

from smcore.strategy.market import compute_market_profile

p = compute_market_profile(as_of="20260827")
print("OK regime=", getattr(p, "regime", None))
