# -*- coding: utf-8 -*-
"""出场审计 ②（定型版）：止损口径、买入定价时点、恒定子样本反事实、跌停顺延验证。"""
import glob
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_exit_audit2_out.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


def safe_read(x):
    try:
        return pd.read_csv(x, dtype=str)
    except Exception:
        return None


# ── 0) 定位 stop_pct / vol20 的定义 ──
p("=" * 100)
p("0) 代码定位：stop_pct 与 vol20 的定义")
p("=" * 100)
for f in ROOT.joinpath("smcore").rglob("*.py"):
    t = f.read_text(encoding="utf-8", errors="ignore")
    for i, ln in enumerate(t.splitlines(), 1):
        if "def _compute_boll_levels" in ln or '"stop_pct"' in ln or "'stop_pct'" in ln:
            rel = f.relative_to(ROOT)
            p(f"  {rel} L{i}: {ln.strip()[:120]}")

# ── 1) vol20 语义 + 止损饱和率 ──
p("")
p("=" * 100)
p("1) 逐只「波动率自适应止损」是否真的在自适应？stop = clamp(8 × vol20, 6%, 15%)")
p("=" * 100)
try:
    from smcore.strategy.position_sizing import _estimate_vol20
    codes = sorted({str(c).zfill(6) for c in
                    pd.concat([safe_read(f) for f in
                               sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv")))
                               if safe_read(f) is not None and not safe_read(f).empty])["code"]})
    vols = _estimate_vol20(codes, window=20)
    arr = []
    for c, v in vols.items():
        if v:
            raw = 8.0 * v
            arr.append((c, v, raw, max(0.06, min(raw, 0.15))))
    A = pd.DataFrame(arr, columns=["code", "vol20", "8*vol20", "stop"])
    p(f"  候选票 {len(A)} 只（vol20 为年化，来自 position_sizing._estimate_vol20）")
    p(f"  vol20 分布: min={A['vol20'].min():.3f} 中位={A['vol20'].median():.3f} "
      f"max={A['vol20'].max():.3f}")
    p(f"  ★ 8×vol20 的分布: min={A['8*vol20'].min():.2f} 中位={A['8*vol20'].median():.2f} "
      f"max={A['8*vol20'].max():.2f}   （要 <0.15 才不触及上限 → 需 vol20 < 1.875%）")
    p(f"  ★ 实际生效止损 = 15% 的票数 = {int((A['stop'] >= 0.1499).sum())}/{len(A)} "
      f"({100*(A['stop'] >= 0.1499).mean():.1f}%)")
    p("  ⇒ 结论：几乎全部饱和到 15% 上限，「逐只波动率自适应」实际退化为固定 15% 止损。")
    p("  ⇒ 量纲诊断：VOL_STOP_MULT=8.0 却在乘**年化**波动率；若要与年化配平，"
      "系数应为 ~0.3-0.5（或先除以 √252）。")
except Exception as exc:
    p("  !! 失败:", type(exc).__name__, exc)

# ── 2) 买入定价时点（修正：对照 buy_date 当日的 open）──
p("")
p("=" * 100)
p("2) buy_price 的定价时点（修正版：对照 k_data）")
p("=" * 100)
from smcore.data.kline import read_kline_cache  # noqa: E402

_kc: dict[str, pd.DataFrame] = {}


def kof(code):
    code = str(code).zfill(6)
    if code not in _kc:
        try:
            k = read_kline_cache(code, base_dir=SD / "k_data")
        except Exception:
            k = pd.DataFrame()
        if not k.empty and "date" in k.columns:
            k = k.copy()
            k["date"] = pd.to_datetime(k["date"], errors="coerce")
            for c in ("open", "high", "low", "close"):
                if c in k.columns:
                    k[c] = pd.to_numeric(k[c], errors="coerce")
            k = k.dropna(subset=["date"]).sort_values("date").reset_index(drop=True)
        _kc[code] = k
    return _kc[code]


frames = []
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv"))):
    d = safe_read(f)
    if d is None or d.empty or "return_pct" not in d.columns:
        continue
    d["_batch"] = re.search(r"(\d{8})", Path(f).name).group(1)
    frames.append(d)
T = pd.concat(frames, ignore_index=True)
for c in ("return_pct", "buy_price", "sell_price", "qty"):
    T[c] = pd.to_numeric(T[c], errors="coerce")

hit_open = hit_close = hit_prevclose = other = 0
ratios = []
for _, r in T.iterrows():
    k = kof(r["code"])
    if k.empty:
        continue
    bd = pd.Timestamp(r["buy_date"])
    idx = k.index[k["date"] == bd]
    if len(idx) == 0:
        prev = k.index[k["date"] <= bd]
        if len(prev) == 0:
            continue
        i = prev[-1]
    else:
        i = idx[0]
    o = k.loc[i, "open"]
    if pd.notna(o) and o:
        ratios.append(r["buy_price"] / o)
        if abs(r["buy_price"] / o - 1) < 0.005:
            hit_open += 1
        elif abs(r["buy_price"] / k.loc[i, "close"] - 1) < 0.005:
            hit_close += 1
        else:
            other += 1
p(f"  ≈buy_date 当日开盘价：{hit_open} 笔   ≈当日收盘价：{hit_close} 笔   都不像：{other} 笔")
if ratios:
    rr = pd.Series(ratios)
    p(f"  buy_price / open 比值：中位 {rr.median():.4f}  p25 {rr.quantile(.25):.4f}  "
      f"p75 {rr.quantile(.75):.4f}")
    p("  ⇒ 若中位≈1.001，即『信号日次日开盘价 + 0.1% 滑点』，与 engine L595 吻合。")

# ── 3) 恒定子样本反事实 ──
p("")
p("=" * 100)
p("3) 恒定子样本的固定持有期反事实（去掉批次窗口偏差）")
p("=" * 100)
try:
    from smcore.strategy.fusion import _get_hs300_close
    hs = _get_hs300_close()
    hs_dates = [d.date() if hasattr(d, "date") else pd.Timestamp(str(d)[:10]).date()
                for d in hs.index]
    hs_idx = pd.Series(list(hs.values), index=hs_dates).sort_index()
    have_hs = True
except Exception as exc:
    p("  !! 沪深300 序列不可用:", type(exc).__name__, exc)
    have_hs = False

HZ = [1, 2, 3, 4, 5, 8, 12]


def fwd(r, H):
    k = kof(r["code"])
    if k.empty:
        return None
    bd = pd.Timestamp(r["buy_date"])
    idx = k.index[k["date"] <= bd]
    if len(idx) == 0:
        return None
    i = idx[-1]
    j = i + H
    if j >= len(k) or pd.isna(k.loc[j, "close"]):
        return None
    ret = (k.loc[j, "close"] / r["buy_price"] - 1) * 100
    bench = None
    if have_hs:
        d0, d1 = k.loc[i, "date"].date(), k.loc[j, "date"].date()
        b0 = hs_idx.asof(d0)
        b1 = hs_idx.asof(d1)
        if pd.notna(b0) and pd.notna(b1) and b0:
            bench = (b1 / b0 - 1) * 100
    return ret, bench


# 恒定子样本：所有 H 都有数据的那些笔
rows = []
for _, r in T.iterrows():
    fwd_all = [fwd(r, h) for h in HZ]
    if all(x is not None for x in fwd_all):
        rows.append({"ret_actual": r["return_pct"],
                     **{f"r{h}": fwd_all[i][0] for i, h in enumerate(HZ)},
                     **{f"b{h}": (fwd_all[i][1] or np.nan) for i, h in enumerate(HZ)}})
C = pd.DataFrame(rows)
p(f"  恒定子样本 n = {len(C)}（这些笔在 H=1..12 全程都有数据，可与实际回测直接对比）")
p(f"  {'口径':<16}{'均值%':>10}{'中位%':>10}{'胜率%':>9}{'标准差':>9}{'超额均值%':>11}")
p(f"  {'实际回测':<16}{C['ret_actual'].mean():>10.2f}{C['ret_actual'].median():>10.2f}"
  f"{100*(C['ret_actual']>0).mean():>9.1f}{C['ret_actual'].std():>9.2f}"
  f"{'      —':>11}")
for h in HZ:
    v = C[f"r{h}"]
    ex = (C[f"r{h}"] - C[f"b{h}"]).mean()
    p(f"  {'固定持有 '+str(h)+' 日':<16}{v.mean():>10.2f}{v.median():>10.2f}"
      f"{100*(v>0).mean():>9.1f}{v.std():>9.2f}{ex:>11.2f}")
p("")
p("  （『超额』= 个股收益 − 同期沪深300 收益，逐笔配对后取均值；能过滤掉市场下跌的影响）")

# ── 4) 跌停顺延验证（002855）──
p("")
p("=" * 100)
p("4) -33.54% 那笔的机制验证：连续跌停导致止损顺延")
p("=" * 100)
tr = T[(T["code"] == "002855") & (T["_batch"] == "20260904")]
if len(tr):
    r = tr.iloc[0]
    buy = r["buy_price"]
    p(f"  {r['code']} 买入 {r['buy_date']} @{buy:.3f}  卖出 {r['sell_date']} "
      f"@{r['sell_price']:.3f}  实际 {r['return_pct']:+.2f}%")
    p(f"  若按 vol 口径止损 15% → 止损价 {buy*0.85:.3f}（-15.0%）")
    p(f"  实际成交价 {r['sell_price']:.3f} ≈ {r['sell_price']/0.999:.3f} / 0.999")
    k = kof("002855")
    ii = k.index[k["date"] >= pd.Timestamp(r["buy_date"])]
    stop_px = buy * 0.85
    p("  逐日路径（看是否钉在最低=跌停→卖不出→顺延）：")
    for i in ii[:8]:
        day = k.loc[i]
        prev = k.loc[i - 1, "close"] if i > 0 else np.nan
        chg = 100 * (day["close"] / prev - 1) if pd.notna(prev) and prev else np.nan
        pinned = abs(day["low"] - day["close"]) < 1e-9
        below = day["low"] <= stop_px
        p(f"    {day['date'].date()} open={day['open']:>7.2f} low={day['low']:>7.2f} "
          f"close={day['close']:>7.2f} 涨跌={chg:>+7.2f}%  "
          f"触及止损={'Y' if below else 'n'}  钉最低(疑似跌停)={'Y' if pinned else 'n'}")
    p(f"  ⇒ 结论：止损价 {stop_px:.2f} 在触及后被「封跌停卖不出」逻辑反复顺延，"
      f"最终在 {r['sell_date']} 以 {r['sell_price']:.2f} 成交 → 实际亏损远超设定的 -15%。")

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
