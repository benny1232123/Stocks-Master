# -*- coding: utf-8 -*-
"""离线补齐 fundamental_cache 的资金面缺口 (turnover / amount_20)。

背景: 299 只部分缓存缺资金面字段 → 网站/日报资金面显示 missing 50。
baostock(10030 端口) 当前被阻断, 而 baostock 与新浪日线同源
(6/6 抽样验证 turnover/amount_20 逐分一致), 故用 akshare 新浪日线离线补齐。

口径 (完全镜像 smcore/strategy/fundamental.py::_fetch_kline_stats_baostock):
  - amount_20 = amount.dropna().tail(20).mean()   (元; 要求 ≥5 有效)
  - turnover   = turnover.iloc[-1] × 100          (sina 为小数, 缓存口径为百分数)

备源 (akshare 失败时, 各字段独立):
  - turnover: 腾讯实时行情 qt.gtimg.cn f[38]
  - amount_20: 本地 k_data/{code}_qfq_full.csv 的 amount 列 (窗口可能滞后, 报告标注)

用法: E:\\Anaconda\\python.exe .workbuddy/fund_fill_offline.py
输出: .workbuddy/fund_fill_offline_report.json {filled, partial, failed, fallback_amt_stale}
"""
import glob
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import akshare as ak  # noqa: E402

K_DATA = "stock_data/k_data"
REPORT = os.path.join(".workbuddy", "fund_fill_offline_report.json")


def sym_of(code6: str) -> str:
    return f"sh{code6}" if code6.startswith(("6", "9")) else f"sz{code6}"


def amt20_from_kdata(code6: str):
    """本地 k_data 兜底: amount 近20日均值(元); 缺文件/列/<5 有效 → None"""
    try:
        import pandas as pd
        df = pd.read_csv(os.path.join(K_DATA, f"{code6}_qfq_full.csv"),
                         encoding="utf-8-sig")
        amt = pd.to_numeric(df["amount"], errors="coerce").dropna()
        today = time.strftime("%Y-%m-%d")
        amt = amt[df["date"].astype(str) < today]  # 排除可能的盘中快照行
        if len(amt) >= 5:
            return float(amt.tail(20).mean())
    except Exception:
        pass
    return None


def turnover_from_tencent(code6: str):
    """腾讯实时换手率(%) f[38]; 失败 → None"""
    try:
        import urllib.request
        req = urllib.request.Request(
            f"https://qt.gtimg.cn/q={sym_of(code6)}",
            headers={"User-Agent": "Mozilla/5.0"})
        body = urllib.request.urlopen(req, timeout=8).read().decode("gbk")
        f = body.split('="')[1].rstrip('";\n').split("~")
        to = f[38].strip()
        if to:
            return float(to)
    except Exception:
        pass
    return None


def targets() -> list[str]:
    out = []
    for f in sorted(glob.glob(os.path.join("stock_data", "fundamental_cache", "*.json"))):
        try:
            d = json.load(open(f, encoding="utf-8"))
        except Exception:
            continue
        if "turnover" not in d or "amount_20" not in d:
            out.append(os.path.basename(f)[:-5])
    return out


def main() -> int:
    codes = targets()
    print(f"待补齐 {len(codes)} 只", flush=True)
    filled, partial, failed, stale = [], [], [], []
    for i, c in enumerate(codes, 1):
        to = amt20 = None
        src = ""
        try:
            df = ak.stock_zh_a_daily(symbol=sym_of(c), adjust="")
            t = df["turnover"].dropna()
            a = pd_to_numeric(df["amount"]).dropna().tail(20)
            if len(t):
                to = float(t.iloc[-1]) * 100
            if len(a) >= 5:
                amt20 = float(a.mean())
            src = "sina"
        except Exception:
            pass
        if amt20 is None:
            v = amt20_from_kdata(c)
            if v is not None:
                amt20, src = v, f"kdata{'+' + src if src else ''}"
                stale.append(c)
        if to is None:
            v = turnover_from_tencent(c)
            if v is not None:
                to, src = v, f"tencent{'+' + src if src else ''}"
        time.sleep(0.15)  # 新浪限速友好

        path = os.path.join("stock_data", "fundamental_cache", f"{c}.json")
        try:
            d = json.load(open(path, encoding="utf-8"))
            if to is not None:
                d["turnover"] = to
            if amt20 is not None:
                d["amount_20"] = amt20
            json.dump(d, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        except Exception as e:
            failed.append([c, f"write:{e!r}"]); continue

        if to is not None and amt20 is not None:
            filled.append(c)
            print(f"[{i}/{len(codes)}] {c} OK({src}) turn={to:.2f} amt20={amt20/1e8:.2f}亿", flush=True)
        elif to is not None or amt20 is not None:
            partial.append([c, src])
            print(f"[{i}/{len(codes)}] {c} PARTIAL({src}) to={to} amt20={amt20}", flush=True)
        else:
            failed.append([c, src or "all-sources-fail"])
            print(f"[{i}/{len(codes)}] {c} FAIL", flush=True)
        if i % 50 == 0:
            print(f"--- 进度 {i}/{len(codes)}  补齐 {len(filled)}  部分 {len(partial)}  失败 {len(failed)} ---", flush=True)

    with open(REPORT, "w", encoding="utf-8") as f:
        json.dump({"total": len(codes), "filled": filled, "partial": partial,
                   "failed": failed, "amount_20_stale(kdata兜底)": stale},
                  f, ensure_ascii=False, indent=1)
    print(f"\n=== 完成: 补齐 {len(filled)}  部分 {len(partial)}  失败 {len(failed)} ===", flush=True)
    print(f"报告: {REPORT}", flush=True)
    return 0 if not failed else 1


def pd_to_numeric(s):
    import pandas as pd
    return pd.to_numeric(s, errors="coerce")


if __name__ == "__main__":
    sys.exit(main())
