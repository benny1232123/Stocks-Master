# -*- coding: utf-8 -*-
"""回测体检 ③：权重是否把仓位押在输家 + 策略数缺口 + _MIN_STRATEGIES（只读）。"""
import glob
import re
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(r"E:\Stocks-Master")
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
OUT = ROOT / ".workbuddy" / "_bt_probe3_out.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


def safe_read(f):
    try:
        return pd.read_csv(f, dtype=str)
    except Exception:
        return None


# ── A) 权重（qty×价）是否押在输家 ──
p("=" * 92)
p("A) 仓位权重 vs 收益：加权口径 是否比 等权口径 差（隔离「权重」的贡献）")
p("=" * 92)
rows = []
for f in sorted(glob.glob(str(SD / "Multi-Backtest-*-trades.csv"))):
    d = safe_read(f)
    if d is None or d.empty or "return_pct" not in d.columns:
        continue
    tag = re.search(r"(\d{8})", Path(f).name).group(1)
    for col in ("return_pct", "qty", "buy_price"):
        if col in d.columns:
            d[col] = pd.to_numeric(d[col], errors="coerce")
    d["_value"] = d["qty"] * d["buy_price"]
    d["_batch"] = tag
    rows.append(d)
T = pd.concat(rows, ignore_index=True)

eq_mean = T["return_pct"].mean()
w_mean = (T["return_pct"] * T["_value"]).sum() / T["_value"].sum()
p(f"  全部 {len(T)} 笔：等权平均 {eq_mean:+.3f}%   市值加权平均 {w_mean:+.3f}%   "
  f"差 {w_mean - eq_mean:+.3f}pp")
p(f"  相关(仓位市值, 收益) = {T['_value'].corr(T['return_pct']):+.4f}")
p("")
p("  逐批次（等权 vs 加权）：")
agg = T.groupby("_batch").apply(
    lambda g: pd.Series({
        "n": len(g),
        "eq": g["return_pct"].mean(),
        "w": (g["return_pct"] * g["_value"]).sum() / g["_value"].sum() if g["_value"].sum() else float("nan"),
    }), include_groups=False)
agg["diff"] = agg["w"] - agg["eq"]
p(agg.round(3).to_string())
p("")
p(f"  加权 - 等权 的均值 = {agg['diff'].mean():+.3f}pp  "
  f"（<0 表示「给的仓位越重、表现越差」= 权重信号反预测）")

# 权重与收益的分组对比
q = T["_value"]
hi, lo = q.quantile(.75), q.quantile(.25)
p(f"  高仓位(>={hi:,.0f}元, n={int((q>=hi).sum())}) 平均收益 "
  f"{T[q >= hi]['return_pct'].mean():+.3f}%")
p(f"  低仓位(<={lo:,.0f}元, n={int((q<=lo).sum())}) 平均收益 "
  f"{T[q <= lo]['return_pct'].mean():+.3f}%")

# ── B) 策略数缺口 ──
p("")
p("=" * 92)
p("B) 策略数缺口：DAL 里实际有几个来源策略？")
p("=" * 92)
from smcore.strategy.factor_types import STRATEGY_ORDER, STRATEGY_LABEL  # noqa: E402

p(f"  STRATEGY_ORDER（活跃菜单）= {list(STRATEGY_ORDER)}  n={len(STRATEGY_ORDER)}")
dals = sorted(glob.glob(str(SD / "Daily-Action-List-*.csv")))
p(f"  DAL 文件 n={len(dals)}")
if dals:
    f = dals[-1]
    d = safe_read(f)
    p(f"  最新 DAL: {Path(f).name}  shape={None if d is None else d.shape}")
    if d is not None:
        p(f"  列: {list(d.columns)}")
        cand = [c for c in d.columns if "strateg" in c.lower() or "策略" in c or "source" in c.lower()]
        p(f"  来源策略列候选: {cand}")
        for c in cand:
            vals = d[c].dropna().astype(str)
            toks = set()
            for v in vals:
                for t in re.split(r"[|,;\s]+", v):
                    t = t.strip()
                    if t:
                        toks.add(t)
            p(f"    {c}: {len(toks)} 个不同 token -> {sorted(toks)[:20]}")

# ── C) _MIN_STRATEGIES ──
p("")
p("=" * 92)
p("C) _MIN_STRATEGIES（backend 的策略完整性筛除阈值）")
p("=" * 92)
bm = (ROOT / "backend" / "main.py").read_text(encoding="utf-8")
for i, ln in enumerate(bm.splitlines(), 1):
    if "_MIN_STRATEGIES" in ln or "def _count_active_strategies" in ln:
        p(f"  backend/main.py L{i}: {ln.strip()[:140]}")
db = (ROOT / "scripts" / "daily_backtest.py").read_text(encoding="utf-8")
for i, ln in enumerate(db.splitlines(), 1):
    if "Stage 0.7" in ln or "MIN_STRATEG" in ln:
        p(f"  daily_backtest.py L{i}: {ln.strip()[:140]}")

OUT.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", OUT)
