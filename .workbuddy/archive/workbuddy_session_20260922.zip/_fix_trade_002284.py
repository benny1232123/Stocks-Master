"""修正 002284 持仓记录：qty 800->900, price 13.53->13.15。

走 TradeRepository.update_by_id（只 PATCH 显式字段，不清空其余列）。
先显式加载仓库 .env（否则 shell 无 SUPABASE_* → fallback 到空的 trades.json）。
"""
import sys, os, pathlib

ROOT = pathlib.Path(r"E:\Stocks-Master")
env_path = ROOT / ".env"
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k, v = k.strip(), v.strip().strip('"').strip("'")
        if k and k not in os.environ:
            os.environ[k] = v
    print("[env] 已加载 .env")
sys.path.insert(0, str(ROOT))

from smcore.storage.trades_repo import get_trade_repository

repo = get_trade_repository()
print("BACKEND:", repo.backend_name)

before = repo.load_all()
print("\n=== BEFORE (%d trades) ===" % len(before))
for t in before:
    print(t)

targets = [t for t in before if str(t.get("code", "")).endswith("002284")]
print("\n002284 records:", targets)

if len(targets) != 1:
    print("!! 预期恰好 1 条 002284 记录，实际 %d 条 —— 中止，不盲改" % len(targets))
    sys.exit(1)

tid = targets[0]["id"]
ok = repo.update_by_id(tid, {"qty": 900, "price": 13.15})
print("\nupdate_by_id(%r, qty=900, price=13.15) -> %s" % (tid, ok))

after = repo.load_all()
print("\n=== AFTER (%d trades) ===" % len(after))
for t in after:
    print(t)

chk = [t for t in after if str(t.get("code", "")).endswith("002284")]
print("\n=== VERIFY ===")
print(chk)
assert chk and chk[0]["qty"] == 900 and abs(chk[0]["price"] - 13.15) < 1e-9, "修正未生效!"
print("OK: 002284 = 900 @ 13.15  ✅")
