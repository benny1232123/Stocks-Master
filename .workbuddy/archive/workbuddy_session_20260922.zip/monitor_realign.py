import subprocess, time, json, datetime, sys

RUNS = {
    "realign_full": "35419554939",
    "r0827_legacy": "35417777015",
}
STATUS_FILE = "E:/Stocks-Master/.workbuddy/_monitor.txt"
TERMINAL = {"completed", "failure", "cancelled", "skipped", "timed_out"}

def gh(args, retries=4):
    """Run gh; on failure, retry (auth can transiently drop in background)."""
    for i in range(retries):
        try:
            p = subprocess.run(["gh"] + args, capture_output=True, text=True, timeout=90)
            if p.returncode == 0:
                return p.stdout
            sys.stderr.write("gh rc=%s err=%s\n" % (p.returncode, p.stderr[:200]))
        except Exception as e:
            sys.stderr.write("gh exc %s\n" % e)
        # try to refresh auth (best-effort, non-interactive may fail silently)
        try:
            subprocess.run(["gh", "auth", "status"], capture_output=True, text=True, timeout=30)
        except Exception:
            pass
        time.sleep(8)
    return None

def view(run):
    out = gh(["run", "view", run, "--json", "status,conclusion,updatedAt,url,name"])
    if not out:
        return None
    try:
        return json.loads(out)
    except Exception:
        return None

start = datetime.datetime.utcnow()
with open(STATUS_FILE, "w", encoding="utf-8") as f:
    f.write("monitor start %s\n" % start.isoformat())

done = {}
for tick in range(240):  # up to ~4h
    now = datetime.datetime.utcnow()
    lines = ["tick %d %s" % (tick, now.isoformat())]
    all_term = True
    for key, run in RUNS.items():
        st = view(run)
        if st is None:
            lines.append("%s: UNKNOWN" % key)
            all_term = False
            continue
        status = st.get("status")
        concl = st.get("conclusion")
        lines.append("%s: %s/%s upd=%s" % (key, status, concl, st.get("updatedAt")))
        if status in TERMINAL:
            done[key] = concl
        else:
            all_term = False
    with open(STATUS_FILE, "a", encoding="utf-8") as f:
        f.write(" | ".join(lines) + "\n")
    if all_term:
        with open(STATUS_FILE, "a", encoding="utf-8") as f:
            f.write("ALL_DONE " + json.dumps(done) + "\n")
        break
    time.sleep(60)
