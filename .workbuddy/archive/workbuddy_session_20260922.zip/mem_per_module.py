"""单模块独立内存成本测量（每模块一个干净子进程）。"""
from __future__ import annotations

import ctypes
import os
import subprocess
import sys
from ctypes import wintypes

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = r"E:\Stocks-Master"

CHILD = r'''
import ctypes, os, sys
from ctypes import wintypes
sys.path.insert(0, r"E:\Stocks-Master")
os.environ.setdefault("KLINE_BACKEND", "akshare")
os.environ.setdefault("RENDER_LITE", "1")
os.environ.setdefault("TDX_ENABLED", "0")
k32 = ctypes.windll.kernel32; psapi = ctypes.windll.psapi
class PMC(ctypes.Structure):
    _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
        ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]
psapi.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(PMC),wintypes.DWORD]
psapi.GetProcessMemoryInfo.restype=wintypes.BOOL
k32.GetCurrentProcess.restype=wintypes.HANDLE
def rss():
    c=PMC(); c.cb=ctypes.sizeof(PMC)
    psapi.GetProcessMemoryInfo(k32.GetCurrentProcess(),ctypes.byref(c),c.cb)
    return c.WorkingSetSize/1024/1024
mod = sys.argv[1]
base = rss()
__import__(mod)
print(f"{mod}|{base:.1f}|{rss():.1f}")
'''

targets = [
    "smcore.artifacts", "smcore.dashboard", "smcore.holdings",
    "smcore.analysis", "smcore.backtest", "smcore.selection",
    "smcore.strategy", "smcore.strategy.fusion", "smcore.strategy.news_surface",
    "backend.main",
]

print(f"{'module':34} {'base':>8} {'after':>8} {'delta':>8}")
for t in targets:
    p = subprocess.run(
        [sys.executable, "-c", CHILD, t],
        capture_output=True, text=True, timeout=300,
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    out = (p.stdout or "").strip().splitlines()
    line = out[-1] if out else ""
    if "|" in line:
        _, b, a = line.split("|")
        print(f"{t:34} {float(b):8.1f} {float(a):8.1f} {float(a)-float(b):8.1f}")
    else:
        print(f"{t:34} FAILED: {(p.stderr or '')[-160:].strip()}")
