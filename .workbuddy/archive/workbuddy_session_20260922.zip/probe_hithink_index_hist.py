"""探针 3：同花顺指数历史K端点参数/范围行为（为何 000300.SH 长区间返回空）。"""
import json
import os
import sys

sys.path.insert(0, r"E:\Stocks-Master")
os.environ.setdefault("HITHINK_FINANCE_API_KEY", "sk-fuyao-5ZAyYPbdnL8A3rjehEj0vgM8Iz-g_-6C")

import requests

KEY = os.environ["HITHINK_FINANCE_API_KEY"]
BASE = "https://fuyao.aicubes.cn"


def probe(thscode, start, end, interval="1d", label=""):
    p = {"thscode": thscode, "interval": interval, "start": start, "end": end}
    try:
        r = requests.get(BASE + "/api/a-share-index/prices/historical", params=p,
                         headers={"X-api-key": KEY}, timeout=30)
        b = r.json()
        d = b.get("data") or {}
        item = d.get("item") or []
        print(f"[{label or thscode}] {start}~{end} code={b.get('code')} msg={b.get('message')} "
              f"data_keys={list(d.keys()) if isinstance(d, dict) else type(d).__name__} item_len={len(item)}")
        if item:
            print("     first:", json.dumps(item[0], ensure_ascii=False))
            print("     last :", json.dumps(item[-1], ensure_ascii=False))
    except Exception as e:
        print(f"[{label or thscode}] {start}~{end} ERROR {e!r}")


# 毫秒戳
import datetime as _dt
SH = _dt.timezone(_dt.timedelta(hours=8))


def ms(s):
    y, m, dd = map(int, s.split("-"))
    return int(_dt.datetime(y, m, dd, tzinfo=SH).timestamp() * 1000)


print("=== 用 6 位代码（无后缀）===")
probe("000300", ms("2026-08-01"), ms("2026-09-12"), label="裸代码")
print("=== 短区间 ===")
probe("000300.SH", ms("2026-08-01"), ms("2026-09-12"), label="短区间")
print("=== 中区间 ===")
probe("000300.SH", ms("2025-01-01"), ms("2026-09-12"), label="中区间")
print("=== 长区间 ===")
probe("000300.SH", ms("2020-01-01"), ms("2026-09-12"), label="长区间")
print("=== 板块指数 thscode ===")
probe("886042.TI", ms("2026-08-01"), ms("2026-09-12"), label="板块指数")
