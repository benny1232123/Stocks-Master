"""经 GitHub Git Database API 把 3 个改动文件推送上 master（fast-forward）。

本地 git 在本会话不可用（shell shim 缺 dirname/cd），改用 gh api：
blob -> tree -> commit -> PATCH ref。仅替换 3 个文件，其余继承 master tip 的 tree。
"""
import base64, json, subprocess, sys

REPO = "benny1232123/Stocks-Master"
FILES = [
    "smcore/config/defaults.py",
    "smcore/analysis.py",
    "scripts/notify_holdings_analysis.py",
]
MSG = (
    "feat(holdings): 持仓日报新增「仓位调整」—— target-current 的 delta 驱动真实加减仓\n\n"
    "- smcore/config/defaults.py: 新增 POSITION_SIZING_CONFIG（目标权重/硬上限/带宽/健康门控/一手/逐票覆盖，全可配）\n"
    "- smcore/analysis.py: 新增 position_sizing_recommendation()，复用 recommendation_from_analysis 健康研判，\n"
    "  按 (target_weight - current_weight) 的 delta + hard_cap + 健康门控产出 加仓/持有偏多/持有观望/减仓偏空/减仓，\n"
    "  返回 current/target/delta 权重、delta 金额、delta 股数(取整到100股)。不改动股票研判语义。\n"
    "- scripts/notify_holdings_analysis.py: 逐只算 sizing 并渲染「仓位调整」区块，与「持仓建议(股票研判)」并列展示。\n"
    "关键安全修正：弱票欠配不再误判加仓（持有偏多）；超单票硬上限强制减仓。\n"
    "自动化推送（Git Database API）。"
)


def gh(method, path, body=None):
    cmd = ["gh", "api", f"repos/{REPO}/{path}", "-X", method]
    if body is not None:
        cmd += ["--input", "-"]
    p = subprocess.run(cmd, input=body, capture_output=True)
    if p.returncode != 0:
        sys.stderr.write(f"[ERR] {method} {path}\n{p.stderr.decode('utf-8','replace')}\n")
        sys.exit(1)
    return json.loads(p.stdout.decode("utf-8"))


def main():
    # 1) master tip + base tree
    ref = gh("GET", "git/refs/heads/master")
    tip = ref["object"]["sha"]
    print("master tip =", tip)
    commit = gh("GET", f"git/commits/{tip}")
    base_tree = commit["tree"]["sha"]

    # 2) blobs
    tree_entries = []
    for path in FILES:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        b64 = base64.b64encode(content.encode("utf-8")).decode("ascii")
        blob = gh("POST", "git/blobs", json.dumps({"content": b64, "encoding": "base64"}).encode("utf-8"))
        tree_entries.append({"path": path, "mode": "100644", "type": "blob", "sha": blob["sha"]})
        print(f"blob {path} -> {blob['sha'][:10]}")

    # 3) tree
    tree = gh("POST", "git/trees", json.dumps({"base_tree": base_tree, "tree": tree_entries}).encode("utf-8"))
    print("tree =", tree["sha"][:10])

    # 4) commit
    new_commit = gh("POST", "git/commits", json.dumps({
        "message": MSG, "tree": tree["sha"], "parents": [tip],
    }).encode("utf-8"))
    print("commit =", new_commit["sha"][:10])

    # 5) fast-forward master
    gh("PATCH", "git/refs/heads/master", json.dumps({"sha": new_commit["sha"], "force": False}).encode("utf-8"))
    print("PUSHED master ->", new_commit["sha"])


if __name__ == "__main__":
    main()
