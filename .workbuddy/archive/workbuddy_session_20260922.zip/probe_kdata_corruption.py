# -*- coding: utf-8 -*-
"""探针：量化 k_data 现有 qfq 序列的失真，及其对策略的实际影响。

已确认现象（000001）：缓存 close(2015-01-05)=0.0426，而 amount/volume=15.96（真实均价），
蕴含 11 年 278 倍涨幅；同花顺同日前复权 close=7.60（对真实均价 factor≈0.48，合理）。

本探针量化两件事：
  A) 全期「隐含总涨幅」两源差异 —— 识别序列是否整体失真；
  B) **滚动 10 交易日收益**的两源差异 —— 这才是策略真正吃的量（hold_days=10）。
     分别看「近 250 交易日」（实盘/近期信号）与「全历史」（回放）两段。
"""
import os
import sys
import time
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
for line in (ROOT / ".env").read_text(encoding="utf-8", errors="ignore").splitlines():
    line = line.strip()
    if line and not line.startswith("#") and "=" in line:
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())

import pandas as pd  # noqa: E402

from smcore.data.kline import list_kline_codes, read_kline_cache  # noqa: E402
from smcore.data import hithink as hk  # noqa: E402

HOLD = 10
out = []


def fetch_chunked(code6, d1: date, d2: date, days: int = 1500) -> pd.DataFrame:
    frames = []
    cur = d1
    while cur <= d2:
        end = min(cur + timedelta(days=days), d2)
        df = hk.fetch_historical_k(code6, cur, end, "qfq")
        if df is not None and not df.empty:
            frames.append(df)
        cur = end + timedelta(days=1)
    if not frames:
        return pd.DataFrame()
    a = pd.concat(frames, ignore_index=True)
    return a.drop_duplicates(subset=["date"]).sort_values("date").reset_index(drop=True)


codes = list_kline_codes()
step = max(1, len(codes) // 40)
sample = codes[::step][:40]
out.append(f"sample={len(sample)} of {len(codes)}  hold={HOLD}")

rec_a, rec_hist, rec_recent = [], [], []
t0 = time.time()
for c in sample:
    try:
        cached = read_kline_cache(c)
        if cached.empty or len(cached) < 260:
            continue
        cached["date"] = cached["date"].astype(str)
        d1 = date.fromisoformat(str(cached["date"].min()))
        d2 = date.fromisoformat(str(cached["date"].max()))
        h = fetch_chunked(c, d1, d2)
        if h.empty:
            continue
        h["date"] = h["date"].astype(str)
        m = cached[["date", "close"]].merge(h[["date", "close"]], on="date", suffixes=("_c", "_h"))
        if len(m) < 260:
            continue
        m = m.sort_values("date").reset_index(drop=True)
        # A) 全期隐含涨幅
        r_c = float(m["close_c"].iloc[-1]) / float(m["close_c"].iloc[0]) - 1.0
        r_h = float(m["close_h"].iloc[-1]) / float(m["close_h"].iloc[0]) - 1.0
        rec_a.append((c, r_c, r_h))
        # B) 滚动 HOLD 日收益差
        rc = m["close_c"].pct_change(HOLD)
        rh = m["close_h"].pct_change(HOLD)
        d = (rc - rh).abs().dropna()
        if not d.empty:
            rec_hist.append((c, float(d.median()), float(d.max())))
            rec_recent.append((c, float(d.tail(250).median()), float(d.tail(250).max())))
    except Exception as e:  # noqa: BLE001
        out.append(f"  {c} ERR {e!r}")

el = time.time() - t0
out.append(f"usable={len(rec_a)}  elapsed={el:.1f}s")


def stat(name, vals):
    if not vals:
        out.append(f"{name}: 无样本")
        return
    v = sorted(vals)
    out.append(f"{name}: p50={v[len(v)//2]:.4e} p90={v[int(len(v)*0.9)]:.4e} max={v[-1]:.4e}")


out.append("--- A) 全期隐含总涨幅 两源差异 ---")
stat("  |cache_ret - hithink_ret|", [abs(a - b) for _, a, b in rec_a])
out.append("  样本（前 8 只）: cache_ret  vs  hithink_ret")
for c, a, b in rec_a[:8]:
    out.append(f"    {c}  cache={a*100:9.1f}%   hithink={b*100:8.1f}%")

out.append(f"--- B) 滚动 {HOLD} 日收益 |差| · 全历史 ---")
stat("  median", [x[1] for x in rec_hist])
stat("  max", [x[2] for x in rec_hist])
n_bad = sum(1 for x in rec_hist if x[2] > 0.005)
out.append(f"  单票最大差 > 0.5% 的票数 = {n_bad}/{len(rec_hist)}")

out.append(f"--- B) 滚动 {HOLD} 日收益 |差| · 近 250 交易日 ---")
stat("  median", [x[1] for x in rec_recent])
stat("  max", [x[2] for x in rec_recent])
n_bad2 = sum(1 for x in rec_recent if x[2] > 0.005)
out.append(f"  单票最大差 > 0.5% 的票数 = {n_bad2}/{len(rec_recent)}")
out.append("  近 250 日最大差 top 8:")
for c, md, mx in sorted(rec_recent, key=lambda x: -x[2])[:8]:
    out.append(f"    {c}  max={mx:.4e} median={md:.4e}")

txt = "\n".join(out)
(ROOT / ".workbuddy" / "probe_kdata_corruption.txt").write_text(txt, encoding="utf-8")
print(txt)
