# -*- coding: utf-8 -*-
import pathlib
import re

ROOT = pathlib.Path(r"E:\Stocks-Master")
pats = re.compile(r"VOL_STOP_MULT|VOL_SCALED_STOP|VOL_POS_SCALE|vol_mode|stop_pct|scaled_stop|stop_loss_pct")
out = []
dirs = ["smcore", "scripts", "backend", "tests", "frontend/src"]
files = []
for d in dirs:
    base = ROOT / d
    if base.is_dir():
        files += [p for p in base.rglob("*") if p.suffix in (".py", ".js", ".jsx", ".ts", ".tsx")]
for p in files:
    try:
        t = p.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        continue
    for i, ln in enumerate(t.splitlines(), 1):
        if pats.search(ln):
            rel = str(p.relative_to(ROOT))
            out.append(f"{rel}:{i}: {ln.strip()[:118]}")
(ROOT / ".workbuddy" / "_stoprefs.txt").write_text("\n".join(out), encoding="utf-8")
print("hits", len(out))
