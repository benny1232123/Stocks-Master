# -*- coding: utf-8 -*-
"""A 方案：用新统一止损口径**全量重建**本地历史 Multi-Backtest 产物。

- 离线：把 fetch_daily_k 打成纯本地 k_data（4 个按名导入的模块都要打），
  避免 TDX/akshare 在沙箱里随机卡死，且保证可复现。
- 先备份现有产物到 .workbuddy/_bt_backup_20260921/，再复用
  scripts/rerun_backtest_history.py（它负责删除旧产物 + runpy 跑 daily_backtest）。
- 环境与生产 CI 对齐：HOLD_DAYS=12（daily-pick.yml 同值）、LOOKBACK_DAYS=200。
"""
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(r"E:\Stocks-Master")
os.environ["SECTOR_MAP_ONDEMAND"] = "0"      # 必须在 import smcore 之前
sys.path.insert(0, str(ROOT))
SD = ROOT / "stock_data"
BK = ROOT / ".workbuddy" / "_bt_backup_20260921"
LOG = ROOT / ".workbuddy" / "_rebuild_out.txt"
lines: list[str] = []


def p(*a):
    s = " ".join(str(x) for x in a)
    lines.append(s)
    print(s)


# ── 1) 备份 ──
BK.mkdir(parents=True, exist_ok=True)
old = sorted(SD.glob("Multi-Backtest-*.csv"))
for f in old:
    shutil.copy2(f, BK / f.name)
p(f"[备份] {len(old)} 个产物 → {BK}")
for extra in ("backtest_status.txt",):
    src = SD / extra
    if src.exists():
        shutil.copy2(src, BK / f"{extra}.bak")
        p(f"[备份] {extra}")

# ── 2) 离线化 fetch_daily_k ──
import importlib  # noqa: E402

kl = importlib.import_module("smcore.data.kline")


def _local_fetch(code, start=None, end=None, *a, **k):
    import pandas as pd
    try:
        d = kl.read_kline_cache(str(code).zfill(6), base_dir=SD / "k_data")
    except Exception:
        d = None
    if d is None or getattr(d, "empty", True) or "date" not in getattr(d, "columns", []):
        return pd.DataFrame()
    d = d.copy()
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d = d.dropna(subset=["date"])
    if start is not None:
        d = d[d["date"] >= pd.Timestamp(start)]
    if end is not None:
        d = d[d["date"] <= pd.Timestamp(end)]
    return d.sort_values("date").reset_index(drop=True)


patched = []
for mname in ("smcore.data.kline", "smcore.backtest.engine",
              "smcore.strategy.boll_levels", "smcore.strategy.factor_scoring"):
    try:
        m = importlib.import_module(mname)
        if hasattr(m, "fetch_daily_k"):
            m.fetch_daily_k = _local_fetch
            patched.append(mname)
    except Exception as exc:
        p(f"  [warn] patch {mname} 失败: {exc}")
p("[离线] fetch_daily_k 已替换:", patched)

# ── 3) 环境与生产对齐 ──
os.environ["HOLD_DAYS"] = "12"
os.environ["LOOKBACK_DAYS"] = "200"
os.environ["BACKTEST_MIN_STRATEGIES"] = "2"
os.environ["PREPULL_INTERVAL"] = "0.01"
os.environ["BACKTEST_INLINE_FILTER"] = "1"
os.environ.pop("BACKTEST_STOP_SOURCE", None)   # 走新默认 dal
p(f"[环境] HOLD_DAYS={os.environ['HOLD_DAYS']} LOOKBACK_DAYS={os.environ['LOOKBACK_DAYS']} "
  f"BACKTEST_STOP_SOURCE={os.environ.get('BACKTEST_STOP_SOURCE', '(default=dal)')}")

# ── 4) 跑失败也要先落日志 ──
try:
    import runpy  # noqa: E402

    runpy.run_path(str(ROOT / "scripts" / "rerun_backtest_history.py"), run_name="__main__")
    p("[完成] runpy 正常返回")
except SystemExit as exc:
    p(f"[完成] runpy SystemExit({exc.code})")
except BaseException as exc:
    import traceback
    p(f"[失败] {type(exc).__name__}: {exc}")
    p(traceback.format_exc())
finally:
    LOG.write_text("\n".join(lines), encoding="utf-8")

new = sorted(SD.glob("Multi-Backtest-*.csv"))
p("")
p(f"[结果] 新产物 {len(new)} 个（旧 {len(old)} 个）")
LOG.write_text("\n".join(lines), encoding="utf-8")
print("WROTE", LOG)
